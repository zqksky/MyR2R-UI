﻿using MetroFramework.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestSkin
{
    public partial class frmMetroframework : MetroForm
    {
        public frmMetroframework()
        {
            InitializeComponent();
        }

        private void frmMetroframework_Load(object sender, EventArgs e)
        {
            #region 
            this.StyleManager = metroStyleManager1;
            this.StyleManager.Style = MetroFramework.MetroColorStyle.Blue;
            this.StyleManager.Style = MetroFramework.MetroColorStyle.Black;
            #endregion
        }
    }
}

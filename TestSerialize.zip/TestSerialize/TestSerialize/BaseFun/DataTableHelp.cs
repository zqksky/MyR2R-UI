﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestSerialize.BaseFun
{
    class DataTableHelp
    {
        public static DataTable CreateTable(List<string> strListColumn,List<List<string>> listStrValue)
        {
            DataTable db = new DataTable("db");

            foreach (var str in strListColumn)
            {
                db.Columns.Add(str, Type.GetType("System.String"));
            }

            for (int n = 0; n < listStrValue.Count; n++)
            {
                db.Rows.Add();
                for (int i = 0; i < strListColumn.Count; i++)
                {
                    db.Rows[n][i] = listStrValue[n][i];
                }
            }

            return db;
        }

        #region
        public static List<string> GetColumn()
        {
            List<string> strListColumn = new List<string>() { "ID","Key1", "Key2", "Modify_By_User", "Modify_By_Time", "Operation", "Status", "StrXml" };
            return strListColumn;
        }

        public static List<List<string>> GetValue()
        {
            List<string> strListValue = new List<string>() { "1", "Key1", "Key2", "admin", "2019-04-17", "Create", "New", "StrXml" };
            List<string> strListValue2 = new List<string>() { "2", "Key1", "Key2", "admin", "2019-04-17", "Modify", "New", "StrXml" };
            List<string> strListValue3 = new List<string>() { "3", "Key1", "Key2", "admin", "2019-04-17", "Deleted", "New", "StrXml" };
            List<string> strListValue4 = new List<string>() { "4", "Key1", "Key2", "user", "2019-04-17", "Create", "New", "StrXml" };
            List<string> strListValue5 = new List<string>() { "5", "Key1", "Key2", "user", "2019-04-17", "Modify", "New", "StrXml" };

            List<List<string>> listStrValue = new List<List<string>>() { strListValue, strListValue2, strListValue3, strListValue4, strListValue5 };

            return listStrValue;
        }
        #endregion

        #region old
        //public static List<string> GetColumn(int tbFlag)
        //{
        //    List<string> strListColumn = new List<string>();
        //    if (tbFlag == 1)
        //    {
        //        strListColumn = new List<string>() { "Key1", "Key2", "Modify_By_User", "Modify_By_Time", "Operation", "Status", "StrXml" };
        //    }
        //    else if (tbFlag == 2)
        //    {
        //        strListColumn = new List<string>() { "Key1", "Key2", "Modify_By_User", "Modify_By_Time", "Operation", "Status", "StrXml" };
        //    }
        //    return strListColumn;
        //}

        //public static List<List<string>> GetValue(int tbFlag)
        //{
        //    List<List<string>> listStrValue = new List<List<string>>();
        //    List<string> strListValue = new List<string>();
        //    List<string> strListValue2 = new List<string>();
        //    List<string> strListValue3 = new List<string>();
        //    List<string> strListValue4 = new List<string>();
        //    List<string> strListValue5 = new List<string>();
        //    if (tbFlag == 1)
        //    {
        //        strListValue = new List<string>() { "Key1", "Key2", "admin", "2019-04-17", "Create", "New", "StrXml" };
        //        strListValue2 = new List<string>() { "Key1", "Key2", "admin", "2019-04-17", "Modify", "New", "StrXml" };
        //        strListValue3 = new List<string>() { "Key1", "Key2", "admin", "2019-04-17", "Deleted", "New", "StrXml" };
        //        strListValue4 = new List<string>() { "Key1", "Key2", "user", "2019-04-17", "Create", "New", "StrXml" };
        //        strListValue5 = new List<string>() { "Key1", "Key2", "user", "2019-04-17", "Modify", "New", "StrXml" };
        //    }
        //    else if (tbFlag == 2)
        //    {
        //        strListValue = new List<string>() { "Key1", "Key2", "tt", "2019-04-17", "New", "StrXml" };
        //        strListValue2 = new List<string>() { "Key1", "Key2", "tt", "2019-04-17", "Approving", "StrXml" };
        //        strListValue3 = new List<string>() { "Key1", "Key2", "tt", "2019-04-17", "Rejected", "StrXml" };
        //        strListValue4 = new List<string>() { "Key1", "Key2", "tt", "2019-04-17", "Approved", "StrXml" };
        //    }


        //    listStrValue = new List<List<string>>() { strListValue, strListValue2, strListValue3, strListValue4, strListValue5 };
        //    return listStrValue;
        //}
        #endregion
    }
}

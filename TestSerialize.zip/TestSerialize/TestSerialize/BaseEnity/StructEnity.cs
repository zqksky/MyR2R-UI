﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace TestSerialize.BaseEnity
{
    [Serializable]
    [XmlRootAttribute("EnitySerialize")]
    public class EnitySerialize
    {
        #region old
        //private string _key1;
        //[XmlElement("Key1")]
        //public string Key1
        //{
        //    get { return _key1; }
        //    set { _key1 = value; }
        //}

        //private string _key2;
        //[XmlElement("Key2")]
        //public string Key2
        //{
        //    get { return _key2; }
        //    set { _key2 = value; }
        //}

        //private string _key3;
        //[XmlElement("Key3")]
        //public string Key3
        //{
        //    get { return _key3; }
        //    set { _key3 = value; }
        //}

        //private string _key4;
        //[XmlElement("Key4")]
        //public string Key4
        //{
        //    get { return _key4; }
        //    set { _key4 = value; }
        //}

        //private string _version;
        //[XmlElement("Version")]
        //public string Version
        //{
        //    get { return _version; }
        //    set { _version = value; }
        //}

        //private string _versionOld;
        //[XmlElement("VersionOld")]
        //public string VersionOld
        //{
        //    get { return _versionOld; }
        //    set { _versionOld = value; }
        //}

        //private string _user;
        //[XmlElement("User")]
        //public string User
        //{
        //    get { return _user; }
        //    set { _user = value; }
        //}

        //private string _dateTime;
        //[XmlElement("DateTime")]
        //public string DateTime
        //{
        //    get { return _dateTime; }
        //    set { _dateTime = value; }
        //}

        //private List<StructEnity> _structEnitySerialize;
        //[XmlElement("StructEnitySerialize")]
        //public List<StructEnity> StructEnitySerialize
        //{
        //    get { return _structEnitySerialize; }
        //    set { _structEnitySerialize = value; }
        //}
        #endregion

        #region
        private StructEnity _structEnitySerialize;
        [XmlElement("StructEnitySerialize")]
        public StructEnity StructEnitySerialize
        {
            get { return _structEnitySerialize; }
            set { _structEnitySerialize = value; }
        }
        #endregion
    }

    public struct StructEnity
    {
        #region old
        //private string _stateId;
        //[XmlElement("StateId")]
        //public string StateId
        //{
        //    get { return _stateId; }
        //    set { _stateId = value; }
        //}
        #endregion

        #region
        private List<StructTable> _tables;
        [XmlElement("Tables")]
        public List<StructTable> Tables
        {
            get { return _tables; }
            set { _tables = value; }
        }
        #endregion
    };

    public struct StructTable
    {
        #region
        private string _tableName;
        [XmlElement("TableName")]
        public string TableName
        {
            get { return _tableName; }
            set { _tableName = value; }
        }

        private List<StructColumns> _rows;
        [XmlElement("Rows")]
        public List<StructColumns> Rows
        {
            get { return _rows; }
            set { _rows = value; }
        }
        #endregion
    };

    public struct StructColumns
    {
        #region
        private List<StructColumn> _columnsOld;
        [XmlElement("ColumnsOld")]
        public List<StructColumn> ColumnsOld
        {
            get { return _columnsOld; }
            set { _columnsOld = value; }
        }

        private List<StructColumn> _columnsNew;
        [XmlElement("ColumnsNew")]
        public List<StructColumn> ColumnsNew
        {
            get { return _columnsNew; }
            set { _columnsNew = value; }
        }
        #endregion
    };

    public struct StructColumn
    {
        #region
        private string _colName;
        [XmlElement("ColName")]
        public string ColName
        {
            get { return _colName; }
            set { _colName = value; }
        }

        private string _colValue;
        [XmlElement("ColValue")]
        public string ColValue
        {
            get { return _colValue; }
            set { _colValue = value; }
        }
        #endregion
    };
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestSerialize.BaseFun;

namespace TestSerialize.BaseEnity
{
    class GetXmlHelp
    {
        public static EnitySerialize InitData()
        {
            EnitySerialize myData = new EnitySerialize();

            StructColumn myColumnOld11 = new StructColumn();
            myColumnOld11.ColName = "col11";
            myColumnOld11.ColValue = "null";
            StructColumn myColumnOld12 = new StructColumn();
            myColumnOld12.ColName = "col12";
            myColumnOld12.ColValue = "null";
            StructColumn myColumnOld13 = new StructColumn();
            myColumnOld13.ColName = "col13";
            myColumnOld13.ColValue = "null";
            StructColumn myColumnOld14 = new StructColumn();
            myColumnOld14.ColName = "col14";
            myColumnOld14.ColValue = "null";

            StructColumn myColumn11 = new StructColumn();
            myColumn11.ColName = "col11";
            myColumn11.ColValue = "11";
            StructColumn myColumn12 = new StructColumn();
            myColumn12.ColName = "col12";
            myColumn12.ColValue = "12";
            StructColumn myColumn13 = new StructColumn();
            myColumn13.ColName = "col13";
            myColumn13.ColValue = "13";
            StructColumn myColumn14 = new StructColumn();
            myColumn14.ColName = "col14";
            myColumn14.ColValue = "14";

            StructColumn myColumnNew11 = new StructColumn();
            myColumnNew11.ColName = "col11";
            myColumnNew11.ColValue = "110";
            StructColumn myColumnNew12 = new StructColumn();
            myColumnNew12.ColName = "col12";
            myColumnNew12.ColValue = "120";
            StructColumn myColumnNew13 = new StructColumn();
            myColumnNew13.ColName = "col13";
            myColumnNew13.ColValue = "130";
            StructColumn myColumnNew14 = new StructColumn();
            myColumnNew14.ColName = "col14";
            myColumnNew14.ColValue = "140";

            StructColumns myRow1 = new StructColumns();
            myRow1.ColumnsOld = new List<StructColumn>() { myColumnOld11, myColumnOld12, myColumnOld13, myColumnOld14 };
            myRow1.ColumnsNew = new List<StructColumn>() { myColumn11, myColumn12, myColumn13, myColumn14 };

            StructColumns myRow2 = new StructColumns();
            myRow2.ColumnsOld = new List<StructColumn>() { myColumn11, myColumn12, myColumn13, myColumn14 };
            myRow2.ColumnsNew = new List<StructColumn>() { myColumnNew11, myColumnNew12, myColumnNew12, myColumnNew12 };

            StructTable structTable1 = new StructTable();
            structTable1.TableName = "TabName1";
            structTable1.Rows = new List<StructColumns>() { myRow1, myRow2 };

            StructTable structTable2 = new StructTable();
            structTable2.TableName = "TabName2";
            structTable2.Rows = new List<StructColumns>() { myRow1, myRow2 };

            StructTable structTable3 = new StructTable();
            structTable3.TableName = "TabName3";
            structTable3.Rows = new List<StructColumns>() { myRow1, myRow2 };

            StructTable structTable4 = new StructTable();
            structTable4.TableName = "TabName4";
            structTable4.Rows = new List<StructColumns>() { myRow1, myRow2 };

            StructEnity myStruct = new StructEnity();
            myStruct.Tables = new List<StructTable>() { structTable1, structTable2, structTable3, structTable4 };

            StructEnity myStruct2 = new StructEnity();
            myStruct2.Tables = new List<StructTable>() { structTable4, structTable3, structTable2, structTable1 };

            StructEnity myStruct3 = new StructEnity();
            myStruct3.Tables = new List<StructTable>() { structTable2, structTable4, structTable1, structTable3 };

            myData.StructEnitySerialize = myStruct;

            return myData;
        }

        public static string GetXmlSerialize()
        {
            EnitySerialize structData = InitData();

            string xml = XmlSerializeHelp.Serializer(typeof(EnitySerialize), structData);
            return xml;
        }


        public static EnitySerialize GetStruct(string strXml)
        {
            EnitySerialize myStruct = new EnitySerialize();
            myStruct = XmlSerializeHelp.Deserialize(typeof(EnitySerialize), strXml) as EnitySerialize;
            return myStruct;
        }

        public static string GetXmlSerialize(EnitySerialize structData)
        {
            string xml = XmlSerializeHelp.Serializer(typeof(EnitySerialize), structData);
            return xml;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TestSerialize.BaseEnity;
using TestSerialize.BaseFun;

namespace TestSerialize
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SqliteHelp sqlite;
        private void Form1_Load(object sender, EventArgs e)
        {
            sqlite = new SqliteHelp("data source=TemporyRecord.db");
            CreateTemporyDb();
            string strXml = GetXmlHelp.GetXmlSerialize();

            EnitySerialize myStruct = new EnitySerialize();
            myStruct = GetXmlHelp.GetStruct(strXml);

            ShowDgvShowUI();
            ShowTableToDgv(dgvOperationRecord, "OperationRecord");
            ShowTableToDgv(dgvPreAction, "PreActionRecord");
            ShowTableToDgv(dgvAction, "ActionRecord");
            ShowTableToDgv(dgvFinal, "FinalRecord");
        }

        private void CreateTemporyDb()
        {
            //创建名为OperationRecord的数据表
            sqlite.CreateTable("OperationRecord", new string[] { "ID","Key1", "Key2", "Modify_By_User", "Modify_Time", "Operation", "Status", "StrXml" }, new string[] { "TEXT", "TEXT", "TEXT", "TEXT", "TEXT", "TEXT", "TEXT", "TEXT" });
            sqlite.CreateTable("PreActionRecord", new string[] { "ID","Key1", "Key2", "Modify_By_User", "Modify_Time", "Operation", "Status", "StrXml" }, new string[] { "TEXT", "TEXT", "TEXT", "TEXT", "TEXT", "TEXT", "TEXT", "TEXT" });
            sqlite.CreateTable("ActionRecord", new string[] { "ID", "Key1", "Key2", "Modify_By_User", "Modify_Time", "Operation", "Status", "StrXml" }, new string[] { "TEXT", "TEXT", "TEXT", "TEXT", "TEXT", "TEXT", "TEXT", "TEXT" });
            //sqlite.CreateTable("FinalRecord", new string[] { "ID", "Key1", "Key2", "Modify_By_User", "Modify_Time", "Operation", "Status", "StrXml" }, new string[] { "TEXT", "TEXT", "TEXT", "TEXT", "TEXT", "TEXT", "TEXT", "TEXT" });
            sqlite.CreateTable("FinalRecord", new string[] { "ID", "KEY", "KEY2", "KEY3", "VALUE", "VALUE2", "VALUE3" }, new string[] { "TEXT", "TEXT", "TEXT", "TEXT", "TEXT", "TEXT", "TEXT" });

            #region
            ////插入数据
            //sqlite.InsertValues("OperationRecord", new string[] { "1", "Key1", "Key2", "admin", "2019-04-17", "Insert", "New", "StrXml" });
            //sqlite.InsertValues("OperationRecord", new string[] { "2", "Key1", "Key2", "admin", "2019-04-17", "Modify", "New", "StrXml" });
            //sqlite.InsertValues("OperationRecord", new string[] { "3", "Key1", "Key2", "admin", "2019-04-17", "Deleted", "New", "StrXml" });
            //sqlite.InsertValues("OperationRecord", new string[] { "4", "Key1", "Key2", "user", "2019-04-17", "Insert", "New", "StrXml" });
            //sqlite.InsertValues("OperationRecord", new string[] { "5", "Key1", "Key2", "user", "2019-04-17", "Modify", "New", "StrXml" });

            ////更新数据，将Name="Zhang3"的记录中的Name改为"lisi"
            //sql.UpdateValues("table1", new string[] { "Name" }, new string[] { "lisi" }, "Name", "Zhang3");

            ////删除Name="张三"且Age=26的记录,DeleteValuesOR方法类似
            //sql.DeleteValuesAND("table1", new string[] { "Name", "Age" }, new string[] { "张三", "26" }, new string[] { "=", "=" });

            ////读取整张表
            //SQLiteDataReader reader = sql.ReadFullTable("table1");
            //while (reader.Read())
            //{
            //    //读取ID
            //    Log("" + reader.GetInt32(reader.GetOrdinal("ID")));
            //    //读取Name
            //    Log("" + reader.GetString(reader.GetOrdinal("Name")));
            //    //读取Age
            //    Log("" + reader.GetInt32(reader.GetOrdinal("Age")));
            //    //读取Email
            //    Log(reader.GetString(reader.GetOrdinal("Email")));
            //}

            //while (true)
            //{
            //    Console.ReadLine();
            //}
            #endregion
        }

        private void DataTableToDgv(DataGridView dgv,DataTable dt)
        {
            dgv.Columns.Clear();//清空列 
            foreach (DataColumn column in dt.Columns)
            {
                //为datagridview添加列，第一个参数是列名，第二个参数是列标题 
                dgv.Columns.Add(column.ColumnName, column.ColumnName);
            }

            dgv.Rows.Clear();//清空行 
            foreach (DataRow line in dt.Rows)
            {
                //因为列已经一致了，所以直接将datatable的行转成数组就可以添加到datagridview中了 
                dgv.Rows.Add(line.ItemArray);
            }
        }

        private void ShowDgvShowUI()
        {
            DataTable dbShowUI = new DataTable("ShowUI");

            dbShowUI = sqlite.GetTable("FinalRecord");

            //dbRecord = DataTableHelp.CreateTable(DataTableHelp.GetColumn(), DataTableHelp.GetValue());
            //dgvShowUI.DataSource = dbShowUI;

            DataTableToDgv(dgvShowUI, dbShowUI);
        }

        private void ShowTableToDgv(DataGridView dgv, string strTbName)
        {
            DataTable db = new DataTable("db");

            db = sqlite.GetTable(strTbName);

            dgv.DataSource = db;

            dgv.CurrentCell = dgv.Rows[dgv.Rows.Count - 1].Cells[0];
        }

        private void btnCommit_Click(object sender, EventArgs e)
        {
            if (dgvOperationRecord.CurrentRow.Index >= 0)
            {
                ShowDgvPreAction();
                ShowDgvAction();
            }
        }

        private List<string> GetSelectedRow(ref string strStatus, DataGridView dgv)
        {
            strStatus = string.Empty;

            List<string> strList = new List<string>();
            if (dgv.CurrentRow == null)
            {
                return strList;
            }
            else
            {
                #region
                DataGridViewRow dgvr = dgv.CurrentRow;
                strStatus = dgvr.Cells["Status"].Value.ToString();

                strList.Add(dgvr.Cells["ID"].Value.ToString());
                strList.Add(dgvr.Cells["Key1"].Value.ToString());
                strList.Add(dgvr.Cells["Key2"].Value.ToString());
                strList.Add(dgvr.Cells["Modify_By_User"].Value.ToString());
                strList.Add(dgvr.Cells["Modify_Time"].Value.ToString());
                strList.Add(dgvr.Cells["Operation"].Value.ToString());
                strList.Add(dgvr.Cells["Status"].Value.ToString());
                strList.Add(dgvr.Cells["StrXml"].Value.ToString());
                #endregion
            }

            return strList;
        }

        private List<string> GetSelectedDgvShowUIRow(DataGridView dgv)
        {
            List<string> strList = new List<string>();
            if (dgv.CurrentRow == null)
            {
                return strList;
            }
            else
            {
                #region
                DataGridViewRow dgvr = dgv.CurrentRow;
                strList.Add(dgvr.Cells["ID"].Value.ToString());
                strList.Add(dgvr.Cells["KEY"].Value.ToString());
                strList.Add(dgvr.Cells["KEY2"].Value.ToString());
                strList.Add(dgvr.Cells["KEY3"].Value.ToString());
                strList.Add(dgvr.Cells["VALUE"].Value.ToString());
                strList.Add(dgvr.Cells["VALUE2"].Value.ToString());
                strList.Add(dgvr.Cells["VALUE3"].Value.ToString());
                #endregion
            }

            return strList;
        }

        private void DeleteSelecteRow()
        {
            if (dgvOperationRecord.CurrentRow == null)
            {

            }
            else
            {
                DataGridViewRow dgvr = dgvOperationRecord.CurrentRow;
                string strId = dgvr.Cells["ID"].Value.ToString();

                //ID=strId的记录,DeleteValuesOR方法类似
                sqlite.DeleteValuesAND("OperationRecord", new string[] { "ID" }, new string[] { strId }, new string[] { "=" });

                dgvOperationRecord.Rows.Remove(dgvr);//删除行   
            }
        }

        private void ShowDgvPreAction()
        {
            string strStatus = string.Empty;
            List<string> strList = new List<string>();
            strList = GetSelectedRow(ref strStatus, dgvOperationRecord);

 
            sqlite.InsertValues("PreActionRecord", strList.ToArray());

            ShowTableToDgv(dgvPreAction, "PreActionRecord");

            //dgvPreAction.CurrentCell = dgvPreAction.Rows[dgvPreAction.Rows.Count - 1].Cells[0];

            DeleteSelecteRow();
        }

        private void ShowDgvAction()
        {
            string strStatus = string.Empty;
            List<string> strList = new List<string>();
            strList = GetSelectedRow(ref strStatus, dgvPreAction);

            if (strStatus.Equals("New"))
            {
                strList[6]= "Approving";
            }
            if (strStatus.Equals("Approving"))
            {
                strList[6] = "Approved";
                strList[6] = "Rejected";
            }

            sqlite.InsertValues("ActionRecord", strList.ToArray());

            ShowTableToDgv(dgvAction, "ActionRecord");

            //dgvAction.CurrentCell = dgvAction.Rows[dgvAction.Rows.Count - 1].Cells[0];
        }

        private void ShowCurrentDgvAction(bool bIsApproved)
        {
            string strStatus = string.Empty;
            List<string> strList = new List<string>();
            int indexRow = dgvAction.CurrentRow.Index;
            strList = GetSelectedRow(ref strStatus, dgvAction);

            if (bIsApproved)
            {
                strList[6] = "Approved";
            }
            else
            {
                strList[6] = "Rejected";
            }

            //更新数据，将ID=strList[0]的记录中的Status改为strList[6] 
            sqlite.UpdateValues("ActionRecord", new string[] { "Status" }, new string[] { strList[6] }, "ID", strList[0]);

            dgvAction.Rows[indexRow].Cells["Status"].Value = strList[6];

            //ShowDgv(dgvAction, "ActionRecord");

            if (indexRow != 0)
            {
                dgvAction.Rows[0].Selected = false;
            }
            dgvAction.Rows[indexRow].Selected = true;
        }

        private void btnApproved_Click(object sender, EventArgs e)
        {
            ShowCurrentDgvAction(true);
        }

        private void btnRejected_Click(object sender, EventArgs e)
        {
            ShowCurrentDgvAction(false);
        }

        private void ShowDgvFianl()
        {
            string strStatus = string.Empty;
            List<string> strListTmp = new List<string>();
            strListTmp = GetSelectedRow(ref strStatus, dgvAction);

            List<string> strList = new List<string>();
            strList = GetSelectedDgvShowUIRow(dgvShowUI);

            string strOperation = strListTmp[5];
            string strId = strListTmp[0];
            string strXml = strListTmp[7];
            if (strStatus.Equals("Approved"))
            {
                DataTable dbFinal = new DataTable("Final");

                if (strOperation.Equals("Insert"))
                {
                    sqlite.InsertValues("FinalRecord", strList.ToArray());
                }
                else if (strOperation.Equals("Modify"))
                {
                    sqlite.InsertValues("FinalRecord", strList.ToArray());
                    sqlite.UpdateValues("FinalRecord", new string[] { "VALUE" }, new string[] { "NewValue" }, "ID", strId);

                }
                else if (strOperation.Equals("Deleted"))
                {
                    sqlite.DeleteValuesAND("FinalRecord", new string[] { "ID" }, new string[] { strId }, new string[] { "=" });
                }

                ShowTableToDgv(dgvFinal, "FinalRecord");
            }
            else if (strStatus.Equals("Approving"))
            {
                MessageBox.Show("Approving");
            }
            else if (strStatus.Equals("Rejected"))
            {
                MessageBox.Show("Rejected");
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            ShowDgvFianl();
        }

        private void InsertDgvOperationRecord(string strOperationType, string strId, string strXml)
        {
            //插入数据
            sqlite.InsertValues("OperationRecord", new string[] { strId, "Key1", "Key2", "admin", "2019-04-17", strOperationType, "New", strXml });

            ShowTableToDgv(dgvOperationRecord,"OperationRecord");
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            bIsInsert = true;

            string strXml = InserRowToDgvShowUI();

            string strId = "1";
            if (dgvShowUI.Rows.Count > 0)
            {
                int index = dgvShowUI.CurrentRow.Index;
                strId = dgvShowUI.Rows[index].Cells[0].Value.ToString();
            }

            InsertDgvOperationRecord("Insert", strId, strXml);
        }

        private string InserRowToDgvShowUI()
        {
            int index = this.dgvShowUI.Rows.Add();
            this.dgvShowUI.Rows[index].Cells[0].Value = (index+1);
            this.dgvShowUI.Rows[index].Cells[1].Value = "Key1" + index;
            this.dgvShowUI.Rows[index].Cells[2].Value = "Key2" + index;
            this.dgvShowUI.Rows[index].Cells[3].Value = "Key3" + index;
            this.dgvShowUI.Rows[index].Cells[4].Value = "Value1" + index;
            this.dgvShowUI.Rows[index].Cells[5].Value = "Value2" + index;
            this.dgvShowUI.Rows[index].Cells[6].Value = "Value3" + index;

            //this.dgvShowUI.Rows[index].Cells[0].Selected = true;
            this.dgvShowUI.CurrentCell = dgvShowUI[0, index]; //设置当前单元格
            //this.dgvShowUI.BeginEdit(true); //设置可编辑状态

            string strXml = "strXml"+index;

            return strXml;
        }

        private void btnDeleted_Click(object sender, EventArgs e)
        {
            if (dgvShowUI.Rows.Count > 0)
            {
                bIsDeleted = true;

                int index = dgvShowUI.CurrentRow.Index;
                string strId = dgvShowUI.Rows[index].Cells[0].Value.ToString();
                string strXml = "strXml" + index;

                SQLiteDataReader reader = sqlite.ReadTable("PreActionRecord", new string[] { "ID" }, new string[] { "ID" }, new string[] { "=" }, new string[] { (index+1).ToString() });

                if (reader.HasRows)
                {
                    MessageBox.Show("Approving");
                }
                else
                {
                    SQLiteDataReader readerOperationRecord = sqlite.ReadTable("OperationRecord", new string[] { "ID" }, new string[] { "ID", "Operation" }, new string[] { "=", "=" }, new string[] { strId, "Insert" });
                    if (readerOperationRecord.HasRows)
                    {
                        sqlite.DeleteValuesAND("OperationRecord", new string[] { "ID", "Operation" }, new string[] { strId, "Insert" }, new string[] { "=", "=" });

                        for (int i = 0; i < dgvOperationRecord.Rows.Count; i++)
                        {
                            if (strId.Equals(dgvOperationRecord.Rows[i].Cells[0].Value.ToString()))
                            {
                                dgvOperationRecord.Rows.RemoveAt(i);
                                break;
                            }
                        }
                    }
                    else
                    {
                        InsertDgvOperationRecord("Deleted", strId, strXml);
                    }

                    dgvShowUI.Rows.RemoveAt(dgvShowUI.CurrentRow.Index);
                }
            }
        }

        bool bIsInsert = false;
        bool bIsDeleted = false;
        private void dgvShowUI_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (bIsInsert || bIsDeleted)
            {
            }
            else
            {
                if (dgvShowUI.Rows.Count > 0)
                {
                    int index = dgvShowUI.CurrentRow.Index;
                    string strId = dgvShowUI.Rows[index].Cells[0].Value.ToString();
                    string strXml = "strXml" + index;
                    InsertDgvOperationRecord("Modify", strId, strXml);
                }
            }
        }

        private void dgvShowUI_RowLeave(object sender, DataGridViewCellEventArgs e)
        {
            bIsInsert = false;
            bIsDeleted = false;
        }
    }
}

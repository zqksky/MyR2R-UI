﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParseXmlDll
{
    [Serializable]
    public struct structKeyBlockData
    {
        public string KeyBlockInstanceId;
        public string SubStrategyName;
        public List<string> InputName;
        public List<string> InputValue;
        public string OutputId;
        public List<string> OutputName;
        public List<string> OutputValue;
    }
}

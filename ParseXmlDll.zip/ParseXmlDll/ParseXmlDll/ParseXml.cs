﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace ParseXmlDll
{
    public class ParseXml
    {
        #region InitMap
        private System.Collections.Hashtable InitMap()
        {
            System.Collections.Hashtable htMap = new System.Collections.Hashtable();

            htMap.Add("Start", "eventInfo");
            htMap.Add("StartSub", "InputData");
            htMap.Add("DataArray", "");
            htMap.Add("And", "MergedPathCount");
            htMap.Add("AppCmd", "");
            htMap.Add("CallSub", "OutputData");
            htMap.Add("Case", "");
            htMap.Add("DataCache", "");
            htMap.Add("DataFilter", "DataFilter");
            htMap.Add("DataSet", "DataSet");
            htMap.Add("StringOps", "Output");
            htMap.Add("Math", "MathResult");
            htMap.Add("DBRead", "Read_Output");
            htMap.Add("DBWrite", "");
            htMap.Add("DTConvert", "DTCovertOutput");
            htMap.Add("ArrayOps", "Operation_Output");
            htMap.Add("End", "");
            htMap.Add("EndSub", "OutputData");
            htMap.Add("FaultSub", "FaultInfo");
            htMap.Add("Invoke", "");
            htMap.Add("Loop", "LoopInfo");
            htMap.Add("Catch", "StrategyException");
            htMap.Add("OR", "DataSet");
            htMap.Add("Param", "Context");
            //htMap.Add("Param", "ParametersOutput");
            htMap.Add("Timer", "TimerBlock");
            htMap.Add("Stats", "StatsResults");
            htMap.Add("Controller", "uReccommended");
            //htMap.Add("Controller", "Optimization");
            htMap.Add("MatrixMath", "MatrixMathResult");
            htMap.Add("Model", "LinearSSModel");
            htMap.Add("R2R_Read", "Result");
            htMap.Add("R2R_Write", "Result");
            htMap.Add("ReadHzn", "HorizonData");
            htMap.Add("ResetHorizon", "ResetHorizon");
            htMap.Add("StateEst", "xEstimate");

            return htMap;
        }

        private string GetOutputType(string strInputKey, ref string strOuputKey)
        {
            System.Collections.Hashtable htMap = new System.Collections.Hashtable();
            htMap = InitMap();

            string strOutputType = strInputKey;
            if (strInputKey.Equals("Param"))
            {
                strOuputKey = "//Context";
            }
            else if (strInputKey.Equals("Controller"))
            {
                strOuputKey = "//uReccommended";
            }
            else if (strInputKey.Equals("Model"))
            {
                strOuputKey = "//LinearSSModel";
                strOutputType = "Special";
            }
            else if (strInputKey.Equals("R2R_Read"))
            {
                strOuputKey = "//Result";
                strOutputType = "Special";
            }
            else if (strInputKey.Equals("StateEst"))
            {
                strOuputKey = "//xEstimate";
                strOutputType = "Special";
            }
            else if (strInputKey.Equals("Invoke"))
            {
                strOutputType = "Invoke";
            }
            else if (htMap.Contains(strInputKey))
            {
                strOuputKey = htMap[strInputKey].ToString();
                if (strOuputKey.Equals(""))
                {
                    strOutputType = "Unspecified";
                }
                else
                {
                    strOuputKey = "//" + strOuputKey;
                    strOutputType = "Specified";
                }
            }
            else
            {
                strOutputType = "Other";
            }
            return strOutputType;
        }
        #endregion

        #region DebugToXml
        private bool IsXml(string strXml)
        {
            try
            {
                XmlDocument xml = new XmlDocument();
                xml.LoadXml(strXml);//判断是否加载成功
                return true;//是xml文件，返回
            }
            catch
            {
                return false;//不是xml文件，返回
            }
        }

        private byte[] Decompress(string strGzipPath)
        {
            byte[] bytes = GetFileData(strGzipPath);
            using (var compressStream = new MemoryStream(bytes))
            {
                using (var zipStream = new GZipStream(compressStream, CompressionMode.Decompress))
                {
                    using (var resultStream = new MemoryStream())
                    {
                        zipStream.CopyTo(resultStream);
                        return resultStream.ToArray();
                    }
                }
            }
        }

        private byte[] GetFileData(string fileUrl)
        {
            FileStream fs = new FileStream(fileUrl, FileMode.Open, FileAccess.Read);
            try
            {
                byte[] buffur = new byte[fs.Length];
                fs.Read(buffur, 0, (int)fs.Length);

                return buffur;
            }
            catch (Exception ex)
            {
                //MessageBoxHelper.ShowPrompt(ex.Message);
                return null;
            }
            finally
            {
                if (fs != null)
                {

                    //关闭资源
                    fs.Close();
                }
            }
        }

        private string DebugToXml(string strDebugFilePath)
        {
            string strXml = "";
            if (File.Exists(strDebugFilePath))
            {
                byte[] bytes;
                bytes = Decompress(strDebugFilePath);

                strXml = Encoding.UTF8.GetString(bytes);
            }
            return strXml;
        }
        #endregion

        #region Define param
        private string processLogXml;
        //public string ProcessLogXml
        //{
        //    get
        //    {
        //        return processLogXml;
        //    }

        //    //set
        //    //{
        //    //    processLogXml = value;
        //    //}
        //}
        #endregion

        #region
        #region 反序列化
        /// <summary>
        /// 反序列化
        /// </summary>
        /// <param name="type">类型</param>
        /// <param name="xml">XML字符串</param>
        /// <returns></returns>
        private object Deserialize(Type type, string xml)
        {
            using (StringReader sr = new StringReader(xml))
            {
                XmlSerializer xmldes = new XmlSerializer(type);
                return xmldes.Deserialize(sr);
            }
        }
        /// <summary>
        /// 反序列化
        /// </summary>
        /// <param name="type"></param>
        /// <param name="xml"></param>
        /// <returns></returns>
        private object Deserialize(Type type, Stream stream)
        {
            XmlSerializer xmldes = new XmlSerializer(type);
            return xmldes.Deserialize(stream);
        }
        #endregion

        #region 序列化
        /// <summary>
        /// 序列化
        /// </summary>
        /// <param name="type">类型</param>
        /// <param name="obj">对象</param>
        /// <returns></returns>
        private string Serializer(Type type, object obj)
        {
            MemoryStream Stream = new MemoryStream();
            XmlSerializer xml = new XmlSerializer(type);
            //序列化对象
            xml.Serialize(Stream, obj);
            Stream.Position = 0;
            StreamReader sr = new StreamReader(Stream);
            string str = sr.ReadToEnd();

            sr.Dispose();
            Stream.Dispose();

            return str;
        }

        #endregion
        #endregion

        #region Fun New
        public string GetDebugFilePath(string strRootPath, string strEngineName, string strMachineName, string strStrategyName, string strTransactionTag)
        {
            string strDebugPathTmp = Path.Combine(strRootPath, strEngineName + ".Debugger." + strMachineName + ".1");

            string strDebugPath = GetDebugPath(strDebugPathTmp, strStrategyName, strTransactionTag);

            return strDebugPath;
        }
        private string GetDebugPath(string strPath,string strStrategyName, string strTransactionTag)
        {
            string strDebugPath = string.Empty;
            string strTransactionTagTmp = strTransactionTag;

            try
            {
                if (Directory.Exists(strPath))
                {
                    if (strTransactionTagTmp.Contains("@"))
                    {
                        strTransactionTagTmp = strTransactionTagTmp.Substring(0, strTransactionTagTmp.IndexOf("@"));
                    }
                    else
                    {
                        strTransactionTagTmp = strTransactionTag;
                    }

                    DirectoryInfo folder = new DirectoryInfo(strPath);

                    foreach (FileInfo file in folder.GetFiles("*.strategyDbg"))
                    {
                        //MessageBox.Show(file.ToString());
                        //MessageBox.Show(file.FullName.ToString());
                        string strFileName = file.Name;
                        if (strFileName.Contains(strStrategyName) && strFileName.Contains(strTransactionTagTmp))
                        {
                            strDebugPath = file.FullName;
                            break;
                        }
                    }
                }
                else
                {
                }
            }
            catch (Exception ee)
            {
                //MessageBox.Show(ee.ToString());
            }

            return strDebugPath;
        }

        private List<structKeyBlockData> GetStructKeyBlockDataSingleNewTest(string strRootPath,string strEngineName,string strMachineName, string strStrategyName, string strTransactionTag, string strSubStrategyName, string strInstanceId)
        {
            //TransactionTag = ID @XXXXXXXX
            //< RootPath >\< EngineName >.Debugger.< MachineName > .1 下搜寻包含 Transaction Tag的ID的那份文件
            string strDebugPath = string.Empty;
            string strDebugPathTmp = string.Empty;
            //strDebugPathTmp = strRootPath + "\\" + strEngineName + "\\Debugger\\" + strMachineName + ".1";
            strDebugPathTmp = Path.Combine(strRootPath, strEngineName+ ".Debugger."+strMachineName+".1");

            strDebugPath = GetDebugPath(strDebugPathTmp, strStrategyName, strTransactionTag);

            List<structKeyBlockData> structListKeyBlockData = new List<structKeyBlockData>();
            structKeyBlockData structData = new structKeyBlockData();
            structData.OutputId = "";
            structData.SubStrategyName = strSubStrategyName;
            structData.KeyBlockInstanceId = strInstanceId;
            structData.InputName = new List<string>();
            structData.InputValue = new List<string>();
            structData.OutputName = new List<string>();
            structData.OutputValue = new List<string>();

            if (strDebugPath.Equals(""))
            {
            }
            else
            {
                List<string> strListInputName = new List<string>();
                List<string> strListInputData = new List<string>();
                List<string> strListOutputName = new List<string>();
                List<string> strListOutputData = new List<string>();

                XmlDocument doc = new XmlDocument();
                try
                {
                    string strXml = DebugToXml(strDebugPath);
                    doc.LoadXml(strXml);

                    XmlNodeList nodeExeInfoList = null;
                    XmlNodeList nodeStrategyExeInfoList = null;
                    nodeStrategyExeInfoList = doc.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo/StrategyName");

                    bool bIsSubStrategyName = false;
                    if (nodeStrategyExeInfoList.Count > 0)
                    {
                        foreach (XmlNode node in nodeStrategyExeInfoList)
                        {
                            if (node.InnerText.Contains(strSubStrategyName))
                            {
                                bIsSubStrategyName = true;
                                nodeExeInfoList = node.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                                break;
                            }
                        }
                    }
                    if (!bIsSubStrategyName)
                    {
                        bool bStrategyName = false;
                        nodeStrategyExeInfoList = doc.SelectNodes("//StrategyExeInfo/StrategyName");
                        if (nodeStrategyExeInfoList.Count > 0)
                        {
                            foreach (XmlNode node in nodeStrategyExeInfoList)
                            {
                                if (node.InnerText.Contains(strSubStrategyName))
                                {
                                    bStrategyName = true;
                                    nodeExeInfoList = node.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                                    break;
                                }
                            }
                        }
                        if (!bStrategyName)
                        {
                            nodeExeInfoList = doc.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                        }
                    }

                    if (nodeExeInfoList.Count > 0)
                    {
                        foreach (XmlNode nodeExeInfo in nodeExeInfoList)
                        {
                            string strId = "";
                            string strOutputId = "";
                            string strOutputKey = "";
                            string strOutputType = "";

                            strId = nodeExeInfo.SelectSingleNode("child::Id").InnerText;
                            strOutputType = GetOutputType(strId, ref strOutputKey);

                            XmlNodeList nodesInput = nodeExeInfo.SelectNodes("child::Inputs/InputParameter");
                            foreach (XmlNode itemInput in nodesInput)
                            {
                                string strInputXml = itemInput.InnerXml;
                                string strInputName = itemInput.SelectSingleNode("child::Name").InnerText;
                                string strInputData = itemInput.SelectSingleNode("child::Data").InnerText;

                                GetInputValue(strInputData, strInputName, ref strListInputName, ref strListInputData);
                            }

                            XmlNodeList nodesOutput = nodeExeInfo.SelectNodes("child::Output");
                            foreach (XmlNode itemOutput in nodesOutput)
                            {
                                string strOutputData = string.Empty;
                                string strOutputXml = itemOutput.InnerXml;
                                strOutputId = itemOutput.SelectSingleNode("child::Id").InnerText;
                                strOutputData = itemOutput.SelectSingleNode("child::Data").InnerText;

                                bool bIsXml = IsXml(strOutputData);
                                if (bIsXml)
                                {
                                    List<string> strListName = new List<string>();
                                    List<string> strListData = new List<string>();

                                    GetOutputValue(strOutputData, strOutputKey, strOutputType, ref strListName, ref strListData);

                                    strListOutputName = new List<string>(strListName);
                                    strListOutputData = new List<string>(strListData);
                                }
                            }

                            structData.OutputId = strOutputId;
                            structData.InputName = new List<string>(strListInputName);
                            structData.InputValue = new List<string>(strListInputData);
                            structData.OutputName = new List<string>(strListOutputName);
                            structData.OutputValue = new List<string>(strListOutputData);

                            structListKeyBlockData.Add(structData);
                        }
                    }
                    else
                    {
                        structListKeyBlockData.Add(structData);
                    }
                }
                catch (Exception err)
                {
                }
                finally
                {
                    doc.RemoveAll();
                    doc = null;
                }
            }
            return structListKeyBlockData;
        }

        private List<structKeyBlockData> GetStructKeyBlockDataSingleNew(string strRootPath, string strEngineName, string strMachineName,string strStrategyName,string strTransactionTag, string strSubStrategyName, string strInstanceId)
        {
            string strDebugPath = string.Empty;
            string strDebugPathTmp = string.Empty;
            //strDebugPathTmp = strRootPath + "\\" + strEngineName + "\\Debugger\\" + strMachineName + ".1";
            strDebugPathTmp = Path.Combine(strRootPath, strEngineName + ".Debugger." + strMachineName + ".1");

            strDebugPath = GetDebugPath(strDebugPathTmp, strStrategyName, strTransactionTag);

            List<structKeyBlockData> structListKeyBlockData = new List<structKeyBlockData>();
            structKeyBlockData structData = new structKeyBlockData();
            structData.OutputId = "";
            structData.SubStrategyName = strSubStrategyName;
            structData.KeyBlockInstanceId = strInstanceId;
            structData.InputName = new List<string>();
            structData.InputValue = new List<string>();
            structData.OutputName = new List<string>();
            structData.OutputValue = new List<string>();

            if (strDebugPath.Equals(""))
            {
            }
            else
            {
                List<string> strListInputName = new List<string>();
                List<string> strListInputData = new List<string>();
                List<string> strListOutputName = new List<string>();
                List<string> strListOutputData = new List<string>();

                XmlDocument doc = new XmlDocument();
                try
                {
                    string strXml = DebugToXml(strDebugPath);
                    doc.LoadXml(strXml);
                    //doc.Load(strXmlPath);

                    XmlNode nodeStrategyExeInfo = null;
                    XmlNodeList nodeExeInfoList = null;

                    nodeStrategyExeInfo = doc.SelectSingleNode("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo" + "[StrategyName='" + strSubStrategyName + "']");
                    if (nodeStrategyExeInfo != null)
                    {
                        nodeExeInfoList = nodeStrategyExeInfo.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                    }
                    else
                    {
                        nodeStrategyExeInfo = doc.SelectSingleNode("//StrategyExeInfo" + "[StrategyName='" + strSubStrategyName + "']");
                        if (nodeStrategyExeInfo != null)
                        {
                            nodeExeInfoList = nodeStrategyExeInfo.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                        }
                        else
                        {
                            nodeExeInfoList = doc.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                        }
                    }
                    if (nodeExeInfoList.Count > 0)
                    {
                        foreach (XmlNode nodeExeInfo in nodeExeInfoList)
                        {
                            string strId = "";
                            string strOutputId = "";
                            string strOutputKey = "";
                            string strOutputType = "";

                            strId = nodeExeInfo.SelectSingleNode("child::Id").InnerText;
                            strOutputType = GetOutputType(strId, ref strOutputKey);

                            XmlNodeList nodesInput = nodeExeInfo.SelectNodes("child::Inputs/InputParameter");
                            foreach (XmlNode itemInput in nodesInput)
                            {
                                string strInputXml = itemInput.InnerXml;
                                string strInputName = itemInput.SelectSingleNode("child::Name").InnerText;
                                string strInputData = itemInput.SelectSingleNode("child::Data").InnerText;

                                GetInputValue(strInputData, strInputName, ref strListInputName, ref strListInputData);
                            }

                            XmlNodeList nodesOutput = nodeExeInfo.SelectNodes("child::Output");
                            foreach (XmlNode itemOutput in nodesOutput)
                            {
                                string strOutputData = string.Empty;
                                string strOutputXml = itemOutput.InnerXml;
                                strOutputId = itemOutput.SelectSingleNode("child::Id").InnerText;
                                strOutputData = itemOutput.SelectSingleNode("child::Data").InnerText;

                                bool bIsXml = IsXml(strOutputData);
                                if (bIsXml)
                                {
                                    List<string> strListName = new List<string>();
                                    List<string> strListData = new List<string>();

                                    GetOutputValue(strOutputData, strOutputKey, strOutputType, ref strListName, ref strListData);

                                    strListOutputName = new List<string>(strListName);
                                    strListOutputData = new List<string>(strListData);
                                }
                            }

                            structData.OutputId = strOutputId;
                            structData.InputName = new List<string>(strListInputName);
                            structData.InputValue = new List<string>(strListInputData);
                            structData.OutputName = new List<string>(strListOutputName);
                            structData.OutputValue = new List<string>(strListOutputData);

                            structListKeyBlockData.Add(structData);
                        }
                    }
                    else
                    {
                        structListKeyBlockData.Add(structData);
                    }
                }
                catch (Exception err)
                {
                }
                finally
                {
                    doc.RemoveAll();
                    doc = null;
                }

            }

            return structListKeyBlockData;
        }

        public structKeyBlockData[] GetStructKeyBlockDataNew(string strRootPath, string strEngineName, string strMachineName,string strStrategyName, string strTransactionTag, string[] strArraySubStrategyName, string[] strArrayInstanceId, int[] iArrayPriority)
        {
            string strDebugPath = string.Empty;
            string strDebugPathTmp = string.Empty;
            //strDebugPathTmp = strRootPath + "\\" + strEngineName + "\\Debugger\\" + strMachineName + ".1";
            strDebugPathTmp = Path.Combine(strRootPath, strEngineName + ".Debugger." + strMachineName + ".1");

            strDebugPath = GetDebugPath(strDebugPathTmp, strStrategyName,strTransactionTag);

            List<structKeyBlockData> structListKeyBlockDataAll = new List<structKeyBlockData>();
            List<structKeyBlockData> structListKeyBlockDataAllSort = new List<structKeyBlockData>();

            if (strDebugPath.Equals(""))
            {
            }
            else
            {
                List<int> iListPriority = new List<int>(iArrayPriority.ToList());
                List<int> iListSortIndex = new List<int>();

                try
                {
                    if (strArraySubStrategyName.Length == strArrayInstanceId.Length)
                    {

                        for (int i = 0; i < strArrayInstanceId.Length; i++)
                        {
                            List<structKeyBlockData> structListKeyBlockData = new List<structKeyBlockData>();
                            structListKeyBlockData = GetStructKeyBlockDataSingleNew(strDebugPath, strArraySubStrategyName[i], strArrayInstanceId[i]);
                            if (structListKeyBlockData.Count > 1)
                            {
                                int n = 0;
                                foreach (var structKeyBlockData in structListKeyBlockData)
                                {
                                    structListKeyBlockDataAll.Add(structKeyBlockData);
                                    if (n > 0)
                                    {
                                        iListPriority.Insert(n - 1 + i, iArrayPriority[i]);
                                    }
                                    n++;
                                }
                            }
                            else
                            {
                                structListKeyBlockDataAll.Add(structListKeyBlockData[0]);
                            }
                        }
                        iListSortIndex = GetSortIndex(iListPriority);
                    }

                    if (structListKeyBlockDataAll.Count == iListSortIndex.Count)
                    {
                        for (int i = 0; i < iListSortIndex.Count; i++)
                        {
                            structListKeyBlockDataAllSort.Add(structListKeyBlockDataAll[iListSortIndex[i]]);
                        }
                    }
                }
                catch (Exception err)
                {
                }
            }
            //return structListKeyBlockDataAll.ToArray();
            return structListKeyBlockDataAllSort.ToArray();
        }
        private List<string> GetProcessLogXmlSingleNewTest(string strRootPath, string strEngineName, string strMachineName, string strStrategyName, string strTransactionTag, string strSubStrategyName, string strInstanceId)
        {
            string strDebugPath = string.Empty;
            string strDebugPathTmp = string.Empty;
            //strDebugPathTmp = strRootPath + "\\" + strEngineName + "\\Debugger\\" + strMachineName + ".1";
            strDebugPathTmp = Path.Combine(strRootPath, strEngineName + ".Debugger." + strMachineName + ".1");

            strDebugPath = GetDebugPath(strDebugPathTmp, strStrategyName,strTransactionTag);

            bool bIsSub = false;
            string strXmlResult = "";
            List<string> strListXml = new List<string>();

            if (strDebugPath.Equals(""))
            {
            }
            else
            {
                List<string> strListInputName = new List<string>();
                List<string> strListInputData = new List<string>();
                List<string> strListOutputName = new List<string>();
                List<string> strListOutputData = new List<string>();

                XmlDocument doc = new XmlDocument();
                try
                {
                    string strXml = DebugToXml(strDebugPath);
                    doc.LoadXml(strXml);
                    //doc.Load(strXmlPath);

                    XmlNode nodeStrategyExeInfo = null;
                    XmlNodeList nodeExeInfoList = null;

                    nodeStrategyExeInfo = doc.SelectSingleNode("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo" + "[StrategyName='" + strSubStrategyName + "']");
                    if (nodeStrategyExeInfo != null)
                    {
                        nodeExeInfoList = nodeStrategyExeInfo.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                        bIsSub = true;
                        //strXmlStructStart = "<StrategyExeInfo><ExecutionSeq><ExeInfo><SubStrategyExeInfo><StrategyName>" + strStrategyName + "</StrategyName><ExecutionSeq><ExeInfo>";
                        //strXmlStructEnd = "</ExeInfo></ExecutionSeq></SubStrategyExeInfo></ExeInfo></ExecutionSeq></StrategyExeInfo>";
                    }
                    else
                    {
                        nodeStrategyExeInfo = doc.SelectSingleNode("//StrategyExeInfo" + "[StrategyName='" + strSubStrategyName + "']");
                        if (nodeStrategyExeInfo != null)
                        {
                            nodeExeInfoList = nodeStrategyExeInfo.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                        }
                        else
                        {
                            nodeExeInfoList = doc.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                        }
                        bIsSub = false;
                        //strXmlStructStart = "<StrategyExeInfo><StrategyName>" + strStrategyName + "</StrategyName><ExecutionSeq><ExeInfo>";
                        //strXmlStructEnd = "</ExeInfo></ExecutionSeq></StrategyExeInfo>";
                    }
                    if (nodeExeInfoList.Count > 0)
                    {
                        foreach (XmlNode nodeExeInfo in nodeExeInfoList)
                        {
                            //string strNodeXml = nodeExeInfo.InnerXml;
                            //strXmlResult = SpliteXml(strNodeXml, strStrategyName, bIsSub);

                            string strXmlTmp = SpliteXml(nodeExeInfo, strSubStrategyName, bIsSub);
                            //strXmlResult += strXmlTmp;
                            strListXml.Add(strXmlTmp);
                        }
                    }
                    else
                    {
                        string strXmlTmp = SpliteXmlNoNode(strSubStrategyName, strInstanceId, bIsSub);
                        strListXml.Add(strXmlTmp);
                    }
                }
                catch (Exception err)
                {
                }
                finally
                {
                    doc.RemoveAll();
                    doc = null;
                }
            }

            return strListXml;
        }

        public string GetProcessLogXmlNew(string strRootPath, string strEngineName, string strMachineName, string strStrategyName, string strTransactionTag, string[] strArraySubStrategyName, string[] strArrayInstanceId, int[] iArrayPriority)
        {
            string strDebugPath = string.Empty;
            string strDebugPathTmp = string.Empty;
            //strDebugPathTmp = strRootPath + "\\" + strEngineName + "\\Debugger\\" + strMachineName + ".1";
            strDebugPathTmp = Path.Combine(strRootPath, strEngineName + ".Debugger." + strMachineName + ".1");

            strDebugPath = GetDebugPath(strDebugPathTmp, strStrategyName, strTransactionTag);

            string strXmlResult = "";
            List<string> strListXmlAll = new List<string>();
            List<string> strListXmlSort = new List<string>();

            if (strDebugPath.Equals(""))
            {
            }
            else
            {
                List<int> iListPriority = new List<int>(iArrayPriority.ToList());
                List<int> iListSortIndex = new List<int>();

                try
                {
                    if (strArraySubStrategyName.Length == strArrayInstanceId.Length)
                    {
                        for (int i = 0; i < strArrayInstanceId.Length; i++)
                        {
                            List<string> strListXmlSingle = new List<string>();
                            strListXmlSingle = GetProcessLogXmlSingleNewTest(strDebugPath, strArraySubStrategyName[i], strArrayInstanceId[i]);
                            if (strListXmlSingle.Count > 1)
                            {
                                int n = 0;
                                foreach (var str in strListXmlSingle)
                                {
                                    strListXmlAll.Add(str);
                                    if (n > 0)
                                    {
                                        iListPriority.Insert(n - 1 + i, iArrayPriority[i]);
                                    }
                                    n++;
                                }
                            }
                            else
                            {
                                strListXmlAll.Add(strListXmlSingle[0]);
                            }
                        }
                        iListSortIndex = GetSortIndex(iListPriority);
                    }

                    if (strListXmlAll.Count == iListSortIndex.Count)
                    {
                        for (int i = 0; i < iListSortIndex.Count; i++)
                        {
                            strListXmlSort.Add(strListXmlAll[iListSortIndex[i]]);
                        }

                        foreach (var str in strListXmlSort)
                        {
                            strXmlResult += str;
                        }
                    }
                }
                catch (Exception err)
                {
                }
                strXmlResult = "<ArrayOfStrategyExeInfo>" + strXmlResult + "</ArrayOfStrategyExeInfo>";
            }

            return strXmlResult;
        }

        private string GetProcessLogXmlSingleNewSerialize(structKeyBlockDataSerialize structData)
        {
            //string xml = XmlSerializeHelp.Serializer(typeof(structKeyBlockDataSerialize), structData);
            string xml = Serializer(typeof(structKeyBlockDataSerialize), structData);
            return xml;
        }

        private List<structKeyBlockDataSerialize> GetStructKeyBlockDataSingleNewSerialize(string strDebugPath, string strStrategyName, string strInstanceId)
        {
            List<structKeyBlockDataSerialize> structListKeyBlockData = new List<structKeyBlockDataSerialize>();
            structKeyBlockDataSerialize structData = new structKeyBlockDataSerialize();
            structData.OutputId = "";
            structData.SubStrategyName = strStrategyName;
            structData.KeyBlockInstanceId = strInstanceId;
            structData.InputName = new List<string>();
            structData.InputValue = new List<string>();
            structData.OutputName = new List<string>();
            structData.OutputValue = new List<string>();

            List<string> strListInputName = new List<string>();
            List<string> strListInputData = new List<string>();
            List<string> strListOutputName = new List<string>();
            List<string> strListOutputData = new List<string>();

            XmlDocument doc = new XmlDocument();
            try
            {
                string strXml = DebugToXml(strDebugPath);
                doc.LoadXml(strXml);
                //doc.Load(strXmlPath);

                XmlNode nodeStrategyExeInfo = null;
                XmlNodeList nodeExeInfoList = null;

                nodeStrategyExeInfo = doc.SelectSingleNode("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo" + "[StrategyName='" + strStrategyName + "']");
                if (nodeStrategyExeInfo != null)
                {
                    nodeExeInfoList = nodeStrategyExeInfo.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                }
                else
                {
                    nodeStrategyExeInfo = doc.SelectSingleNode("//StrategyExeInfo" + "[StrategyName='" + strStrategyName + "']");
                    if (nodeStrategyExeInfo != null)
                    {
                        nodeExeInfoList = nodeStrategyExeInfo.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                    }
                    else
                    {
                        nodeExeInfoList = doc.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                    }
                }
                if (nodeExeInfoList.Count > 0)
                {
                    foreach (XmlNode nodeExeInfo in nodeExeInfoList)
                    {
                        string strId = "";
                        string strOutputId = "";
                        string strOutputKey = "";
                        string strOutputType = "";

                        strId = nodeExeInfo.SelectSingleNode("child::Id").InnerText;
                        strOutputType = GetOutputType(strId, ref strOutputKey);

                        XmlNodeList nodesInput = nodeExeInfo.SelectNodes("child::Inputs/InputParameter");
                        foreach (XmlNode itemInput in nodesInput)
                        {
                            string strInputXml = itemInput.InnerXml;
                            string strInputName = itemInput.SelectSingleNode("child::Name").InnerText;
                            string strInputData = itemInput.SelectSingleNode("child::Data").InnerText;

                            GetInputValue(strInputData, strInputName, ref strListInputName, ref strListInputData);
                        }

                        XmlNodeList nodesOutput = nodeExeInfo.SelectNodes("child::Output");
                        foreach (XmlNode itemOutput in nodesOutput)
                        {
                            string strOutputData = string.Empty;
                            string strOutputXml = itemOutput.InnerXml;
                            strOutputId = itemOutput.SelectSingleNode("child::Id").InnerText;
                            strOutputData = itemOutput.SelectSingleNode("child::Data").InnerText;

                            bool bIsXml = IsXml(strOutputData);
                            if (bIsXml)
                            {
                                List<string> strListName = new List<string>();
                                List<string> strListData = new List<string>();

                                GetOutputValue(strOutputData, strOutputKey, strOutputType, ref strListName, ref strListData);

                                strListOutputName = new List<string>(strListName);
                                strListOutputData = new List<string>(strListData);
                            }
                        }

                        structData.OutputId = strOutputId;
                        structData.InputName = new List<string>(strListInputName);
                        structData.InputValue = new List<string>(strListInputData);
                        structData.OutputName = new List<string>(strListOutputName);
                        structData.OutputValue = new List<string>(strListOutputData);

                        structListKeyBlockData.Add(structData);
                    }
                }
                else
                {
                    structListKeyBlockData.Add(structData);
                }
            }
            catch (Exception err)
            {
            }
            finally
            {
                doc.RemoveAll();
                doc = null;
            }


            return structListKeyBlockData;
        }

        private structKeyBlockDataSerialize[] GetStructKeyBlockDataNewSerialize(string strRootPath, string strEngineName, string strMachineName, string strStrategyName, string strTransactionTag, string[] strArraySubStrategyName, string[] strArrayInstanceId, int[] iArrayPriority)
        {
            string strDebugPath = string.Empty;
            string strDebugPathTmp = string.Empty;
            //strDebugPathTmp = strRootPath + "\\" + strEngineName + "\\Debugger\\" + strMachineName + ".1";
            strDebugPathTmp = Path.Combine(strRootPath, strEngineName + ".Debugger." + strMachineName + ".1");

            strDebugPath = GetDebugPath(strDebugPathTmp, strStrategyName, strTransactionTag);

            List<structKeyBlockDataSerialize> structListKeyBlockDataAll = new List<structKeyBlockDataSerialize>();
            List<structKeyBlockDataSerialize> structListKeyBlockDataAllSort = new List<structKeyBlockDataSerialize>();

            if (strDebugPath.Equals(""))
            {
            }
            else
            {
                List<int> iListPriority = new List<int>(iArrayPriority.ToList());
                List<int> iListSortIndex = new List<int>();

                try
                {
                    if (strArraySubStrategyName.Length == strArrayInstanceId.Length)
                    {

                        for (int i = 0; i < strArrayInstanceId.Length; i++)
                        {
                            List<structKeyBlockDataSerialize> structListKeyBlockData = new List<structKeyBlockDataSerialize>();
                            structListKeyBlockData = GetStructKeyBlockDataSingleNewSerialize(strDebugPath, strArraySubStrategyName[i], strArrayInstanceId[i]);
                            if (structListKeyBlockData.Count > 1)
                            {
                                int n = 0;
                                foreach (var structKeyBlockData in structListKeyBlockData)
                                {
                                    structListKeyBlockDataAll.Add(structKeyBlockData);
                                    if (n > 0)
                                    {
                                        iListPriority.Insert(n - 1 + i, iArrayPriority[i]);
                                    }
                                    n++;
                                }
                            }
                            else
                            {
                                structListKeyBlockDataAll.Add(structListKeyBlockData[0]);
                            }
                        }
                        iListSortIndex = GetSortIndex(iListPriority);
                    }

                    if (structListKeyBlockDataAll.Count == iListSortIndex.Count)
                    {
                        for (int i = 0; i < iListSortIndex.Count; i++)
                        {
                            structListKeyBlockDataAllSort.Add(structListKeyBlockDataAll[iListSortIndex[i]]);
                        }
                    }
                }
                catch (Exception err)
                {
                }
            }
            //return structListKeyBlockDataAll.ToArray();
            return structListKeyBlockDataAllSort.ToArray();
        }

        public string GetProcessLogXmlNewSerialize(string strRootPath, string strEngineName, string strMachineName, string strStrategyName, string strTransactionTag, string[] strArraySubStrategyName, string[] strArrayInstanceId, int[] iArrayPriority)
        {
            string strXmlResult = "";
            List<structKeyBlockDataSerialize> structListKeyBlockDataAll = new List<structKeyBlockDataSerialize>();
            try
            {
                structListKeyBlockDataAll = GetStructKeyBlockDataNewSerialize(strRootPath, strEngineName, strMachineName, strStrategyName, strTransactionTag, strArraySubStrategyName, strArrayInstanceId, iArrayPriority).ToList();

                //strXmlResult = XmlSerializeHelp.Serializer(typeof(List<structKeyBlockData>), structListKeyBlockDataAll);
                strXmlResult = Serializer(typeof(List<structKeyBlockDataSerialize>), structListKeyBlockDataAll);
            }
            catch (Exception err)
            {
            }
            //strXmlResult = "<ArrayOfStrategyExeInfo>" + strXmlResult + "</ArrayOfStrategyExeInfo>";

            return strXmlResult;
        }
        #endregion

        #region Fun Test
        private List<structKeyBlockData> GetStructKeyBlockDataSingleNewTest(string strDebugPath, string strStrategyName, string strInstanceId)
        {
            List<structKeyBlockData> structListKeyBlockData = new List<structKeyBlockData>();
            structKeyBlockData structData = new structKeyBlockData();
            structData.OutputId = "";
            structData.SubStrategyName = strStrategyName;
            structData.KeyBlockInstanceId = strInstanceId;
            structData.InputName = new List<string>();
            structData.InputValue = new List<string>();
            structData.OutputName = new List<string>();
            structData.OutputValue = new List<string>();

            List<string> strListInputName = new List<string>();
            List<string> strListInputData = new List<string>();
            List<string> strListOutputName = new List<string>();
            List<string> strListOutputData = new List<string>();

            XmlDocument doc = new XmlDocument();
            try
            {
                string strXml = DebugToXml(strDebugPath);
                doc.LoadXml(strXml);
   
                XmlNodeList nodeExeInfoList = null;
                XmlNodeList nodeStrategyExeInfoList = null;
                nodeStrategyExeInfoList = doc.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo/StrategyName");

                bool bIsSubStrategyName = false;
                if (nodeStrategyExeInfoList.Count > 0)
                {
                    foreach (XmlNode node in nodeStrategyExeInfoList)
                    {
                        if (node.InnerText.Contains(strStrategyName))
                        {
                            bIsSubStrategyName = true;
                            nodeExeInfoList = node.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                            break;
                        }
                    }
                }
                if (!bIsSubStrategyName)
                {
                    bool bStrategyName = false;
                    nodeStrategyExeInfoList = doc.SelectNodes("//StrategyExeInfo/StrategyName");
                    if (nodeStrategyExeInfoList.Count > 0)
                    {
                        foreach (XmlNode node in nodeStrategyExeInfoList)
                        {
                            if (node.InnerText.Contains(strStrategyName))
                            {
                                bStrategyName = true;
                                nodeExeInfoList = node.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                                break;
                            }
                        }
                    }
                    if (!bStrategyName)
                    {
                        nodeExeInfoList = doc.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                    }
                }
 
                if (nodeExeInfoList.Count > 0)
                {
                    foreach (XmlNode nodeExeInfo in nodeExeInfoList)
                    {
                        string strId = "";
                        string strOutputId = "";
                        string strOutputKey = "";
                        string strOutputType = "";

                        strId = nodeExeInfo.SelectSingleNode("child::Id").InnerText;
                        strOutputType = GetOutputType(strId, ref strOutputKey);

                        XmlNodeList nodesInput = nodeExeInfo.SelectNodes("child::Inputs/InputParameter");
                        foreach (XmlNode itemInput in nodesInput)
                        {
                            string strInputXml = itemInput.InnerXml;
                            string strInputName = itemInput.SelectSingleNode("child::Name").InnerText;
                            string strInputData = itemInput.SelectSingleNode("child::Data").InnerText;

                            GetInputValue(strInputData, strInputName, ref strListInputName, ref strListInputData);
                        }

                        XmlNodeList nodesOutput = nodeExeInfo.SelectNodes("child::Output");
                        foreach (XmlNode itemOutput in nodesOutput)
                        {
                            string strOutputData = string.Empty;
                            string strOutputXml = itemOutput.InnerXml;
                            strOutputId = itemOutput.SelectSingleNode("child::Id").InnerText;
                            strOutputData = itemOutput.SelectSingleNode("child::Data").InnerText;

                            bool bIsXml = IsXml(strOutputData);
                            if (bIsXml)
                            {
                                List<string> strListName = new List<string>();
                                List<string> strListData = new List<string>();

                                GetOutputValue(strOutputData, strOutputKey, strOutputType, ref strListName, ref strListData);

                                strListOutputName = new List<string>(strListName);
                                strListOutputData = new List<string>(strListData);
                            }
                        }

                        structData.OutputId = strOutputId;
                        structData.InputName = new List<string>(strListInputName);
                        structData.InputValue = new List<string>(strListInputData);
                        structData.OutputName = new List<string>(strListOutputName);
                        structData.OutputValue = new List<string>(strListOutputData);

                        structListKeyBlockData.Add(structData);
                    }
                }
                else
                {
                    structListKeyBlockData.Add(structData);
                }
            }
            catch (Exception err)
            {
            }
            finally
            {
                doc.RemoveAll();
                doc = null;
            }


            return structListKeyBlockData;
        }

        private List<structKeyBlockData> GetStructKeyBlockDataSingleNew(string strDebugPath, string strStrategyName, string strInstanceId)
        {
            List<structKeyBlockData> structListKeyBlockData = new List<structKeyBlockData>();
            structKeyBlockData structData = new structKeyBlockData();
            structData.OutputId = "";
            structData.SubStrategyName = strStrategyName;
            structData.KeyBlockInstanceId = strInstanceId;
            structData.InputName = new List<string>();
            structData.InputValue = new List<string>();
            structData.OutputName = new List<string>();
            structData.OutputValue = new List<string>();

            List<string> strListInputName = new List<string>();
            List<string> strListInputData = new List<string>();
            List<string> strListOutputName = new List<string>();
            List<string> strListOutputData = new List<string>();

            XmlDocument doc = new XmlDocument();
            try
            {
                string strXml = DebugToXml(strDebugPath);
                doc.LoadXml(strXml);
                //doc.Load(strXmlPath);

                XmlNode nodeStrategyExeInfo = null;
                XmlNodeList nodeExeInfoList = null;

                nodeStrategyExeInfo = doc.SelectSingleNode("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo" + "[StrategyName='" + strStrategyName + "']");
                if (nodeStrategyExeInfo != null)
                {
                    nodeExeInfoList = nodeStrategyExeInfo.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                }
                else
                {
                    nodeStrategyExeInfo = doc.SelectSingleNode("//StrategyExeInfo" + "[StrategyName='" + strStrategyName + "']");
                    if (nodeStrategyExeInfo != null)
                    {
                        nodeExeInfoList = nodeStrategyExeInfo.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                    }
                    else
                    {
                        nodeExeInfoList = doc.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                    }
                }
                if (nodeExeInfoList.Count > 0)
                {
                    foreach (XmlNode nodeExeInfo in nodeExeInfoList)
                    {
                        string strId = "";
                        string strOutputId = "";
                        string strOutputKey = "";
                        string strOutputType = "";

                        strId = nodeExeInfo.SelectSingleNode("child::Id").InnerText;
                        strOutputType = GetOutputType(strId, ref strOutputKey);

                        XmlNodeList nodesInput = nodeExeInfo.SelectNodes("child::Inputs/InputParameter");
                        foreach (XmlNode itemInput in nodesInput)
                        {
                            string strInputXml = itemInput.InnerXml;
                            string strInputName = itemInput.SelectSingleNode("child::Name").InnerText;
                            string strInputData = itemInput.SelectSingleNode("child::Data").InnerText;

                            GetInputValue(strInputData, strInputName, ref strListInputName, ref strListInputData);
                        }

                        XmlNodeList nodesOutput = nodeExeInfo.SelectNodes("child::Output");
                        foreach (XmlNode itemOutput in nodesOutput)
                        {
                            string strOutputData = string.Empty;
                            string strOutputXml = itemOutput.InnerXml;
                            strOutputId = itemOutput.SelectSingleNode("child::Id").InnerText;
                            strOutputData = itemOutput.SelectSingleNode("child::Data").InnerText;

                            bool bIsXml = IsXml(strOutputData);
                            if (bIsXml)
                            {
                                List<string> strListName = new List<string>();
                                List<string> strListData = new List<string>();

                                GetOutputValue(strOutputData, strOutputKey, strOutputType, ref strListName, ref strListData);

                                strListOutputName = new List<string>(strListName);
                                strListOutputData = new List<string>(strListData);
                            }
                        }

                        structData.OutputId = strOutputId;
                        structData.InputName = new List<string>(strListInputName);
                        structData.InputValue = new List<string>(strListInputData);
                        structData.OutputName = new List<string>(strListOutputName);
                        structData.OutputValue = new List<string>(strListOutputData);

                        structListKeyBlockData.Add(structData);
                    }
                }
                else
                {
                    structListKeyBlockData.Add(structData);
                }
            }
            catch (Exception err)
            {
            }
            finally
            {
                doc.RemoveAll();
                doc = null;
            }


            return structListKeyBlockData;
        }

        public structKeyBlockData[] GetStructKeyBlockDataNew(string strDebugPath, string[] strArrayStrategyName, string[] strArrayInstanceId, int[] iArrayPriority)
        {
            List<structKeyBlockData> structListKeyBlockDataAll = new List<structKeyBlockData>();
            List<structKeyBlockData> structListKeyBlockDataAllSort = new List<structKeyBlockData>();

            List<int> iListPriority = new List<int>(iArrayPriority.ToList());
            List<int> iListSortIndex = new List<int>();

            //structKeyBlockData[] strArrayStructSort = new structKeyBlockData[strArrayInstanceId.Length];
            try
            {
                if (strArrayStrategyName.Length == strArrayInstanceId.Length)
                {
                    
                    for (int i = 0; i < strArrayInstanceId.Length; i++)
                    {
                        List<structKeyBlockData> structListKeyBlockData = new List<structKeyBlockData>();
                        structListKeyBlockData = GetStructKeyBlockDataSingleNew(strDebugPath, strArrayStrategyName[i], strArrayInstanceId[i]);
                        if (structListKeyBlockData.Count > 1)
                        {
                            int n = 0;
                            foreach (var structKeyBlockData in structListKeyBlockData)
                            {
                                structListKeyBlockDataAll.Add(structKeyBlockData);
                                if (n > 0)
                                {
                                    iListPriority.Insert(n-1 + i, iArrayPriority[i]);                                    
                                }
                                n++;
                            }
                        }
                        else
                        {
                            structListKeyBlockDataAll.Add(structListKeyBlockData[0]);
                        }
                    }
                    iListSortIndex = GetSortIndex(iListPriority);
                }

                if (structListKeyBlockDataAll.Count == iListSortIndex.Count)
                {
                    for (int i = 0; i < iListSortIndex.Count; i++)
                    {
                        structListKeyBlockDataAllSort.Add(structListKeyBlockDataAll[iListSortIndex[i]]);
                    }
                }
            }
            catch (Exception err)
            {
            }

            //return structListKeyBlockDataAll.ToArray();
            return structListKeyBlockDataAllSort.ToArray();
        }
        private List<string> GetProcessLogXmlSingleNewTest(string strDebugPath, string strStrategyName, string strInstanceId)
        {
            bool bIsSub = false;
            string strXmlResult = "";
            List<string> strListXml = new List<string>();

            List<string> strListInputName = new List<string>();
            List<string> strListInputData = new List<string>();
            List<string> strListOutputName = new List<string>();
            List<string> strListOutputData = new List<string>();

            XmlDocument doc = new XmlDocument();
            try
            {
                string strXml = DebugToXml(strDebugPath);
                doc.LoadXml(strXml);
                //doc.Load(strXmlPath);

                XmlNode nodeStrategyExeInfo = null;
                XmlNodeList nodeExeInfoList = null;

                nodeStrategyExeInfo = doc.SelectSingleNode("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo" + "[StrategyName='" + strStrategyName + "']");
                if (nodeStrategyExeInfo != null)
                {
                    nodeExeInfoList = nodeStrategyExeInfo.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                    bIsSub = true;
                    //strXmlStructStart = "<StrategyExeInfo><ExecutionSeq><ExeInfo><SubStrategyExeInfo><StrategyName>" + strStrategyName + "</StrategyName><ExecutionSeq><ExeInfo>";
                    //strXmlStructEnd = "</ExeInfo></ExecutionSeq></SubStrategyExeInfo></ExeInfo></ExecutionSeq></StrategyExeInfo>";
                }
                else
                {
                    nodeStrategyExeInfo = doc.SelectSingleNode("//StrategyExeInfo" + "[StrategyName='" + strStrategyName + "']");
                    if (nodeStrategyExeInfo != null)
                    {
                        nodeExeInfoList = nodeStrategyExeInfo.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                    }
                    else
                    {
                        nodeExeInfoList = doc.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                    }
                    bIsSub = false;
                    //strXmlStructStart = "<StrategyExeInfo><StrategyName>" + strStrategyName + "</StrategyName><ExecutionSeq><ExeInfo>";
                    //strXmlStructEnd = "</ExeInfo></ExecutionSeq></StrategyExeInfo>";
                }
                if (nodeExeInfoList.Count > 0)
                {
                    foreach (XmlNode nodeExeInfo in nodeExeInfoList)
                    {
                        //string strNodeXml = nodeExeInfo.InnerXml;
                        //strXmlResult = SpliteXml(strNodeXml, strStrategyName, bIsSub);

                        string strXmlTmp = SpliteXml(nodeExeInfo, strStrategyName, bIsSub);
                        //strXmlResult += strXmlTmp;
                        strListXml.Add(strXmlTmp);
                    }
                }
                else
                {
                    string strXmlTmp = SpliteXmlNoNode(strStrategyName, strInstanceId, bIsSub);
                    strListXml.Add(strXmlTmp);
                }
            }
            catch (Exception err)
            {
            }
            finally
            {
                doc.RemoveAll();
                doc = null;
            }
            return strListXml;
        }

        public string GetProcessLogXmlNew(string strDebugPath, string[] strArrayStrategyName, string[] strArrayInstanceId, int[] iArrayPriority)
        {
            string strXmlResult = "";
            List<string> strListXmlAll = new List<string>();
            List<string> strListXmlSort = new List<string>();

            List<int> iListPriority = new List<int>(iArrayPriority.ToList());
            List<int> iListSortIndex = new List<int>();

            try
            {
                if (strArrayStrategyName.Length == strArrayInstanceId.Length)
                {
                    for (int i = 0; i < strArrayInstanceId.Length; i++)
                    {
                        List<string> strListXmlSingle = new List<string>();
                        strListXmlSingle = GetProcessLogXmlSingleNewTest(strDebugPath, strArrayStrategyName[i], strArrayInstanceId[i]);
                        if (strListXmlSingle.Count > 1)
                        {
                            int n = 0;
                            foreach (var str in strListXmlSingle)
                            {
                                strListXmlAll.Add(str);
                                if (n > 0)
                                {
                                    iListPriority.Insert(n - 1 + i, iArrayPriority[i]);
                                }
                                n++;
                            }
                        }
                        else
                        {
                            strListXmlAll.Add(strListXmlSingle[0]);
                        }
                    }
                    iListSortIndex = GetSortIndex(iListPriority);
                }

                if (strListXmlAll.Count == iListSortIndex.Count)
                {
                    for (int i = 0; i < iListSortIndex.Count; i++)
                    {
                        strListXmlSort.Add(strListXmlAll[iListSortIndex[i]]);
                    }

                    foreach (var str in strListXmlSort)
                    {
                        strXmlResult += str;
                    }
                }
            }
            catch (Exception err)
            {
            }

            strXmlResult = "<ArrayOfStrategyExeInfo>" + strXmlResult + "</ArrayOfStrategyExeInfo>";
            return strXmlResult;
        }

        private List<structKeyBlockDataSerialize> GetStructKeyBlockDataSingleSerialize(string strDebugPath, string strStrategyName, string strInstanceId)
        {
            List<structKeyBlockDataSerialize> structListKeyBlockDataSerialize = new List<structKeyBlockDataSerialize>();
            structKeyBlockDataSerialize structData = new structKeyBlockDataSerialize();
            structData.OutputId = "";
            structData.SubStrategyName = strStrategyName;
            structData.KeyBlockInstanceId = strInstanceId;
            structData.InputName = new List<string>();
            structData.InputValue = new List<string>();
            structData.OutputName = new List<string>();
            structData.OutputValue = new List<string>();

            List<string> strListInputName = new List<string>();
            List<string> strListInputData = new List<string>();
            List<string> strListOutputName = new List<string>();
            List<string> strListOutputData = new List<string>();

            XmlDocument doc = new XmlDocument();
            try
            {
                string strXml = DebugToXml(strDebugPath);
                doc.LoadXml(strXml);
                //doc.Load(strXmlPath);

                XmlNode nodeStrategyExeInfo = null;
                XmlNodeList nodeExeInfoList = null;

                nodeStrategyExeInfo = doc.SelectSingleNode("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo" + "[StrategyName='" + strStrategyName + "']");
                if (nodeStrategyExeInfo != null)
                {
                    nodeExeInfoList = nodeStrategyExeInfo.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                }
                else
                {
                    nodeStrategyExeInfo = doc.SelectSingleNode("//StrategyExeInfo" + "[StrategyName='" + strStrategyName + "']");
                    if (nodeStrategyExeInfo != null)
                    {
                        nodeExeInfoList = nodeStrategyExeInfo.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                    }
                    else
                    {
                        nodeExeInfoList = doc.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                    }
                }
                if (nodeExeInfoList.Count > 0)
                {
                    foreach (XmlNode nodeExeInfo in nodeExeInfoList)
                    {
                        string strId = "";
                        string strOutputId = "";
                        string strOutputKey = "";
                        string strOutputType = "";

                        strId = nodeExeInfo.SelectSingleNode("child::Id").InnerText;
                        strOutputType = GetOutputType(strId, ref strOutputKey);

                        XmlNodeList nodesInput = nodeExeInfo.SelectNodes("child::Inputs/InputParameter");
                        foreach (XmlNode itemInput in nodesInput)
                        {
                            string strInputXml = itemInput.InnerXml;
                            string strInputName = itemInput.SelectSingleNode("child::Name").InnerText;
                            string strInputData = itemInput.SelectSingleNode("child::Data").InnerText;

                            GetInputValue(strInputData, strInputName, ref strListInputName, ref strListInputData);
                        }

                        XmlNodeList nodesOutput = nodeExeInfo.SelectNodes("child::Output");
                        foreach (XmlNode itemOutput in nodesOutput)
                        {
                            string strOutputData = string.Empty;
                            string strOutputXml = itemOutput.InnerXml;
                            strOutputId = itemOutput.SelectSingleNode("child::Id").InnerText;
                            strOutputData = itemOutput.SelectSingleNode("child::Data").InnerText;

                            bool bIsXml = IsXml(strOutputData);
                            if (bIsXml)
                            {
                                List<string> strListName = new List<string>();
                                List<string> strListData = new List<string>();

                                GetOutputValue(strOutputData, strOutputKey, strOutputType, ref strListName, ref strListData);

                                strListOutputName = new List<string>(strListName);
                                strListOutputData = new List<string>(strListData);
                            }
                        }

                        structData.OutputId = strOutputId;
                        structData.InputName = new List<string>(strListInputName);
                        structData.InputValue = new List<string>(strListInputData);
                        structData.OutputName = new List<string>(strListOutputName);
                        structData.OutputValue = new List<string>(strListOutputData);

                        structListKeyBlockDataSerialize.Add(structData);
                    }
                }
                else
                {
                    structListKeyBlockDataSerialize.Add(structData);
                }
            }
            catch (Exception err)
            {
            }
            finally
            {
                doc.RemoveAll();
                doc = null;
            }


            return structListKeyBlockDataSerialize;
        }

        private structKeyBlockDataSerialize[] GetStructKeyBlockDataSerialize(string strDebugPath, string[] strArrayStrategyName, string[] strArrayInstanceId, int[] iArrayPriority)
        {
            List<structKeyBlockDataSerialize> structListKeyBlockDataSerialize = new List<structKeyBlockDataSerialize>();
            List<structKeyBlockDataSerialize> structListKeyBlockDataSerializeSort = new List<structKeyBlockDataSerialize>();

            List<int> iListPriority = new List<int>(iArrayPriority.ToList());
            List<int> iListSortIndex = new List<int>();

            //structKeyBlockData[] strArrayStructSort = new structKeyBlockData[strArrayInstanceId.Length];
            try
            {
                if (strArrayStrategyName.Length == strArrayInstanceId.Length)
                {

                    for (int i = 0; i < strArrayInstanceId.Length; i++)
                    {
                        List<structKeyBlockDataSerialize> structListKeyBlockData = new List<structKeyBlockDataSerialize>();
                        structListKeyBlockData = GetStructKeyBlockDataSingleSerialize(strDebugPath, strArrayStrategyName[i], strArrayInstanceId[i]);
                        if (structListKeyBlockData.Count > 1)
                        {
                            int n = 0;
                            foreach (var structKeyBlockData in structListKeyBlockData)
                            {
                                structListKeyBlockDataSerialize.Add(structKeyBlockData);
                                if (n > 0)
                                {
                                    iListPriority.Insert(n - 1 + i, iArrayPriority[i]);
                                }
                                n++;
                            }
                        }
                        else
                        {
                            structListKeyBlockDataSerialize.Add(structListKeyBlockData[0]);
                        }
                    }
                    iListSortIndex = GetSortIndex(iListPriority);
                }

                if (structListKeyBlockDataSerialize.Count == iListSortIndex.Count)
                {
                    for (int i = 0; i < iListSortIndex.Count; i++)
                    {
                        structListKeyBlockDataSerializeSort.Add(structListKeyBlockDataSerialize[iListSortIndex[i]]);
                    }
                }
            }
            catch (Exception err)
            {
            }

            //return structListKeyBlockDataAll.ToArray();
            return structListKeyBlockDataSerializeSort.ToArray();
        }

        public string GetProcessLogXmlNewSerialize(string strDebugPath, string[] strArraySubStrategyName, string[] strArrayInstanceId, int[] iArrayPriority)
        {
            string strXmlResult = "";
            List<structKeyBlockDataSerialize> structListKeyBlockDataSerialize = new List<structKeyBlockDataSerialize>();
            try
            {
                structListKeyBlockDataSerialize = GetStructKeyBlockDataSerialize(strDebugPath, strArraySubStrategyName, strArrayInstanceId, iArrayPriority).ToList();

                //strXmlResult = XmlSerializeHelp.Serializer(typeof(List<structKeyBlockData>), structListKeyBlockDataAll);

                strXmlResult = Serializer(typeof(List<structKeyBlockDataSerialize>), structListKeyBlockDataSerialize);
            }
            catch (Exception err)
            {
            }
            //strXmlResult = "<ArrayOfStrategyExeInfo>" + strXmlResult + "</ArrayOfStrategyExeInfo>";

            return strXmlResult;
        }

        public List<structKeyBlockDataSerialize> GetStructKeyBlockDataNewSerialize(string strXml)
        {
            List<structKeyBlockDataSerialize> structListKeyBlockDataAll = new List<structKeyBlockDataSerialize>();
            //structListKeyBlockDataAll = XmlSerializeHelp.Deserialize(typeof(List<structKeyBlockData>), strXml) as List<structKeyBlockData>;
            structListKeyBlockDataAll = Deserialize(typeof(List<structKeyBlockDataSerialize>), strXml) as List<structKeyBlockDataSerialize>;

            return structListKeyBlockDataAll;
        }

        private List<int> GetSortIndex(List<int> iList)
        {
            List<int> iListResult = new List<int>();

            iListResult = iList.Select((item, index) => new { item, index }).OrderBy(a => a.item).Select(a => a.index).ToList();

            //var vList = iList.Select((m, index) => new { index, m }).OrderBy(n => n.m).Take(iList.Count).ToList();
            //foreach (var v in vList)
            //{
            //    iListResult.Add(v.index);
            //}

            return iListResult;
        }

        private string GetProcessLogXmlSingleNew(string strDebugPath, string strStrategyName, string strInstanceId)
        {
            bool bIsSub = false;
            string strXmlResult = "";

            List<string> strListInputName = new List<string>();
            List<string> strListInputData = new List<string>();
            List<string> strListOutputName = new List<string>();
            List<string> strListOutputData = new List<string>();

            XmlDocument doc = new XmlDocument();
            try
            {
                string strXml = DebugToXml(strDebugPath);
                doc.LoadXml(strXml);
                //doc.Load(strXmlPath);

                XmlNode nodeStrategyExeInfo = null;
                XmlNodeList nodeExeInfoList = null;

                nodeStrategyExeInfo = doc.SelectSingleNode("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo" + "[StrategyName='" + strStrategyName + "']");
                if (nodeStrategyExeInfo != null)
                {
                    nodeExeInfoList = nodeStrategyExeInfo.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                    bIsSub = true;
                    //strXmlStructStart = "<StrategyExeInfo><ExecutionSeq><ExeInfo><SubStrategyExeInfo><StrategyName>" + strStrategyName + "</StrategyName><ExecutionSeq><ExeInfo>";
                    //strXmlStructEnd = "</ExeInfo></ExecutionSeq></SubStrategyExeInfo></ExeInfo></ExecutionSeq></StrategyExeInfo>";
                }
                else
                {
                    nodeStrategyExeInfo = doc.SelectSingleNode("//StrategyExeInfo" + "[StrategyName='" + strStrategyName + "']");
                    if (nodeStrategyExeInfo != null)
                    {
                        nodeExeInfoList = nodeStrategyExeInfo.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                    }
                    else
                    {
                        nodeExeInfoList = doc.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                    }
                    bIsSub = false;
                    //strXmlStructStart = "<StrategyExeInfo><StrategyName>" + strStrategyName + "</StrategyName><ExecutionSeq><ExeInfo>";
                    //strXmlStructEnd = "</ExeInfo></ExecutionSeq></StrategyExeInfo>";
                }
                if (nodeExeInfoList.Count > 0)
                {
                    foreach (XmlNode nodeExeInfo in nodeExeInfoList)
                    {
                        //string strNodeXml = nodeExeInfo.InnerXml;
                        //strXmlResult = SpliteXml(strNodeXml, strStrategyName, bIsSub);

                        string strXmlTmp = SpliteXml(nodeExeInfo, strStrategyName, bIsSub);
                        strXmlResult += strXmlTmp;
                    }
                }
                else
                {
                    //strXmlResult = SpliteXmlNoNode(strStrategyName, strInstanceId, bIsSub);
                }
            }
            catch (Exception err)
            {
            }
            finally
            {
                doc.RemoveAll();
                doc = null;
            }
            return strXmlResult;
        }

        private string GetProcessLogXmlNew(string strDebugPath, string[] strArrayStrategyName, string[] strArrayInstanceId)
        {
            string strXmlResult = "";
            try
            {
                if (strArrayStrategyName.Length == strArrayInstanceId.Length)
                {
                    for (int i = 0; i < strArrayInstanceId.Length; i++)
                    {
                        string str = GetProcessLogXmlSingleNew(strDebugPath, strArrayStrategyName[i], strArrayInstanceId[i]);
                        strXmlResult += str;
                    }
                }
            }
            catch (Exception err)
            {
            }

            strXmlResult = "<ArrayOfStrategyExeInfo>" + strXmlResult + "</ArrayOfStrategyExeInfo>";
            return strXmlResult;
        }
        #endregion

        #region Fun Test Old
        private structKeyBlockData GetStructKeyBlockDataSingleTest(string strDebugPath, string strStrategyName, string strInstanceId)
        {
            structKeyBlockData structData = new structKeyBlockData();
            structData.OutputId = "";
            structData.SubStrategyName = strStrategyName;
            structData.KeyBlockInstanceId = strInstanceId;
            structData.InputName = new List<string>();
            structData.InputValue = new List<string>();
            structData.OutputName = new List<string>();
            structData.OutputValue = new List<string>();

            List<string> strListInputName = new List<string>();
            List<string> strListInputData = new List<string>();
            List<string> strListOutputName = new List<string>();
            List<string> strListOutputData = new List<string>();

            XmlDocument doc = new XmlDocument();
            try
            {
                string strXml = DebugToXml(strDebugPath);
                doc.LoadXml(strXml);
                //doc.Load(strXmlPath);

                XmlNode nodeExeInfo = null;
                XmlNodeList nodeStrategyExeInfos = null;
                nodeStrategyExeInfos = doc.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo/StrategyName");
                //nodeStrategyExeInfos = doc.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo/StrategyName"+ "[contains(StrategyName,'" + strStrategyName + "')]");
                //nodeStrategyExeInfos = doc.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo/StrategyName"+ "[contains(StrategyName,'CMP_L2LPostMetrology')]");


                bool bIsSubStrategyName = false;
                if (nodeStrategyExeInfos.Count > 0)
                {
                    foreach (XmlNode node in nodeStrategyExeInfos)
                    {
                        if (node.InnerText.Contains(strStrategyName))
                        {
                            bIsSubStrategyName = true;
                            nodeExeInfo = node.SelectSingleNode("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                            break;
                        }
                    }
                }
                if (!bIsSubStrategyName)
                {
                    bool bStrategyName = false;
                    nodeStrategyExeInfos = doc.SelectNodes("//StrategyExeInfo/StrategyName");
                    if (nodeStrategyExeInfos.Count > 0)
                    {
                        foreach (XmlNode node in nodeStrategyExeInfos)
                        {
                            if (node.InnerText.Contains(strStrategyName))
                            {
                                bStrategyName = true;
                                nodeExeInfo = node.SelectSingleNode("//StrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                                break;
                            }
                        }
                    }
                    if (!bStrategyName)
                    {
                        nodeExeInfo = doc.SelectSingleNode("//StrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                    }
                }

                if (nodeExeInfo != null)
                {
                    string strId = "";
                    string strOutputId = "";
                    string strOutputKey = "";
                    string strOutputType = "";

                    strId = nodeExeInfo.SelectSingleNode("child::Id").InnerText;
                    strOutputType = GetOutputType(strId, ref strOutputKey);

                    XmlNodeList nodesInput = nodeExeInfo.SelectNodes("child::Inputs/InputParameter");
                    foreach (XmlNode itemInput in nodesInput)
                    {
                        string strInputXml = itemInput.InnerXml;
                        string strInputName = itemInput.SelectSingleNode("child::Name").InnerText;
                        string strInputData = itemInput.SelectSingleNode("child::Data").InnerText;

                        GetInputValue(strInputData, strInputName, ref strListInputName, ref strListInputData);
                    }

                    XmlNodeList nodesOutput = nodeExeInfo.SelectNodes("child::Output");
                    foreach (XmlNode itemOutput in nodesOutput)
                    {
                        string strOutputData = string.Empty;
                        string strOutputXml = itemOutput.InnerXml;
                        strOutputId = itemOutput.SelectSingleNode("child::Id").InnerText;
                        strOutputData = itemOutput.SelectSingleNode("child::Data").InnerText;

                        bool bIsXml = IsXml(strOutputData);
                        if (bIsXml)
                        {
                            List<string> strListName = new List<string>();
                            List<string> strListData = new List<string>();

                            GetOutputValue(strOutputData, strOutputKey, strOutputType, ref strListName, ref strListData);

                            strListOutputName = new List<string>(strListName);
                            strListOutputData = new List<string>(strListData);
                        }
                    }

                    structData.OutputId = strOutputId;
                    structData.InputName = new List<string>(strListInputName);
                    structData.InputValue = new List<string>(strListInputData);
                    structData.OutputName = new List<string>(strListOutputName);
                    structData.OutputValue = new List<string>(strListOutputData);
                }
                else
                {

                }
            }
            catch (Exception err)
            {
            }
            finally
            {
                doc.RemoveAll();
                doc = null;
            }

            return structData;
        }

        private structKeyBlockData GetStructKeyBlockDataSingle(string strDebugPath, string strStrategyName, string strInstanceId)
        {
            structKeyBlockData structData = new structKeyBlockData();
            structData.OutputId = "";
            structData.SubStrategyName = strStrategyName;
            structData.KeyBlockInstanceId = strInstanceId;
            structData.InputName = new List<string>();
            structData.InputValue = new List<string>();
            structData.OutputName = new List<string>();
            structData.OutputValue = new List<string>();

            List<string> strListInputName = new List<string>();
            List<string> strListInputData = new List<string>();
            List<string> strListOutputName = new List<string>();
            List<string> strListOutputData = new List<string>();

            XmlDocument doc = new XmlDocument();
            try
            {
                string strXml = DebugToXml(strDebugPath);
                doc.LoadXml(strXml);
                //doc.Load(strXmlPath);

                XmlNode nodeExeInfo = null;
                XmlNode nodeStrategyExeInfo = null;
                nodeStrategyExeInfo = doc.SelectSingleNode("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo" + "[StrategyName='" + strStrategyName + "']");
                if (nodeStrategyExeInfo != null)
                {
                    nodeExeInfo = nodeStrategyExeInfo.SelectSingleNode("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                }
                else
                {
                    nodeStrategyExeInfo = doc.SelectSingleNode("//StrategyExeInfo" + "[StrategyName='" + strStrategyName + "']");
                    if (nodeStrategyExeInfo != null)
                    {
                        nodeExeInfo = nodeStrategyExeInfo.SelectSingleNode("//StrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                    }
                    else
                    {
                        nodeExeInfo = doc.SelectSingleNode("//StrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                    }
                }
                if (nodeExeInfo != null)
                {
                    string strId = "";
                    string strOutputId = "";
                    string strOutputKey = "";
                    string strOutputType = "";

                    strId = nodeExeInfo.SelectSingleNode("child::Id").InnerText;
                    strOutputType = GetOutputType(strId, ref strOutputKey);

                    XmlNodeList nodesInput = nodeExeInfo.SelectNodes("child::Inputs/InputParameter");
                    foreach (XmlNode itemInput in nodesInput)
                    {
                        string strInputXml = itemInput.InnerXml;
                        string strInputName = itemInput.SelectSingleNode("child::Name").InnerText;
                        string strInputData = itemInput.SelectSingleNode("child::Data").InnerText;

                        GetInputValue(strInputData, strInputName, ref strListInputName, ref strListInputData);
                    }

                    XmlNodeList nodesOutput = nodeExeInfo.SelectNodes("child::Output");
                    foreach (XmlNode itemOutput in nodesOutput)
                    {
                        string strOutputData = string.Empty;
                        string strOutputXml = itemOutput.InnerXml;
                        strOutputId = itemOutput.SelectSingleNode("child::Id").InnerText;
                        strOutputData = itemOutput.SelectSingleNode("child::Data").InnerText;

                        bool bIsXml = IsXml(strOutputData);
                        if (bIsXml)
                        {
                            List<string> strListName = new List<string>();
                            List<string> strListData = new List<string>();

                            GetOutputValue(strOutputData, strOutputKey, strOutputType, ref strListName, ref strListData);

                            strListOutputName = new List<string>(strListName);
                            strListOutputData = new List<string>(strListData);
                        }
                    }

                    structData.OutputId = strOutputId;
                    structData.InputName = new List<string>(strListInputName);
                    structData.InputValue = new List<string>(strListInputData);
                    structData.OutputName = new List<string>(strListOutputName);
                    structData.OutputValue = new List<string>(strListOutputData);
                }
                else
                {

                }
            }
            catch (Exception err)
            {
            }
            finally
            {
                doc.RemoveAll();
                doc = null;
            }


            return structData;
        }

        private structKeyBlockData[] GetStructKeyBlockData(string strDebugPath, string[] strArrayStrategyName, string[] strArrayInstanceId, int[] iArrayPriority)
        {
            structKeyBlockData[] strArrayStruct = new structKeyBlockData[strArrayInstanceId.Length];
            structKeyBlockData[] strArrayStructSort = new structKeyBlockData[strArrayInstanceId.Length];
            try
            {
                if (strArrayStrategyName.Length == strArrayInstanceId.Length)
                {
                    for (int i = 0; i < strArrayInstanceId.Length; i++)
                    {
                        structKeyBlockData structData = new structKeyBlockData();
                        structData = GetStructKeyBlockDataSingle(strDebugPath, strArrayStrategyName[i], strArrayInstanceId[i]);
                        strArrayStruct[i] = structData;
                    }
                }
                if (strArrayStruct.Length == iArrayPriority.Length)
                {
                    for (int i = 0; i < iArrayPriority.Length; i++)
                    {
                        strArrayStructSort[i] = strArrayStruct[iArrayPriority[i] - 1];
                    }
                }

            }
            catch (Exception err)
            {
            }

            return strArrayStruct;
            //return strArrayStructSort;
        }

        private string GetProcessLogXmlSingle(string strDebugPath, string strStrategyName, string strInstanceId)
        {
            bool bIsSub = false;
            string strXmlResult = "";
            List<string> strListInputName = new List<string>();
            List<string> strListInputData = new List<string>();
            List<string> strListOutputName = new List<string>();
            List<string> strListOutputData = new List<string>();

            XmlDocument doc = new XmlDocument();
            try
            {
                string strXml = DebugToXml(strDebugPath);
                doc.LoadXml(strXml);
                //doc.Load(strXmlPath);

                XmlNode nodeExeInfo = null;
                XmlNode nodeStrategyExeInfo = null;
                nodeStrategyExeInfo = doc.SelectSingleNode("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo" + "[StrategyName='" + strStrategyName + "']");
                if (nodeStrategyExeInfo != null)
                {
                    nodeExeInfo = nodeStrategyExeInfo.SelectSingleNode("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                    bIsSub = true;
                    //strXmlStructStart = "<StrategyExeInfo><ExecutionSeq><ExeInfo><SubStrategyExeInfo><StrategyName>" + strStrategyName + "</StrategyName><ExecutionSeq><ExeInfo>";
                    //strXmlStructEnd = "</ExeInfo></ExecutionSeq></SubStrategyExeInfo></ExeInfo></ExecutionSeq></StrategyExeInfo>";
                }
                else
                {
                    nodeStrategyExeInfo = doc.SelectSingleNode("//StrategyExeInfo" + "[StrategyName='" + strStrategyName + "']");
                    if (nodeStrategyExeInfo != null)
                    {
                        nodeExeInfo = nodeStrategyExeInfo.SelectSingleNode("//StrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                    }
                    else
                    {
                        nodeExeInfo = doc.SelectSingleNode("//StrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                    }
                    bIsSub = false;
                    //strXmlStructStart = "<StrategyExeInfo><StrategyName>" + strStrategyName + "</StrategyName><ExecutionSeq><ExeInfo>";
                    //strXmlStructEnd = "</ExeInfo></ExecutionSeq></StrategyExeInfo>";
                }
                if (nodeExeInfo != null)
                {
                    //string strNodeXml = nodeExeInfo.InnerXml;
                    //strXmlResult = SpliteXml(strNodeXml, strStrategyName, bIsSub);

                    strXmlResult = SpliteXml(nodeExeInfo, strStrategyName, bIsSub);
                }
            }
            catch (Exception err)
            {
            }
            finally
            {
                doc.RemoveAll();
                doc = null;
            }
            return strXmlResult;
        }

        private string GetProcessLogXml(string strDebugPath, string[] strArrayStrategyName, string[] strArrayInstanceId)
        {
            string strXmlResult = "";
            try
            {
                if (strArrayStrategyName.Length == strArrayInstanceId.Length)
                {
                    for (int i = 0; i < strArrayInstanceId.Length; i++)
                    {
                        string str = GetProcessLogXmlSingle(strDebugPath, strArrayStrategyName[i], strArrayInstanceId[i]);
                        strXmlResult += str;
                    }
                }
            }
            catch (Exception err)
            {
            }

            strXmlResult = "<ArrayOfStrategyExeInfo>" + strXmlResult + "</ArrayOfStrategyExeInfo>";
            return strXmlResult;
        }
        #endregion

        #region SpliteXml
        private string SpliteXmlNoNode(string strStrategyName, string strInstanceId, bool bIsSub)
        {
            string Temp = string.Empty;
            StringBuilder sb = new StringBuilder();
            string strXmlResult = "";
            string strXmlStructStart = "";
            string strXmlStructEnd = "";
            try
            {
                if (bIsSub)
                {
                    strXmlStructStart = "<StrategyExeInfo><ExecutionSeq><ExeInfo><SubStrategyExeInfo><StrategyName>" + strStrategyName + "</StrategyName><ExecutionSeq><ExeInfo>";
                    strXmlStructEnd = "</ExeInfo></ExecutionSeq></SubStrategyExeInfo></ExeInfo></ExecutionSeq></StrategyExeInfo>";
                }
                else
                {
                    strXmlStructStart = "<StrategyExeInfo><StrategyName>" + strStrategyName + "</StrategyName><ExecutionSeq><ExeInfo>";
                    strXmlStructEnd = "</ExeInfo></ExecutionSeq></StrategyExeInfo>";
                }

                sb.Append(strXmlStructStart);
                sb.Append("<Id></Id><InstanceId>" + strInstanceId + "</InstanceId><Inputs/><Output><Id/><Data/></Output>");
                sb.Append(strXmlStructEnd);

                strXmlResult = sb.ToString();
                //bool bIsXml = IsXml(strResult);
            }
            catch (Exception err)
            {
            }

            return strXmlResult;
        }

        private string SpliteXml(XmlNode nodeExeInfo, string strStrategyName, bool bIsSub)
        {
            string Temp = string.Empty;
            StringBuilder sb = new StringBuilder();
            string strXmlResult = "";
            string strXmlStructStart = "";
            string strXmlStructEnd = "";
            try
            {
                if (bIsSub)
                {
                    strXmlStructStart = "<StrategyExeInfo><ExecutionSeq><ExeInfo><SubStrategyExeInfo><StrategyName>" + strStrategyName + "</StrategyName><ExecutionSeq><ExeInfo>";
                    strXmlStructEnd = "</ExeInfo></ExecutionSeq></SubStrategyExeInfo></ExeInfo></ExecutionSeq></StrategyExeInfo>";
                }
                else
                {
                    strXmlStructStart = "<StrategyExeInfo><StrategyName>" + strStrategyName + "</StrategyName><ExecutionSeq><ExeInfo>";
                    strXmlStructEnd = "</ExeInfo></ExecutionSeq></StrategyExeInfo>";
                }

                sb.Append(strXmlStructStart);
                if (nodeExeInfo == null)
                {
                    //sb.Append("<Id></Id><InstanceId></InstanceId><Inputs/><Output><Id/><Data/></Output>");
                }
                else
                {
                    foreach (XmlNode item in nodeExeInfo.ChildNodes)
                    {
                        if (item.Name == "Id")
                        {
                            Temp = item.OuterXml;
                            sb.Append(Temp);
                        }
                        if (item.Name == "InstanceId")
                        {
                            Temp = item.OuterXml;
                            sb.Append(Temp);
                        }
                        if (item.Name == "Inputs")
                        {
                            Temp = item.OuterXml;
                            sb.Append(Temp);
                        }
                        if (item.Name == "Output")
                        {
                            Temp = item.OuterXml;
                            sb.Append(Temp);
                        }
                    }
                }
                
                sb.Append(strXmlStructEnd);
                strXmlResult = sb.ToString();
                //bool bIsXml = IsXml(strResult);
            }
            catch (Exception err)
            {
            }

            return strXmlResult;
        }

        private string SpliteXml(string strNodeXml, string strStrategyName, bool bIsSub)
        {
            string strResult = "";
            string strStructStart = "";
            string strStructEnd = "";
            try
            {
                if (bIsSub)
                {
                    strStructStart = "<StrategyExeInfo><ExecutionSeq><ExeInfo><SubStrategyExeInfo><StrategyName>" + strStrategyName + "</StrategyName><ExecutionSeq><ExeInfo>";
                    strStructEnd = "</ExeInfo></ExecutionSeq></SubStrategyExeInfo></ExeInfo></ExecutionSeq></StrategyExeInfo>";
                }
                else
                {
                    strStructStart = "<StrategyExeInfo><StrategyName>" + strStrategyName + "</StrategyName><ExecutionSeq><ExeInfo>";
                    strStructEnd = "</ExeInfo></ExecutionSeq></StrategyExeInfo>";
                }

                if (strNodeXml.Equals(""))
                {
                    strResult = strStructStart + "<Inputs/><Output><Id>" + "</Id><Data></Data><Output>" + strStructEnd;
                }
                else
                {
                    string strTmp = "";
                    strTmp = strNodeXml.Substring(strNodeXml.IndexOf("<Id>"), strNodeXml.IndexOf("</InstanceId>") - strNodeXml.IndexOf("<Id>"));
                    strTmp += "</InstanceId>";
                    strResult = strStructStart + strTmp;

                    strTmp = strNodeXml.Substring(strNodeXml.IndexOf("<Inputs"), strNodeXml.IndexOf("</Output>") - strNodeXml.IndexOf("<Inputs"));
                    strTmp += "</Output>";
                    strResult = strResult + strTmp + strStructEnd;
                }
                //bool bIsXml = IsXml(strResult);
            }
            catch (Exception err)
            {
            }

            return strResult;
        }

        private structKeyBlockData GetStructKeyBlockDataTest(string strXml, string strStrategyName, string strInstanceId)
        {
            structKeyBlockData structData = new structKeyBlockData();
            structData.OutputId = "";
            structData.SubStrategyName = strStrategyName;
            structData.KeyBlockInstanceId = strInstanceId;
            structData.InputName = new List<string>();
            structData.InputValue = new List<string>();
            structData.OutputName = new List<string>();
            structData.OutputValue = new List<string>();

            List<string> strListInputName = new List<string>();
            List<string> strListInputData = new List<string>();
            List<string> strListOutputName = new List<string>();
            List<string> strListOutputData = new List<string>();

            XmlDocument doc = new XmlDocument();
            try
            {
                doc.LoadXml(strXml);
                //doc.Load(strXmlPath);

                XmlNode nodeExeInfo = null;
                XmlNode nodeStrategyExeInfo = null;
                nodeStrategyExeInfo = doc.SelectSingleNode("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo" + "[StrategyName='" + strStrategyName + "']");
                if (nodeStrategyExeInfo != null)
                {
                    nodeExeInfo = nodeStrategyExeInfo.SelectSingleNode("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                }
                else
                {
                    nodeStrategyExeInfo = doc.SelectSingleNode("//StrategyExeInfo" + "[StrategyName='" + strStrategyName + "']");
                    if (nodeStrategyExeInfo != null)
                    {
                        nodeExeInfo = nodeStrategyExeInfo.SelectSingleNode("//StrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                    }
                    else
                    {
                        nodeExeInfo = doc.SelectSingleNode("//StrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                    }
                }
                if (nodeExeInfo != null)
                {
                    string strId = "";
                    string strOutputId = "";
                    string strOutputKey = "";
                    string strOutputType = "";

                    strId = nodeExeInfo.SelectSingleNode("child::Id").InnerText;
                    strOutputType = GetOutputType(strId, ref strOutputKey);

                    XmlNodeList nodesInput = nodeExeInfo.SelectNodes("child::Inputs/InputParameter");
                    foreach (XmlNode itemInput in nodesInput)
                    {
                        string strInputXml = itemInput.InnerXml;
                        string strInputName = itemInput.SelectSingleNode("child::Name").InnerText;
                        string strInputData = itemInput.SelectSingleNode("child::Data").InnerText;

                        GetInputValue(strInputData, strInputName, ref strListInputName, ref strListInputData);
                    }

                    XmlNodeList nodesOutput = nodeExeInfo.SelectNodes("child::Output");
                    foreach (XmlNode itemOutput in nodesOutput)
                    {
                        string strOutputData = string.Empty;
                        string strOutputXml = itemOutput.InnerXml;
                        strOutputId = itemOutput.SelectSingleNode("child::Id").InnerText;
                        strOutputData = itemOutput.SelectSingleNode("child::Data").InnerText;

                        bool bIsXml = IsXml(strOutputData);
                        if (bIsXml)
                        {
                            List<string> strListName = new List<string>();
                            List<string> strListData = new List<string>();

                            GetOutputValue(strOutputData, strOutputKey, strOutputType, ref strListName, ref strListData);

                            strListOutputName = new List<string>(strListName);
                            strListOutputData = new List<string>(strListData);
                        }
                    }

                    structData.OutputId = strOutputId;
                    structData.InputName = new List<string>(strListInputName);
                    structData.InputValue = new List<string>(strListInputData);
                    structData.OutputName = new List<string>(strListOutputName);
                    structData.OutputValue = new List<string>(strListOutputData);
                }
                else
                {

                }
            }
            catch (Exception err)
            {
            }
            finally
            {
                doc.RemoveAll();
                doc = null;
            }


            return structData;
        }
        #endregion

        #region Get InputValue
        private void GetInputValue(string strXml, string strNodeName, ref List<string> strListName, ref List<string> strListData)
        {
            string strValue = string.Empty;
            bool bIsXml = IsXml(strXml);
            if (bIsXml)
            {
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(strXml);

                //使用xPath选择需要的节点
                XmlNodeList subNodes = doc.SelectNodes("child::*");//ParametersOutput;
                foreach (XmlNode item in subNodes)
                {
                    GetInputSubNodeValue(item, strNodeName, ref strListName, ref strListData);
                }
            }
            else
            {
                strListName.Add(strNodeName);
                strListData.Add(strXml);
            }
        }

        private void GetInputSubNodeValue(XmlNode subNode, string strInputName, ref List<string> strListName, ref List<string> strListData)
        {
            string strValue = string.Empty;
            string strName = subNode.Name;

            XmlNodeList nodes = subNode.SelectNodes("child::*");
            if (nodes.Count > 0)
            {
                int i = 0;
                foreach (XmlNode item in nodes)
                {
                    i++;
                    strListName.Add(strInputName + "." + i);
                    //strListName.Add(strInputName + "-" + strName + "." + i);
                    strListData.Add(item.InnerText);
                }
            }
            else
            {
                strListName.Add(strInputName + "-" + strName);
                strListData.Add(subNode.InnerText);
            }
        }
        #endregion

        #region Get OutputValue
        private void GetOutputValue(string strXml, string strOutputNode, string strOutputType, ref List<string> strListName, ref List<string> strListData)
        {
            try
            {
                strListName.Clear();
                strListData.Clear();

                List<string> strListNameTmp = new List<string>();
                List<string> strListDataTmp = new List<string>();

                XmlDocument doc = new XmlDocument();
                doc.LoadXml(strXml);

                //使用xPath选择需要的节点
                XmlNodeList nodes = null;
                if (strOutputType.Equals("Unspecified"))
                {
                    nodes = doc.SelectNodes("child::*");
                    if (nodes.Count > 0)
                    {
                        GetOutputDataUnspecified(nodes, ref strListName, ref strListData);
                    }
                }
                else if (strOutputType.Equals("Param"))
                {
                    int type = 0;
                    nodes = doc.SelectNodes(strOutputNode); //strOutputNode = "//Context"
                    if (nodes.Count > 0)
                    {
                        type = 1;
                        //GetOutputDataParam(nodes, ref strListName, ref strListData);
                        GetOutputData(nodes, strOutputType, ref strListName, ref strListData);
                    }

                    nodes = doc.SelectNodes("//ParametersOutput");
                    if (nodes.Count > 0)
                    {
                        type = 2;
                        //GetOutputDataParam(nodes, ref strListNameTmp, ref strListDataTmp);
                        GetOutputData(nodes, strOutputType, ref strListNameTmp, ref strListDataTmp);//by zqk modify 20181226
                    }
                    if (type == 2)
                    {
                        for (int i = 0; i < strListNameTmp.Count; i++)
                        {
                            strListName.Add(strListNameTmp[i]);
                            strListData.Add(strListDataTmp[i]);
                        }
                    }
                    else if (type == 0)//ParameterBlockResult
                    {
                        nodes = doc.SelectNodes("//ParameterBlockResult");

                        if (nodes.Count > 0)
                        {
                            GetOutputData(nodes, strOutputType, ref strListName, ref strListData);
                        }
                    }
                }
                else if (strOutputType.Equals("Invoke"))
                {
                    nodes = doc.SelectNodes("child::*");
                    if (nodes.Count > 0)
                    {
                        GetOutputDataInvoke(nodes, ref strListName, ref strListData);
                    }
                }
                else //Controller   Special Specified
                {
                    nodes = doc.SelectNodes(strOutputNode);

                    if (nodes.Count > 0)
                    {
                        GetOutputData(nodes, strOutputType, ref strListName, ref strListData);
                    }
                }
            }
            catch (Exception err)
            {

            }
        }

        #region GetOutputData
        private void GetOutputData(XmlNodeList nodes, string strSpecial, ref List<string> strListName, ref List<string> strListData)
        {
            try
            {
                if (nodes.Count > 0)
                {
                    strListName.Clear();
                    strListData.Clear();
                    foreach (XmlNode item in nodes)
                    {
                        XmlNodeList nodes2 = item.SelectNodes("child::*");
                        if (nodes2.Count > 0)
                        {
                            foreach (XmlNode item2 in nodes2)
                            {
                                switch (strSpecial)
                                {
                                    case "Specified":
                                        GetSubNodeDataSpecified(item2, ref strListName, ref strListData);
                                        break;
                                    case "Param":
                                        GetSubNodeDataParam(item2, ref strListName, ref strListData);
                                        break;
                                    case "Controller":
                                        GetSubNodeDataController(item2, ref strListName, ref strListData);
                                        break;
                                    case "Special":
                                        //GetSubNodeDataSpecial(item2, ref strListName, ref strListData);
                                        GetSubNodeDataSpecial(item2, item2.Name, ref strListName, ref strListData);
                                        break;
                                    default:
                                        break;
                                }
                            }
                        }
                        else
                        {
                            string strName = item.Name;
                            strListName.Add(strName);

                            string strValue = item.InnerText;
                            strListData.Add(strValue);
                        }
                    }
                }
            }
            catch (Exception err)
            {

            }
        }
        #endregion

        #region Unspecified
        private void GetOutputDataUnspecified(XmlNodeList nodes, ref List<string> strListName, ref List<string> strListData)
        {
            try
            {
                if (nodes.Count > 0)
                {
                    strListName.Clear();
                    strListData.Clear();
                    foreach (XmlNode item in nodes)
                    {
                        XmlNodeList nodes2 = item.SelectNodes("child::*");
                        if (nodes2.Count > 0)
                        {
                            int i = 0;
                            foreach (XmlNode item2 in nodes2)
                            {
                                i++;
                                GetSubNodeDataUnspecified(item2, item.Name + "." + i, ref strListName, ref strListData);
                            }
                        }
                        else
                        {
                            string strName = item.Name;
                            strListName.Add(strName);

                            string strValue = item.InnerText;
                            strListData.Add(strValue);
                        }
                    }
                }
            }
            catch (Exception ee)
            {

            }
        }

        private void GetSubNodeDataUnspecified(XmlNode subNode, string strNodeName, ref List<string> strListName, ref List<string> strListData)
        {
            string strValue = string.Empty;
            string strName = subNode.Name;

            XmlNodeList nodes = subNode.SelectNodes("child::*");
            if (nodes.Count > 0)
            {
                int i = 0;
                foreach (XmlNode item in nodes)
                {
                    i++;
                    strListName.Add(strNodeName + "." + i);
                    //strListName.Add(strName + "." + i);
                    strListData.Add(item.InnerText);
                }
            }
            else
            {
                strListName.Add(strNodeName);
                //strListName.Add(strName);
                strListData.Add(subNode.InnerText);
            }
        }
        #endregion

        #region Specified
        private void GetOutputDataSpecified(XmlNodeList nodes, ref List<string> strListName, ref List<string> strListData)
        {
            try
            {
                if (nodes.Count > 0)
                {
                    strListName.Clear();
                    strListData.Clear();
                    foreach (XmlNode item in nodes)
                    {
                        XmlNodeList nodes2 = item.SelectNodes("child::*");
                        if (nodes2.Count > 0)
                        {
                            foreach (XmlNode item2 in nodes2)
                            {
                                GetSubNodeDataSpecified(item2, ref strListName, ref strListData);
                            }
                        }
                        else
                        {
                            string strName = item.Name;
                            strListName.Add(strName);

                            string strValue = item.InnerText;
                            strListData.Add(strValue);
                        }
                    }
                }
            }
            catch (Exception err)
            {

            }
        }

        private void GetSubNodeDataSpecified(XmlNode subNode, ref List<string> strListName, ref List<string> strListData)
        {
            string strValue = string.Empty;
            string strName = subNode.Name;

            XmlNodeList nodes = subNode.SelectNodes("child::*");
            if (nodes.Count > 0)
            {
                int i = 0;
                foreach (XmlNode item in nodes)
                {
                    i++;
                    strListName.Add(strName + "." + i);
                    strListData.Add(item.InnerText);
                }
            }
            else
            {
                strListName.Add(strName);
                strListData.Add(subNode.InnerText);
            }
        }
        #endregion

        #region Param
        private void GetOutputDataParam(XmlNodeList nodes, ref List<string> strListName, ref List<string> strListData)
        {
            try
            {
                if (nodes.Count > 0)
                {
                    strListName.Clear();
                    strListData.Clear();
                    foreach (XmlNode item in nodes)
                    {
                        XmlNodeList nodes2 = item.SelectNodes("child::*");
                        if (nodes2.Count > 0)
                        {
                            foreach (XmlNode item2 in nodes2)
                            {
                                GetSubNodeDataParam(item2, ref strListName, ref strListData);
                            }
                        }
                        else
                        {
                            string strName = item.Name;
                            strListName.Add(strName);

                            string strValue = item.InnerText;
                            strListData.Add(strValue);
                        }
                    }
                }
            }
            catch (Exception err)
            {

            }
        }

        private void GetSubNodeDataParam(XmlNode subNode, ref List<string> strListName, ref List<string> strListData)
        {
            string strValue = string.Empty;
            string strName = subNode.Name;

            XmlNodeList nodes = subNode.SelectNodes("child::*");
            if (nodes.Count > 0)
            {
                int i = 0;
                foreach (XmlNode item in nodes)
                {
                    i++;
                    strListName.Add(strName + "." + i);
                    strListData.Add(item.InnerText);
                }
            }
            else
            {
                strListName.Add(strName);
                strListData.Add(subNode.InnerText);
            }
        }
        #endregion

        #region Controller
        private void GetOutputDataController(XmlNodeList nodes, ref List<string> strListName, ref List<string> strListData)
        {
            try
            {
                if (nodes.Count > 0)
                {
                    strListName.Clear();
                    strListData.Clear();
                    foreach (XmlNode item in nodes)
                    {
                        XmlNodeList nodes2 = item.SelectNodes("child::*");
                        if (nodes2.Count > 0)
                        {
                            foreach (XmlNode item2 in nodes2)
                            {
                                GetSubNodeDataController(item2, ref strListName, ref strListData);
                            }
                        }
                        else
                        {
                            string strName = item.Name;
                            strListName.Add(strName);

                            string strValue = item.InnerText;
                            strListData.Add(strValue);
                        }
                    }
                }
            }
            catch (Exception err)
            {

            }
        }

        private void GetSubNodeDataController(XmlNode subNode, ref List<string> strListName, ref List<string> strListData)
        {
            bool flag = false;
            string strValue = string.Empty;
            string strName = subNode.Name;

            if (strName.Equals("Value"))
            {
                flag = false;
                strName = "uReccommended";
            }
            else if (strName.Equals("Optimization"))
            {
                flag = true;
            }

            XmlNodeList nodes = subNode.SelectNodes("child::*");
            if (nodes.Count > 0)
            {
                int i = 0;
                foreach (XmlNode item in nodes)
                {
                    i++;
                    if (flag)
                    {
                        strName = item.Name;
                        strListName.Add(strName);
                        strListData.Add(item.InnerText);
                    }
                    else
                    {
                        strListName.Add(strName + "." + i);
                        strListData.Add(item.InnerText);
                    }
                }
            }
            else
            {
                strListName.Add(strName);
                strListData.Add(subNode.InnerText);
            }
        }
        #endregion

        #region Invoke
        private void GetOutputDataInvoke(XmlNodeList nodes, ref List<string> strListName, ref List<string> strListData)
        {
            try
            {
                if (nodes.Count > 0)
                {
                    strListName.Clear();
                    strListData.Clear();
                    foreach (XmlNode item in nodes)
                    {
                        XmlNodeList nodes2 = item.SelectNodes("child::*");
                        if (nodes2.Count > 0)
                        {
                            int i = 0;
                            foreach (XmlNode item2 in nodes2)
                            {
                                i++;
                                GetSubNodeDataInvoke(item2, item.Name + "." + i, ref strListName, ref strListData);
                            }
                        }
                        else
                        {
                            strListName.Add(item.Name);
                            strListData.Add(item.InnerText);
                        }
                    }
                }
            }
            catch (Exception ee)
            {

            }
        }

        private void GetSubNodeDataInvoke(XmlNode subNode, string strNodeName, ref List<string> strListName, ref List<string> strListData)
        {
            string strValue = string.Empty;
            string strName = subNode.Name;

            XmlNodeList nodes = subNode.SelectNodes("child::*");
            if (nodes.Count > 0)
            {
                int i = 0;
                foreach (XmlNode item in nodes)
                {
                    i++;
                    if (item.Name.Equals("string") || item.Name.Equals("double") || item.Name.Equals("int"))
                    {
                        strListName.Add(strName + "." + i);
                    }
                    else
                    {
                        string strOutXml = GetOutputNameSpecial(item.OuterXml);
                        strListName.Add("<" + strName + ">" + "." + strOutXml);
                    }
                    strListData.Add(item.InnerText);
                }

                return;
            }
            else if (strName.Equals("string") || strName.Equals("double") || strName.Equals("int"))
            {
                strListName.Add(strNodeName);
                strListData.Add(subNode.InnerText);
            }
            else
            {
                strListName.Add(strName);
                strListData.Add(subNode.InnerText);
            }
        }
        #endregion

        #region Special (Model/R2R_Read/StateEst)
        private void GetOutputDataSpecial(XmlNodeList nodes, ref List<string> strListName, ref List<string> strListData)
        {
            try
            {
                if (nodes.Count > 0)
                {
                    strListName.Clear();
                    strListData.Clear();
                    foreach (XmlNode item in nodes)
                    {
                        XmlNodeList nodes2 = item.SelectNodes("child::*");
                        if (nodes2.Count > 0)
                        {
                            foreach (XmlNode item2 in nodes2)
                            {
                                //GetSubNodeDataSpecial(item2, ref strListName, ref strListData);
                                GetSubNodeDataSpecial(item2, item2.Name, ref strListName, ref strListData);
                            }
                        }
                        else
                        {
                            strListName.Add(item.Name);
                            strListData.Add(item.InnerText);
                        }
                    }
                }
            }
            catch (Exception err)
            {

            }
        }

        private void GetSubNodeDataSpecial(XmlNode subNode, ref List<string> strListName, ref List<string> strListData)
        {
            string strValue = string.Empty;
            string strName = subNode.Name;

            XmlNodeList nodes = subNode.SelectNodes("child::*");
            if (nodes.Count > 0)
            {
                int i = 0;
                foreach (XmlNode item in nodes)
                {
                    i++;
                    XmlNodeList subItems = item.SelectNodes("child::*");
                    if (subItems.Count > 0)
                    {
                        int n = 0;
                        string strSubName = item.Name;
                        foreach (XmlNode subItem in subItems)
                        {
                            n++;
                            if (subItem.Name.Equals("string") || subItem.Name.Equals("double") || subItem.Name.Equals("int"))
                            {
                                strListName.Add("<" + strName + ">" + "." + "<" + strSubName + ">" + "." + n);
                            }
                            else
                            {
                                string strOutXml = GetOutputNameSpecial(item.OuterXml);
                                strListName.Add("<" + strName + ">" + "." + strOutXml);
                            }
                            strListData.Add(subItem.InnerText);
                        }
                    }
                    else
                    {
                        if (item.Name.Equals("string") || item.Name.Equals("double") || item.Name.Equals("int"))
                        {
                            strListName.Add(strName + "." + i);
                        }
                        else
                        {
                            string strOutXml = GetOutputNameSpecial(item.OuterXml);
                            strListName.Add("<" + strName + ">" + "." + strOutXml);
                        }
                        strListData.Add(item.InnerText);
                    }
                }

                return;
            }
            else
            {
                strListName.Add(strName);
                strListData.Add(subNode.InnerText);
            }
        }

        private void GetSubNodeDataSpecial(XmlNode subNode, string strSubNodeName, ref List<string> strListName, ref List<string> strListData)
        {
            string strValue = string.Empty;

            XmlNodeList nodes = subNode.SelectNodes("child::*");
            if (nodes.Count > 0)
            {
                int i = 0;
                foreach (XmlNode item in nodes)
                {
                    i++;
                    XmlNodeList subItems = item.SelectNodes("child::*");
                    if (subItems.Count > 0)
                    {
                        string strSubName = "<" + strSubNodeName + ">" + "." + "<" + item.Name + ">";
                        GetSubNodeDataSpecial(item, strSubName, ref strListName, ref strListData);
                    }
                    else
                    {
                        if (item.Name.Equals("string") || item.Name.Equals("double") || item.Name.Equals("int"))
                        {
                            strListName.Add(strSubNodeName + "." + i);
                        }
                        else
                        {
                            string strOutXml = GetOutputNameSpecial(item.OuterXml);
                            strListName.Add("<" + strSubNodeName + ">" + "." + strOutXml);
                        }
                        strListData.Add(item.InnerText);
                    }
                }

                return;
            }
            else
            {
                strListName.Add(strSubNodeName);
                strListData.Add(subNode.InnerText);
            }
        }

        private string GetOutputNameSpecial(string strOutXml)
        {
            string strName = "";
            if (strOutXml.Contains("</"))
            {
                strOutXml = strOutXml.Substring(0, strOutXml.IndexOf("</") - 1);
                strOutXml = strOutXml.Substring(0, strOutXml.LastIndexOf(">") + 1);

                strName = strOutXml.Replace(">", ">.");
                strName = strName.TrimEnd('.');
            }
            if (strName.Contains(".<string>"))
            {
                strName = strName.Replace(".<string>", "");
            }
            if (strName.Contains(".<double>"))
            {
                strName = strName.Replace(".<double>", "");
            }
            if (strName.Contains(".<int>"))
            {
                strName = strName.Replace(".<int>", "");
            }
            return strName;
        }

        private List<string> GetOutputDataSpecial(string strOutXml)
        {
            string str = string.Empty;
            List<string> strList = new List<string>();
            if (strOutXml.Contains("</string>"))
            {
                str = strOutXml.Replace("", "<string>");
                str = strOutXml.Replace(";", "</string>");
            }
            if (strOutXml.Contains("</doule>"))
            {
                str = strOutXml.Replace("", "<double>");
                str = strOutXml.Replace(";", "</double>");
            }
            if (strOutXml.Contains("</int>"))
            {
                str = strOutXml.Replace("", "<int>");
                str = strOutXml.Replace(";", "</int>");
            }
            string[] strSplit = str.Split(';');
            strList = strSplit.ToList();
            return strList;
        }

        #endregion

        #endregion

        #region Old
        private int GetStrCount(List<string> strList, string strKey)
        {
            int n = 0;
            if (strList.Contains(strKey))
            {
                foreach (var str in strList)
                {
                    if (str.Equals(strKey))
                    {
                        n++;
                    }
                }
            }

            return n;
        }

        private structKeyBlockData GetStructKeyBlockDataOld(string strDebugPath, string strId, string strInstanceId)
        {
            structKeyBlockData structData = new structKeyBlockData();
            structData.KeyBlockInstanceId = strInstanceId;
            structData.SubStrategyName = strId;
            structData.OutputId = "";
            structData.InputName = new List<string>();
            structData.InputValue = new List<string>();
            structData.OutputName = new List<string>();
            structData.OutputValue = new List<string>();


            string strOutputKey = "";
            string strOutputType = "";
            strOutputType = GetOutputType(strId, ref strOutputKey);

            string strOutputId = "";
            string strOutputData = string.Empty;


            List<string> strListInputName = new List<string>();
            List<string> strListInputData = new List<string>();
            List<string> strListOutputName = new List<string>();
            List<string> strListOutputData = new List<string>();

            XmlDocument doc = new XmlDocument();
            try
            {
                string strXml = DebugToXml(strDebugPath);
                doc.LoadXml(strXml);
                //doc.Load(strXmlPath);

                //使用xPath选择需要的节点
                XmlNodeList nodes = doc.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo" + "[Id='" + strId + "']");

                if (nodes.Count < 1)
                {
                    nodes = doc.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo/ExecutionSeq/ExeInfo" + "[Id='" + strId + "']");
                }

                int n = 0;
                List<string> strListInstanceId = new List<string>();
                List<string> strListInstanceIdTmp = new List<string>();
                foreach (XmlNode item in nodes)
                {
                    processLogXml = item.InnerXml;
                    string strInstanceIdKey = item.SelectSingleNode("child::InstanceId").InnerText;
                    string strInstanceIdTmp = strInstanceIdKey;
                    if (strListInstanceId.Contains(strInstanceIdKey))
                    {

                        n = GetStrCount(strListInstanceIdTmp, strInstanceIdKey);
                        if (n != 0)
                        {
                            strInstanceIdKey += "-" + n;
                        }
                    }
                    strListInstanceId.Add(strInstanceIdKey);
                    strListInstanceIdTmp.Add(strInstanceIdTmp);

                    if (strInstanceId.Equals(strInstanceIdKey))
                    {
                        XmlNodeList nodesInput = item.SelectNodes("child::Inputs/InputParameter");

                        foreach (XmlNode itemInput in nodesInput)
                        {
                            string strInputXml = itemInput.InnerXml;
                            string strInputName = itemInput.SelectSingleNode("child::Name").InnerText;
                            string strInputData = itemInput.SelectSingleNode("child::Data").InnerText;

                            GetInputValue(strInputData, strInputName, ref strListInputName, ref strListInputData);

                            structData.InputName = new List<string>(strListInputName);
                            structData.InputValue = new List<string>(strListInputData);
                        }

                        XmlNodeList nodesOutput = item.SelectNodes("child::Output");
                        foreach (XmlNode itemOutput in nodesOutput)
                        {
                            string strOutputXml = itemOutput.InnerXml;
                            strOutputId = itemOutput.SelectSingleNode("child::Id").InnerText;
                            strOutputData = itemOutput.SelectSingleNode("child::Data").InnerText;

                            bool bIsXml = IsXml(strOutputData);
                            if (bIsXml)
                            {
                                List<string> strListName = new List<string>();
                                List<string> strListData = new List<string>();

                                GetOutputValue(strOutputData, strOutputKey, strOutputType, ref strListName, ref strListData);

                                strListOutputName = new List<string>(strListName);
                                strListOutputData = new List<string>(strListData);
                            }
                        }
                        structData.OutputId = strOutputId;
                        structData.OutputName = new List<string>(strListOutputName);
                        structData.OutputValue = new List<string>(strListOutputData);
                        break;
                    }
                    else
                    {
                        continue;
                    }
                }
            }
            catch (Exception err)
            {
            }
            finally
            {
                doc.RemoveAll();
                doc = null;
            }


            return structData;
        }

        //public List<structKeyBlockData> GetStructKeyBlockDataOld(string strDebugPath, string[] strArrayId, string[] strArrayInstanceId, int[] iArrayPriority)
        //{
        //    List<structKeyBlockData> strListStruct = new List<structKeyBlockData>();

        //    structKeyBlockData structData = new structKeyBlockData();
        //    for (int i = 0; i < strArrayInstanceId.Length; i++)
        //    {
        //        structData = GetStructKeyBlockData(strDebugPath, strArrayId[i], strArrayInstanceId[i]);
        //        strListStruct.Add(structData);
        //    }
        //    return strListStruct;
        //}

        private structKeyBlockData[] GetStructKeyBlockDataOld(string strDebugPath, string[] strArrayId, string[] strArrayInstanceId, int[] iArrayPriority)
        {
            structKeyBlockData[] strArrayStruct=new structKeyBlockData[strArrayInstanceId.Length];

            for (int i = 0; i < strArrayInstanceId.Length; i++)
            {
                structKeyBlockData structData = new structKeyBlockData();
                structData = GetStructKeyBlockDataOld(strDebugPath, strArrayId[i], strArrayInstanceId[i]);
                strArrayStruct[i] = structData;
            }
            return strArrayStruct;
        }

        private string InputListToXml(List<string> strListName, List<string> strListValue)
        {
            string str = "";
            str = "<InputData>";
            if (strListName.Count < 1)
            {
                str += "<Data><InputName></InputName><InputValue></InputValue></Data>";
            }
            for (int i = 0; i < strListName.Count; i++)
            {
                str += "<Data><InputName>" + strListName[i] + "</InputName>" + "<InputValue>" + strListValue[i] + "</InputValue>" + "</Data>";
            }
            str += "</InputData>";
            return str;
        }

        private string OutputListToXml(List<string> strListName, List<string> strListValue, string strOutputId)
        {
            string str = "";
            str = "<OutputData><OutputId>" + strOutputId + "</OutputId>";
            if (strListName.Count < 1)
            {
                str += "<Data><OutputName></OutputName><OutputValue></OutputValue></Data>";
            }
            for (int i = 0; i < strListName.Count; i++)
            {
                str += "<Data><OutputName>" + strListName[i] + "</OutputName>" + "<OutputValue>" + strListValue[i] + "</OutputValue>" + "</Data>";
            }
            str += "</OutputData>";
            return str;
        }

        private string GetProcessLogXmlOld(string strDebugPath, string strId, string strInstanceId)
        {
            structKeyBlockData structData = new structKeyBlockData();
            structData = GetStructKeyBlockDataOld(strDebugPath, strId, strInstanceId);
            string strTmp = "";
            string str = "<KeyBlockData><KeyBlockInstanceId>" + structData.KeyBlockInstanceId + "</KeyBlockInstanceId><SubStrategyName>" + structData.SubStrategyName + "</SubStrategyName>";
            strTmp = InputListToXml(structData.InputName, structData.InputValue);
            str += strTmp;
            strTmp = OutputListToXml(structData.OutputName, structData.OutputValue, structData.OutputId);
            str += strTmp;
            str += "<KeyBlockData>";

            return str;
        }

        private string GetProcessLogXmlOld(structKeyBlockData structData)
        {
            string strTmp = "";
            string str = "<KeyBlockData><KeyBlockInstanceId>" + structData.KeyBlockInstanceId + "</KeyBlockInstanceId><SubStrategyName>" + structData.SubStrategyName + "</SubStrategyName>";
            strTmp = InputListToXml(structData.InputName, structData.InputValue);
            str += strTmp;
            strTmp = OutputListToXml(structData.OutputName, structData.OutputValue, structData.OutputId);
            str += strTmp;
            str += "<KeyBlockData>";

            return str;
        }
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ParseXmlDll
{
    [XmlRootAttribute("StructEneity")]
    public class StructEneity
    {
        private string _keyBlockInstanceId;

        [XmlAttribute("KeyBlockInstanceId")]
        public string KeyBlockInstanceId
        {
            get { return _keyBlockInstanceId; }
            set { _keyBlockInstanceId = value; }
        }
        private string _subStrategyName;
        [XmlAttribute("SubStrategyName")]
        public string SubStrategyName
        {
            get { return _subStrategyName; }
            set { _subStrategyName = value; }
        }

        private List<string> _inputName;
        [XmlAttribute("InputName")]
        public List<string> InputName
        {
            get{ return _inputName; }
            set{ _inputName = value;}
        }

        private List<string> _inputValue;
        [XmlAttribute("InputValue")]
        public List<string> InputValue
        {
            get { return _inputValue; }
            set { _inputValue = value; }
        }

        private string _outputId;
        [XmlAttribute("OutputId")]
        public string OutputId
        {
            get { return _outputId; }
            set { _outputId = value; }
        }

        private List<string> _outputName;
        [XmlAttribute("OutputName")]
        public List<string> OutputName
        {
            get { return _outputName; }
            set { _outputName = value; }
        }

        private List<string> _outputValue;
        [XmlAttribute("OutputValue")]
        public List<string> OutputValue
        {
            get { return _outputValue; }
            set { _outputValue = value; }
        }

    }
}

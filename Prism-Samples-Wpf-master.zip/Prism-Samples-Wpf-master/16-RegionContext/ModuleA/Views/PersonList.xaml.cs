﻿using System.Windows.Controls;

namespace ModuleA.Views
{
    /// <summary>
    /// Interaction logic for PersonList
    /// </summary>
    public partial class PersonList : UserControl
    {
        public PersonList()
        {
            InitializeComponent();
        }
    }
}

﻿using System.Windows.Controls;

namespace ModuleA.Views
{
    /// <summary>
    /// Interaction logic for PersonDetail
    /// </summary>
    public partial class PersonDetail : UserControl
    {
        public PersonDetail()
        {
            InitializeComponent();
        }
    }
}

﻿using System.Windows.Controls;

namespace UsingPopupWindowAction.Views
{
    /// <summary>
    /// Interaction logic for ItemSelectionView
    /// </summary>
    public partial class ItemSelectionView : UserControl
    {
        public ItemSelectionView()
        {
            InitializeComponent();
        }
    }
}

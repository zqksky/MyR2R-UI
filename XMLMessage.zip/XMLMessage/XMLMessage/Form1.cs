﻿using mshtml;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using XMLMessage.BaseFun;

namespace XMLMessage
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        
        private void AddImagToImagList()
        {
            //ImageList imageList = new ImageList();
            //imageList.Images.Add(Image.FromFile(@"D:\我的文件\myrice\favicon.ico"));
            //imageList.Images.Add(Image.FromFile(@"D:\我的文件\myrice\favicon4.ico"));
            //imageList.Images.Add(Image.FromFile(@"D:\我的文件\myrice\favicon5.ico"));

            //imagListTreeView.Images.Add(Image.FromFile(@"D:\我的文件\myrice\favicon.ico"));
        }
       
        private Hashtable ht = new Hashtable();
        private List<string> strListNodeNames = new List<string>();
        private List<string> strListLogFilePaths = new List<string>();

        private void Log4netTest()
        {
            try
            {
                LogFun.DebugWriteLog(typeof(frmMain), "mytest");
                throw new Exception();
            }
            catch (Exception ee)
            {
                LogFun.DebugWriteLog(typeof(frmMain), ee);
            }
        }
        private void Log4netDefineLoggerTest()
        {
            try
            {
                LogFun.TestDefineLogger("MyDefinLoggerTest");
                throw new Exception();
            }
            catch (Exception ee)
            {
                LogFun.TestDefineLogger( ee.ToString());
            }
        }
        private  void Form1_Load(object sender, EventArgs e)
        {
            //webBrowser1.DocumentText = string.Empty;
            //webBrowser1.Document.ExecCommand("EditMode", false, null);
            //webBrowser1.Document.ExecCommand("LiveResize", false, null);

            #region strategydbg To xml
            string strGzipPath = @"C:\YMTC\XMLMessage\XMLMessage\strategydbg\R2R_CMP_L2LCalcRcpSettings.strategydbg";
            string strXmlSavePath = @"C:\YMTC\XMLMessage\XMLMessage\strategydbg\R2R_CMP_L2LCalcRcpSettings.xml";

            byte[] bytes ;
            bytes=  GzipHelp.Decompress(strGzipPath);

            string strXml = Encoding.UTF8.GetString(bytes);
            rtxtXml.Text = strXml;

            XmlHelp.WriteStringToXml(strXml, strXmlSavePath);

            webBrowser1.Navigate(new Uri(strXmlSavePath));

            GzipHelp.CompressSingleFile(strXmlSavePath);

            //LinqXmlHelp.ShowNextLevelEle(strXmlSavePath, "ExeInfo");

            XPathHelp.UseXPathWithXmlDocument(strXmlSavePath, "ExeInfo", "0016 - CM - Read Control Model");
            #endregion

            #region Log4net
            //Log4netDefineLoggerTest();
            //Log4netTest();
            #endregion

            #region AsyncTest
            //AsyncTest.CallAsyncMethod();
            //Task<int> taskFun = AsyncTest.MyMethodAsync();
            #endregion

            #region
            ////FileHelp.getAppPath();
            //string strLogFolderPath = @"C:\YMTC\XMLMessage\XMLMessage\LogFile";
            //string strXmlFolderPath = @"C:\YMTC\XMLMessage\XMLMessage\XMLFile";

            //ht = FileHelp.GetFile(strLogFolderPath);
            //HashtableHelp.GetHashtableKeysAndValues(ht,ref strListNodeNames, ref strListLogFilePaths);

            //TreeNode rootNode = new TreeNode();
            //rootNode = TreeviewHelp.GetTreeNode("LogFile", strListNodeNames);
            //rootNode.ImageIndex = 0;
            //rootNode.SelectedImageIndex = 0;
            //tvwMain.Nodes.Add(rootNode);

            //for (int i = 0; i < strListLogFilePaths.Count(); i++)
            //{
            //    string strTxt = "";
            //    strTxt = TxtHelp.ReadTxt(strListLogFilePaths[i]);

            //    string strNewFolderName = strListNodeNames[i];
            //    //string strNewXmlFolder = strXmlFolderPath + "\\" + strNewFolderName;
            //    string strNewXmlFolder = Path.Combine(strXmlFolderPath, strNewFolderName);

            //    FileHelp.CreateDirectory(strNewXmlFolder);

            //    string[] strTest = strTxt.Split(new string[] { "</msg>]" }, StringSplitOptions.None);
            //    List<string> strListXmlFileName = new List<string>();

            //    for (int n = 0; n < strTest.Count(); n++)
            //    {
            //        string strTmp = strTest[n].Trim();


            //        if (strTmp.Equals(""))
            //        {
            //        }
            //        else if (strTmp.Contains("Message[<?xml version=\"1.0\" encoding="))
            //        {
            //            string strXmlNote="";
            //            string strXmlFileName="";

            //            TxtHelp.GetXmlFile(strTmp,ref strXmlFileName,ref strXmlNote, strNewXmlFolder);
            //            strListXmlFileName.Add(strXmlFileName);
            //        }
            //    }
            //    TreeNode sonNode = rootNode.Nodes[strListNodeNames[i]];
            //    sonNode.ImageIndex = 2;
            //    sonNode.SelectedImageIndex = 3;
            //    TreeviewHelp.AddSonTreeNode(sonNode, strListXmlFileName);
            //}

            ////string strXmlFilePath = strXmlFolderPath + "\\" + strListNodeNames[0] + "\\" + strListXmlFileName[0];
            #endregion
        }

        private void tvwMain_AfterSelect(object sender, TreeViewEventArgs e)
        {
            //rtxtXml.Text = "";
            if (e.Node.Text.ToString().Contains(".xml"))
            {
                string strXmlFolderPath = @"C:\YMTC\XMLMessage\XMLMessage\XMLFile";
                string strFolder = "";
                string strXmlName = "";

                TreeNode node = e.Node;
                strXmlName = node.Text.ToString().Trim();

                TreeNode nodeParent = e.Node.Parent;
                strFolder = nodeParent.Text.ToString().Trim();
                //string strXmlFilePath = strXmlFolderPath + "\\" + strFolder + "\\" + strXmlName;
                string strXmlFilePath = Path.Combine(strXmlFolderPath, strFolder, strXmlName);

                webBrowser1.Navigate(new Uri(strXmlFilePath));
                string strXml = "";
                strXml = TxtHelp.ReadTxt(strXmlFilePath);
                rtxtXml.Text = strXml;

                //rtxtXml.AppendTextColorful("Add new line", Color.Green);

                //MessageBox.Show(strXmlFilePath);
            }
        }

        private void webBrowser1_Navigated(object sender, WebBrowserNavigatedEventArgs e)
        {
            //使内容可编辑
            IHTMLDocument2 doc = webBrowser1.Document.DomDocument as IHTMLDocument2;
            doc.designMode = "On";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string str = webBrowser1.Document.Body.InnerText;
            //string str = webBrowser1.Document.Body.InnerHtml;
        }
    }
}

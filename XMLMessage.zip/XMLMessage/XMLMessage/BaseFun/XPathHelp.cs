﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace XMLMessage.BaseFun
{
    class XPathHelp
    {
        public static void UseXPathWithXmlDocument(string strXmlPath, string strNodeName,string strInstanceId)
        {
            
            XmlDocument doc = new XmlDocument();

            doc.Load(strXmlPath);

            //使用xPath选择需要的节点
            //XmlNodeList nodes = doc.SelectNodes("//ExeInfo[InstanceId='0058 - CC - Create Full Array of Zero Values']");
            XmlNodeList nodes = doc.SelectNodes("//"+ strNodeName + "[InstanceId='"+strInstanceId+"']");

            List<string> strListInputName = new List<string>();
            List<string> strListInputData = new List<string>();
            List<string> strListOutputName = new List<string>();
            List<string> strListOutputData = new List<string>();

            foreach (XmlNode item in nodes)
            {
                XmlNodeList nodesInput = item.SelectNodes("child::Inputs/InputParameter");

                foreach (XmlNode itemInput in nodesInput)
                {
                    string strInputName = itemInput.SelectSingleNode("child::Name").InnerText;
                    string strInputData = itemInput.SelectSingleNode("child::Data").InnerText;
                    strListInputName.Add(strInputName);
                    strListInputData.Add(strInputData);
                }

                XmlNodeList nodesOutput = item.SelectNodes("child::Output");
                foreach (XmlNode itemOutput in nodesOutput)
                {
                    string strOutputId = itemOutput.SelectSingleNode("child::Id").InnerText;
                    string strOutputData = itemOutput.SelectSingleNode("child::Data").InnerText;
                    strListOutputName.Add(strOutputId);
                    strListOutputData.Add(strOutputData);
                }                   
            }
        }
    }
}

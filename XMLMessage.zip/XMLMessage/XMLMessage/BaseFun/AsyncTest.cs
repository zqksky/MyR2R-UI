﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XMLMessage.BaseFun
{
    class AsyncTest
    {
        public static async void CallAsyncMethod()
        {
            var result = await MyMethodAsync();

            //Task<int> taskFun = MyMethodAsync();
            //var result = await taskFun;
        }

        public static async Task<int> MyMethodAsync()
        {
            for (int i = 0; i < 5; i++)
            {
                System.Windows.Forms.MessageBox.Show("Async start:" + i.ToString() + "..");
                await Task.Delay(1000); //模拟耗时操作
            }
            return 0;
        }
    }
}

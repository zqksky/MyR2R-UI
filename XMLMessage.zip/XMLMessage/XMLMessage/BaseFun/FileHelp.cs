﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace XMLMessage.BaseFun
{
    class FileHelp
    {
        #region
        ////1.获取模块的完整路径。 
        //string path1 = System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName;

        ////2.获取和设置当前目录(该进程从中启动的目录)的完全限定目录 
        //string path2 = System.Environment.CurrentDirectory;

        ////3.获取应用程序的当前工作目录 
        //string path3 = System.IO.Directory.GetCurrentDirectory();

        ////4.获取程序的基目录 
        //string path4 = System.AppDomain.CurrentDomain.BaseDirectory;

        ////5.获取和设置包括该应用程序的目录的名称 
        //string path5 = System.AppDomain.CurrentDomain.SetupInformation.ApplicationBase;

        ////6.获取启动了应用程序的可执行文件的路径 
        //string path6 = System.Windows.Forms.Application.StartupPath;

        ////7.获取启动了应用程序的可执行文件的路径及文件名 
        //string path7 = System.Windows.Forms.Application.ExecutablePath; 

        // 输出结果 
        //1. D:\work\prj\VP-VPlatform\XmlAndXsd\bin\Release\XmlAndXsd.vshost.exe 
        //2. D:\work\prj\VP-VPlatform\XmlAndXsd\bin\Release 
        //3. D:\work\prj\VP-VPlatform\XmlAndXsd\bin\Release 
        //4. D:\work\prj\VP-VPlatform\XmlAndXsd\bin\Release\ 
        //5. D:\work\prj\VP-VPlatform\XmlAndXsd\bin\Release\ 
        //6. D:\work\prj\VP-VPlatform\XmlAndXsd\bin\Release 
        //7. D:\work\prj\VP-VPlatform\XmlAndXsd\bin\Release\XmlAndXsd.EXE
        #endregion

        #region
        //首先，获取目录的情况下，DirectoryInfo.GetDirectories()：获取目录（不包含子目录）的子目录，返回类型为DirectoryInfo[]，支持通配符查找；
        //其次，获取文件的情况下， DirectoryInfo.GetFiles()：获取目录中（不包含子目录）的文件，返回类型为FileInfo[]，支持通配符查找；
        //最后，DirectoryInfo.GetFileSystemInfos()：获取指定目录下（不包含子目录）的文件和子目录，返回类型为FileSystemInfo[]，支持通配符查找；

        //如何获取指定文件的基本信息；
        //FileInfo.Exists：获取指定文件是否存在；
        //FileInfo.Name，FileInfo.Extensioin：获取文件的名称和扩展名；
        //FileInfo.FullName：获取文件的全限定名称（完整路径）；
        //FileInfo.Directory：获取文件所在目录，返回类型为DirectoryInfo；
        //FileInfo.DirectoryName：获取文件所在目录的路径（完整路径）；
        //FileInfo.Length：获取文件的大小（字节数）；
        //FileInfo.IsReadOnly：获取文件是否只读；
        //FileInfo.Attributes：获取或设置指定文件的属性，返回类型为FileAttributes枚举，可以是多个值的组合
        //FileInfo.CreationTime、FileInfo.LastAccessTime、FileInfo.LastWriteTime：分别用于获取文件的创建时间、访问时间、修改时间；
        #endregion

        #region
        //只获取目录下一级的文件夹与文件
        public static Hashtable GetFile(string strFilePath)
        {
            Hashtable ht = new Hashtable();

            ////第一种方法
            //string[] files = Directory.GetFiles(strFilePath, "*.Log");

            //foreach (string file in files)
            //{
            //    MessageBox.Show(file.ToString());
            //}

            //第二种方法
            DirectoryInfo folder = new DirectoryInfo(strFilePath);

            foreach (FileInfo file in folder.GetFiles("*.Log"))
            {
                //MessageBox.Show(file.ToString());
                //MessageBox.Show(file.FullName.ToString());
                ht.Add(file.ToString(), file.FullName.ToString());
            }

            return ht;
        }

        /// <summary>
        /// 追加文件夹，不存在则创建
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        public static void CreateDirectory(string path)
        {
            try
            {
                if (Directory.Exists(path))
                {
                    //return "已经有这个路径";
                }
                DirectoryInfo DirInfo = Directory.CreateDirectory(path);//用于创建指定目录的文件夹

                //return "路径创建成功！";
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.ToString());
            }
        }

        /// <summary>
        /// 移动文件夹
        /// 支持重新命名
        /// </summary>
        public static void MoveDirectory(string sourcePath, string objectPath)
        {
            //sourcePath = @"C:\Documents and Settings\Administrator\桌面\flash\专项\操作文件夹\FoundFile\FoundFile\bin\f";
            //objectPath = @"C:\Documents and Settings\Administrator\桌面\flash\专项\操作文件夹\FoundFile\FoundFile\bin\Debug\file";
            try
            {
                if (!Directory.Exists(sourcePath))
                {
                    return;
                }
                if (Directory.Exists(objectPath))
                {
                    return;
                }
                Directory.Move(sourcePath, objectPath);
            }
            catch (Exception ee)
            { }
        }


        /// <summary>
        /// 删除文件夹
        /// </summary>
        public static void DeleteDirectory(string path)
        {
            //path = @"C:\Documents and Settings\Administrator\桌面\flash\专项\操作文件夹\FoundFile\FoundFile\bin\Debug\file\新建文件夹";
            try
            {
                if (!Directory.Exists(path))
                {
                    return;
                }
                Directory.Delete(path);
            }
            catch (Exception ee)
            { }
        }

        /// <summary>
        /// 复制目录到目标目录
        /// </summary>
        /// <param name="source">源目录</param>
        /// <param name="destination">目标目录</param>
        public static void CopyDirectory(DirectoryInfo source, DirectoryInfo destination)
        {
            // 如果两个目录相同，则无须复制
            if (destination.FullName.Equals(source.FullName))
            {
                return;
            }

            // 如果目标目录不存在，创建它
            if (!destination.Exists)
            {
                destination.Create();
            }

            // 复制所有文件
            FileInfo[] files = source.GetFiles();
            foreach (FileInfo file in files)
            {
                // 将文件复制到目标目录
                file.CopyTo(Path.Combine(destination.FullName, file.Name), true);
            }

            // 处理子目录
            DirectoryInfo[] dirs = source.GetDirectories();
            foreach (DirectoryInfo dir in dirs)
            {
                string destinationDir = Path.Combine(destination.FullName, dir.Name);

                // 递归处理子目录
                CopyDirectory(dir, new DirectoryInfo(destinationDir));
            }
        }


        public static void GetAllDir(string strDir)
        {
            List<string> list = new List<string>();
            DirectoryInfo dir = new DirectoryInfo(strDir);
            DirectoryInfo[] dirinfo = dir.GetDirectories();

            for (int i = 0; i < dirinfo.Length; i++)
            {
                list.Add(dirinfo[i].FullName);
                GetAllDir(dirinfo[i].FullName);
            }
            for (int i = 0; i < list.Count; i++)
            {
                Console.WriteLine(list[i]);
            }
        }

        /// <summary>
        /// 判断两个文件内容是否一致
        /// </summary>
        public static bool IsFilesEqual(string fileName1, string fileName2)
        {
            using (HashAlgorithm hashAlg = HashAlgorithm.Create())
            {
                using (FileStream fs1 = new FileStream(fileName1, FileMode.Open), fs2 = new FileStream(fileName2, FileMode.Open))
                {
                    byte[] hashBytes1 = hashAlg.ComputeHash(fs1);
                    byte[] hashBytes2 = hashAlg.ComputeHash(fs2);

                    // 比较哈希码
                    return (BitConverter.ToString(hashBytes1) == BitConverter.ToString(hashBytes2));
                }
            }
        }

        /// <summary>
        /// 获得指定路径下所有文件名
        /// </summary>
        /// <param name="sw">文件写入流</param>
        /// <param name="path">文件写入流</param>
        /// <param name="indent">输出时的缩进量</param>
        public static void getFileName(StreamWriter sw, string path, int indent)
        {
            DirectoryInfo root = new DirectoryInfo(path);
            foreach (FileInfo f in root.GetFiles())
            {
                for (int i = 0; i < indent; i++)
                {
                    sw.Write("  ");
                }
                sw.WriteLine(f.Name);
            }
        }

        /// <summary>
        /// 获得指定路径下所有子目录名
        /// </summary>
        /// <param name="sw">文件写入流</param>
        /// <param name="path">文件夹路径</param>
        /// <param name="indent">输出时的缩进量</param>
        public static void getDirectory(StreamWriter sw, string path, int indent)
        {
            getFileName(sw, path, indent);
            DirectoryInfo root = new DirectoryInfo(path);
            foreach (DirectoryInfo d in root.GetDirectories())
            {
                for (int i = 0; i < indent; i++)
                {
                    sw.Write("  ");
                }
                sw.WriteLine("文件夹：" + d.Name);
                getDirectory(sw, d.FullName, indent + 2);
                sw.WriteLine();
            }
        }
        #endregion

        #region
        /// <summary>
        /// 获取App的当前路径 \\结束
        /// </summary>
        /// <returns></returns>
        public static string getAppPath()
        {
            return GetAssemblyPath();
        }

        /// <summary>
        /// 获取Assembly的运行路径 \\结束
        /// </summary>
        /// <returns></returns>
        public static string GetAssemblyPath()
        {
            string sCodeBase = System.Reflection.Assembly.GetExecutingAssembly().CodeBase;

            sCodeBase = sCodeBase.Substring(8, sCodeBase.Length - 8);    // 8是 file:// 的长度

            string[] arrSection = sCodeBase.Split(new char[] { '/' });

            string sDirPath = "";
            for (int i = 0; i < arrSection.Length - 1; i++)
            {
                sDirPath += arrSection[i] + Path.DirectorySeparatorChar;
            }

            return sDirPath;
        }

        /// <summary>
        /// 文件夹复制
        /// </summary>
        /// <param name="sSourceDirName">原始路径</param>
        /// <param name="sDestDirName">目标路径</param>
        /// <returns></returns>
        public static bool CopyDirectory(string sSourceDirName, string sDestDirName)
        {
            if (string.IsNullOrEmpty(sSourceDirName) || string.IsNullOrEmpty(sDestDirName))
            {
                return false;
            }

            //不复制.svn文件夹
            if (sSourceDirName.EndsWith("svn"))
            {
                return true;
            }

            if (sSourceDirName.Substring(sSourceDirName.Length - 1) != Path.DirectorySeparatorChar.ToString())
            {
                sSourceDirName = sSourceDirName + Path.DirectorySeparatorChar;
            }
            if (sDestDirName.Substring(sDestDirName.Length - 1) != Path.DirectorySeparatorChar.ToString())
            {
                sDestDirName = sDestDirName + Path.DirectorySeparatorChar;
            }

            #region 复制函数
            if (Directory.Exists(sSourceDirName))
            {
                if (!Directory.Exists(sDestDirName))
                {
                    Directory.CreateDirectory(sDestDirName);
                }
                foreach (string item in Directory.GetFiles(sSourceDirName))
                {
                    File.Copy(item, sDestDirName + System.IO.Path.GetFileName(item), true);
                }
                foreach (string item in Directory.GetDirectories(sSourceDirName))
                {
                    CopyDirectory(item, sDestDirName + item.Substring(item.LastIndexOf(Path.DirectorySeparatorChar) + 1));
                }
            }
            return true;
            #endregion
        }


        /// <summary> 
        /// 启动其他的应用程序 
        /// </summary> 
        /// <param name="file">应用程序名称</param> 
        /// <param name="workdirectory">应用程序工作目录</param> 
        /// <param name="args">命令行参数</param> 
        /// <param name="style">窗口风格</param> 
        public static bool StartProcess(string file, string workdirectory, string args, ProcessWindowStyle style)
        {
            try
            {
                Process pMyProcess = new Process();
                ProcessStartInfo pStartInfo = new ProcessStartInfo(file, args);
                pStartInfo.WindowStyle = style;
                pStartInfo.WorkingDirectory = workdirectory;
                pMyProcess.StartInfo = pStartInfo;
                pMyProcess.StartInfo.UseShellExecute = false;
                pMyProcess.Start();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        /// <summary>
        /// 获得本地计算机名
        /// </summary>
        /// <returns></returns>
        public static string GetComputerName()
        {
            return Dns.GetHostName();
        }

        /// <summary>
        /// 获得计算机IP地址
        /// </summary>
        /// <returns></returns>
        public static string GetIPAddress()
        {
            try
            {
                string sComputerName;
                sComputerName = GetComputerName();
                string sIpAddress = "";
                IPAddress[] addr = Dns.GetHostAddresses(sComputerName);
                //for (int i = 0; i < addr.Length; i++)
                //{
                //    sIpAddress += addr[i].ToString() + " ";
                //}
                sIpAddress = addr[0].ToString();
                return sIpAddress;
            }
            catch (Exception ep)
            {
                return "127.0.0.1";
            }
        }

        /// <summary>
        /// 描述:创建目录
        /// </summary>
        /// <returns></returns>
        public static bool CreateFolder(string sFolder)
        {
            //如果临时文件夹不存在，则创建该文件夹
            if (!Directory.Exists(sFolder))
            {
                Directory.CreateDirectory(sFolder);
            }
            return true;
        }
        #endregion

        #region 大文件多次复制文件
        /// <summary>
        /// 大文件多次复制文件  true：复制成功   false：复制失败
        /// </summary>
        /// <param name="soucrePath">原始文件路径</param>
        /// <param name="targetPath">复制目标文件路径</param>
        /// <returns></returns>
        public static bool CopyFile(string soucrePath, string targetPath)
        {
            try
            {
                //读取复制文件流
                using (FileStream fsRead = new FileStream(soucrePath, FileMode.Open, FileAccess.Read))
                {
                    //写入文件复制流
                    using (FileStream fsWrite = new FileStream(targetPath, FileMode.OpenOrCreate, FileAccess.Write))
                    {
                        byte[] buffer = new byte[1024 * 1024 * 2]; //每次读取2M
                        //可能文件比较大，要循环读取，每次读取2M
                        while (true)
                        {
                            //每次读取的数据    n：是每次读取到的实际数据大小
                            int n = fsRead.Read(buffer, 0, buffer.Count());
                            //如果n=0说明读取的数据为空，已经读取到最后了，跳出循环
                            if (n == 0)
                            {
                                break;
                            }
                            //写入每次读取的实际数据大小
                            fsWrite.Write(buffer, 0, n);
                        }
                    }
                }
                return true;
            }
            catch (System.Exception ex)
            {
                return false;
            }
        }
        #endregion
    }
}

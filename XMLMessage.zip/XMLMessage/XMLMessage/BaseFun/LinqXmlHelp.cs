﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;

namespace XMLMessage.BaseFun
{
    class LinqXmlHelp
    {
        /// <summary>
        /// 显示指定节点的所有父节点
        /// </summary>
        public static void ShowAllParentEle(string strXmlPath,string strNodeName)
        {
            XElement xele = XElement.Load(strXmlPath);
            var item = (from ele in xele.Descendants(strNodeName)
                        select ele).FirstOrDefault();
            if (item != null)
            {
                foreach (var sub in item.Ancestors())
                {
                    Console.WriteLine(sub.Name);
                }
                Console.WriteLine("----------------");
                foreach (var sub in item.AncestorsAndSelf())
                {
                    Console.WriteLine(sub.Name);
                }
                Console.ReadKey();
            }
        }

        /// <summary>
        /// 显示指定节点的所有子节点
        /// </summary>
        public static void ShowAllChildEle(string strXmlPath)
        {
            List<string> strList = new List<string>();

            XElement xele = XElement.Load(strXmlPath);
            foreach (var sub in xele.Descendants())
            {
                Console.WriteLine(sub.Name);
                //strList.Add(sub.Value.ToString());
            }
            //Console.WriteLine("-----------------");
            //foreach (var sub in xele.DescendantsAndSelf())
            //{
            //    Console.WriteLine(sub.Name);
            //}
            //Console.ReadKey();
        }

        /// <summary>
        /// 显示指定节点的所有子节点
        /// </summary>
        public static void ShowAllChildEle(string strXmlPath, string strNodeName)
        {
            List<string> strList = new List<string>();

            XElement xele = XElement.Load(strXmlPath);
            foreach (var sub in xele.Descendants(strNodeName))
            {
                foreach (var subChild in sub.Descendants())
                {
                    strList.Add(subChild.Name.ToString());
                }
                Console.WriteLine(sub.Name);
                //strList.Add(sub.Value.ToString());
            }
            //Console.WriteLine("-----------------");
            //foreach (var sub in xele.DescendantsAndSelf())
            //{
            //    Console.WriteLine(sub.Name);
            //}
            //Console.ReadKey();
        }

        /// <summary>
        /// 显示同级节 not
        /// </summary>
        public static void ShowSameLevelEle(string strXmlPath, string strNodeName)
        {
            List<string> strList = new List<string>();

            XElement xele = XElement.Load(strXmlPath);
            var item = (from ele in xele.Descendants(strNodeName)
                        select ele).FirstOrDefault();
            if (item != null)
            {
                foreach (var sub in item.Descendants())
                {
                    //Console.WriteLine(sub.Name);
                    strList.Add(sub.Name.ToString());
                }
            }
            //Console.ReadKey();
        }

        /// <summary>
        /// 显示同级节点之前的节点
        /// </summary>
        public static void ShowPrevLevelEle(string strXmlPath, string strNodeName)
        {
            XElement xele = XElement.Load(strXmlPath);
            var item = (from ele in xele.Descendants(strNodeName)
                        select ele).FirstOrDefault();
            if (item != null)
            {
                foreach (var sub in item.ElementsBeforeSelf())
                {
                    Console.WriteLine(sub.Name);
                }
            }
            Console.ReadKey();
        }

        /// <summary>
        /// 显示同级节点后面的节点
        /// </summary>
        public static void ShowNextLevelEle(string strXmlPath, string strNodeName)
        {
            bool flag = false;
            List<string> strList = new List<string>();
            List<string> strListInputs = new List<string>();
            List<string> strListOutputs = new List<string>();
            XElement xele = XElement.Load(strXmlPath);
            var item = (from ele in xele.Descendants(strNodeName)
                        select ele).FirstOrDefault();
            if (item != null)
            {
                XElement eleNode=null;
                flag = HaveElementChild(item, "0146 - CC - Update Fab, ToolId, LotId, and TxId to Cache", ref eleNode);
                if (flag)
                {
                    GetSomeLevelChildElement(eleNode, "Inputs", ref strListInputs);
                    GetSomeLevelChildElement(eleNode, "Output", ref strListOutputs);
                }
                foreach (var sub in item.ElementsAfterSelf())
                {
                    //Console.WriteLine(sub.Name);
                    strList.Add(sub.Name.ToString());
                    flag = HaveElementChild(sub, "0146 - CC - Update Fab, ToolId, LotId, and TxId to Cache", ref eleNode);
                    if (flag)
                    {
                        GetSomeLevelChildElement(eleNode, "Inputs", ref strListInputs);
                        GetSomeLevelChildElement(eleNode, "Output", ref strListOutputs);
                        break;
                    }
                }              
            }
            //Console.ReadKey();
        }

        private static bool HaveElementChild(XElement ele, string strNodeValue,ref XElement eleNode)
        {
            bool flag=false;
            if (ele != null)
            {
                foreach (var sub in ele.Descendants())
                {
                    if (sub.Value.ToString().Equals(strNodeValue))
                    {
                        eleNode = sub;
                        flag = true;
                        break;
                    }
                    else
                    {
                        flag = false;
                    }
                }
            }
            return flag; 
        }

        private static void GetSomeLevelChildElement(XElement ele, string strNodeName, ref List<string> strList)
        {
            if (ele != null)
            {
                foreach (var sub in ele.ElementsAfterSelf())
                {
                    if (sub.Name.ToString().Equals(strNodeName))
                    {
                        GetChildElement(sub, ref strList);
                    }
                    else
                    {

                    }
                }
            }
        }

        private static void GetChildElement(XElement ele,ref List<string> strList)
        {
            if (ele != null)
            {
                foreach (var sub in ele.Descendants())
                {
                    strList.Add(sub.Name.ToString()+":"+ sub.Value.ToString());
                }
            }
        }

        /// <summary>
        /// 流式处理XML
        /// </summary>
        public static void ReadXml(string strXmlPath, string strNodeName)
        {
            List<string> strList = new List<string>();
            XmlReader reader = XmlReader.Create(strXmlPath);
            while (reader.Read())
            {
                if (reader.NodeType == XmlNodeType.Element && reader.Name.Equals(strNodeName))
                {
                    XElement ele = XElement.ReadFrom(reader) as XElement;
                    //Console.WriteLine(ele.Value.Trim());
                    strList.Add(ele.Value.ToString());
                }
            }
            //Console.ReadKey();
        }

        public static void ReadXml(string strXmlPath)
        {
            // XmlTextReader 读文件
            XmlTextReader readerXml = new XmlTextReader(strXmlPath);
            while (readerXml.Read())
            {
                if (readerXml.NodeType == XmlNodeType.Element)
                {

                    if (readerXml.Name == "IpAddress")
                    {
                        Console.WriteLine(readerXml.ReadElementString().Trim());
                    }
                    if (readerXml.Name == "Netmask")
                    {
                        Console.WriteLine(readerXml.ReadElementString().Trim());
                    }
                    if (readerXml.Name == "Gateway")
                    {
                        Console.WriteLine(readerXml.ReadElementString().Trim());
                    }
                }
            }

        }


        public static String Path
        {
            get
            {
                String path = String.Format("{0}\\test.xml", Environment.CurrentDirectory);
                return path;
            }
        }

        /// <summary>
        /// 创建简单的xml并保存
        /// </summary>
        public static void CreateElement()
        {
            XDocument xdoc = new XDocument(
            new XDeclaration("1.0", "utf-8", "yes"),
            new XElement("root",
            new XElement("item", "1"),
            new XElement("item", "2")
            ));
            xdoc.Save(Path);
        }

        /// <summary>
        /// 创建注释
        /// </summary>
        public static void CreateComment()
        {
            XDocument doc = new XDocument(
                new XDeclaration("1.0", "utf-8", "yes"),
                new XComment("提示"),
                new XElement("item", "asd")
                );
            doc.Save(Path);
        }

        /// <summary>
        /// 根据对象创建xml并保存
        /// </summary>
        public static void CreateElementByObjects()
        {
            var s = Enumerable.Range(1, 10);
            XElement xele = new XElement(
                "Root",
                from item in s
                select new XElement("item", item.ToString())
                );
            xele.Save(Path);
        }

        /// <summary>
        /// 创建属性
        /// </summary>
        public static void CreteAttribute()
        {
            XAttribute xa = new XAttribute("V2", "2");
            XElement xele = new XElement(
                "Root",
                new XElement("Item",
                    new XAttribute("V1", "1"),
                    xa
                    ));
            xele.Save(Path);
        }

        /// <summary>
        /// 创建命名空间
        /// </summary>
        public static void CreateNamespace()
        {
            XElement xele = new XElement("{http://www.xamarin-cn.com}Root",
                new XElement("Item", "1"),
                new XElement("{http://www.baidu.com}Item", 2));
            xele.Save(Path);
        }

        /// <summary>
        /// 通过文件读取xml
        /// </summary>
        public static void QueryElementByFile(string strXmlPath, string strNodeName)
        {
            XElement xele = XElement.Load(strXmlPath);
            XElement xele1 = xele.Element(strNodeName);
            Console.Write(xele1.Value.Trim());
            Console.ReadKey();
        }

        /// <summary>
        /// 在指定节点前后添加新节点
        /// </summary>
        public static void AddToElementAfterAndBefore(string strXmlPath, string strNodeName, string strNodeValue, string strNewNodeName, string strNewNodeValue)
        {
            XElement xele = XElement.Load(strXmlPath);
            var item = (from ele in xele.Elements(strNodeName)
                        where ele.Value.Equals(strNodeValue)
                        select ele).SingleOrDefault();
            if (item != null)
            {
                XElement nele = new XElement(strNewNodeName, strNewNodeValue);
                XElement nele2 = new XElement("BItem", "BItem");
                item.AddAfterSelf(nele);
                item.AddBeforeSelf(nele2);
                xele.Save(strXmlPath);
            }
        }

        /// <summary>
        /// 添加属性到节点中
        /// </summary>
        public static void AddAttributeToEle(string strXmlPath, string strNodeName, string strNodeValue,string strAttributeName,string strAttributeValue)
        {
            XElement xele = XElement.Load(strXmlPath);
            var item = (from ele in xele.Elements(strNodeName)
                        where ele.Value.Equals(strNodeValue)
                        select ele).SingleOrDefault();
            item.SetAttributeValue(strAttributeName, strAttributeValue);
            xele.Save(strXmlPath);
        }

        /// <summary>
        /// 添加注释到节点前后
        /// </summary>
        public static void AddCommentToAfterAndBefore(string strXmlPath, string strNodeName, string strNodeValue)
        {
            //            TextReader tr = new StringReader(@"<?xml version='1.0' encoding='utf-8'?><Root><!--前面的注释-->
            //<Item v1='1' v2='2'>Item1</Item><!--后面的注释--><Item v1='1' v2='2' v3='3'>Item2</Item></Root>");
            XElement xele = XElement.Load(strXmlPath);
            var item = (from ele in xele.Elements(strNodeName)
                        where ele.Value.Equals(strNodeValue)
                        select ele).FirstOrDefault();
            if (item != null)
            {
                XComment xcom = new XComment("后面的注释");
                XComment xcoma = new XComment("前面的注释");
                item.AddAfterSelf(xcom);
                item.AddBeforeSelf(xcoma);
            }
            //tr.Close();
            xele.Save(strXmlPath);
        }

        /// <summary>
        /// 替换指定节点
        /// </summary>
        public static void ReplaceElement(string strXmlPath, string strNodeName, string strNodeValue,string strNodeNewValue)
        {
            XElement xele = XElement.Load(strXmlPath);
            var item = (from ele in xele.Elements(strNodeName)
                        where ele.Value.Equals(strNodeValue)
                        select ele).FirstOrDefault();
            if (item != null)
            {
                item.ReplaceWith(new XElement(strNodeName, strNodeNewValue));
            }
            xele.Save(strXmlPath);
        }

        /// <summary>
        /// 删除指定节点
        /// </summary>
        public static void RemoveElement(string strXmlPath, string strNodeName,string strNodeValue)
        {
            XElement xele = XElement.Load(strXmlPath);
            var item = (from ele in xele.Elements(strNodeName)
                        where ele.Value.Equals(strNodeValue)
                        select ele).FirstOrDefault();
            if (item != null)
            {
                item.Remove();
            }
            xele.Save(strXmlPath);
        }

        /// <summary>
        /// 删除指定属性
        /// </summary>
        public static void RemoveAttribute(string strXmlPath, string strNodeName, string strNodeValue,string strNodeAttribute)
        {
            XElement xele = XElement.Load(strXmlPath);
            var item = (from ele in xele.Elements(strNodeName)
                        where ele.Value.Equals(strNodeValue)
                        select ele).FirstOrDefault().Attribute(strNodeAttribute);
            if (item != null)
            {
                item.Remove();
            }
            xele.Save(strXmlPath);
        }
    }
}

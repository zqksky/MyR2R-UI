﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XMLMessage.BaseFun
{
    class GzipHelp
    {
        #region
        //压缩字节
        //1.创建压缩的数据流 
        //2.设定compressStream为存放被压缩的文件流,并设定为压缩模式
        //3.将需要压缩的字节写到被压缩的文件流
        public static byte[] CompressBytes(byte[] bytes)
        {
            using (MemoryStream compressStream = new MemoryStream())
            {
                using (var zipStream = new GZipStream(compressStream, CompressionMode.Compress))
                    zipStream.Write(bytes, 0, bytes.Length);
                return compressStream.ToArray();
            }
        }

        //解压缩字节
        //1.创建被压缩的数据流
        //2.创建zipStream对象，并传入解压的文件流
        //3.创建目标流
        //4.zipStream拷贝到目标流
        //5.返回目标流输出字节
        public static byte[] Decompress(byte[] bytes)
        {
            using (var compressStream = new MemoryStream(bytes))
            {
                using (var zipStream = new GZipStream(compressStream, CompressionMode.Decompress))
                {
                    using (var resultStream = new MemoryStream())
                    {
                        zipStream.CopyTo(resultStream);
                        return resultStream.ToArray();
                    }
                }
            }
        }

        //解压缩字节
        //1.创建被压缩的数据流
        //2.创建zipStream对象，并传入解压的文件流
        //3.创建目标流
        //4.zipStream拷贝到目标流
        //5.返回目标流输出字节
        public static byte[] Decompress(string strGzipPath)
        {
            byte[] bytes = GetFileData(strGzipPath);
            using (var compressStream = new MemoryStream(bytes))
            {
                using (var zipStream = new GZipStream(compressStream, CompressionMode.Decompress))
                {
                    using (var resultStream = new MemoryStream())
                    {
                        zipStream.CopyTo(resultStream);
                        return resultStream.ToArray();
                    }
                }
            }
        }
        #endregion

        #region
        /// <summary>
        /// 将文件转换成byte[] 数组
        /// </summary>
        /// <param name="fileUrl">文件路径文件名称</param>
        /// <returns>byte[]</returns>
        protected static byte[] GetFileData(string fileUrl)
        {
            FileStream fs = new FileStream(fileUrl, FileMode.Open, FileAccess.Read);
            try
            {
                byte[] buffur = new byte[fs.Length];
                fs.Read(buffur, 0, (int)fs.Length);

                return buffur;
            }
            catch (Exception ex)
            {
                //MessageBoxHelper.ShowPrompt(ex.Message);
                return null;
            }
            finally
            {
                if (fs != null)
                {

                    //关闭资源
                    fs.Close();
                }
            }
        }

        /// <summary>
        /// 将文件转换成byte[] 数组
        /// </summary>
        /// <param name="fileUrl">文件路径文件名称</param>
        /// <returns>byte[]</returns>
        protected  static byte[] AuthGetFileData(string fileUrl)
        {
            using (FileStream fs = new FileStream(fileUrl, FileMode.OpenOrCreate, FileAccess.ReadWrite))
            {
                byte[] buffur = new byte[fs.Length];
                using (BinaryWriter bw = new BinaryWriter(fs))
                {
                    bw.Write(buffur);
                    bw.Close();
                }
                return buffur;
            }
        }
        #endregion

        #region
        private static string  ByteToString(byte[] bytes)
        {
            //第一种
            string str = System.Text.Encoding.UTF8.GetString(bytes);
            byte[] decBytes = System.Text.Encoding.UTF8.GetBytes(str);
            //同样的，System.Text.Encoding.Default，System.Text.Encoding.ASCII也是可以的。
            //还可以使用System.Text.Encoding.UTF8.GetString(bytes).TrimEnd('\0')给字符串加上结束标识。


            ////第二种
            //string str = BitConverter.ToString(bytes);
            //String[] tempArr = str.Split('-');
            //byte[] decBytes = new byte[tempArr.Length];
            //for (int i = 0; i < tempArr.Length; i++)
            //{
            //    decBytes[i] = Convert.ToByte(tempArr[i], 16);
            //}
            ////这种方法会给字符串加上 '-' 连字符，并且没有函数转换回去。所以需要手动转换为bytes。



            ////第三种
            //string str = Convert.ToBase64String(bytes);
            //byte[] decBytes = Convert.FromBase64String(str);
            ////这种方法简单明了，完美无问题。需要注意的是，转换出来的string可能会包含 '+'，'/' ， '=' 所以如果作为url地址的话，需要进行encode。


            ////第四种
            //string str = HttpServerUtility.UrlTokenEncode(bytes);
            //byte[] decBytes = HttpServerUtility.UrlTokenDecode(str);
            ////这种方法会自动编码url地址的特殊字符，可以直接当做url地址使用。但需要依赖System.Web库才能使用。

            return str;
        }
        #endregion

        #region 
        private static string directoryPath = @"c:\temp";
        public static void test()
        {
            DirectoryInfo directorySelected = new DirectoryInfo(directoryPath);
            Compress(directorySelected);

            foreach (FileInfo fileToDecompress in directorySelected.GetFiles("*.gz"))
            {
                Decompress(fileToDecompress);
            }

            //var tmp = new SevenZipCompressor();
            //tmp.ScanOnlyWritable = true;
            //tmp.CompressFilesEncrypted(outputFilePath, password, filePaths);

            //Sample(using ZipArchive):
            //ZipArchive zip = ZipFile.Open(filePath, ZipArchiveMode.Create);
            //zip.CreateEntryFromFile(file, Path.GetFileName(file), CompressionLevel.Optimal);
            //zip.Dispose();
        }

        public static void Compress(DirectoryInfo directorySelected)
        {
            foreach (FileInfo fileToCompress in directorySelected.GetFiles())
            {
                using (FileStream originalFileStream = fileToCompress.OpenRead())
                {
                    if ((File.GetAttributes(fileToCompress.FullName) &
                       FileAttributes.Hidden) != FileAttributes.Hidden & fileToCompress.Extension != ".gz")
                    {
                        using (FileStream compressedFileStream = File.Create(fileToCompress.FullName + ".gz"))
                        {
                            using (GZipStream compressionStream = new GZipStream(compressedFileStream,
                               CompressionMode.Compress))
                            {
                                originalFileStream.CopyTo(compressionStream);

                            }
                        }
                        FileInfo info = new FileInfo(directoryPath + "\\" + fileToCompress.Name + ".gz");
                        //Console.WriteLine("Compressed {0} from {1} to {2} bytes.",
                        //fileToCompress.Name, fileToCompress.Length.ToString(), info.Length.ToString());
                    }

                }
            }
        }

        public static void CompressSingleFile(string strFileUrl)
        {
            FileInfo file = new FileInfo(strFileUrl);
            using (FileStream originalFileStream = file.OpenRead())
            {
                if ((File.GetAttributes(file.FullName) & FileAttributes.Hidden) != FileAttributes.Hidden & file.Extension != ".gz")
                {
                    string strFullName = file.FullName.Substring(0, file.FullName.IndexOf(file.Extension));
                    using (FileStream compressedFileStream = File.Create(strFullName + ".gz"))// file.FullName
                    {
                        using (GZipStream compressionStream = new GZipStream(compressedFileStream, CompressionMode.Compress))
                        {
                            originalFileStream.CopyTo(compressionStream);
                        }
                    }
                    //string strFileName = file.Name.Substring(0, file.Name.IndexOf(file.Extension));
                    //FileInfo info = new FileInfo(file.DirectoryName + "\\" + strFileName + ".gz");
                    //Console.WriteLine("Compressed {0} from {1} to {2} bytes.",
                    //fileToCompress.Name, fileToCompress.Length.ToString(), info.Length.ToString());
                }
            }
        }

        public static void Compress(FileInfo fileToCompress)
        {
            using (FileStream originalFileStream = fileToCompress.OpenRead())
            {
                if ((File.GetAttributes(fileToCompress.FullName) & FileAttributes.Hidden) != FileAttributes.Hidden & fileToCompress.Extension != ".gz")
                {
                    using (FileStream compressedFileStream = File.Create(fileToCompress.FullName + ".gz"))
                    {
                        using (GZipStream compressionStream = new GZipStream(compressedFileStream, CompressionMode.Compress))
                        {
                            originalFileStream.CopyTo(compressionStream);
                            Console.WriteLine("Compressed {0} from {1} to {2} bytes.",
                                fileToCompress.Name, fileToCompress.Length.ToString(), compressedFileStream.Length.ToString());
                        }
                    }
                }
            }
        }

        public static void Decompress(FileInfo fileToDecompress)
        {
            using (FileStream originalFileStream = fileToDecompress.OpenRead())
            {
                string currentFileName = fileToDecompress.FullName;
                string newFileName = currentFileName.Remove(currentFileName.Length - fileToDecompress.Extension.Length);

                using (FileStream decompressedFileStream = File.Create(newFileName))
                {
                    using (GZipStream decompressionStream = new GZipStream(originalFileStream, CompressionMode.Decompress))
                    {
                        decompressionStream.CopyTo(decompressedFileStream);
                        //Console.WriteLine("Decompressed: {0}", fileToDecompress.Name);
                    }
                }
            }
        }
        #endregion
    }
}

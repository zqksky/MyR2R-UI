﻿using ICSharpCode.SharpZipLib.Checksums;
using ICSharpCode.SharpZipLib.GZip;
using ICSharpCode.SharpZipLib.Zip;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XMLMessage.BaseFun
{
    class ZipHelp
    {
        #region
        //程序集有两个：System.IO.Compression 和 System.IO.Compression.FileSystem ;需要确保使用 .NET 4.5 版
        public void TestFun()
        {
            System.IO.Compression.ZipFile.CreateFromDirectory(@"e:\test", @"e:\test\test.zip"); //压缩
            System.IO.Compression.ZipFile.ExtractToDirectory(@"e:\test\test.zip", @"e:\test"); //解压
        }

        //通过现存的.zip文件的内容重复存档并提取有一个 .txt 扩展名的文件。 它使用 ZipArchive 类访问现有的 .zip 文件与 ZipArchiveEntry 类来检查压缩文件的各个项
        public static void GetFileInZip()
        {
            string zipPath = @"c:\example\start.zip";
            string extractPath = @"c:\example\extract";
            using (ZipArchive archive = System.IO.Compression.ZipFile.OpenRead(zipPath))
            {
                foreach (ZipArchiveEntry entry in archive.Entries)
                {
                    if (entry.FullName.EndsWith(".txt", StringComparison.OrdinalIgnoreCase))
                    {
                        entry.ExtractToFile(Path.Combine(extractPath, entry.FullName));
                    }
                }
            }
        }
        //使用 ZipArchive 类访问现有的 .zip 文件，然后添加新文件到压缩文件。 当添加到现有的 .zip 文件时，新文件获取压缩
        public static void AddFileToZip()
        {
            using (FileStream zipToOpen = new FileStream(@"c:\users\exampleuser\release.zip", FileMode.Open))
            {
                using (ZipArchive archive = new ZipArchive(zipToOpen, ZipArchiveMode.Update))
                {
                    ZipArchiveEntry readmeEntry = archive.CreateEntry("Readme.txt");

                    using (StreamWriter writer = new StreamWriter(readmeEntry.Open()))
                    {
                        writer.WriteLine("Information about this package.");
                        writer.WriteLine("========================");
                    }
                }
            }
        }

        public static void ZipArchive()
        {
            const string zipFilePath = @"..\..\Sample.zip";
            // 创建并添加被压缩文件
            using (FileStream zipFileToOpen = new FileStream(zipFilePath, FileMode.Create))
            {
                using (ZipArchive archive = new ZipArchive(zipFileToOpen, ZipArchiveMode.Create))
                {
                    System.Reflection.Assembly assemble = System.Reflection.Assembly.GetExecutingAssembly();
                    string path = assemble.Location;
                    string filename = System.IO.Path.GetFileName(path);

                    ZipArchiveEntry readMeEntry = archive.CreateEntry(filename);
                    using (System.IO.Stream stream = readMeEntry.Open())
                    {
                        byte[] bytes = System.IO.File.ReadAllBytes(path);
                        stream.Write(bytes, 0, bytes.Length);
                    }
                }
            }
        }
        #endregion

        #region
        private void Test()
        {
            List<string> strList = new List<string>() { @"D:\文档\soapUI工程\Synchro-soapui-project.xml", @"D:\文档\soapUI工程\PKBSML-soapui-project.xml", @"D:\文档\soapUI工程\PKBSML-soapui-project.xml" };
            CompressMulti(strList.ToArray(), @"D:\wulala.gz");
            DeCompressMulti(@"D:\wulala.gz", @"D:\web\");
        }

        /// <summary>
        /// 单文件压缩（生成的压缩包和第三方的解压软件兼容）
        /// </summary>
        /// <param name="sourceFilePath"></param>
        /// <returns></returns>
        public static string CompressSingle(string sourceFilePath)
        {
            string zipFileName = sourceFilePath + ".gz";
            using (FileStream sourceFileStream = new FileInfo(sourceFilePath).OpenRead())
            {
                using (FileStream zipFileStream = File.Create(zipFileName))
                {
                    using (GZipStream zipStream = new GZipStream(zipFileStream, CompressionMode.Compress))
                    {
                        sourceFileStream.CopyTo(zipStream);
                    }
                }
            }
            return zipFileName;
        }

        /// <summary>
        /// 自定义多文件压缩（生成的压缩包和第三方的压缩文件解压不兼容）
        /// </summary>
        /// <param name="sourceFileList">文件列表</param>
        /// <param name="saveFullPath">压缩包全路径</param>
        public static void CompressMulti(string[] sourceFileList, string saveFullPath)
        {
            MemoryStream ms = new MemoryStream();
            foreach (string filePath in sourceFileList)
            {
                Console.WriteLine(filePath);
                if (File.Exists(filePath))
                {
                    string fileName = Path.GetFileName(filePath);
                    byte[] fileNameBytes = System.Text.Encoding.UTF8.GetBytes(fileName);
                    byte[] sizeBytes = BitConverter.GetBytes(fileNameBytes.Length);
                    ms.Write(sizeBytes, 0, sizeBytes.Length);
                    ms.Write(fileNameBytes, 0, fileNameBytes.Length);
                    byte[] fileContentBytes = System.IO.File.ReadAllBytes(filePath);
                    ms.Write(BitConverter.GetBytes(fileContentBytes.Length), 0, 4);
                    ms.Write(fileContentBytes, 0, fileContentBytes.Length);
                }
            }
            ms.Flush();
            ms.Position = 0;
            using (FileStream zipFileStream = File.Create(saveFullPath))
            {
                using (GZipStream zipStream = new GZipStream(zipFileStream, CompressionMode.Compress))
                {
                    ms.Position = 0;
                    ms.CopyTo(zipStream);
                }
            }
            ms.Close();
        }

        /// <summary>
        /// 多文件压缩解压
        /// </summary>
        /// <param name="zipPath">压缩文件路径</param>
        /// <param name="targetPath">解压目录</param>
        public static void DeCompressMulti(string zipPath, string targetPath)
        {
            byte[] fileSize = new byte[4];
            if (File.Exists(zipPath))
            {
                using (FileStream fStream = File.Open(zipPath, FileMode.Open))
                {
                    using (MemoryStream ms = new MemoryStream())
                    {
                        using (GZipStream zipStream = new GZipStream(fStream, CompressionMode.Decompress))
                        {
                            zipStream.CopyTo(ms);
                        }
                        ms.Position = 0;
                        while (ms.Position != ms.Length)
                        {
                            ms.Read(fileSize, 0, fileSize.Length);
                            int fileNameLength = BitConverter.ToInt32(fileSize, 0);
                            byte[] fileNameBytes = new byte[fileNameLength];
                            ms.Read(fileNameBytes, 0, fileNameBytes.Length);
                            string fileName = System.Text.Encoding.UTF8.GetString(fileNameBytes);
                            string fileFulleName = targetPath + fileName;
                            ms.Read(fileSize, 0, 4);
                            int fileContentLength = BitConverter.ToInt32(fileSize, 0);
                            byte[] fileContentBytes = new byte[fileContentLength];
                            ms.Read(fileContentBytes, 0, fileContentBytes.Length);
                            using (FileStream childFileStream = File.Create(fileFulleName))
                            {
                                childFileStream.Write(fileContentBytes, 0, fileContentBytes.Length);
                            }
                        }
                    }
                }
            }
        }
        #endregion

        #region SharpZipLib
        //SharpZipLib是一个很不错的C#库，它能够解压缩zip、gzip和tar格式的文件，首先下载SharpZipLib解压后，在您的项目中引用ICSharpCode.SharpZLib.dll
        public void TestSharpZipLib()
        {
            //ZipOutputStream zipOutStream = new ZipOutputStream(File.Create("my.zip"));
            //CreateFileZipEntry(zipOutStream, "file1.txt", "file1.txt");
            //CreateFileZipEntry(zipOutStream, @"folder1\folder2\folder3\file2.txt", "file2.txt");
            //zipOutStream.Close();

            //Directory.CreateDirectory("ZipOutPut");
            //ZipInputStream zipInputStream = new ZipInputStream(File.Open("my.zip", FileMode.Open));
            //ZipEntry zipEntryFromZippedFile = zipInputStream.GetNextEntry();
            //while (zipEntryFromZippedFile != null)
            //{
            //    if (zipEntryFromZippedFile.IsFile)
            //    {
            //        FileInfo fInfo = new FileInfo(string.Format("ZipOutPut\\{0}", zipEntryFromZippedFile.Name));
            //        if (!fInfo.Directory.Exists) fInfo.Directory.Create();

            //        FileStream file = fInfo.Create();
            //        byte[] bufferFromZip = new byte[zipInputStream.Length];
            //        zipInputStream.Read(bufferFromZip, 0, bufferFromZip.Length);
            //        file.Write(bufferFromZip, 0, bufferFromZip.Length);
            //        file.Close();
            //    }
            //    zipEntryFromZippedFile = zipInputStream.GetNextEntry();
            //}
            //zipInputStream.Close();
        }

        //对二进制数据进行压缩和解压
        public static byte[] UnGZip(byte[] byteArray)
        {
            GZipInputStream gzi = new GZipInputStream(new MemoryStream(byteArray));

            MemoryStream re = new MemoryStream(50000);
            int count;
            byte[] data = new byte[50000];

            while ((count = gzi.Read(data, 0, data.Length)) != 0)
            {
                re.Write(data, 0, count);
            }
            byte[] overarr = re.ToArray();

            return overarr;

        }

        public static byte[] CompressGZip(byte[] rawData)
        {
            MemoryStream ms = new MemoryStream();

            GZipOutputStream compressedzipStream = new GZipOutputStream(ms);
            compressedzipStream.Write(rawData, 0, rawData.Length);

            compressedzipStream.Close();
            return ms.ToArray();
        }

        /// <summary>
        /// 压缩单个文件
        /// </summary>
        /// <param name="FileToZip">需要压缩的文件</param>
        /// <param name="ZipedFile">压缩后的文件(初始时不存在)</param>
        /// <param name="CompressionLevel">压缩级别</param>
        /// <param name="BlockSize">每次写入的内存大小</param>
        public void ZipFile(string FileToZip, string ZipedFile, int CompressionLevel, int BlockSize)
        {
            // 如果文件没有找到，则报错
            if (!File.Exists(FileToZip))
            {
                throw new FileNotFoundException("The specified file" + FileToZip + "could not be found. Zipping aborderd.");
            }

            string fileName = Path.GetFileName(FileToZip);      // 文件名

            Encoding gbk = Encoding.GetEncoding("gbk");      // 防止中文名乱码
            ICSharpCode.SharpZipLib.Zip.ZipConstants.DefaultCodePage = gbk.CodePage;

            FileStream streamToZip = new FileStream(FileToZip, FileMode.Open, FileAccess.Read); // 读取需压缩的文件

            FileStream ZipFile = File.Create(ZipedFile);                // 创建压缩文件
            ZipOutputStream ZipStream = new ZipOutputStream(ZipFile);
            ZipEntry ZipEntry = new ZipEntry(fileName);
            ZipStream.PutNextEntry(ZipEntry);
            ZipStream.SetLevel(CompressionLevel);             // 设置压缩级别

            byte[] buffer = new byte[BlockSize];
            int size = streamToZip.Read(buffer, 0, buffer.Length);    // 每次读入指定大小
            ZipStream.Write(buffer, 0, size);
            //Debug.Log(fileName);
            //Debug.Log(size + "----" + streamToZip.Length);        // 输入当前一次写入的内容大小和当前文件的总大小（字节）

            try
            {
                while (size < streamToZip.Length)       // 保证文件被全部写入
                {
                    int sizeRead = streamToZip.Read(buffer, 0, buffer.Length);
                    ZipStream.Write(buffer, 0, sizeRead);
                    size += sizeRead;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            ZipStream.Finish();
            ZipStream.Close();
            streamToZip.Close();
        }


        /// <summary>
        /// 将整个文件夹进行压缩
        /// </summary>
        /// <param name="文件夹和压缩后的压缩文件"（初始时不存在）>Arguments.</param>
        public void ZipFileMain(string[] args)
        {
            string[] filenames = Directory.GetFiles(args[0]);    // 获取指定的文件夹

            Crc32 crc = new Crc32();
            ZipOutputStream s = new ZipOutputStream(File.Create(args[1]));    //  压缩后的ZIP文件

            s.SetLevel(6); // 0 - store only to 9 - means best compression

            Encoding gbk = Encoding.GetEncoding("gbk");      // 防止中文名乱码
            ICSharpCode.SharpZipLib.Zip.ZipConstants.DefaultCodePage = gbk.CodePage;

            foreach (string file in filenames)
            {
                //打开压缩文件
                FileStream fs = File.OpenRead(file);
                byte[] buffer = new byte[fs.Length];
                fs.Read(buffer, 0, buffer.Length);
                string fileName = Path.GetFileName(file);      // 文件名
                ZipEntry entry = new ZipEntry(fileName);

                //Debug.Log(buffer.Length + "---" + file);     // 文件大小和文件名

                entry.DateTime = DateTime.Now;

                // set Size and the crc, because the information
                // about the size and crc should be stored in the header
                // if it is not set it is automatically written in the footer.
                // (in this case size == crc == -1 in the header)
                // Some ZIP programs have problems with zip files that don't store
                // the size and crc in the header.
                entry.Size = fs.Length;
                fs.Close();

                crc.Reset();
                crc.Update(buffer);

                entry.Crc = crc.Value;
                s.PutNextEntry(entry);
                s.Write(buffer, 0, buffer.Length);
            }

            s.Finish();
            s.Close();
        }

        /// <summary>
        /// 解压ZIP
        /// </summary>
        /// <param name="args">要解压的ZIP文件和解压后保存到的文件夹</param>
        public void UnZip(string[] args)
        {
            ZipInputStream s = new ZipInputStream(File.OpenRead(args[0]));  // 获取要解压的ZIP文件

            Encoding gbk = Encoding.GetEncoding("gbk");      // 防止中文名乱码
            ICSharpCode.SharpZipLib.Zip.ZipConstants.DefaultCodePage = gbk.CodePage;

            ZipEntry theEntry;
            while ((theEntry = s.GetNextEntry()) != null)
            {
                string directoryName = Path.GetDirectoryName(args[1]);   // 获取解压后保存到的文件夹
                string fileName = Path.GetFileName(theEntry.Name);

                //生成解压目录
                Directory.CreateDirectory(directoryName);

                if (fileName != String.Empty)
                {
                    //解压文件到指定的目录
                    FileStream streamWriter = File.Create(args[1] + theEntry.Name);

                    int size = 2048;
                    byte[] data = new byte[2048];
                    while (true)       //  循环写入单个文件
                    {
                        size = s.Read(data, 0, data.Length);
                        if (size > 0)
                        {
                            streamWriter.Write(data, 0, size);     // 每次写入的文件大小
                        }
                        else
                        {
                            break;
                        }
                    }

                    streamWriter.Close();
                }
            }
            s.Close();
        }

        //// Use this for initialization
        //void Start()
        //{
        //    //	Compression ();    // 压缩
        //    Decompress();     // 解压
        //}

        ///// <summary>
        ///// 压缩单个文件
        ///// </summary>
        //void SingleFileCompress()
        //{
        //    string s1 = "D:\\RAR\\Result\\12\\image.jpg"; // //待压缩文件
        //    string s2 = "D:\\RAR\\Result\\c.zip";       //压缩后的目标文件
        //    ZipFile(s1, s2, 6, 10);
        //}

        ///// <summary>
        ///// 将整个文件夹压缩成zip
        ///// </summary>
        //void MultiFilesCompress()
        //{
        //    string p1 = "D:\\RAR\\Result\\12";    // //待压缩文件目录
        //    string p2 = "D:\\RAR\\Result\\a.zip";   //压缩后的目标文件
        //    string[] FileProperties = new string[2];
        //    FileProperties[0] = p1;
        //    FileProperties[1] = p2;
        //    ZipFileMain(FileProperties);
        //}

        //void Decompress()    // 解压
        //{
        //    string p1 = "D:\\RAR\\Result\\a.zip";   //待解压的文件
        //    string p2 = "D:\\RAR\\Result\\11\\";//解压后放置的目标目录
        //    string[] FileProperties = new string[2];
        //    FileProperties[0] = p1;
        //    FileProperties[1] = p2;
        //    UnZip(FileProperties);
        //}
        #endregion

        #region SharpCompress
        ////SharpCompress的C#框架被开源，它支持：rar 7zip, zip, tar, tzip和bzip2格式的压缩和解压
        //public void DeCompressZip()
        //{
        //    var archive = ArchiveFactory.Open(@"C:\Code\sharpcompress\TestArchives\sharpcompress.zip");
        //    foreach (var entry in archive.Entries)
        //    {
        //        if (!entry.IsDirectory)
        //        {
        //            Console.WriteLine(entry.FilePath);
        //            entry.WriteToDirectory(@"C:\temp", ExtractOptions.ExtractFullPath | ExtractOptions.Overwrite);
        //        }
        //    }
        //}

        //public void DeCompressRAR()
        //{
        //    using (Stream stream = File.OpenRead(@"C:\Code\sharpcompress.rar"))
        //    {
        //        var reader = ReaderFactory.Open(stream);
        //        while (reader.MoveToNextEntry())
        //        {
        //            if (!reader.Entry.IsDirectory)
        //            {
        //                Console.WriteLine(reader.Entry.FilePath);
        //                reader.WriteEntryToDirectory(@"C:\temp", ExtractOptions.ExtractFullPath | ExtractOptions.Overwrite);
        //            }
        //        }
        //    }
        //}

        //public void CompressRAR()
        //{

        //    using (Stream stream = File.OpenWrite(tarPath))
        //    using (var writer = WriterFactory.Open(ArchiveType.Tar, stream))
        //    {
        //        writer.WriteAll(filesPath, "*", SearchOption.AllDirectories);
        //    }
        //    using (Stream stream = File.OpenWrite(tarbz2Path))
        //    using (var writer = WriterFactory.Open(ArchiveType.BZip2, stream))
        //    {
        //        writer.Write("Tar.tar", tarPath);
        //    }

        //}

        //public void CompressZip()
        //{

        //    using (var archive = ZipArchive.Create())
        //    {
        //        archive.AddAllFromDirectoryEntry(@"C:\\source");
        //        archive.SaveTo("@C:\\new.zip");
        //    }

        //    using (Stream stream = File.OpenWrite(tarPath))
        //    using (var writer = WriterFactory.Open(ArchiveType.Tar, stream))
        //    {
        //        writer.WriteAll(filesPath, "*", SearchOption.AllDirectories);
        //    }
        //    using (Stream stream = File.OpenWrite(tarbz2Path))
        //    using (var writer = WriterFactory.Open(ArchiveType.BZip2, stream))
        //    {
        //        writer.Write("Tar.tar", tarPath);
        //    }

        //}
        #endregion

        #region rar的压缩文件
        public static string ExistsWinRar()
        {
            string result = string.Empty;

            string key = @"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\WinRAR.exe";
            RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(key);
            if (registryKey != null)
            {
                result = registryKey.GetValue("").ToString();
            }
            registryKey.Close();

            return result;
        }
        /// <summary>
        /// 将格式为rar的压缩文件解压到指定的目录
        /// </summary>
        /// <param name="rarFileName">要解压rar文件的路径</param>
        /// <param name="saveDir">解压后要保存到的目录</param>
        public static void DeCompressRar(string rarFileName, string saveDir)
        {
            string regKey = @"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\WinRAR.exe";
            RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(regKey);
            string winrarPath = registryKey.GetValue("").ToString();
            registryKey.Close();
            string winrarDir = System.IO.Path.GetDirectoryName(winrarPath);
            String commandOptions = string.Format("x {0} {1} -y", rarFileName, saveDir);

            ProcessStartInfo processStartInfo = new ProcessStartInfo();
            processStartInfo.FileName = System.IO.Path.Combine(winrarDir, "rar.exe");
            processStartInfo.Arguments = commandOptions;
            processStartInfo.WindowStyle = ProcessWindowStyle.Hidden;

            Process process = new Process();
            process.StartInfo = processStartInfo;
            process.Start();
            process.WaitForExit();
            process.Close();
        }
        /// <summary>
        /// 将目录和文件压缩为rar格式并保存到指定的目录
        /// </summary>
        /// <param name="soruceDir">要压缩的文件夹目录</param>
        /// <param name="rarFileName">压缩后的rar保存路径</param>
        public static void CompressRar(string soruceDir, string rarFileName)
        {
            string regKey = @"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\WinRAR.exe";
            RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(regKey);
            string winrarPath = registryKey.GetValue("").ToString();
            registryKey.Close();
            string winrarDir = System.IO.Path.GetDirectoryName(winrarPath);
            String commandOptions = string.Format("a {0} {1} -r", rarFileName, soruceDir);

            ProcessStartInfo processStartInfo = new ProcessStartInfo();
            processStartInfo.FileName = System.IO.Path.Combine(winrarDir, "rar.exe");
            processStartInfo.Arguments = commandOptions;
            processStartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            Process process = new Process();
            process.StartInfo = processStartInfo;
            process.Start();
            process.WaitForExit();
            process.Close();
        }
        #endregion

    }
}

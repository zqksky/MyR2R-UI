﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace XMLMessage.BaseFun
{
    class RichTextBoxHelp
    {
        public void test()
        {
            XmlDocument xmlDoc = new XmlDocument();//创建一个XML文档对象
            xmlDoc.Load("C:\\bookstore.xml");//加载XML文档
            StringWriter tw = new StringWriter();//定义一个StringWriter
            XmlTextWriter tw2 = new XmlTextWriter(tw);//创建一个StringWriter实例的XmlTextWriter
            tw2.Formatting = Formatting.Indented;//设置缩进
            tw2.Indentation = 1;//设置缩进字数
            tw2.IndentChar = '\t';//用\t字符作为缩进
            xmlDoc.WriteTo(tw2);
            tw.Close();//关闭StringWriter
        }
    }
}

﻿// -----------------------------------------------------------------------
// <copyright file="RVNodeManager.cs" company="Applied Materials">
// TODO: Update copyright text.
// </copyright>
// -----------------------------------------------------------------------

namespace SimulatorConsole
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using TIBCO.Rendezvous;
    using AMAT.RVAdapter.CommonData;
    using AMAT.RVAdapter.CommonData.Events;
    using AMAT.RVAdapter.CommonData.EventArgs;
    using AMAT.RVAdapter.Log;

    using EIS.XML.Parser;
    using EIS.XML.Parser.Adapter;
    using EIS.XML.Parser.Structure;

    using AMAT.RVAdapter.RVComponentAdapter;
    using AMAT.RVAdapter.TransactionPool;
    using SimpleEventBroker;

    /// <summary>
    /// TODO: Update summary.
    /// </summary>
    public class RVManage
    {
        private EventBroker ebroker;
        private RVManagerConfig Config;
        private Dictionary<string, RVProxy> RVNodeDic = new Dictionary<string, RVProxy>();

        private Dictionary<string, SyncTimer> SyncDic = new Dictionary<string, SyncTimer>();
        private LogHelper Logger;
        private TransactionFactory factory = TransactionFactory.OpenFactory("Test",20);
        public RVManage()
        {
            ebroker = EventBroker.GetInstance();
            ebroker.RegisterEvents<PublicRVMessageArrivedEvent>();

            string formatXML = System.Configuration.ConfigurationManager.AppSettings["FormatXML"];
            RVManagerConfig config = ReadConfigFile();
            RVConnectInfo rvConnectInfo = null;
            try
            {
                rvConnectInfo = System.Configuration.ConfigurationManager.GetSection("RVConnectInfo") as RVConnectInfo;
            }
            catch (Exception ex)
            {

            }
            if (rvConnectInfo == null)
            {

            }

            foreach (RVNodeConfig nodeConfig in config.RVAdapterConfigList)
            {
                nodeConfig.ConnectionInfo = rvConnectInfo;
                try
                {
                    nodeConfig.FormatXML = Convert.ToBoolean(formatXML);
                }
                catch (Exception ex)
                {
                    nodeConfig.FormatXML = false;
                }
            }

            Config = config;
            Logger = LogHelper.GetInstance();
            ebroker.SubscribeEvents<PublicRVMessageArrivedEvent>(HandlePublicRVMessageArrivedEvent);
        }

        public bool InitRVService()
        {
            bool result = false;
            TIBCO.Rendezvous.Environment.Open();

            foreach (RVNodeConfig rvConfig in Config.RVAdapterConfigList)
            {
                RVProxy proxy = new RVProxy(rvConfig);
                if (proxy.Connect())
                {
                    RVNodeDic.Add(proxy.Config.SystemName, proxy);
                }
                else
                {
                    result = false;
                    break;
                }

                result = true;
            }

            if (!result)
            {
                CloseAllService();
                return result;
            }

            foreach (RVProxy rvProxy in RVNodeDic.Values)
            {

                if (!rvProxy.CreatePublicListener())
                {
                    result = false;
                    break;
                }

                if (!rvProxy.CreatePrivateListener())
                {
                    result = false;
                    break;
                }
            }

            if (!result)
            {
                CloseAllService();
            }

            return result;
        }

        public void CloseAllService()
        {
            foreach (RVProxy rvProxy in RVNodeDic.Values)
            {
                try
                {
                    rvProxy.Disconnect();
                }
                catch (Exception ex)
                {

                }
            }
        }

        public void CloseAllPublicListern()
        {
            foreach (RVProxy rvProxy in RVNodeDic.Values)
            {
                try
                {
                    rvProxy.ClosePublicListern();
                }
                catch (Exception ex)
                {

                }
            }
        }

        public void CloseRV()
        {
            TIBCO.Rendezvous.Environment.Close();
        }

        public void CloseService(string systemName)
        {
            if (RVNodeDic.ContainsKey(systemName))
            {
                RVProxy proxy = RVNodeDic[systemName];
                proxy.Disconnect();
            }
        }

        private RVManagerConfig ReadConfigFile()
        {
            RVManagerConfig config = new RVManagerConfig();
            string filePath = System.Configuration.ConfigurationManager.AppSettings["SimLocation"];
            using (System.IO.StreamReader sr = new System.IO.StreamReader(filePath))
            {
                string message;
                while ((message = sr.ReadLine()) != null)
                {
                    RVNodeConfig nodeConfig = new RVNodeConfig();
                    if (message.StartsWith("SYNC"))
                    {

                        char[] split = { ':' };
                        char[] split2 = { ';' };
                        string[] messageList = message.Split(split);
                        string[] syncMessage = messageList[1].Split(split2);
                        config.ReplyMessageList.AddRange(syncMessage);
                    }
                    else
                    {
                        char[] split = { ';' };
                        char[] split2 = { ',' };
                        string[] messages = message.Split(split);
                        foreach (string s in messages)
                        {
                            string[] pair = s.Split(split2);
                            switch (pair[0])
                            {
                                case "SystemName":
                                    nodeConfig.SystemName = pair[1];
                                    break;
                                case "ListenSubject":
                                    nodeConfig.ListenSubject = pair[1];
                                    break;
                                case "TargetSubject":
                                    nodeConfig.TargetSubject = pair[1];
                                    break;
                                case "GroupName":
                                    nodeConfig.GroupName = pair[1];
                                    break;
                                case "Service":
                                    nodeConfig.Service = pair[1];
                                    break;
                                case "Network":
                                    nodeConfig.Network = string.Format(";{0}", pair[1]);
                                    break;
                                case "Daemon":
                                    nodeConfig.Daemon = pair[1];
                                    break;
                            }
                        }

                        config.RVAdapterConfigList.Add(nodeConfig);
                    }
                }
            }
            return config;
        }

        private void HandlePublicRVMessageArrivedEvent(object sender, EventArgs e)
        {
            ThreadPool.QueueUserWorkItem(PublicRVMessageArrivedEventThread, e);
        }

        private void PublicRVMessageArrivedEventThread(object e)
        {
            PublicRVMessageArrivedEventArgs args = e as PublicRVMessageArrivedEventArgs;
            Logger.LogTrace(string.Format("Target:{0} ,OnPublicReceived ,TargetSubject:{1}----->>>>>>>>>-------", args.SystemName, args.Subject));

            EIS.XML.Parser.Adapter.Header.msgType header = null;
            Exception ex;
            string xml = args.Message;

            Console.WriteLine("Public Message Received: \r\n" + xml);

            bool result = EIS.XML.Parser.Adapter.Header.msgType.Deserialize(xml, out header, out ex);

            if (!result)
            {
                Console.WriteLine("Error Message\r\n.." + ex.Message);
                return;
            }

            //get reply target, msgHeader.reply>Message.Reply
            string replyAddress = header.rvHeader.replyApplication.address[0].Value;
            /*
            if(header.rvHeader.replyApplication!=null 
                && header.rvHeader.replyApplication.address!=null 
                && (!string.IsNullOrEmpty(header.rvHeader.replyApplication.address.Value))){
                replyAddress=header.rvHeader.replyApplication.address.Value;
            }*/
            if ("RandomQuery".Equals(header.msgHeader.srvMethod))
            {
                factory.CreateTransaction(header.msgHeader.txId, 30, DateTime.Now, "");
                Console.WriteLine("RandomQuery Request TxId:" + header.msgHeader.txId);
                this.TestRandomQuery(xml, args.Subject, replyAddress);

                factory.CloseTransaction(header.msgHeader.txId);
                Console.WriteLine("replyAddress :" + replyAddress);
            }

            if ("AlarmMessage".Equals(header.msgHeader.srvMethod))
            {
                factory.CreateTransaction(header.msgHeader.txId, 30, DateTime.Now, "");
                Console.WriteLine("AlarmMessage Request TxId:" + header.msgHeader.txId);
                this.TestSendAlarm(xml, args.Subject, replyAddress);

                factory.CloseTransaction(header.msgHeader.txId);
                Console.WriteLine("replyAddress 1:" + replyAddress);
            }
        }


        public string TestSendMetrology()
        {
            RVProxy proxy = RVNodeDic["I_AM_MES"];
            EIS.XML.Parser.Adapter.Metrology.msgType met = EIS.XML.Parser.Adapter.Metrology.msgType.LoadFromFile(@"./message/metrology.xml");
            //replyApplication
            met.rvHeader.replyApplication = new EIS.XML.Parser.Adapter.Metrology.replyApplicationType();
            met.rvHeader.replyApplication.addressNo = "1";
            met.rvHeader.replyApplication.address = new List<EIS.XML.Parser.Adapter.Metrology.addressType>();
            EIS.XML.Parser.Adapter.Metrology.addressType tmp = new EIS.XML.Parser.Adapter.Metrology.addressType();
            tmp.seq = "1";
            tmp.applicationName = "MES";
            met.rvHeader.replyApplication.address.Add(tmp);
            //met.rvHeader.replyApplication.address.Value = proxy.GetInbox();
            //destination
            met.rvHeader.destination.application = "MES";
            met.rvHeader.destination.address = proxy.Config.TargetSubject;
            met.msgHeader.timeStamp = DateTime.Now.ToString();
            met.msgHeader.txId = string.Format("{0}.{1}", DateTime.Now.ToString("yyyyMMddHHmmss.fff"), new Object().GetHashCode().ToString());
            met.msgHeader.timeOut = "30";
            int retCode;
            string retMessage;
            string txId = met.msgHeader.txId;

            string res = "";
            if (string.IsNullOrEmpty(met.rvHeader.replyApplication.address[0].Value))
            {
                proxy.SendMessage(met.SerializeXmlSpec(true, met), proxy.Config.TargetSubject, out retCode, out retMessage);
            }
            else
            {
                factory.CreateTransaction(txId, 20, DateTime.Now, "");
                res = proxy.SendRequest(met.SerializeXmlSpec(true, met), proxy.Config.TargetSubject, 20, proxy.GetInbox(), txId, out retCode, out retMessage);
                factory.CloseTransaction(txId);
            }
            
            Console.WriteLine(res);
            return res;
        }

        //Test Method: xxx
        public string TestSendUsedSettings()
        {
            RVProxy proxy=RVNodeDic["I_AM_MES"];
            EIS.XML.Parser.Adapter.UsedSettings.msgType used = EIS.XML.Parser.Adapter.UsedSettings.msgType.LoadFromFile(@"./message/used.xml");
            //replyApplication
            used.rvHeader.replyApplication = new EIS.XML.Parser.Adapter.UsedSettings.replyApplicationType();
            used.rvHeader.replyApplication.addressNo = "1";
            used.rvHeader.replyApplication.address = new List<EIS.XML.Parser.Adapter.UsedSettings.addressType>();
            EIS.XML.Parser.Adapter.UsedSettings.addressType tmp = new EIS.XML.Parser.Adapter.UsedSettings.addressType();
            tmp.seq = "1";
            tmp.applicationName = "MES";
            used.rvHeader.replyApplication.address.Add(tmp);
            //used.rvHeader.replyApplication.address.Value = proxy.GetInbox();
            //destination
            used.rvHeader.destination.application = "MES";
            used.rvHeader.destination.address = proxy.Config.TargetSubject;
            used.msgHeader.timeStamp = DateTime.Now.ToString();
            used.msgHeader.txId = string.Format("{0}.{1}", DateTime.Now.ToString("yyyyMMddHHmmss.fff"), new Object().GetHashCode().ToString());
            used.msgHeader.timeOut = "30";
            int retCode;
            string retMessage;
            string txId = used.msgHeader.txId;

            string res = "";
            
            if (string.IsNullOrEmpty(used.rvHeader.replyApplication.address[0].Value))
            {
                proxy.SendMessage(used.SerializeXmlSpec(true, used), proxy.Config.TargetSubject, out retCode, out retMessage);
            }
            else
            {
                factory.CreateTransaction(txId, 20, DateTime.Now, "");
                res = proxy.SendRequest(used.SerializeXmlSpec(true, used), proxy.Config.TargetSubject, 20, proxy.GetInbox(), txId, out retCode, out retMessage);
                factory.CloseTransaction(txId);
            }
            
            Console.WriteLine(res);
            return res;
        }

        //Test Method: xxx
        public string TestCalcRecipeSettings()
        {
            RVProxy proxy = RVNodeDic["I_AM_MES"];
            EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgType used = EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgType.LoadFromFile(@"./message/calc.xml");
            //replyApplication
            used.rvHeader.replyApplication = new EIS.XML.Parser.Adapter.CalcRecipeSettingsR.replyApplicationType();
            used.rvHeader.replyApplication.addressNo = "1";
            used.rvHeader.replyApplication.address = new List<EIS.XML.Parser.Adapter.CalcRecipeSettingsR.addressType>();
            EIS.XML.Parser.Adapter.CalcRecipeSettingsR.addressType tmp = new EIS.XML.Parser.Adapter.CalcRecipeSettingsR.addressType();
            tmp.seq = "1";
            tmp.applicationName = "MES";
            tmp.Value = proxy.GetInbox();
            used.rvHeader.replyApplication.address.Add(tmp);
            //destination
            used.rvHeader.destination.application = "MES";
            used.rvHeader.destination.address = proxy.Config.TargetSubject;
            used.msgHeader.timeStamp = DateTime.Now.ToString();
            used.msgHeader.txId = string.Format("{0}.{1}", DateTime.Now.ToString("yyyyMMddHHmmss.fff"), new Object().GetHashCode().ToString());
            used.msgHeader.timeOut = "30";

            int retCode;
            string retMessage;
            string txId = used.msgHeader.txId;
            factory.CreateTransaction(txId, 30, DateTime.Now, "");
            string res = proxy.SendRequest(used.SerializeXmlSpec(true,used), proxy.Config.TargetSubject, 30, proxy.GetInbox(), txId,out retCode, out retMessage);
            factory.CloseTransaction(txId);
            //Console.WriteLine("CalcRecipeSettings Reply:\r\n"+res);
            return res;
        }

        //Test Method: xxx
        public void TestSendAlarm(string requestXml, string replyTarget, string replyTargetSubject)
        {
            EIS.XML.Parser.Adapter.AlarmReportEventR.msgType r = EIS.XML.Parser.Adapter.AlarmReportEventR.msgType.Deserialize(requestXml);

            r.msgBody.AlarmHeader = new EIS.XML.Parser.Adapter.AlarmReportEventR.AlarmHeaderType();
            r.msgBody.AlarmBody = new EIS.XML.Parser.Adapter.AlarmReportEventR.AlarmBodyType();
            r.msgBody.AlarmBody.ReturnStatus = "OK";
            r.msgBody.AlarmBody.Comments = "";
            r.msgBody.AlarmReturn = new EIS.XML.Parser.Adapter.AlarmReportEventR.AlarmReturnType();
            r.msgBody.AlarmReturn.ReturnCode = "0";
            r.msgBody.AlarmReturn.ReturnMessage = "";

            string replyXml = r.SerializeXmlSpec(true, r);
            Console.WriteLine("Reply SendAlarm:\r\n" + replyXml);
            RVProxy proxy = RVNodeDic["I_AM_AMS"];
            int retCode;
            string retMessage;
            System.Threading.Thread.Sleep(1500);
            if(!string.IsNullOrEmpty(replyTargetSubject)){
                proxy.SendPrivateMessage(replyXml, replyTargetSubject, out retCode, out retMessage);
            }
        }

        //Test Methos: xxx
        public void TestRandomQuery(string requestXml, string replyTarget, string replyTargetSubject)

        {
            EIS.XML.Parser.Adapter.RandomQueryR.msgType r = EIS.XML.Parser.Adapter.RandomQueryR.msgType.Deserialize(requestXml);
            /*
            string[] names = r.msgBody.vidNames.Split(',');
            StringBuilder sb = new StringBuilder("");
            foreach (string s in names)
            {
                sb.Append(",").Append(new System.Random(10).NextDouble());
            }
            r.msgBody.vidValues = sb.ToString().TrimStart(',');
            */
            string replyXml = r.SerializeXmlSpec(true, r);
            System.Threading.Thread.Sleep(500);
            Console.WriteLine("Reply RandomQuery:\r\n" + replyXml);
            RVProxy proxy = RVNodeDic["I_AM_EAP"];
            int retCode;
            string retMessage;
            
            proxy.SendPrivateMessage(replyXml, replyTargetSubject, out retCode, out retMessage);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Configuration;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

using TIBCO.Rendezvous;
using AMAT.RVAdapter.CommonData;

namespace SimulatorConsole
{
    public class Program
    {
        
        public Program()
        {
           

        }
        
        static void Main(string[] args)
        {
            RVManage manager = new RVManage();
            
            manager.InitRVService();
            AMAT.RVAdapter.TransactionPool.TransactionFactory factory = AMAT.RVAdapter.TransactionPool.TransactionFactory.OpenFactory("test", 100);
 
            Program prog = new Program();
            Console.Write(">");
            string cmd = Console.ReadLine();
            while (true)
            {
                if (cmd.Equals("used"))
                {
                    //string reply = prog.TestSendUsedSettings();
                    //Console.WriteLine(reply == null ? "None Reply" : reply);
                    manager.TestSendUsedSettings();
                }
                if (cmd.Equals("metrology"))
                {
                    //string reply = prog.TestSendUsedSettings();
                    //Console.WriteLine(reply == null ? "None Reply" : reply);
                    manager.TestSendMetrology();
                }
                else if (cmd.Equals("calc"))
                {
                    var calc = new Func<string>(manager.TestCalcRecipeSettings);

                    Task<string>.Factory.FromAsync(calc.BeginInvoke, calc.EndInvoke, null).ContinueWith(t => Console.WriteLine("：{0}", t.Result));

                    Console.ReadKey();

                    //string reply = prog.TestCalcRecipeSettings();
                    //Console.WriteLine(reply == null ? "None Reply" : reply);
                    //manager.TestCalcRecipeSettings();
                }
                else if (cmd.Equals("test"))
                {
                    //string reply = prog.Test();
                    //Console.WriteLine("...");
                }
                else if ("exit".Equals(cmd))
                {
                    break;

                }
                Console.Write("\r\n>");

                cmd = Console.ReadLine();
            }
            manager.CloseAllService();
        
        }

    }
}

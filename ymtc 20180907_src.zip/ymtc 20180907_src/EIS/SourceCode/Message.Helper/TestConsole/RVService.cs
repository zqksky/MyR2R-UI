﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using TIBCO.Rendezvous;

namespace SimulatorConsole
{
   public  class RVService
    {
       private bool listening = false;
        public string Inbox;
        private TIBCO.Rendezvous.NetTransport netTtransport = null;
        private TIBCO.Rendezvous.Queue queue = null;
        public TIBCO.Rendezvous.Listener publicListner = null;
        public TIBCO.Rendezvous.Listener privateListener = null;
        
        //simulator MES listen
        private string SystemName = "MES";
        private string Service = "7580";
        private string Network = ";225.225.225.0";
        private string Daemon = "tcp:192.168.150.135:7500";
        private string listenSubject = "Y1.TEST.MES.*";
        //Service,7580;Network,;225.225.225.0;Daemon,tcp:127.0.0.1:7500
       //private
       private string FiledName="xmlData";

       public RVService(string systemName, string listenSubject)
       {
           this.SystemName = systemName;
           this.listenSubject = listenSubject;
       }

        public bool Connect()
        {
            bool result = false;
            try
            {
                TIBCO.Rendezvous.Environment.Open();
                netTtransport = new NetTransport(Service, Network, Daemon);
                Inbox = netTtransport.CreateInbox();

            }
            catch (Exception ex)
            {
                result = false;
            }

            return result;
        }

        public void StopSubscribe()
        {
            listening = false;
        }

        public void StartSubscribe()
        {
            while (listening)
            {
                TIBCO.Rendezvous.Queue.Default.TimedDispatch(1.0);
            }            
        }

        public bool CreatePublicListener()
        {
            bool result = false;
            try
            {
                //queue = new TIBCO.Rendezvous.Queue();
                publicListner = new Listener(Queue.Default, netTtransport, listenSubject, null);
                listening = true;
                Console.WriteLine(string.Format("Create Public Listener, Listen Subject:{0}, Service:{1}, Network:{2}, Daemon:{3}",listenSubject,Service, Network, Daemon));
                //publicListner.MessageReceived += new MessageReceivedEventHandler(ProcessPublicRVMessageArrived);
            }
            catch (Exception ex)
            {
                result = false;
            }
            return result;
        }

        public bool CreatePrivateListener()
        {
            bool result = false;
            try
            {
                privateListener = new Listener(Queue.Default, netTtransport, Inbox, null);
                Console.WriteLine(string.Format("Create Private Listener, Inbox Subject:{0}, Service:{1}, Network:{2}, Daemon:{3}", Inbox, Service, Network, Daemon));

                //privateListener.MessageReceived += new MessageReceivedEventHandler(ProcessPrivateRVMessageArrived);
                result = true;
            }
            catch (Exception ex)
            {
                result = false;
            }
            return result;
        }

        public bool SendPrivate(string message, string targetSubject, out int RetCode, out string RetMessage)
        {
            RetCode = 0;
            RetMessage = "";
            bool result = false;
            try
            {
                TIBCO.Rendezvous.Message replyMessage = new TIBCO.Rendezvous.Message() { SendSubject = targetSubject };
                replyMessage.AddField(this.FiledName, message);
                //this.publicListner.Transport.Send(replyMessage);
                this.netTtransport.Send(replyMessage);
                result = true;
            }
            catch (Exception ex)
            {
                result = false;
                RetCode = 1;
                RetMessage = ex.Message;
            }
            return result;
        }

        public bool SendReply(Message requestMsg,string message, string targetSubject, out int RetCode, out string RetMessage)
        {
            RetCode = 0;
            RetMessage = "";
            bool result = false;
            try
            {
                TIBCO.Rendezvous.Message replyMessage = new TIBCO.Rendezvous.Message() { SendSubject = targetSubject };
                replyMessage.AddField(this.FiledName, message);
                this.netTtransport.SendReply(replyMessage,requestMsg);
                result = true;
            }
            catch (Exception ex)
            {
                result = false;
                RetCode = 1;
                RetMessage = ex.Message;
            }
            return result;
        }

        public string SendRequest(string message, string targetSubject, string replySubject, out int RetCode, out string RetMessage)
        {
            RetCode = 0;
            RetMessage = "";
            try
            {
                TIBCO.Rendezvous.Message rvMessage = new TIBCO.Rendezvous.Message() { SendSubject = targetSubject, ReplySubject=replySubject};
                rvMessage.AddField(this.FiledName, message);
                TIBCO.Rendezvous.Message reply=this.netTtransport.SendRequest(rvMessage, 20);
                return reply.GetFieldByIndex(0);
            }
            catch (Exception ex)
            {
                RetCode = 1;
                RetMessage = ex.Message;
            }
            return "";
        }
        
        public string Send(string message, string targetSubject, string replySubject, out int RetCode, out string RetMessage)
        {
            RetCode = 0;
            RetMessage = "";
            try
            {
                TIBCO.Rendezvous.Message rvMessage = new TIBCO.Rendezvous.Message() { SendSubject = targetSubject, ReplySubject = replySubject };
                rvMessage.AddField(this.FiledName, message);
                this.netTtransport.Send(rvMessage);
                return "";
            }
            catch (Exception ex)
            {
                RetCode = 1;
                RetMessage = ex.Message;
            }
            return "";
        }
  
   }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AMAT.RVAdapter.CommonData;
using AMAT.RVAdapter.CommonData.EventArgs;
using EIS.XML.Parser;
using EIS.XML.Parser.Adapter;

namespace EIS.Business.Generic
{
    public abstract class ServiceController
    {
        public event RVMessageSendHandler RvMessageReplyHandler = null;

        public event DispatchEventHandler DispatchEventHandler = null;

        public event DispatchCommandHandler DispatchCommandHandler = null;

        //primary in
        public  void CmdCalcRecipeSettings(PublicRVMessageArrivedEventArgs args)
        {
            //1.dispatch Event to E3 lot by lot
            #region dispatch Event to E3 lot by lot
            EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgType calc = EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgType.Deserialize(args.Message);
            DispatchArgs dsp = new DispatchArgs();

            dsp.Fab = calc.msgBody.fabName;
            dsp.Area = calc.msgBody.area;
            dsp.BatchId = calc.msgBody.batchId;
            dsp.ServiceMethod = calc.msgHeader.srvMethod;
            dsp.EventName = calc.msgBody.eventName;

            SortedList<string, EIS.XML.Parser.Adapter.CalcRecipeSettingsR.lotType> lots = new SortedList<string, EIS.XML.Parser.Adapter.CalcRecipeSettingsR.lotType>();
            SortedList<string, string> lotsRetCode = new SortedList<string, string>();
            SortedList<string, string> lotsRetMsg = new SortedList<string, string>();
            List<string> lotList = new List<string>();
            foreach (EIS.XML.Parser.Adapter.CalcRecipeSettingsR.lotType l in calc.msgBody.lot)
            {
                lotList.Add(l.lotId);
                lots.Add(l.lotId, l);
                lotsRetCode.Add(l.lotId, "0");
                lotsRetMsg.Add(l.lotId, "Start CalcRecipeSettings");
            }

            //loop each lot and dispatch command to E3 
            foreach (string itor in lotList)
            {
                EIS.XML.Parser.Adapter.CalcRecipeSettingsR.lotType s = lots[itor];
                calc.msgBody.lot.Clear();
                calc.msgBody.retCode = "0";
                calc.msgBody.retMessage = "";
                //
                dsp.DspRetCode = 0;
                dsp.DspRetMessage = "";
                //
                dsp.Layer = s.layerName;
                dsp.LotId = s.lotId;
                dsp.ProductId = s.productId;
                dsp.ProductType = s.productType;
                dsp.R2RControl = s.r2rMode;
                dsp.RecipeId = s.recipeId;
                dsp.StepSequence = s.stepSequence;
                dsp.ToolId = s.eqpId;
                dsp.TxId = calc.msgHeader.txId;
                //dsp.ReplyTarget = args.ReplySubject;
                foreach (AddressInfo reply in args.ReplySubjects)
                {
                    dsp.ReplyTarget += reply.ToString() + " ";
                }
                

                calc.msgBody.lot.Add(s);

                dsp.XmlString = calc.SerializeXmlSpec(false, calc);
                //Dispatch Event to E3 for lot
                if (this.DispatchCommandHandler != null)
                {
                    this.DispatchCommandHandler(dsp);
                }

                //to get 
                try{
                    if (dsp.DspRetCode != 0)
                    {
                        throw new Exception(string.Format("DispatchCommand Error{0}", dsp.DspRetMessage));
                    }

                    string typeName = "";
                    string errMessge = "";
                    StructureBase sb = (StructureBase)StructureUitily.DeserializeToObject(dsp.ReplyXmlString, StructureUitily.FindType(dsp.ReplyXmlString, out typeName, out errMessge));
                    bool result = this.MergeOutStructureResult2XmlObject(calc,sb);
                    
                    if (!result)
                        throw new Exception("Error when BuildOutStructureResult2XmlObject.");
                    //
                    lots[dsp.LotId] = calc.msgBody.lot[0];
                    lotsRetCode[dsp.LotId] = calc.msgBody.retCode;
                    lotsRetMsg[dsp.LotId] = lotsRetMsg[dsp.LotId]+","+calc.msgBody.retMessage;
                }
                catch(Exception ex)
                {
                    lotsRetCode[dsp.LotId] = "-1";
                    lotsRetMsg[dsp.LotId] = lotsRetMsg[dsp.LotId] + "," + ex.Message;
                }
            }
            #endregion

            //2.0. merge lots result in msgBody
            #region merge lots result in msgBody
            calc.msgBody.lot.Clear();
            calc.msgBody.retCode = "0";
            calc.msgBody.retMessage = "";
            foreach (EIS.XML.Parser.Adapter.CalcRecipeSettingsR.lotType s in lots.Values)
            {
                string lotId = s.lotId;
                if ("0".Equals(calc.msgBody.retCode)) calc.msgBody.retCode = lotsRetCode[lotId];
                calc.msgBody.retMessage += ("," + lotId + "[Code:" + lotsRetCode[lotId] + " Details:" + lotsRetMsg[lotId]+" End]");

                calc.msgBody.lot.Add(s);
            }
            #endregion

            //2.generate the reply message and notify the sender
            #region generate the reply message and notify the sender
            if (this.RvMessageReplyHandler != null)
            {
                RVMessageSendEventArgs e = new RVMessageSendEventArgs();
                e.Domain = calc.rvHeader.source.domain;
                //for CalcRecipeSettings
                //only reply to the last address and keep the first address in the message
                if (calc.rvHeader.replyApplication.address.Count() >= 1)
                {
                    calc.rvHeader.replyApplication.address.RemoveAt(calc.rvHeader.replyApplication.address.Count() - 1);
                    calc.rvHeader.replyApplication.addressNo = calc.rvHeader.replyApplication.address.Count()+"";
                }

                //exchange the source and destination
                string tmpApplication=calc.rvHeader.source.application;
                string tmpMsgBus = calc.rvHeader.source.msgBus;
                string tmpDomain = calc.rvHeader.source.domain;
                string tmpAddress = calc.rvHeader.source.address;
                calc.rvHeader.source.application = calc.rvHeader.destination.application;
                calc.rvHeader.source.msgBus = calc.rvHeader.destination.msgBus;
                calc.rvHeader.source.domain = calc.rvHeader.destination.domain;
                calc.rvHeader.source.address = calc.rvHeader.destination.address;
                calc.rvHeader.destination.application = tmpApplication;
                calc.rvHeader.destination.msgBus = tmpMsgBus;
                calc.rvHeader.destination.domain = tmpDomain;
                calc.rvHeader.destination.address = tmpAddress;
                //
                e.MessageXml = calc.SerializeXmlSpec(true, calc);
                //e.ReplyAddress = "";
                e.ReplyExpected = false;
                e.SourceSystem = SourceApplication.R2R.ToString();
                e.SourceAddress = args.Subject;
                //e.TargetSystem = args.SystemName;
                e.TxId = calc.msgHeader.txId;

                //for CalcRecipeSettings
                //only reply to the last address and keep the first address in the message
                e.TargetAddress = args.ReplySubjects.Last().Address;
                e.TargetSystem = args.ReplySubjects.Last().Application;

                e.xmlSpec = calc;
                this.RvMessageReplyHandler(e);
            }
            #endregion
        }

        //primary in
        public void CmdJobInSettings(PublicRVMessageArrivedEventArgs args)
        {
            //1.generate the sync reply message and notify the sender
            #region generate the sync reply message and notify the sender
            EIS.XML.Parser.Adapter.Header.msgType header;
            Exception ex;
            bool result;

            result = EIS.XML.Parser.Adapter.Header.msgType.Deserialize(args.Message, out header, out ex);
            header.msgBody = new XML.Parser.Adapter.Header.msgBodyType();
            header.msgBody.retCode = "0";
            header.msgBody.retMessage = "JobInSettings Received Confirm.";
            //header.rvHeader.replyApplication = null;

            if (args.ReplySubjects == null || args.ReplySubjects.Count() == 0)
            {
                //none reply address 
            }
            else if (this.RvMessageReplyHandler != null)
            {
                RVMessageSendEventArgs e = new RVMessageSendEventArgs();
                e.Domain = header.rvHeader.source.domain;
                //for UsedSettings
                //only reply to the last address and keep the first address in the message
                if (header.rvHeader.replyApplication.address.Count() >= 1)
                {
                    header.rvHeader.replyApplication.address.RemoveAt(header.rvHeader.replyApplication.address.Count() - 1);
                    header.rvHeader.replyApplication.addressNo = header.rvHeader.replyApplication.address.Count() + "";
                }
                //exchange the source and destination
                string tmpApplication = header.rvHeader.source.application;
                string tmpMsgBus = header.rvHeader.source.msgBus;
                string tmpDomain = header.rvHeader.source.domain;
                string tmpAddress = header.rvHeader.source.address;
                header.rvHeader.source.application = header.rvHeader.destination.application;
                header.rvHeader.source.msgBus = header.rvHeader.destination.msgBus;
                header.rvHeader.source.domain = header.rvHeader.destination.domain;
                header.rvHeader.source.address = header.rvHeader.destination.address;
                header.rvHeader.destination.application = tmpApplication;
                header.rvHeader.destination.msgBus = tmpMsgBus;
                header.rvHeader.destination.domain = tmpDomain;
                header.rvHeader.destination.address = tmpAddress;
                //
                e.MessageXml = header.SerializeXmlSpec(true, header);
                //e.ReplyAddress = "";
                e.ReplyExpected = false;
                e.SourceSystem = SourceApplication.R2R.ToString();
                e.SourceAddress = args.Subject;
                //e.TargetSystem = args.SystemName;
                e.TxId = header.msgHeader.txId;

                //for JonInSettings
                //only reply to the last address and keep the first address in the message
                e.TargetSystem = args.ReplySubjects.Last().Application;
                e.TargetAddress = args.ReplySubjects.Last().Address;

                e.xmlSpec = header;
                this.RvMessageReplyHandler(e);
            }
            #endregion

            //2.dispatch Event to E3 lot by lot
            #region dispatch Event to E3 lot by lot
            EIS.XML.Parser.Adapter.JobInSettings.msgType jobIn;
            result = EIS.XML.Parser.Adapter.JobInSettings.msgType.Deserialize(args.Message, out jobIn, out ex);

            DispatchArgs dsp = new DispatchArgs();

            dsp.Fab = jobIn.msgBody.fabName;
            dsp.Area = jobIn.msgBody.area;
            dsp.BatchId = jobIn.msgBody.batchId;
            dsp.ServiceMethod = jobIn.msgHeader.srvMethod;
            dsp.EventName = jobIn.msgBody.eventName;

            SortedList<string, EIS.XML.Parser.Adapter.JobInSettings.lotType> lots = new SortedList<string, XML.Parser.Adapter.JobInSettings.lotType>();
            foreach (EIS.XML.Parser.Adapter.JobInSettings.lotType l in jobIn.msgBody.lot)
            {
                lots.Add(l.lotId, l);
            }

            //loop each lot and dispatch event to E3 
            jobIn.msgBody.lot.Clear();
            foreach (EIS.XML.Parser.Adapter.JobInSettings.lotType s in lots.Values)
            {
                dsp.DspRetCode = 0;
                dsp.DspRetMessage = "";
                //
                dsp.Layer = s.layerName;
                dsp.LotId = s.lotId;
                dsp.ProductId = s.productId;
                dsp.ProductType = s.productType;
                dsp.R2RControl = s.r2rMode;
                dsp.RecipeId = s.recipeId;
                dsp.StepSequence = s.stepSequence;
                dsp.ToolId = s.eqpId;
                dsp.TxId = jobIn.msgHeader.txId;

                //dsp.ReplyTarget = args.ReplySubject;
                foreach (AddressInfo reply in args.ReplySubjects)
                {
                    dsp.ReplyTarget += reply.ToString() + " ";
                }

                jobIn.msgBody.lot.Add(s);

                dsp.XmlString = jobIn.SerializeXmlSpec(true, jobIn);

                //Dispatch Event to E3 for lot
                if (this.DispatchEventHandler != null)
                {
                    this.DispatchEventHandler(dsp);
                }
            }
            #endregion
        }

        //primary in
        public void CmdUsedSettings(PublicRVMessageArrivedEventArgs args)
        {
            //1.generate the sync reply message and notify the sender
            #region generate the sync reply message and notify the sender
            EIS.XML.Parser.Adapter.Header.msgType header ;
            Exception ex;
            bool result;

            result = EIS.XML.Parser.Adapter.Header.msgType.Deserialize(args.Message, out header, out ex);
            header.msgBody = new XML.Parser.Adapter.Header.msgBodyType();
            header.msgBody.retCode = "0";
            header.msgBody.retMessage = "UsedSettings Received Confirm.";
            //header.rvHeader.replyApplication = null;

            if (args.ReplySubjects == null || args.ReplySubjects.Count()==0)
            {
                //none reply address 
            }
            else if (this.RvMessageReplyHandler != null)
            {
                RVMessageSendEventArgs e = new RVMessageSendEventArgs();
                e.Domain = header.rvHeader.source.domain;
                //for UsedSettings
                //only reply to the last address and keep the first address in the message
                if (header.rvHeader.replyApplication.address.Count() >= 1)
                {
                    header.rvHeader.replyApplication.address.RemoveAt(header.rvHeader.replyApplication.address.Count() - 1);
                    header.rvHeader.replyApplication.addressNo = header.rvHeader.replyApplication.address.Count() + "";
                }
                //exchange the source and destination
                string tmpApplication = header.rvHeader.source.application;
                string tmpMsgBus = header.rvHeader.source.msgBus;
                string tmpDomain = header.rvHeader.source.domain;
                string tmpAddress = header.rvHeader.source.address;
                header.rvHeader.source.application = header.rvHeader.destination.application;
                header.rvHeader.source.msgBus = header.rvHeader.destination.msgBus;
                header.rvHeader.source.domain = header.rvHeader.destination.domain;
                header.rvHeader.source.address = header.rvHeader.destination.address;
                header.rvHeader.destination.application = tmpApplication;
                header.rvHeader.destination.msgBus = tmpMsgBus;
                header.rvHeader.destination.domain = tmpDomain;
                header.rvHeader.destination.address = tmpAddress;
                //
                e.MessageXml = header.SerializeXmlSpec(true,header);
                //e.ReplyAddress = "";
                e.ReplyExpected = false;
                e.SourceSystem = SourceApplication.R2R.ToString();
                e.SourceAddress = args.Subject;
                //e.TargetSystem = args.SystemName;
                e.TxId = header.msgHeader.txId;

                //for UsedSettings
                //only reply to the last address and keep the first address in the message
                e.TargetSystem = args.ReplySubjects.Last().Application;
                e.TargetAddress = args.ReplySubjects.Last().Address;
                
                e.xmlSpec=header;
                this.RvMessageReplyHandler(e);
            }
            #endregion

            //2.dispatch Event to E3 lot by lot
            #region dispatch Event to E3 lot by lot
            EIS.XML.Parser.Adapter.UsedSettings.msgType used;
            result = EIS.XML.Parser.Adapter.UsedSettings.msgType.Deserialize(args.Message, out used, out ex);

            DispatchArgs dsp=new DispatchArgs();

            dsp.Fab = used.msgBody.fabName;
            dsp.Area=used.msgBody.area;
            dsp.BatchId = used.msgBody.batchId;
            dsp.ServiceMethod=used.msgHeader.srvMethod;
            dsp.EventName = used.msgBody.eventName;

            SortedList<string,EIS.XML.Parser.Adapter.UsedSettings.lotType> lots=new SortedList<string,XML.Parser.Adapter.UsedSettings.lotType>();
            foreach(EIS.XML.Parser.Adapter.UsedSettings.lotType l in used.msgBody.lot)
            {
                lots.Add(l.lotId, l);
            }

            //loop each lot and dispatch event to E3 
            used.msgBody.lot.Clear();
            foreach(EIS.XML.Parser.Adapter.UsedSettings.lotType s in lots.Values){
                dsp.DspRetCode = 0;
                dsp.DspRetMessage = "";
                //
                dsp.Layer = s.layerName;
                dsp.LotId = s.lotId;
                dsp.ProductId = s.productId;
                dsp.ProductType = s.productType;
                dsp.R2RControl = s.r2rMode;
                dsp.RecipeId = s.recipeId;
                dsp.StepSequence = s.stepSequence;
                dsp.ToolId = s.eqpId;
                dsp.TxId = used.msgHeader.txId;

                //dsp.ReplyTarget = args.ReplySubject;
                foreach (AddressInfo reply in args.ReplySubjects)
                {
                    dsp.ReplyTarget += reply.ToString() + " ";
                }

                used.msgBody.lot.Add(s);

                dsp.XmlString = used.SerializeXmlSpec(true,used);

                //Dispatch Event to E3 for lot
                if (this.DispatchEventHandler != null)
                {
                    this.DispatchEventHandler(dsp);
                }
            }
            #endregion
            
        }

        //primary in
        public void CmdMetrology(PublicRVMessageArrivedEventArgs args)
        {

            //1.generate the sync reply message and notify the sender
            #region generate the sync reply message and notify the sender
            EIS.XML.Parser.Adapter.Header.msgType header = EIS.XML.Parser.Adapter.Header.msgType.Deserialize(args.Message);
            header.msgBody = new XML.Parser.Adapter.Header.msgBodyType();
            header.msgBody.retCode = "0";
            header.msgBody.retMessage = "Metrology Received Confirm.";
            //header.rvHeader.replyApplication = null;
            if (args.ReplySubjects == null || args.ReplySubjects.Count() == 0)
            {
                //none reply address 
            }
            else if (this.RvMessageReplyHandler != null)
            {
                RVMessageSendEventArgs e = new RVMessageSendEventArgs();
                e.Domain = header.rvHeader.source.domain;
                //for Metrology
                //only reply to the last address and keep the first address in the message
                if (header.rvHeader.replyApplication.address.Count() >= 1)
                {
                    header.rvHeader.replyApplication.address.RemoveAt(header.rvHeader.replyApplication.address.Count() - 1);
                    header.rvHeader.replyApplication.addressNo = header.rvHeader.replyApplication.address.Count() + "";
                }
                //exchange the source and destination
                string tmpApplication = header.rvHeader.source.application;
                string tmpMsgBus = header.rvHeader.source.msgBus;
                string tmpDomain = header.rvHeader.source.domain;
                string tmpAddress = header.rvHeader.source.address;
                header.rvHeader.source.application = header.rvHeader.destination.application;
                header.rvHeader.source.msgBus = header.rvHeader.destination.msgBus;
                header.rvHeader.source.domain = header.rvHeader.destination.domain;
                header.rvHeader.source.address = header.rvHeader.destination.address;
                header.rvHeader.destination.application = tmpApplication;
                header.rvHeader.destination.msgBus = tmpMsgBus;
                header.rvHeader.destination.domain = tmpDomain;
                header.rvHeader.destination.address = tmpAddress;
                //
                e.MessageXml = header.SerializeXmlSpec(true,header);
                //e.ReplyAddress = "";
                e.ReplyExpected = false;
                e.SourceSystem = SourceApplication.R2R.ToString();
                e.SourceAddress = args.Subject;
                //e.TargetSystem = args.SystemName;
                e.TxId = header.msgHeader.txId;

                //for Metrology
                //only reply to the last address and keep the first address in the message
                e.TargetSystem = args.ReplySubjects.Last().Application;
                e.TargetAddress = args.ReplySubjects.Last().Address;

                e.xmlSpec = header;
                this.RvMessageReplyHandler(e);
            }
            #endregion

            //2.dispatch Event to E3 lot by lot
            #region dispatch Event to E3 lot by lot
            EIS.XML.Parser.Adapter.Metrology.msgType used = EIS.XML.Parser.Adapter.Metrology.msgType.Deserialize(args.Message);
            DispatchArgs dsp = new DispatchArgs();

            dsp.Fab = used.msgBody.fabName;
            dsp.Area = used.msgBody.area;
            dsp.BatchId = used.msgBody.batchId;
            dsp.ServiceMethod = used.msgHeader.srvMethod;
            dsp.EventName = used.msgBody.eventName;

            SortedList<string, EIS.XML.Parser.Adapter.Metrology.lotType> lots = new SortedList<string, XML.Parser.Adapter.Metrology.lotType>();
            foreach (EIS.XML.Parser.Adapter.Metrology.lotType l in used.msgBody.lot)
            {
                lots.Add(l.lotId, l);
            }

            //loop each lot and dispatch event to E3 
            used.msgBody.lot.Clear();
            foreach (EIS.XML.Parser.Adapter.Metrology.lotType s in lots.Values)
            {
                dsp.DspRetCode = 0;
                dsp.DspRetMessage = "";
                //
                dsp.Layer = s.metrologyLayerName;
                dsp.LotId = s.lotId;
                dsp.ProductId = s.productId;
                dsp.ProductType = s.productType;
                dsp.R2RControl = s.r2rMode;
                dsp.RecipeId = s.metrologyRecipeName;
                dsp.StepSequence = s.metrologyStepSequence;
                dsp.ToolId = s.metrologyToolName;
                dsp.TxId = used.msgHeader.txId;

                //dsp.ReplyTarget = args.ReplySubject;
                foreach (AddressInfo reply in args.ReplySubjects)
                {
                    dsp.ReplyTarget += reply.ToString() + " ";
                }

                used.msgBody.lot.Add(s);

                dsp.XmlString = used.SerializeXmlSpec(true,used);

                //Dispatch Event to E3 for lot
                if (this.DispatchEventHandler != null)
                {
                    this.DispatchEventHandler(dsp);
                }
            }
            #endregion
            
        }

        //primary in
        public void CmdSendExposureContext(PublicRVMessageArrivedEventArgs args)
        {
            //1.dispatch Event to E3 lot by lot
            #region dispatch Event to E3 lot by lot
            EIS.XML.Parser.Adapter.SendExposureContextR.msgType expo = EIS.XML.Parser.Adapter.SendExposureContextR.msgType.Deserialize(args.Message);
            DispatchArgs dsp = new DispatchArgs();
            
            dsp.Fab = expo.msgBody.fabName;
            dsp.Area = expo.msgBody.area;
            dsp.BatchId = expo.msgBody.batchId;
            dsp.ServiceMethod = expo.msgHeader.srvMethod;
            dsp.EventName = expo.msgBody.eventName;

            SortedList<string, EIS.XML.Parser.Adapter.SendExposureContextR.lotType> lots = new SortedList<string, EIS.XML.Parser.Adapter.SendExposureContextR.lotType>();
            SortedList<string, string> lotsRetCode = new SortedList<string, string>();
            SortedList<string, string> lotsRetMsg = new SortedList<string, string>();
            List<string> lotList = new List<string>();
            foreach (EIS.XML.Parser.Adapter.SendExposureContextR.lotType l in expo.msgBody.lot)
            {
                lotList.Add(l.lotId);
                lots.Add(l.lotId, l);
                lotsRetCode.Add(l.lotId, "0");
                lotsRetMsg.Add(l.lotId, "Start SendExposureContext");
            }

            //loop each lot and dispatch command to E3 
            foreach (string itor in lotList)
            {
                EIS.XML.Parser.Adapter.SendExposureContextR.lotType s = lots[itor];
                expo.msgBody.lot.Clear();
                expo.msgBody.retCode = "0";
                expo.msgBody.retMessage = "";
                //
                dsp.DspRetCode = 0;
                dsp.DspRetMessage = "";
                //
                dsp.Layer = s.layerName;
                dsp.LotId = s.lotId;
                dsp.ProductId = s.productId;
                dsp.ProductType = s.productType;
                dsp.R2RControl = s.r2rMode;
                dsp.RecipeId = s.metrologyRecipeName;
                dsp.StepSequence = s.metrologyStepSequence;
                dsp.ToolId = s.metrologyToolName;
                dsp.TxId = expo.msgHeader.txId;
                //dsp.ReplyTarget = args.ReplySubject;
                foreach (AddressInfo reply in args.ReplySubjects)
                {
                    dsp.ReplyTarget += reply.ToString() + " ";
                }
                 

                expo.msgBody.lot.Add(s);

                dsp.XmlString = expo.SerializeXmlSpec(false, expo);
                //Dispatch Event to E3 for lot
                if (this.DispatchCommandHandler != null)
                {
                    this.DispatchCommandHandler(dsp);
                }

                //to get 
                try
                {
                    if (dsp.DspRetCode != 0)
                    {
                        throw new Exception(string.Format("DispatchCommand Error{0}", dsp.DspRetMessage));
                    }
                    string typeName = "";
                    string errMessagge = "";

                    StructureBase sb = (StructureBase)StructureUitily.DeserializeToObject(dsp.ReplyXmlString, StructureUitily.FindType(dsp.ReplyXmlString, out typeName, out errMessagge));
                    bool result = this.MergeOutStructureResult2XmlObject(expo, sb);

                    if (!result)
                        throw new Exception("Error when BuildOutStructureResult2XmlObject.");
                    //
                    lots[dsp.LotId] = expo.msgBody.lot[0];
                    lotsRetCode[dsp.LotId] = expo.msgBody.retCode;
                    lotsRetMsg[dsp.LotId] = lotsRetMsg[dsp.LotId] + "," + expo.msgBody.retMessage;
                }
                catch (Exception ex)
                {
                    lotsRetCode[dsp.LotId] = "-1";
                    lotsRetMsg[dsp.LotId] = lotsRetMsg[dsp.LotId] + "," + ex.Message;
                }
            }
            #endregion

            //2.0. merge lots result in msgBody
            #region merge lots result in msgBody
            expo.msgBody.lot.Clear();
            expo.msgBody.retCode = "0";
            expo.msgBody.retMessage = "";
            foreach (EIS.XML.Parser.Adapter.SendExposureContextR.lotType s in lots.Values)
            {
                string lotId = s.lotId;
                if ("0".Equals(expo.msgBody.retCode)) expo.msgBody.retCode = lotsRetCode[lotId];
                expo.msgBody.retMessage += ("," + lotId + "[Code:" + lotsRetCode[lotId] + " Details:" + lotsRetMsg[lotId] + " End]");

                expo.msgBody.lot.Add(s);
            }
            #endregion

            //2.generate the reply message and notify the sender
            #region generate the reply message and notify the sender
            if (this.RvMessageReplyHandler != null)
            {
                RVMessageSendEventArgs e = new RVMessageSendEventArgs();
                e.Domain = expo.rvHeader.source.domain;
                //for SendExposureContext
                //only reply to the last address and keep the first address in the message
                if (expo.rvHeader.replyApplication.address.Count() >= 1)
                {
                    expo.rvHeader.replyApplication.address.RemoveAt(expo.rvHeader.replyApplication.address.Count() - 1);
                    expo.rvHeader.replyApplication.addressNo = expo.rvHeader.replyApplication.address.Count() + "";
                }
                //exchange the source and destination
                string tmpApplication = expo.rvHeader.source.application;
                string tmpMsgBus = expo.rvHeader.source.msgBus;
                string tmpDomain = expo.rvHeader.source.domain;
                string tmpAddress = expo.rvHeader.source.address;
                expo.rvHeader.source.application = expo.rvHeader.destination.application;
                expo.rvHeader.source.msgBus = expo.rvHeader.destination.msgBus;
                expo.rvHeader.source.domain = expo.rvHeader.destination.domain;
                expo.rvHeader.source.address = expo.rvHeader.destination.address;
                expo.rvHeader.destination.application = tmpApplication;
                expo.rvHeader.destination.msgBus = tmpMsgBus;
                expo.rvHeader.destination.domain = tmpDomain;
                expo.rvHeader.destination.address = tmpAddress;
                //
                e.MessageXml = expo.SerializeXmlSpec(true, expo);
                //e.ReplyAddress = "";
                e.ReplyExpected = false;
                e.SourceSystem = SourceApplication.R2R.ToString();
                e.SourceAddress = args.Subject;
                //e.TargetSystem = args.SystemName;
                e.TxId = expo.msgHeader.txId;

                //for SendExposureContext
                //only reply to the last address and keep the first address in the message
                e.TargetSystem = args.ReplySubjects.Last().Application;
                e.TargetAddress = args.ReplySubjects.Last().Address;

                e.xmlSpec = expo;
                this.RvMessageReplyHandler(e);
            }
            #endregion
        }

        //primary in
        public void CmdFDCR2ROcapInfo(PublicRVMessageArrivedEventArgs args)
        {

        }

        //primary in
        public void CmdEAPReqLISCondition(PublicRVMessageArrivedEventArgs args)
        {
            //1.dispatch Event to E3 lot by lot
            #region dispatch Event to E3 lot by lot
            EIS.XML.Parser.Adapter.EAPReqLISConditionR.msgType lisLots = EIS.XML.Parser.Adapter.EAPReqLISConditionR.msgType.Deserialize(args.Message);
            DispatchArgs dsp = new DispatchArgs();

            dsp.Fab = lisLots.msgBody.fabName;
            dsp.Area = lisLots.msgBody.area;
            dsp.BatchId = lisLots.msgBody.batchId;
            dsp.ServiceMethod = lisLots.msgHeader.srvMethod;
            dsp.EventName = lisLots.msgBody.eventName;

            SortedList<string, EIS.XML.Parser.Adapter.EAPReqLISConditionR.lotType> lots = new SortedList<string, EIS.XML.Parser.Adapter.EAPReqLISConditionR.lotType>();
            SortedList<string, string> lotsRetCode = new SortedList<string, string>();
            SortedList<string, string> lotsRetMsg = new SortedList<string, string>();
            List<string> lotList = new List<string>();
            foreach (EIS.XML.Parser.Adapter.EAPReqLISConditionR.lotType l in lisLots.msgBody.lot)
            {
                lotList.Add(l.lotId);
                lots.Add(l.lotId, l);
                lotsRetCode.Add(l.lotId, "0");
                lotsRetMsg.Add(l.lotId, "Start EAPReqLISCondition");
            }

            //loop each lot and dispatch command to E3 
            foreach (string itor in lotList)
            {
                EIS.XML.Parser.Adapter.EAPReqLISConditionR.lotType s = lots[itor];
                lisLots.msgBody.lot.Clear();
                //lisLots.msgBody.retCode = "0";
                //lisLots.msgBody.retMessage = "";
                //
                dsp.DspRetCode = 0;
                dsp.DspRetMessage = "";
                //
                dsp.Layer = "NA"; //s.layerName;
                dsp.LotId = s.lotId;
                dsp.ProductId = s.productId;
                dsp.ProductType = s.productType;
                dsp.R2RControl = s.r2rMode;
                dsp.RecipeId = s.metrologyRecipeName;
                dsp.StepSequence = s.metrologyStepSequence;
                dsp.ToolId = s.metrologyToolName;
                dsp.TxId = lisLots.msgHeader.txId;
                //dsp.ReplyTarget = args.ReplySubject;
                foreach (AddressInfo reply in args.ReplySubjects)
                {
                    dsp.ReplyTarget += reply.ToString() + " ";
                }


                lisLots.msgBody.lot.Add(s);

                dsp.XmlString = lisLots.SerializeXmlSpec(false, lisLots);
                //Dispatch Event to E3 for lot
                if (this.DispatchCommandHandler != null)
                {
                    this.DispatchCommandHandler(dsp);
                }

                //to get 
                try
                {
                    if (dsp.DspRetCode != 0)
                    {
                        throw new Exception(string.Format("DispatchCommand Error{0}", dsp.DspRetMessage));
                    }
                    string typeName = "";
                    string errMessagge = "";

                    StructureBase sb = (StructureBase)StructureUitily.DeserializeToObject(dsp.ReplyXmlString, StructureUitily.FindType(dsp.ReplyXmlString, out typeName, out errMessagge));
                    bool result = this.MergeOutStructureResult2XmlObject(lisLots, sb);

                    if (!result)
                        throw new Exception("Error when BuildOutStructureResult2XmlObject.");
                    //
                    lots[dsp.LotId] = lisLots.msgBody.lot[0];
                    lotsRetCode[dsp.LotId] = lisLots.msgBody.retCode;
                    lotsRetMsg[dsp.LotId] = lotsRetMsg[dsp.LotId] + "," + lisLots.msgBody.retMessage;
                }
                catch (Exception ex)
                {
                    lotsRetCode[dsp.LotId] = "-1";
                    lotsRetMsg[dsp.LotId] = lotsRetMsg[dsp.LotId] + "," + ex.Message;
                }
            }
            #endregion

            //2.0. merge lots result in msgBody
            #region merge lots result in msgBody
            lisLots.msgBody.lot.Clear();
            lisLots.msgBody.retCode = "0";
            lisLots.msgBody.retMessage = "";
            foreach (EIS.XML.Parser.Adapter.EAPReqLISConditionR.lotType s in lots.Values)
            {
                string lotId = s.lotId;
                if ("0".Equals(lisLots.msgBody.retCode)) lisLots.msgBody.retCode = lotsRetCode[lotId];
                lisLots.msgBody.retMessage += ("," + lotId + "[Code:" + lotsRetCode[lotId] + " Details:" + lotsRetMsg[lotId] + " End]");

                lisLots.msgBody.lot.Add(s);
            }
            #endregion

            //2.generate the reply message and notify the sender
            #region generate the reply message and notify the sender
            if (this.RvMessageReplyHandler != null)
            {
                RVMessageSendEventArgs e = new RVMessageSendEventArgs();
                e.Domain = lisLots.rvHeader.source.domain;
                //for SendExposureContext
                //only reply to the last address and keep the first address in the message
                if (lisLots.rvHeader.replyApplication.address.Count() >= 1)
                {
                    lisLots.rvHeader.replyApplication.address.RemoveAt(lisLots.rvHeader.replyApplication.address.Count() - 1);
                    lisLots.rvHeader.replyApplication.addressNo = lisLots.rvHeader.replyApplication.address.Count() + "";
                }
                //exchange the source and destination
                string tmpApplication = lisLots.rvHeader.source.application;
                string tmpMsgBus = lisLots.rvHeader.source.msgBus;
                string tmpDomain = lisLots.rvHeader.source.domain;
                string tmpAddress = lisLots.rvHeader.source.address;
                lisLots.rvHeader.source.application = lisLots.rvHeader.destination.application;
                lisLots.rvHeader.source.msgBus = lisLots.rvHeader.destination.msgBus;
                lisLots.rvHeader.source.domain = lisLots.rvHeader.destination.domain;
                lisLots.rvHeader.source.address = lisLots.rvHeader.destination.address;
                lisLots.rvHeader.destination.application = tmpApplication;
                lisLots.rvHeader.destination.msgBus = tmpMsgBus;
                lisLots.rvHeader.destination.domain = tmpDomain;
                lisLots.rvHeader.destination.address = tmpAddress;
                //
                e.MessageXml = lisLots.SerializeXmlSpec(true, lisLots);
                //e.ReplyAddress = "";
                e.ReplyExpected = false;
                e.SourceSystem = SourceApplication.R2R.ToString();
                e.SourceAddress = args.Subject;
                //e.TargetSystem = args.SystemName;
                e.TxId = lisLots.msgHeader.txId;

                //for SendExposureContext
                //only reply to the last address and keep the first address in the message
                e.TargetSystem = args.ReplySubjects.Last().Application;
                e.TargetAddress = args.ReplySubjects.Last().Address;

                e.xmlSpec = lisLots;
                this.RvMessageReplyHandler(e);
            }
            #endregion
        }

        //
        public void CmdEAPReqToolSecsData(PublicRVMessageArrivedEventArgs args)
        {

            //1.generate the sync reply message and notify the sender
            #region generate the sync reply message and notify the sender
            EIS.XML.Parser.Adapter.Header.msgType header = EIS.XML.Parser.Adapter.Header.msgType.Deserialize(args.Message);
            header.msgBody = new XML.Parser.Adapter.Header.msgBodyType();
            header.msgBody.retCode = "0";
            header.msgBody.retMessage = "ToolSecsData Received Confirm.";
            //header.rvHeader.replyApplication = null;
            if (args.ReplySubjects == null || args.ReplySubjects.Count() == 0)
            {
                //none reply address 
            }
            else if (this.RvMessageReplyHandler != null)
            {
                RVMessageSendEventArgs e = new RVMessageSendEventArgs();
                e.Domain = header.rvHeader.source.domain;
                //for Metrology
                //only reply to the last address and keep the first address in the message
                if (header.rvHeader.replyApplication.address.Count() >= 1)
                {
                    header.rvHeader.replyApplication.address.RemoveAt(header.rvHeader.replyApplication.address.Count() - 1);
                    header.rvHeader.replyApplication.addressNo = header.rvHeader.replyApplication.address.Count() + "";
                }
                //exchange the source and destination
                string tmpApplication = header.rvHeader.source.application;
                string tmpMsgBus = header.rvHeader.source.msgBus;
                string tmpDomain = header.rvHeader.source.domain;
                string tmpAddress = header.rvHeader.source.address;
                header.rvHeader.source.application = header.rvHeader.destination.application;
                header.rvHeader.source.msgBus = header.rvHeader.destination.msgBus;
                header.rvHeader.source.domain = header.rvHeader.destination.domain;
                header.rvHeader.source.address = header.rvHeader.destination.address;
                header.rvHeader.destination.application = tmpApplication;
                header.rvHeader.destination.msgBus = tmpMsgBus;
                header.rvHeader.destination.domain = tmpDomain;
                header.rvHeader.destination.address = tmpAddress;
                //
                e.MessageXml = header.SerializeXmlSpec(true, header);
                //e.ReplyAddress = "";
                e.ReplyExpected = false;
                e.SourceSystem = SourceApplication.R2R.ToString();
                e.SourceAddress = args.Subject;
                //e.TargetSystem = args.SystemName;
                e.TxId = header.msgHeader.txId;

                //for Metrology
                //only reply to the last address and keep the first address in the message
                e.TargetSystem = args.ReplySubjects.Last().Application;
                e.TargetAddress = args.ReplySubjects.Last().Address;

                e.xmlSpec = header;
                this.RvMessageReplyHandler(e);
            }
            #endregion

            //2.dispatch Event to E3 lot by lot
            #region dispatch Event to E3 lot by lot
            EIS.XML.Parser.Adapter.EAPReqToolSecsData.msgType secsData = EIS.XML.Parser.Adapter.EAPReqToolSecsData.msgType.Deserialize(args.Message);
            DispatchArgs dsp = new DispatchArgs();

            dsp.Fab = secsData.msgBody.fabName;
            dsp.Area = "NA"; 
            dsp.BatchId = "NA";
            dsp.ServiceMethod = secsData.msgHeader.srvMethod;
            dsp.EventName = secsData.msgBody.eventName;

            //dispatch event to E3 
            dsp.DspRetCode = 0;
            dsp.DspRetMessage = "";
            //
            dsp.Layer = "NA";
            dsp.LotId = "NA";
            dsp.ProductId = "NA";
            dsp.ProductType = "NA";
            dsp.R2RControl = "NA";
            dsp.RecipeId = "NA";
            dsp.StepSequence = "NA";
            dsp.ToolId = secsData.msgBody.eqpId;
            dsp.TxId = secsData.msgHeader.txId;

            //dsp.ReplyTarget = args.ReplySubject;
            foreach (AddressInfo reply in args.ReplySubjects)
            {
                dsp.ReplyTarget += reply.ToString() + " ";
            }

            dsp.XmlString = secsData.SerializeXmlSpec(true, secsData);

            //Dispatch Event to E3 for lot
            if (this.DispatchEventHandler != null)
            {
                this.DispatchEventHandler(dsp);
            }
            #endregion
        }


        public abstract XmlSpec BuildOutStructureFull2XmlObject(StructureBase structureBase);

        public abstract bool MergeOutStructureResult2XmlObject(XmlSpec spec, StructureBase structureBase);

    }
}

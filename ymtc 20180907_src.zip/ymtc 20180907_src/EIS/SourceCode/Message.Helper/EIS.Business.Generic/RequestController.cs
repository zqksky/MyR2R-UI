﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AMAT.RVAdapter.CommonData;
using AMAT.RVAdapter.CommonData.EventArgs;
using EIS.XML.Parser;
using EIS.XML.Parser.Adapter;

namespace EIS.Business.Generic
{
    public abstract class RequestController
    {
        public event RVMessageSendHandler RvMessageRequestHandler = null;

        //primary out
        /// <summary>
        /// to response the AlarmMessage from E3 
        /// make the xml specificaiton message from structure xml
        /// </summary>
        /// <param name="requestStructureXml">the reuqest structure xml</param>
        /// <param name="replyExpected">if reply expected by E3</param>
        /// <param name="domain">ususlly the fab name</param>
        /// <param name="targetSystem">the target system name : MES, EAP , AMS etc</param>
        /// <param name="targetAddress">the target system listen address </param>
        /// <param name="txId">the unique transaction Id </param>
        /// <param name="timeOut">the timeout settings for this transaction</param>
        /// <returns>the reply xml specificaiton message</returns>
        public string CmdAlarmReportEvent(string requestStructureXml, bool replyExpected, string domain, string targetSystem, string targetAddress, string txId, int timeOut)
        {
            RequestRVMessageEventArgs args = new RequestRVMessageEventArgs();
            args.MessageXml = "";//obsolete
            args.ReplyExpected = replyExpected;
            args.Domain = domain;

            args.SourceSystem = SourceApplication.R2R.ToString();
            args.SourceAddress = "";
            args.TargetSystem = targetSystem;
            args.TargetAddress = targetAddress;

            args.TxId = txId;
            args.TimeOut = timeOut;

            string typeName = "";
            string errMessge = "";
            StructureBase sb = (StructureBase)StructureUitily.DeserializeToObject(requestStructureXml, StructureUitily.FindType(requestStructureXml,out typeName,out errMessge));
            XmlSpec spec = this.BuildOutStructureFull2XmlObject(domain, txId, args.TimeOut + "", sb);

            args.xmlSpec = spec;

            //rvHeader
            //the rvHeader should be build in RV by args
            //XmlSpecUtility.MakeGeneralRvHeader(xmlSpec, domain, SourceApplication.R2R.ToString(), targetSystem, targetAddress);
            //
            if (this.RvMessageRequestHandler != null)
            {
                this.RvMessageRequestHandler(args);
            }

            return args.ReplyMessageXml;
        }

        //primary out
        /// <summary>
        /// to response the AlarmMessage from E3 
        /// make the xml specificaiton message from structure xml
        /// </summary>
        /// <param name="reportStructureXml">the report structure xml</param>
        /// <param name="domain">ususlly the fab name</param>
        /// <param name="targetSystem">the target system name : MES, EAP , AMS etc</param>
        /// <param name="targetAddress">the target system listen address</param>
        /// <param name="txId">the unique transaction Id </param>
        public void ReportAlarmReportEvent(string reportStructureXml, string domain, string targetSystem, string targetAddress, string txId)
        {
            RequestRVMessageEventArgs args = new RequestRVMessageEventArgs();
            args.MessageXml = "";//obsolete
            args.ReplyExpected = false;
            args.Domain = domain;

            args.SourceSystem = SourceApplication.R2R.ToString();
            args.SourceAddress = "";
            args.TargetSystem = targetSystem;
            args.TargetAddress = targetAddress;

            args.TxId = txId;
            args.TimeOut = 0;

            string typeName = "";
            string errMessage = "";
            StructureBase sb = (StructureBase)StructureUitily.DeserializeToObject(reportStructureXml, StructureUitily.FindType(reportStructureXml, out typeName, out errMessage));
            XmlSpec spec = this.BuildOutStructureFull2XmlObject(domain, txId, args.TimeOut + "", sb);

            args.xmlSpec = spec;

            //rvHeader
            //the rvHeader should be build in RV by args
            //XmlSpecUtility.MakeGeneralRvHeader(xmlSpec, domain, SourceApplication.R2R.ToString(), targetSystem, targetAddress);
            //
            if (this.RvMessageRequestHandler != null)
            {
                this.RvMessageRequestHandler(args);
            }

            return;
        }

        //primary out
        /// <summary>
        /// to response the RandomQuery from E3 
        /// make the xml specificaiton message from structure xml
        /// </summary>
        /// <param name="requestStructureXml">the reuqest structure xml</param>
        /// <param name="replyExpected">if reply expected by E3</param>
        /// <param name="domain">ususlly the fab name</param>
        /// <param name="targetSystem">the target system name : MES, EAP , AMS etc</param>
        /// <param name="targetAddress">the target system listen address </param>
        /// <param name="txId">the unique transaction Id </param>
        /// <param name="timeOut">the timeout settings for this transaction</param>
        /// <returns>the reply xml specificaiton message</returns>
        public string CmdRandomQuery(string requestStructureXml, bool replyExpected, string domain, string targetSystem, string targetAddress, string txId, int timeOut)
        {
            RequestRVMessageEventArgs args = new RequestRVMessageEventArgs();
            args.MessageXml = "";//obsolete
            args.ReplyExpected = replyExpected;
            args.Domain = domain;

            args.SourceSystem = SourceApplication.R2R.ToString();
            args.SourceAddress = "";
            args.TargetSystem = targetSystem;
            args.TargetAddress = targetAddress;

            args.TxId = txId;
            args.TimeOut = timeOut;

            string typeName = "";
            string errMessge = "";
            StructureBase sb = (StructureBase)StructureUitily.DeserializeToObject(requestStructureXml, StructureUitily.FindType(requestStructureXml,out typeName, out errMessge));
            XmlSpec spec = this.BuildOutStructureFull2XmlObject(domain, txId, args.TimeOut+"", sb);

            args.xmlSpec = spec;
            
            //rvHeader
            //the rvHeader should be build in RV by args
            //XmlSpecUtility.MakeGeneralRvHeader(xmlSpec, domain, SourceApplication.R2R.ToString(), targetSystem, targetAddress);
            //
            if (this.RvMessageRequestHandler != null)
            {
                this.RvMessageRequestHandler(args);
            }

            return args.ReplyMessageXml;
        }

        //primary out
        /// <summary>
        /// to response the RandomQuery from E3 
        /// make the xml specificaiton message from structure xml
        /// </summary>
        /// <param name="requestStructureXml">the reuqest structure xml</param>
        /// <param name="replyExpected">if reply expected by E3</param>
        /// <param name="domain">ususlly the fab name</param>
        /// <param name="targetSystem">the target system name : MES, EAP , AMS etc</param>
        /// <param name="targetAddress">the target system listen address </param>
        /// <param name="txId">the unique transaction Id </param>
        /// <param name="timeOut">the timeout settings for this transaction</param>
        /// <returns>the reply xml specificaiton message</returns>
        public string CmdQueryLotInfo(string requestStructureXml, bool replyExpected, string domain, string targetSystem, string targetAddress, string txId, int timeOut)
        {
            RequestRVMessageEventArgs args = new RequestRVMessageEventArgs();
            args.MessageXml = "";//obsolete
            args.ReplyExpected = replyExpected;
            args.Domain = domain;

            args.SourceSystem = SourceApplication.R2R.ToString();
            args.SourceAddress = "";
            args.TargetSystem = targetSystem;
            args.TargetAddress = targetAddress;

            args.TxId = txId;
            args.TimeOut = timeOut;

            string typeName = "";
            string errMessge = "";
            StructureBase sb = (StructureBase)StructureUitily.DeserializeToObject(requestStructureXml, StructureUitily.FindType(requestStructureXml, out typeName, out errMessge));
            XmlSpec spec = this.BuildOutStructureFull2XmlObject(domain, txId, args.TimeOut + "", sb);

            args.xmlSpec = spec;

            //rvHeader
            //the rvHeader should be build in RV by args
            //XmlSpecUtility.MakeGeneralRvHeader(xmlSpec, domain, SourceApplication.R2R.ToString(), targetSystem, targetAddress);
            //
            if (this.RvMessageRequestHandler != null)
            {
                this.RvMessageRequestHandler(args);
            }

            return args.ReplyMessageXml;
        }

        //primary out
        /// <summary>
        /// to response the R2RReqHoldLot from E3 
        /// make the xml specificaiton message from structure xml
        /// </summary>
        /// <param name="requestStructureXml">the reuqest structure xml</param>
        /// <param name="replyExpected">if reply expected by E3</param>
        /// <param name="domain">ususlly the fab name</param>
        /// <param name="targetSystem">the target system name : MES, EAP , AMS etc</param>
        /// <param name="targetAddress">the target system listen address </param>
        /// <param name="txId">the unique transaction Id </param>
        /// <param name="timeOut">the timeout settings for this transaction</param>
        /// <returns>the reply xml specificaiton message</returns>
        public string CmdR2RReqHoldLot(string requestStructureXml, bool replyExpected, string domain, string targetSystem, string targetAddress, string txId, int timeOut)
        {
            RequestRVMessageEventArgs args = new RequestRVMessageEventArgs();
            args.MessageXml = "";//obsolete
            args.ReplyExpected = replyExpected;
            args.Domain = domain;

            args.SourceSystem = SourceApplication.R2R.ToString();
            args.SourceAddress = "";
            args.TargetSystem = targetSystem;
            args.TargetAddress = targetAddress;

            args.TxId = txId;
            args.TimeOut = timeOut;

            string typeName = "";
            string errMessge = "";
            StructureBase sb = (StructureBase)StructureUitily.DeserializeToObject(requestStructureXml, StructureUitily.FindType(requestStructureXml, out typeName, out errMessge));
            XmlSpec spec = this.BuildOutStructureFull2XmlObject(domain, txId, args.TimeOut + "", sb);

            args.xmlSpec = spec;

            //rvHeader
            //the rvHeader should be build in RV by args
            //XmlSpecUtility.MakeGeneralRvHeader(xmlSpec, domain, SourceApplication.R2R.ToString(), targetSystem, targetAddress);
            //
            if (this.RvMessageRequestHandler != null)
            {
                this.RvMessageRequestHandler(args);
            }

            return args.ReplyMessageXml;
        }

        //primary out
        /// <summary>
        /// to response the BSReqHoldLot from E3 
        /// make the xml specificaiton message from structure xml
        /// </summary>
        /// <param name="requestStructureXml">the reuqest structure xml</param>
        /// <param name="replyExpected">if reply expected by E3</param>
        /// <param name="domain">ususlly the fab name</param>
        /// <param name="targetSystem">the target system name : MES, EAP , AMS etc</param>
        /// <param name="targetAddress">the target system listen address </param>
        /// <param name="txId">the unique transaction Id </param>
        /// <param name="timeOut">the timeout settings for this transaction</param>
        /// <returns>the reply xml specificaiton message</returns>
        public string CmdBSReqHoldLot(string requestStructureXml, bool replyExpected, string domain, string targetSystem, string targetAddress, string txId, int timeOut)
        {
            RequestRVMessageEventArgs args = new RequestRVMessageEventArgs();
            args.MessageXml = "";//obsolete
            args.ReplyExpected = replyExpected;
            args.Domain = domain;

            args.SourceSystem = SourceApplication.R2R.ToString();
            args.SourceAddress = "";
            args.TargetSystem = targetSystem;
            args.TargetAddress = targetAddress;

            args.TxId = txId;
            args.TimeOut = timeOut;

            string typeName = "";
            string errMessge = "";
            StructureBase sb = (StructureBase)StructureUitily.DeserializeToObject(requestStructureXml, StructureUitily.FindType(requestStructureXml, out typeName, out errMessge));
            XmlSpec spec = this.BuildOutStructureFull2XmlObject(domain, txId, args.TimeOut + "", sb);

            args.xmlSpec = spec;

            //rvHeader
            //the rvHeader should be build in RV by args
            //XmlSpecUtility.MakeGeneralRvHeader(xmlSpec, domain, SourceApplication.R2R.ToString(), targetSystem, targetAddress);
            //
            if (this.RvMessageRequestHandler != null)
            {
                this.RvMessageRequestHandler(args);
            }

            return args.ReplyMessageXml;
        }


        public string CmdR2RReqLISResult(string requestStructureXml, bool replyExpected, string domain, string targetSystem, string targetAddress, string txId, int timeOut)
        {
            RequestRVMessageEventArgs args = new RequestRVMessageEventArgs();
            args.MessageXml = "";//obsolete
            args.ReplyExpected = replyExpected;
            args.Domain = domain;

            args.SourceSystem = SourceApplication.R2R.ToString();
            args.SourceAddress = "";
            args.TargetSystem = targetSystem;
            args.TargetAddress = targetAddress;

            args.TxId = txId;
            args.TimeOut = timeOut;

            string typeName = "";
            string errMessge = "";
            StructureBase sb = (StructureBase)StructureUitily.DeserializeToObject(requestStructureXml, StructureUitily.FindType(requestStructureXml, out typeName, out errMessge));
            XmlSpec spec = this.BuildOutStructureFull2XmlObject(domain, txId, args.TimeOut + "", sb);

            args.xmlSpec = spec;

            //rvHeader
            //the rvHeader should be build in RV by args
            //XmlSpecUtility.MakeGeneralRvHeader(xmlSpec, domain, SourceApplication.R2R.ToString(), targetSystem, targetAddress);
            //
            if (this.RvMessageRequestHandler != null)
            {
                this.RvMessageRequestHandler(args);
            }

            return args.ReplyMessageXml;
        }

        /// <summary>
        /// transfer the structure to xml specifiction
        /// </summary>
        /// <param name="domain">usually the fabname</param>
        /// <param name="txId">the unique transaction Id </param>
        /// <param name="structureBase">the input structure</param>
        /// <returns></returns>
        public abstract XmlSpec BuildOutStructureFull2XmlObject(string domain, string txId, string timeOut,StructureBase structureBase);
        
    }
}

﻿namespace IntegrationGUI.Control
{
    partial class ChannelControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.daemonLbl = new System.Windows.Forms.Label();
            this.serivceLbl = new System.Windows.Forms.Label();
            this.netWorkLbl = new System.Windows.Forms.Label();
            this.listenSubjectLbl = new System.Windows.Forms.Label();
            this.statusBox = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.OpenBtn = new System.Windows.Forms.Button();
            this.traceLbl = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtBoxDaemon = new System.Windows.Forms.TextBox();
            this.txtBoxService = new System.Windows.Forms.TextBox();
            this.txtBoxNetWork = new System.Windows.Forms.TextBox();
            this.txtBoxListenOn = new System.Windows.Forms.TextBox();
            this.txtBoxTargetDefault = new System.Windows.Forms.TextBox();
            this.txtBoxPrivateListen = new System.Windows.Forms.TextBox();
            this.transView = new System.Windows.Forms.TreeView();
            this.label2 = new System.Windows.Forms.Label();
            this.ClearBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // daemonLbl
            // 
            this.daemonLbl.AutoSize = true;
            this.daemonLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.daemonLbl.Location = new System.Drawing.Point(8, 14);
            this.daemonLbl.Name = "daemonLbl";
            this.daemonLbl.Size = new System.Drawing.Size(63, 16);
            this.daemonLbl.TabIndex = 0;
            this.daemonLbl.Text = "Daemon:";
            // 
            // serivceLbl
            // 
            this.serivceLbl.AutoSize = true;
            this.serivceLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.serivceLbl.Location = new System.Drawing.Point(8, 40);
            this.serivceLbl.Name = "serivceLbl";
            this.serivceLbl.Size = new System.Drawing.Size(57, 16);
            this.serivceLbl.TabIndex = 2;
            this.serivceLbl.Text = "Service:";
            // 
            // netWorkLbl
            // 
            this.netWorkLbl.AutoSize = true;
            this.netWorkLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.netWorkLbl.Location = new System.Drawing.Point(8, 67);
            this.netWorkLbl.Name = "netWorkLbl";
            this.netWorkLbl.Size = new System.Drawing.Size(64, 16);
            this.netWorkLbl.TabIndex = 3;
            this.netWorkLbl.Text = "NetWork:";
            // 
            // listenSubjectLbl
            // 
            this.listenSubjectLbl.AutoSize = true;
            this.listenSubjectLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listenSubjectLbl.Location = new System.Drawing.Point(8, 95);
            this.listenSubjectLbl.Name = "listenSubjectLbl";
            this.listenSubjectLbl.Size = new System.Drawing.Size(111, 16);
            this.listenSubjectLbl.TabIndex = 4;
            this.listenSubjectLbl.Text = "Listen On (Public)";
            // 
            // statusBox
            // 
            this.statusBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.statusBox.BackColor = System.Drawing.Color.Azure;
            this.statusBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statusBox.FormattingEnabled = true;
            this.statusBox.ItemHeight = 15;
            this.statusBox.Location = new System.Drawing.Point(5, 212);
            this.statusBox.Name = "statusBox";
            this.statusBox.Size = new System.Drawing.Size(407, 109);
            this.statusBox.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(8, 123);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 16);
            this.label1.TabIndex = 6;
            this.label1.Text = "Target (Default)";
            // 
            // OpenBtn
            // 
            this.OpenBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.OpenBtn.BackColor = System.Drawing.Color.LightGray;
            this.OpenBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OpenBtn.Location = new System.Drawing.Point(322, 176);
            this.OpenBtn.Name = "OpenBtn";
            this.OpenBtn.Size = new System.Drawing.Size(75, 30);
            this.OpenBtn.TabIndex = 7;
            this.OpenBtn.Text = "Open";
            this.OpenBtn.UseVisualStyleBackColor = false;
            this.OpenBtn.Click += new System.EventHandler(this.OpenBtn_Click);
            // 
            // traceLbl
            // 
            this.traceLbl.AutoSize = true;
            this.traceLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.traceLbl.Location = new System.Drawing.Point(8, 182);
            this.traceLbl.Name = "traceLbl";
            this.traceLbl.Size = new System.Drawing.Size(47, 16);
            this.traceLbl.TabIndex = 8;
            this.traceLbl.Text = "Trace:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(8, 149);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 16);
            this.label3.TabIndex = 9;
            this.label3.Text = "Private Listen";
            // 
            // txtBoxDaemon
            // 
            this.txtBoxDaemon.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtBoxDaemon.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxDaemon.Location = new System.Drawing.Point(159, 13);
            this.txtBoxDaemon.Name = "txtBoxDaemon";
            this.txtBoxDaemon.ReadOnly = true;
            this.txtBoxDaemon.Size = new System.Drawing.Size(238, 22);
            this.txtBoxDaemon.TabIndex = 10;
            this.txtBoxDaemon.TextChanged += new System.EventHandler(this.OnChangeDaemon);
            // 
            // txtBoxService
            // 
            this.txtBoxService.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtBoxService.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtBoxService.Location = new System.Drawing.Point(159, 39);
            this.txtBoxService.Name = "txtBoxService";
            this.txtBoxService.ReadOnly = true;
            this.txtBoxService.Size = new System.Drawing.Size(238, 22);
            this.txtBoxService.TabIndex = 11;
            this.txtBoxService.TextChanged += new System.EventHandler(this.OnChangeService);
            // 
            // txtBoxNetWork
            // 
            this.txtBoxNetWork.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtBoxNetWork.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtBoxNetWork.Location = new System.Drawing.Point(159, 66);
            this.txtBoxNetWork.Name = "txtBoxNetWork";
            this.txtBoxNetWork.ReadOnly = true;
            this.txtBoxNetWork.Size = new System.Drawing.Size(238, 22);
            this.txtBoxNetWork.TabIndex = 12;
            this.txtBoxNetWork.TextChanged += new System.EventHandler(this.OnChangeNetWork);
            // 
            // txtBoxListenOn
            // 
            this.txtBoxListenOn.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtBoxListenOn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtBoxListenOn.Location = new System.Drawing.Point(159, 94);
            this.txtBoxListenOn.Name = "txtBoxListenOn";
            this.txtBoxListenOn.ReadOnly = true;
            this.txtBoxListenOn.Size = new System.Drawing.Size(238, 22);
            this.txtBoxListenOn.TabIndex = 13;
            this.txtBoxListenOn.TextChanged += new System.EventHandler(this.OnChangePublicListen);
            // 
            // txtBoxTargetDefault
            // 
            this.txtBoxTargetDefault.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtBoxTargetDefault.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtBoxTargetDefault.Location = new System.Drawing.Point(159, 122);
            this.txtBoxTargetDefault.Name = "txtBoxTargetDefault";
            this.txtBoxTargetDefault.ReadOnly = true;
            this.txtBoxTargetDefault.Size = new System.Drawing.Size(238, 22);
            this.txtBoxTargetDefault.TabIndex = 14;
            this.txtBoxTargetDefault.TextChanged += new System.EventHandler(this.OnChangeTargetListen);
            // 
            // txtBoxPrivateListen
            // 
            this.txtBoxPrivateListen.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtBoxPrivateListen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtBoxPrivateListen.Location = new System.Drawing.Point(159, 148);
            this.txtBoxPrivateListen.Name = "txtBoxPrivateListen";
            this.txtBoxPrivateListen.ReadOnly = true;
            this.txtBoxPrivateListen.Size = new System.Drawing.Size(238, 22);
            this.txtBoxPrivateListen.TabIndex = 15;
            // 
            // transView
            // 
            this.transView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.transView.BackColor = System.Drawing.Color.Azure;
            this.transView.Location = new System.Drawing.Point(5, 360);
            this.transView.Name = "transView";
            this.transView.ShowNodeToolTips = true;
            this.transView.Size = new System.Drawing.Size(407, 339);
            this.transView.TabIndex = 16;
            this.transView.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.transView_NodeMouseClick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(8, 336);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 16);
            this.label2.TabIndex = 17;
            this.label2.Text = "Transaction";
            // 
            // ClearBtn
            // 
            this.ClearBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ClearBtn.BackColor = System.Drawing.Color.LightGray;
            this.ClearBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClearBtn.Location = new System.Drawing.Point(322, 327);
            this.ClearBtn.Name = "ClearBtn";
            this.ClearBtn.Size = new System.Drawing.Size(75, 30);
            this.ClearBtn.TabIndex = 18;
            this.ClearBtn.Text = "Clear";
            this.ClearBtn.UseVisualStyleBackColor = false;
            this.ClearBtn.Click += new System.EventHandler(this.OnClickClearTrans);
            // 
            // ChannelControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.ClearBtn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.transView);
            this.Controls.Add(this.txtBoxPrivateListen);
            this.Controls.Add(this.txtBoxTargetDefault);
            this.Controls.Add(this.txtBoxListenOn);
            this.Controls.Add(this.txtBoxNetWork);
            this.Controls.Add(this.txtBoxService);
            this.Controls.Add(this.txtBoxDaemon);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.traceLbl);
            this.Controls.Add(this.OpenBtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.statusBox);
            this.Controls.Add(this.listenSubjectLbl);
            this.Controls.Add(this.netWorkLbl);
            this.Controls.Add(this.serivceLbl);
            this.Controls.Add(this.daemonLbl);
            this.Name = "ChannelControl";
            this.Size = new System.Drawing.Size(418, 703);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label daemonLbl;
        private System.Windows.Forms.Label serivceLbl;
        private System.Windows.Forms.Label netWorkLbl;
        private System.Windows.Forms.Label listenSubjectLbl;
        private System.Windows.Forms.ListBox statusBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button OpenBtn;
        private System.Windows.Forms.Label traceLbl;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtBoxDaemon;
        private System.Windows.Forms.TextBox txtBoxService;
        private System.Windows.Forms.TextBox txtBoxNetWork;
        private System.Windows.Forms.TextBox txtBoxListenOn;
        private System.Windows.Forms.TextBox txtBoxTargetDefault;
        private System.Windows.Forms.TextBox txtBoxPrivateListen;
        private System.Windows.Forms.TreeView transView;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button ClearBtn;



    }
}

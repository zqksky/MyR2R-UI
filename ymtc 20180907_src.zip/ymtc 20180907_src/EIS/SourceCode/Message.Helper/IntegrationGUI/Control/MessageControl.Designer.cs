﻿namespace IntegrationGUI.Control
{
    partial class MessageControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.transcontentTxt = new System.Windows.Forms.RichTextBox();
            this.messageTreeView = new System.Windows.Forms.TreeView();
            this.contextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.sendMessagMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // transcontentTxt
            // 
            this.transcontentTxt.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.transcontentTxt.BackColor = System.Drawing.Color.Azure;
            this.transcontentTxt.Location = new System.Drawing.Point(3, 3);
            this.transcontentTxt.Name = "transcontentTxt";
            this.transcontentTxt.Size = new System.Drawing.Size(270, 538);
            this.transcontentTxt.TabIndex = 14;
            this.transcontentTxt.Text = "";
            // 
            // messageTreeView
            // 
            this.messageTreeView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.messageTreeView.BackColor = System.Drawing.Color.Azure;
            this.messageTreeView.ContextMenuStrip = this.contextMenuStrip;
            this.messageTreeView.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.messageTreeView.Location = new System.Drawing.Point(279, 3);
            this.messageTreeView.Name = "messageTreeView";
            this.messageTreeView.Size = new System.Drawing.Size(723, 538);
            this.messageTreeView.TabIndex = 13;
            // 
            // contextMenuStrip
            // 
            this.contextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sendMessagMenuItem});
            this.contextMenuStrip.Name = "contextMenuStrip1";
            this.contextMenuStrip.Size = new System.Drawing.Size(153, 48);
            // 
            // sendMessagMenuItem
            // 
            this.sendMessagMenuItem.Name = "sendMessagMenuItem";
            this.sendMessagMenuItem.Size = new System.Drawing.Size(152, 22);
            this.sendMessagMenuItem.Text = "SendMessage";
            // 
            // MessageControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.transcontentTxt);
            this.Controls.Add(this.messageTreeView);
            this.Name = "MessageControl";
            this.Size = new System.Drawing.Size(1005, 544);
            this.contextMenuStrip.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox transcontentTxt;
        private System.Windows.Forms.TreeView messageTreeView;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem sendMessagMenuItem;
    }
}

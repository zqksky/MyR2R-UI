﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SimpleEventBroker;

namespace IntegrationGUI.Control
{
    public partial class MessageControl : UserControl
    {
        private EventBroker ebroker;
        public EventHandler StatusChangedHandler;
        private string cacheXmlMessage = "";

        public MessageControl()
        {
            InitializeComponent();
            ebroker = EventBroker.GetInstance();
        }

        public void SetSourceApplication(string[] sourceApplications)
        {
            ebroker.SubscribeEvents<DisplayMessageEvent>(this.HandleDisplayMessage);

            this.contextMenuStrip.Items.Clear();
            this.sendMessagMenuItem.DropDownItems.Clear();
            this.sendMessagMenuItem.Tag = "NoneSource";

            foreach (string source in sourceApplications)
            {
                ToolStripMenuItem soureItem = new ToolStripMenuItem();
                soureItem.Name = source;
                soureItem.Text = source;

                ToolStripMenuItem senderItem = new ToolStripMenuItem();
                senderItem.Name = "SendMessage"+source;
                senderItem.Tag=source;
                senderItem.Text = "SendMessage";
                senderItem.Click += new EventHandler(this.OnSendMessage);

                soureItem.DropDownItems.Add(senderItem);

                this.contextMenuStrip.Items.Add(soureItem);
            }
            
        }

        private void OnSendMessage(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(this.cacheXmlMessage))
            {
                MessageBox.Show("Please select a file", "Warn", MessageBoxButtons.OK);
                return;
            }

            ToolStripMenuItem item = sender as ToolStripMenuItem;
            ebroker.GetEvent<SendMessageRequestEvent>().Publish(new SendMessageRequestEventArgs(item.Tag + "", this.cacheXmlMessage, false, -1));
        }

        private void HandleDisplayMessage(object sender, EventArgs e)
        {
            DisplayMessageEventArgs displayEvent = e as DisplayMessageEventArgs;
            this.messageTreeView.Nodes.Clear();
            this.transcontentTxt.Text = "";
            this.cacheXmlMessage = "";
            //

            this.transcontentTxt.Text = displayEvent.TransContent;

            List<string> xmlStrings =new List<string>();
            if (!string.IsNullOrEmpty(displayEvent.File))
            {
                #region read from file
                System.IO.FileStream file = null;
                System.IO.StreamReader sr = null;
                try
                {
                    file = new System.IO.FileStream(displayEvent.File, System.IO.FileMode.Open, System.IO.FileAccess.Read);
                    sr = new System.IO.StreamReader(file, Encoding.UTF8);
                    string tmp = sr.ReadToEnd();
                    xmlStrings.Add(tmp);
                    this.cacheXmlMessage = tmp;
                    sr.Close();
                    file.Close();
                }
                finally
                {
                    if ((file != null))
                    {
                        file.Dispose();
                    }
                    if ((sr != null))
                    {
                        sr.Dispose();
                    }
                }
                #endregion
            }
            else
            {
                xmlStrings.AddRange(displayEvent.XmlContent);
            }
            try
            {
                foreach (string xmlString in xmlStrings)
                {
                    if (!string.IsNullOrEmpty(xmlString))
                    {
                        System.Xml.XmlDocument document = new System.Xml.XmlDataDocument();
                        document.LoadXml(xmlString);
                        TreeNode rootNode = new TreeNode(string.IsNullOrEmpty(document.DocumentElement.Name)?"Content":document.DocumentElement.Name);
                        populateTreeControl(document.DocumentElement, rootNode.Nodes);
                        this.messageTreeView.Nodes.Add(rootNode);
                    } 
                }
                this.NotifyStatusChanged("");
            }
            catch (Exception ex)
            {
                this.NotifyStatusChanged("Read Xml file Error  :"+ex.Message);
            }
        }

        private void populateTreeControl(System.Xml.XmlNode document,System.Windows.Forms.TreeNodeCollection nodes)
        {
            foreach (System.Xml.XmlNode node in document.ChildNodes)
            {
                // If the element has a value, display it; 
                // otherwise display the first attribute 
                // (if there is one) or the element name 
                // (if there isn't)



                if (node.HasChildNodes && node.ChildNodes.Count == 1 && node.ChildNodes[0].NodeType == System.Xml.XmlNodeType.Text)
                {
                    string text = (node.Value != null ? node.Value :
                            (node.Attributes != null && node.Attributes.Count > 0) ?
                            node.Attributes[0].Value : node.Name) + " :"+ node.ChildNodes[0].InnerText;
                    TreeNode new_child = new TreeNode(text);
                    nodes.Add(new_child);
                }
                else{
                    string text = (node.Value != null ? node.Value :
                            (node.Attributes != null && node.Attributes.Count > 0) ?
                            node.Attributes[0].Value : node.Name);
                            TreeNode new_child = new TreeNode(text);
                    nodes.Add(new_child);
                    populateTreeControl(node, new_child.Nodes);
                }
            }
        }

        private void NotifyStatusChanged(string status)
        {
            if (this.StatusChangedHandler != null)
            {
                this.StatusChangedHandler(this, new StatusChangedtEventArgs(status));
            }
        }
    }
}

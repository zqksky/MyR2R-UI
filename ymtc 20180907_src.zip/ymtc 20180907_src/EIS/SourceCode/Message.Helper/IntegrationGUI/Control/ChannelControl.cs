﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using AMAT.RVAdapter.RVComponentAdapter;
using TIBCO.Rendezvous;
using AMAT.RVAdapter.CommonData;
using AMAT.RVAdapter.CommonData.Events;
using AMAT.RVAdapter.CommonData.EventArgs;
using AMAT.RVAdapter.Log;

using EIS.XML.Parser;
using EIS.XML.Parser.Adapter;
using EIS.XML.Parser.Structure;
using AMAT.RVAdapter.TransactionPool;
using SimpleEventBroker;

namespace IntegrationGUI.Control
{
    public partial class ChannelControl : UserControl
    {
        private delegate void InvokeAddNodeCall(TreeNode node);
        private delegate void InvokeUpdateNodeCall(ChannelTransItem item);
        private string systemName;
        private RVProxy proxy;
        private EventBroker ebroker;
        private LogHelper Logger;
        private TransactionFactory factory = TransactionFactory.GetFactory();
        private ReceivedMessageHandle receiveHandle = new ReceivedMessageHandle();
        public event EventHandler StatusChangedHandler;
        public static Boolean tibcoOpened = false;
        //private SortedDictionary<string, ChannelTransItem> translist = new SortedDictionary<string, ChannelTransItem>();

        public ChannelControl()
        {
            InitializeComponent();

            Logger = LogHelper.GetInstance();
            ebroker = EventBroker.GetInstance();

            ebroker.SubscribeEvents<PublicRVMessageArrivedEvent>(HandlePublicRVMessageArrivedEvent);
            ebroker.SubscribeEvents<SendMessageRequestEvent>(HandleSendMessageRequestEvent);
            ebroker.SubscribeEvents<SendFileRequestEvent>(HandleSendFileRequestEvent);
            ebroker.SubscribeEvents<SendFilesRequestEvent>(HandleSendFilesRequestEvent);
        }

        public void SetProxy(string systemName, RVProxy proxy)
        {
            this.proxy = proxy;
            this.systemName = systemName;
            //display the proxy info 
            this.txtBoxDaemon.Text = proxy.Config.Daemon;
            this.txtBoxService.Text = proxy.Config.Service;
            this.txtBoxNetWork.Text = proxy.Config.Network;
            this.txtBoxListenOn.Text = proxy.Config.ListenSubject;
            this.txtBoxTargetDefault.Text = proxy.Config.TargetSubject;
            this.txtBoxPrivateListen.Text = proxy.GetInbox();

            //notifiy status changed
            this.NotifyStatusChanged(this.systemName + " Loadded");
        }

        private void OpenBtn_Click(object sender, EventArgs e)
        {
            if(!ChannelControl.tibcoOpened){
                TIBCO.Rendezvous.Environment.Open();
                ChannelControl.tibcoOpened = true;
            }
            

            if (proxy == null)
            {
                this.statusBox.Items.Add(DateTime.Now.ToString() + "  None RV Channel configureation , please restart");
            }
            else if(!this.proxy.GetConnectStatus())
            {
                //do connect
                bool flag = true;
                if (this.proxy.Connect())
                {
                    this.statusBox.Items.Add(DateTime.Now.ToString()+"  Connect successful");
                    //this.proxy.CreatePublicListener();
                    if (this.proxy.CreatePublicListener())
                    {
                        this.statusBox.Items.Add(DateTime.Now.ToString() + "  Create Public Subject successful");
                    }
                    else
                    {
                        this.statusBox.Items.Add(DateTime.Now.ToString() + "  Create Public Subject fail");
                        flag = false;
                    }
                    if (this.proxy.CreatePrivateListener())
                    {
                        this.statusBox.Items.Add(DateTime.Now.ToString() + "  Create Private Subject successful");
                        this.txtBoxPrivateListen.Text = proxy.GetInbox();
                    }
                    else
                    {
                        this.statusBox.Items.Add(DateTime.Now.ToString() + "  Create Private Subject fail");
                        flag = false;
                    }
                }
                else
                {
                    this.statusBox.Items.Add(DateTime.Now.ToString() + "  Connect fail");
                    flag = false;
                }

                if (!flag)
                {
                    this.proxy.Disconnect();
                    this.OpenBtn.Text = "Open";
                    this.traceLbl.Text = "Channel Closed";
                    this.NotifyStatusChanged(this.systemName + " fail to connect");
 
                }
                else
                {
                    this.OpenBtn.BackColor = Color.Green;
                    this.OpenBtn.Text = "Close";
                    this.traceLbl.Text = "Channel Connected";
                    this.NotifyStatusChanged(this.systemName + " connect successful");
                }
                //here to test 
                string error;
                //this.OnSendOneFile(@"./message/used.xml", out error);
                
            }
            else if (this.proxy.GetConnectStatus())
            {
                //do disconnect
                this.proxy.Disconnect();
                this.OpenBtn.BackColor = Color.LightGray;
                this.OpenBtn.Text = "Open";
                this.traceLbl.Text = "Channel Closed";
                this.statusBox.Items.Add(DateTime.Now.ToString() + "  Disconnect");
                this.NotifyStatusChanged(this.systemName + " disconnect");
            }
        }

        #region Event handlers

        private void HandlePublicRVMessageArrivedEvent(object sender, EventArgs e)
        {
            ThreadPool.QueueUserWorkItem(PublicRVMessageArrivedEventThread, e);
        }

        private void HandleSendMessageRequestEvent(object sender, EventArgs e)
        {
            ThreadPool.QueueUserWorkItem(SendMessageRequestEventThread, e);
        }

        private void HandleSendFileRequestEvent(object sender, EventArgs e)
        {
            ThreadPool.QueueUserWorkItem(SendFileRequestEventThread, e);
        }

        private void HandleSendFilesRequestEvent(object sender, EventArgs e)
        {
            ThreadPool.QueueUserWorkItem(SendFilesRequestEventThread, e);
        }

        #endregion

        #region Event Thread
        private void PublicRVMessageArrivedEventThread(object e)
        {
            PublicRVMessageArrivedEventArgs args = e as PublicRVMessageArrivedEventArgs;
            if (!args.SystemName.Equals(this.systemName)) return;

            EIS.XML.Parser.Adapter.Header.msgType header = null;
            Exception ex;
            string xml = args.Message;
            bool result = EIS.XML.Parser.Adapter.Header.msgType.Deserialize(xml, out header, out ex);
            if (!result)
            {
                this.NotifyStatusChanged(this.systemName + "   receive message " + "    " + ex.Message);
                return;
            }
            this.NotifyStatusChanged(this.systemName + "   receive message ");
            string replyAddress = "";
            string replyTarget="";
            if (header.rvHeader.replyApplication != null && header.rvHeader.replyApplication.address != null)
            {
                foreach (EIS.XML.Parser.Adapter.Header.addressType add in header.rvHeader.replyApplication.address)
                {
                    replyAddress += (add.Value + ",");
                    replyTarget += (add.applicationName + ",");
                }
            }
            //
            ChannelTransItem item = this.ParseTransItem(header);

            int retCode;
            string retMessage="";
            string replyMessage = "" ;
            string serviceName = CommandMapping.Instance.FindCmd(header.msgHeader.srvMethod, header.msgHeader.srvMethod);
            

            replyMessage = this.receiveHandle.HandleReceiveMessage(serviceName, this.proxy, xml, replyTarget, replyAddress, out retCode, out retMessage);

            /*
            if ("RandomQuery".Equals(header.msgHeader.srvMethod))
            {
                replyMessage=this.receiveHandle.HandleReceiveMessage(header.msgHeader.srvMethod, this.proxy, xml, replyTarget, replyAddress, out retCode, out retMessage);
            }
            if ("AlarmReportEvent".Equals(header.msgHeader.srvMethod))
            {
                replyMessage=this.receiveHandle.HandleReceiveMessage(header.msgHeader.srvMethod, this.proxy, xml, replyTarget, replyAddress, out retCode, out retMessage);
            }
            if ("QueryLotInfo".Equals(header.msgHeader.srvMethod))
            {
                replyMessage = this.receiveHandle.HandleReceiveMessage(header.msgHeader.srvMethod, this.proxy, xml, replyTarget, replyAddress, out retCode, out retMessage);
            }*/
            Thread.Sleep(200);
            item.RequestContent = xml;
            item.ReplyTime = DateTime.Now;
            item.ReplyContent = replyMessage;

            this.AppendTransactionItem(item);
            this.NotifyStatusChanged(this.systemName + "   reply message finished " + "    " + retMessage);
        }

        private void SendMessageRequestEventThread(object e)
        {
            SendMessageRequestEventArgs sendEvent = e as SendMessageRequestEventArgs;
            if (!this.systemName.Equals(sendEvent.SourceApplication)) return;
            this.NotifyStatusChanged(this.systemName + "   send message processing ");
            string error;
            bool res = this.OnSendOneMessage(sendEvent.Message, sendEvent.AutoTxId, sendEvent.Timeout, out error);
            this.NotifyStatusChanged(this.systemName + "   send message finished " + "    " + error);

            return;
        }

        private void SendFileRequestEventThread(object e)
        {
            if (this.transView.InvokeRequired)
            {
                SendFileRequestEventArgs sendEvent = e as SendFileRequestEventArgs;
                if (!this.systemName.Equals(sendEvent.SourceApplication)) return;
                this.NotifyStatusChanged(this.systemName + "   send file processing ");
                string error;
                bool res = this.OnSendOneFile(sendEvent.FileName, sendEvent.AutoTxId, sendEvent.Timeout, out error);
                this.NotifyStatusChanged(this.systemName + "   send file finished " + "    " + error);
            }
        }

        private void SendFilesRequestEventThread(object e)
        {
            if (this.transView.InvokeRequired)
            {
                SendFilesRequestEventArgs sendEvent = e as SendFilesRequestEventArgs;
                if (!this.systemName.Equals(sendEvent.SourceApplication)) return;
                this.NotifyStatusChanged(this.systemName + "   send files( " + sendEvent.FileNames.Count() + " ) processing ");
                string error;
                bool res = this.OnSendFiles(sendEvent.FileNames, sendEvent.AutoTxId, sendEvent.Timeout, out error);
                this.NotifyStatusChanged(this.systemName + "   send files( " + sendEvent.FileNames.Count() + " ) finished " + "    " + error); ;
            } 
        }
        #endregion

        private void AppendTransactionItem(ChannelTransItem item)
        {
            lock (this.systemName)
            {
                try
                {

                    this.transView.Nodes.RemoveByKey(item.TxId);

                    TreeNode node = new TreeNode();
                    node.Name = item.TxId;
                    node.Text = item.ToString();
                    node.ToolTipText = item.Content();
                    node.Tag = item;

                    this.transView.BeginInvoke(new InvokeAddNodeCall(this.AddTreeNode),node);

                    //this.transView.Nodes.Add(node);
                }
                catch (Exception e)
                {
                    item.Err = e.Message;
                }
            }
        }

        private ChannelTransItem ParseTransItem(EIS.XML.Parser.Adapter.Header.msgType header)
        {
            //EIS.XML.Parser.Adapter.Header.msgType header=EIS.XML.Parser.Adapter.Header.msgType.Deserialize(xmlSpec.SerializeXmlSpec(true, xmlSpec));
           
            string ss=header.msgHeader.timeOut;
            if(string.IsNullOrEmpty(ss)) ss="1";

            IList<AddressInfo> replys = new List<AddressInfo>();
            if (header.rvHeader.replyApplication != null && header.rvHeader.replyApplication.address != null)
            {
                foreach (EIS.XML.Parser.Adapter.Header.addressType at in header.rvHeader.replyApplication.address)
                {
                    replys.Add(new AddressInfo(at.seq, at.applicationName, at.Value));
                }
            }

            ChannelTransItem item = new ChannelTransItem(header.msgHeader.txId,
                header.rvHeader.source.application,
                header.rvHeader.source.address,
                header.rvHeader.destination.application,
                header.rvHeader.destination.address,
                replys,
                header.msgHeader.srvMethod,
                int.Parse(ss),
                DateTime.Now);

            return item;
        }

        private bool OnSendOneMessage(string message,bool autoTxId, int timeout,out string error)
        {
            error = "";
            if (this.proxy == null || !this.proxy.GetConnectStatus())
            {
                error = "Channel isn't Connected";
                return false;
            } 
            EIS.XML.Parser.Adapter.Header.msgType header ;
            bool result=EIS.XML.Parser.Adapter.Header.msgType.Deserialize(message, out header);
            if (!result)
            {
                error = "Uncognicated Message";
                return false;
            }

            ChannelTransItem item = this.ParseTransItem(header);
            if (!this.systemName.Equals(item.SourceApplication))
            {
                error = "Source doesn't match.";
                return false;
            }
            //re build the rvheader
            string mss;
            if (!this.RebuildSendingMessageHeader(item, message, autoTxId, timeout, out mss))
            {
                error = "Rebuild Message Header fail.(maybe this message isn't supported)";
                return false;
            }

            //should be placed after RebuildSendingMessageHeader
            item.Status = "Processing";
            this.AppendTransactionItem(item);
            try
            {
                if (item.ReplyAddress==null || item.ReplyAddress.Count()==0)
                {
                    //send message
                    int retCode;
                    string retMessage;
                    item.RequestContent = mss;
                    this.proxy.SendMessage(mss, item.DestinationAddress, out retCode, out retMessage);
                    item.Err = retMessage;
                    //
                    Thread.Sleep(200);
                    item.Status = "";
                    //item.ReplyContent = reply;
                    //item.ReplyTime = DateTime.Now;
                    this.transView.BeginInvoke(new InvokeUpdateNodeCall(this.UpdateTreeNode), item);
                }
                else
                {
                    //send request
                    int retCode;
                    string retMessage;
                    item.RequestContent = mss;
                    factory.CreateTransaction(item.TxId, item.Timeout, DateTime.Now, "");
                    string reply = proxy.SendRequest(mss, item.DestinationAddress, item.Timeout, "NA", item.TxId, out retCode, out retMessage);
                    factory.CloseTransaction(item.TxId);
                    item.Err = retMessage;
                    //
                    Thread.Sleep(200);
                    item.Status = "";
                    item.ReplyContent = reply;
                    item.ReplyTime = DateTime.Now;
                    this.transView.BeginInvoke(new InvokeUpdateNodeCall(this.UpdateTreeNode),item);
                }
            }
            catch (Exception ex)
            {
                item.Err = ex.Message;
            }

            return true;
        }

        private bool OnSendOneFile(string fileName, bool autoTxId, int timeout, out string error)
        {
            System.IO.FileStream file = null;
            System.IO.StreamReader sr = null;
            try
            {
                file = new System.IO.FileStream(fileName, System.IO.FileMode.Open, System.IO.FileAccess.Read);
                sr = new System.IO.StreamReader(file, Encoding.UTF8);
                string xmlString = sr.ReadToEnd();
                sr.Close();
                file.Close();

                error="";
                bool res = OnSendOneMessage(xmlString, autoTxId, timeout, out error);
                //this.NotifyStatusChanged(this.systemName + " send "+fileName +" finished" + "   "+error);
                return res;
            }
            finally
            {
                if ((file != null))
                {
                    file.Dispose();
                }
                if ((sr != null))
                {
                    sr.Dispose();
                }
            }
        }

        private bool OnSendFiles(string[] fileNames, bool autoTxId, int timeout, out string error)
        {
            error = "";
            foreach (string fileName in fileNames)
            {
                if (!OnSendOneFile(fileName,autoTxId,timeout,out error)) return false;
            }
            return true;
        }

        private bool OnSendFolder(string folderName)
        {

            return true;
        }

        private bool RebuildSendingMessageHeader(ChannelTransItem item, string message, bool autoTxId, int timeout, out string result)
        {
            result = message;
            string cmd=CommandMapping.Instance.FindCmd(item.ServiceName,item.ServiceName);

            switch (item.ServiceName){

                case "EAPReqToolSecsData":
                    EIS.XML.Parser.Adapter.EAPReqToolSecsData.msgType secs = EIS.XML.Parser.Adapter.EAPReqToolSecsData.msgType.Deserialize(message);
                    //replyApplication
                    //////////////////////
                    if (secs.rvHeader.replyApplication == null)
                        secs.rvHeader.replyApplication = new EIS.XML.Parser.Adapter.EAPReqToolSecsData.replyApplicationType();
                    if (secs.rvHeader.replyApplication.address == null)
                        secs.rvHeader.replyApplication.address = new List<EIS.XML.Parser.Adapter.EAPReqToolSecsData.addressType>();

                    EIS.XML.Parser.Adapter.EAPReqToolSecsData.addressType tmp21 = new EIS.XML.Parser.Adapter.EAPReqToolSecsData.addressType();
                    tmp21.seq = secs.rvHeader.replyApplication.address.Count() + 1 + "";
                    tmp21.applicationName = secs.rvHeader.source.application;
                    tmp21.Value = this.proxy.GetInbox();
                    secs.rvHeader.replyApplication.address.Add(tmp21);
                    secs.rvHeader.replyApplication.addressNo = secs.rvHeader.replyApplication.address.Count() + "";
                    //////////////////
                    //destination
                    secs.rvHeader.destination.application = secs.rvHeader.destination.application;
                    secs.rvHeader.destination.address = proxy.Config.TargetSubject;
                    //source
                    secs.rvHeader.source.address = this.proxy.Config.ListenSubject;

                    item.ReplyAddress = new List<AddressInfo>();
                    if (secs.rvHeader.replyApplication != null)
                    {
                        foreach (EIS.XML.Parser.Adapter.EAPReqToolSecsData.addressType ad in secs.rvHeader.replyApplication.address)
                        {
                            item.ReplyAddress.Add(new AddressInfo(ad.seq, ad.applicationName, ad.Value));
                        }
                    }
                    item.DestinationApplication = secs.rvHeader.destination.application;
                    item.DestinationAddress = proxy.Config.TargetSubject;
                    item.SourceApplication = this.systemName;
                    item.SourceAddress = this.proxy.Config.ListenSubject;

                    //change txid and timeout
                    if (autoTxId)
                    {
                        secs.msgHeader.txId = string.Format("{0}.{1}", DateTime.Now.ToString("yyyyMMddHHmmss.fff"), new Object().GetHashCode().ToString());
                        item.TxId = secs.msgHeader.txId;
                    }
                    if (timeout > 0)
                    {
                        secs.msgHeader.timeOut = timeout + "";
                        item.Timeout = timeout;
                    }

                    result = secs.SerializeXmlSpec(true, secs);
                    return true;
                    break;

                case "CalcRecipeSettings":
                    EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgType calc = EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgType.Deserialize(message);
                    //replyApplication
                    //////////////////////
                    if (calc.rvHeader.replyApplication == null)
                        calc.rvHeader.replyApplication = new EIS.XML.Parser.Adapter.CalcRecipeSettingsR.replyApplicationType();
                    if (calc.rvHeader.replyApplication.address == null)
                        calc.rvHeader.replyApplication.address = new List<EIS.XML.Parser.Adapter.CalcRecipeSettingsR.addressType>();
                    
                    EIS.XML.Parser.Adapter.CalcRecipeSettingsR.addressType tmp1 = new EIS.XML.Parser.Adapter.CalcRecipeSettingsR.addressType();
                    tmp1.seq = calc.rvHeader.replyApplication.address.Count() + 1 + "";
                    tmp1.applicationName = calc.rvHeader.source.application;
                    tmp1.Value = this.proxy.GetInbox();
                    calc.rvHeader.replyApplication.address.Add(tmp1);
                    calc.rvHeader.replyApplication.addressNo = calc.rvHeader.replyApplication.address.Count() + "";
                    //////////////////
                    //destination
                    calc.rvHeader.destination.application = calc.rvHeader.destination.application;
                    calc.rvHeader.destination.address = proxy.Config.TargetSubject;
                    //source
                    calc.rvHeader.source.address = this.proxy.Config.ListenSubject;

                    item.ReplyAddress = new List<AddressInfo>();
                    if (calc.rvHeader.replyApplication != null)
                    {
                        foreach (EIS.XML.Parser.Adapter.CalcRecipeSettingsR.addressType ad in calc.rvHeader.replyApplication.address)
                        {
                            item.ReplyAddress.Add(new AddressInfo(ad.seq, ad.applicationName, ad.Value));
                        }
                    }
                    item.DestinationApplication = calc.rvHeader.destination.application;
                    item.DestinationAddress = proxy.Config.TargetSubject;
                    item.SourceApplication = this.systemName;
                    item.SourceAddress = this.proxy.Config.ListenSubject;
                    
                    //change txid and timeout
                    if (autoTxId)
                    {
                        calc.msgHeader.txId = string.Format("{0}.{1}", DateTime.Now.ToString("yyyyMMddHHmmss.fff"), new Object().GetHashCode().ToString());
                        item.TxId = calc.msgHeader.txId;
                    }
                    if (timeout > 0)
                    {
                        calc.msgHeader.timeOut = timeout + "";
                        item.Timeout = timeout;
                    }

                    result = calc.SerializeXmlSpec(true, calc);
                    return true;
                    break;

                case "EAPReqLISCondition":
                    EIS.XML.Parser.Adapter.EAPReqLISCondition.msgType eap = EIS.XML.Parser.Adapter.EAPReqLISCondition.msgType.Deserialize(message);
                    //replyApplication
                    //////////////////////
                    if (eap.rvHeader.replyApplication == null)
                        eap.rvHeader.replyApplication = new EIS.XML.Parser.Adapter.EAPReqLISCondition.replyApplicationType();
                    if (eap.rvHeader.replyApplication.address == null)
                        eap.rvHeader.replyApplication.address = new List<EIS.XML.Parser.Adapter.EAPReqLISCondition.addressType>();

                    EIS.XML.Parser.Adapter.EAPReqLISCondition.addressType tmp2 = new EIS.XML.Parser.Adapter.EAPReqLISCondition.addressType();
                    tmp2.seq = eap.rvHeader.replyApplication.address.Count() + 1 + "";
                    tmp2.applicationName = eap.rvHeader.source.application;
                    tmp2.Value = this.proxy.GetInbox();
                    eap.rvHeader.replyApplication.address.Add(tmp2);
                    eap.rvHeader.replyApplication.addressNo = eap.rvHeader.replyApplication.address.Count() + "";
                    //////////////////
                    //destination
                    eap.rvHeader.destination.application = eap.rvHeader.destination.application;
                    eap.rvHeader.destination.address = proxy.Config.TargetSubject;
                    //source
                    eap.rvHeader.source.address = this.proxy.Config.ListenSubject;

                    item.ReplyAddress = new List<AddressInfo>();
                    if (eap.rvHeader.replyApplication != null)
                    {
                        foreach (EIS.XML.Parser.Adapter.EAPReqLISCondition.addressType ad in eap.rvHeader.replyApplication.address)
                        {
                            item.ReplyAddress.Add(new AddressInfo(ad.seq, ad.applicationName, ad.Value));
                        }
                    }
                    item.DestinationApplication = eap.rvHeader.destination.application;
                    item.DestinationAddress = proxy.Config.TargetSubject;
                    item.SourceApplication = this.systemName;
                    item.SourceAddress = this.proxy.Config.ListenSubject;

                    //change txid and timeout
                    if (autoTxId)
                    {
                        eap.msgHeader.txId = string.Format("{0}.{1}", DateTime.Now.ToString("yyyyMMddHHmmss.fff"), new Object().GetHashCode().ToString());
                        item.TxId = eap.msgHeader.txId;
                    }
                    if (timeout > 0)
                    {
                        eap.msgHeader.timeOut = timeout + "";
                        item.Timeout = timeout;
                    }

                    result = eap.SerializeXmlSpec(true, eap);
                    return true;
                    break;

                case "SendExposureContext":
                    EIS.XML.Parser.Adapter.SendExposureContextR.msgType expo = EIS.XML.Parser.Adapter.SendExposureContextR.msgType.Deserialize(message);
                    //replyApplication
                    //////////////////////
                    if (expo.rvHeader.replyApplication == null)
                        expo.rvHeader.replyApplication = new EIS.XML.Parser.Adapter.SendExposureContextR.replyApplicationType();
                    if (expo.rvHeader.replyApplication.address == null)
                        expo.rvHeader.replyApplication.address = new List<EIS.XML.Parser.Adapter.SendExposureContextR.addressType>();

                    EIS.XML.Parser.Adapter.SendExposureContextR.addressType tmp3 = new EIS.XML.Parser.Adapter.SendExposureContextR.addressType();//new EIS.XML.Parser.Adapter.SendExposureContextR.addressType();
                    tmp3.seq = expo.rvHeader.replyApplication.address.Count() + 1 + "";
                    tmp3.applicationName = expo.rvHeader.source.application;
                    tmp3.Value = this.proxy.GetInbox();
                    expo.rvHeader.replyApplication.address.Add(tmp3);
                    expo.rvHeader.replyApplication.addressNo = expo.rvHeader.replyApplication.address.Count() + "";
                    //////////////////
                    

                    //destination
                    expo.rvHeader.destination.application = "R2R";
                    expo.rvHeader.destination.address = proxy.Config.TargetSubject;
                    //source
                    expo.rvHeader.source.address = this.proxy.Config.ListenSubject;

                    item.ReplyAddress = new List<AddressInfo>();
                    if (expo.rvHeader.replyApplication != null)
                    {
                        foreach (EIS.XML.Parser.Adapter.SendExposureContextR.addressType ad in expo.rvHeader.replyApplication.address)
                        {
                            item.ReplyAddress.Add(new AddressInfo(ad.seq, ad.applicationName, ad.Value));
                        }
                    }

                    item.DestinationApplication = "R2R";
                    item.DestinationAddress = proxy.Config.TargetSubject;
                    item.SourceApplication = this.systemName;
                    item.SourceAddress = this.proxy.Config.ListenSubject;

                    //change txid and timeout
                    if (autoTxId)
                    {
                        expo.msgHeader.txId = string.Format("{0}.{1}", DateTime.Now.ToString("yyyyMMddHHmmss.fff"), new Object().GetHashCode().ToString());
                        item.TxId = expo.msgHeader.txId;
                    }
                    if (timeout > 0)
                    {
                        expo.msgHeader.timeOut = timeout + "";
                        item.Timeout = timeout;
                    }

                    result = expo.SerializeXmlSpec(true, expo);
                    return true;
                    break;

                case "JobInSettings":
                    EIS.XML.Parser.Adapter.JobInSettings.msgType jobin = EIS.XML.Parser.Adapter.JobInSettings.msgType.Deserialize(message);
                    //replyApplication
                    //////////////////////
                    if (jobin.rvHeader.replyApplication == null)
                        jobin.rvHeader.replyApplication = new EIS.XML.Parser.Adapter.JobInSettings.replyApplicationType();
                    if (jobin.rvHeader.replyApplication.address == null)
                        jobin.rvHeader.replyApplication.address = new List<EIS.XML.Parser.Adapter.JobInSettings.addressType>();

                    if (jobin.rvHeader.replyApplication.address.Count() > 0)
                    {
                        EIS.XML.Parser.Adapter.JobInSettings.addressType tmp4 = new EIS.XML.Parser.Adapter.JobInSettings.addressType();
                        tmp4.seq = jobin.rvHeader.replyApplication.address.Count() + 1 + "";
                        tmp4.applicationName = jobin.rvHeader.source.application;
                        tmp4.Value = this.proxy.GetInbox();
                        jobin.rvHeader.replyApplication.address.Add(tmp4);
                        jobin.rvHeader.replyApplication.addressNo = jobin.rvHeader.replyApplication.address.Count() + "";
                    }
                    
                    //////////////////
                    //destination
                    jobin.rvHeader.destination.application = jobin.rvHeader.destination.application;
                    jobin.rvHeader.destination.address = proxy.Config.TargetSubject;
                    //source
                    jobin.rvHeader.source.address = this.proxy.Config.ListenSubject;

                    item.ReplyAddress = new List<AddressInfo>();
                    if (jobin.rvHeader.replyApplication != null)
                    {
                        foreach (EIS.XML.Parser.Adapter.JobInSettings.addressType ad in jobin.rvHeader.replyApplication.address)
                        {
                            item.ReplyAddress.Add(new AddressInfo(ad.seq, ad.applicationName, ad.Value));
                        }
                    }
                    item.DestinationApplication = "R2R";
                    item.DestinationAddress = proxy.Config.TargetSubject;
                    item.SourceApplication = this.systemName;
                    item.SourceAddress = this.proxy.Config.ListenSubject;
                    
                    //change txid and timeout
                    if (autoTxId)
                    {
                        jobin.msgHeader.txId = string.Format("{0}.{1}", DateTime.Now.ToString("yyyyMMddHHmmss.fff"), new Object().GetHashCode().ToString());
                        item.TxId = jobin.msgHeader.txId;
                    }
                    if (timeout > 0)
                    {
                        jobin.msgHeader.timeOut = timeout + "";
                        item.Timeout = timeout;
                    }

                    result = jobin.SerializeXmlSpec(true, jobin);
                    return true;
                    break;
                case "UsedSettings":
                    EIS.XML.Parser.Adapter.UsedSettings.msgType used = EIS.XML.Parser.Adapter.UsedSettings.msgType.Deserialize(message);
                    //replyApplication
                    //////////////////////
                    if (used.rvHeader.replyApplication == null)
                        used.rvHeader.replyApplication = new EIS.XML.Parser.Adapter.UsedSettings.replyApplicationType();
                    if (used.rvHeader.replyApplication.address == null)
                        used.rvHeader.replyApplication.address = new List<EIS.XML.Parser.Adapter.UsedSettings.addressType>();

                    if (used.rvHeader.replyApplication.address.Count() > 0)
                    {
                        EIS.XML.Parser.Adapter.UsedSettings.addressType tmp5 = new EIS.XML.Parser.Adapter.UsedSettings.addressType();
                        tmp5.seq = used.rvHeader.replyApplication.address.Count() + 1 + "";
                        tmp5.applicationName = used.rvHeader.source.application;
                        tmp5.Value = this.proxy.GetInbox();
                        used.rvHeader.replyApplication.address.Add(tmp5);
                        used.rvHeader.replyApplication.addressNo = used.rvHeader.replyApplication.address.Count() + "";
                    }
                    
                    //////////////////
                    //destination
                    used.rvHeader.destination.application = used.rvHeader.destination.application;
                    used.rvHeader.destination.address = proxy.Config.TargetSubject;
                    //source
                    used.rvHeader.source.address = this.proxy.Config.ListenSubject;

                    item.ReplyAddress = new List<AddressInfo>();
                    if (used.rvHeader.replyApplication != null)
                    {
                        foreach (EIS.XML.Parser.Adapter.UsedSettings.addressType ad in used.rvHeader.replyApplication.address)
                        {
                            item.ReplyAddress.Add(new AddressInfo(ad.seq, ad.applicationName, ad.Value));
                        }
                    }
                    item.DestinationApplication = "R2R";
                    item.DestinationAddress = proxy.Config.TargetSubject;
                    item.SourceApplication = this.systemName;
                    item.SourceAddress = this.proxy.Config.ListenSubject;
                    
                    //change txid and timeout
                    if (autoTxId)
                    {
                        used.msgHeader.txId = string.Format("{0}.{1}", DateTime.Now.ToString("yyyyMMddHHmmss.fff"), new Object().GetHashCode().ToString());
                        item.TxId = used.msgHeader.txId;
                    }
                    if (timeout > 0)
                    {
                        used.msgHeader.timeOut = timeout + "";
                        item.Timeout = timeout;
                    }

                    result = used.SerializeXmlSpec(true, used);
                    return true;
                    break;

                case "Metrology":
                    EIS.XML.Parser.Adapter.Metrology.msgType mss = EIS.XML.Parser.Adapter.Metrology.msgType.Deserialize(message);
                    //replyApplication
                    //////////////////////
                    if (mss.rvHeader.replyApplication == null)
                        mss.rvHeader.replyApplication = new EIS.XML.Parser.Adapter.Metrology.replyApplicationType();
                    if (mss.rvHeader.replyApplication.address == null)
                        mss.rvHeader.replyApplication.address = new List<EIS.XML.Parser.Adapter.Metrology.addressType>();

                    if (mss.rvHeader.replyApplication.address.Count() > 0)
                    {
                        EIS.XML.Parser.Adapter.Metrology.addressType tmp4 = new EIS.XML.Parser.Adapter.Metrology.addressType();
                        tmp4.seq = mss.rvHeader.replyApplication.address.Count() + 1 + "";
                        tmp4.applicationName = mss.rvHeader.source.application;
                        tmp4.Value = this.proxy.GetInbox();
                        mss.rvHeader.replyApplication.address.Add(tmp4);
                        mss.rvHeader.replyApplication.addressNo = mss.rvHeader.replyApplication.address.Count() + "";
                    }
                    //////////////////

                    //destination
                    mss.rvHeader.destination.application = mss.rvHeader.destination.application;
                    mss.rvHeader.destination.address = proxy.Config.TargetSubject;
                    //source
                    mss.rvHeader.source.address = this.proxy.Config.ListenSubject;

                    item.ReplyAddress = new List<AddressInfo>();
                    if (mss.rvHeader.replyApplication != null)
                    {
                        foreach (EIS.XML.Parser.Adapter.Metrology.addressType ad in mss.rvHeader.replyApplication.address)
                        {
                            item.ReplyAddress.Add(new AddressInfo(ad.seq, ad.applicationName, ad.Value));
                        }
                    }
                    item.DestinationApplication = mss.rvHeader.destination.application;
                    item.DestinationAddress = proxy.Config.TargetSubject;
                    item.SourceApplication = this.systemName;
                    item.SourceAddress = this.proxy.Config.ListenSubject;

                    //change txid and timeout
                    if (autoTxId)
                    {
                        mss.msgHeader.txId = string.Format("{0}.{1}", DateTime.Now.ToString("yyyyMMddHHmmss.fff"), new Object().GetHashCode().ToString());
                        item.TxId = mss.msgHeader.txId;
                    }
                    if (timeout > 0)
                    {
                        mss.msgHeader.timeOut = timeout + "";
                        item.Timeout = timeout;
                    }
                    result = mss.SerializeXmlSpec(true, mss);
                    return true;
                    break;
            }

            //doesn't support send other message
            return false ;
        }

        private void transView_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            TreeNode node = e.Node;
            string name = node.Name;
            ChannelTransItem item = (ChannelTransItem)node.Tag;
            DisplayMessageEventArgs args = new DisplayMessageEventArgs(item.Content(), new string[] { item.RequestContent,item.ReplyContent }, "");
            ebroker.GetEvent<DisplayMessageEvent>().Publish(args);
        }

        private void NotifyStatusChanged(string status)
        {
            if (this.StatusChangedHandler != null)
            {
                this.StatusChangedHandler(this, new StatusChangedtEventArgs(status));
            }
        }

        private void AddTreeNode(TreeNode node)
        {
            this.transView.Nodes.Add(node);
        }

        private void UpdateTreeNode(ChannelTransItem item)
        {
            if (this.transView.Nodes == null) return;
            TreeNode[] nodes=this.transView.Nodes.Find(item.TxId,false);
            if (nodes == null || nodes.Count() <= 0) return;
            nodes[0].Text = item.ToString();
            nodes[0].Tag = item;
            nodes[0].ToolTipText = item.Content();
        }

        #region RV Settings changed
        private void OnChangeDaemon(object sender, EventArgs e)
        {
             
        }

        private void OnChangeService(object sender, EventArgs e)
        {

        }

        private void OnChangeNetWork(object sender, EventArgs e)
        {

        }

        private void OnChangePublicListen(object sender, EventArgs e)
        {

        }

        private void OnChangeTargetListen(object sender, EventArgs e)
        {

        }
        #endregion

        private void OnClickClearTrans(object sender, EventArgs e)
        {
            lock (this.systemName)
            {
                this.transView.Nodes.Clear();
            }
        }


    }
}

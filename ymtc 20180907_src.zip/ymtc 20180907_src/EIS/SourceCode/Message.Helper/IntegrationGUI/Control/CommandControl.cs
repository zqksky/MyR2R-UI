﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SimpleEventBroker;

namespace IntegrationGUI.Control
{
    public partial class CommandControl : UserControl
    {
        private string folder = "";
        private EventBroker ebroker;

        public CommandControl()
        {
            InitializeComponent();
            ebroker = EventBroker.GetInstance();
        }

        public void SetSourceApplication(string[] sourceApplications)
        {
            this.sourceComboBox.Items.Clear();

            foreach (string source in sourceApplications)
            {
                this.sourceComboBox.Items.Add(source);
            }

            if (sourceApplications != null && sourceApplications.Count() > 0)
            {
                this.sourceComboBox.SelectedIndex = 0;
            }
            else
            {
                this.sendBtn.Enabled = false;
            }
        }

        public void SetFolder(string folder)
        {
            if (string.IsNullOrEmpty(folder)) return;
            //
            
            this.folder = folder;
            if (!this.folder.Contains(":"))
            {
                this.folder = System.IO.Directory.GetCurrentDirectory() + "\\" + this.folder.TrimStart('.').TrimStart('/').TrimStart('\\');
            }

            this.fileTreeView.Nodes.Clear();
            try
            {
                if (!System.IO.Directory.Exists(this.folder)) return;
                //root node
                TreeNode root = new TreeNode(this.folder);
                root.ImageIndex = 0;
                root.Tag=this.folder;
                //dir node
                string[] subDirs = System.IO.Directory.GetDirectories(this.folder);
                foreach (string dir in subDirs)
                {
                    string[] dirName = dir.Split('\\');
                    TreeNode dirNode = new TreeNode(dirName[dirName.Count() - 1]);
                    dirNode.ImageIndex = 0;
                    dirNode.Tag =  dir;
                    root.Nodes.Add(dirNode);
                }
                //file node
                string[] files = System.IO.Directory.GetFiles(this.folder);
                foreach (string file in files)
                {
                    string[] fileName=file.Split('\\');
                    TreeNode fileNode = new TreeNode(fileName[fileName.Count()-1]);
                    fileNode.ImageIndex = 1;
                    fileNode.Tag =  file;
                    root.Nodes.Add(fileNode); 
                }
                this.fileTreeView.Nodes.Add(root);
            }
            catch (Exception ex)
            {
            }
        }

        private void OnSend(object sender, EventArgs e)
        {
            string source = this.sourceComboBox.SelectedItem+"";
            TreeNode td = this.fileTreeView.SelectedNode;

            IList<string> selectFiles=new List<string>();
            this.GetSelectNodes(this.fileTreeView.Nodes,selectFiles);
            int timeout;
            if (!int.TryParse(this.timeoutTxt.Text, out timeout)) timeout = -1;
            SendFilesRequestEventArgs args = new SendFilesRequestEventArgs(source, selectFiles.ToArray(),this.autoTxIdChkBox.Checked, timeout);
            ebroker.GetEvent<SendFilesRequestEvent>().Publish(args);
        }

        private void sourceComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            string source = this.sourceComboBox.SelectedItem+"";
            if (string.IsNullOrEmpty(source)) this.sendBtn.Enabled = false;
        }

        private void OnNodeClicked(object sender, TreeNodeMouseClickEventArgs e)
        {
            //if click on file, then display it
            string tag = e.Node.Tag+"";
            if (System.IO.File.Exists(tag))
            {
                DisplayMessageEventArgs args = new DisplayMessageEventArgs("",new string[]{""},tag);
                ebroker.GetEvent<DisplayMessageEvent>().Publish(args);
            }
            
        }

        private void OnNodeDoubleClicked(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (this.folder.Equals(e.Node.Tag))
            {
                FolderBrowserDialog fbd = new FolderBrowserDialog();
                fbd.ShowNewFolderButton = false;
                //Environment.SpecialFolder sf = Environment.SpecialFolder.;
                fbd.SelectedPath = this.folder;
                if (fbd.ShowDialog() == DialogResult.OK)
                {
                    this.SetFolder(fbd.SelectedPath);
                }
            }
            else
            {
                string tag = e.Node.Tag + "" ;
                //if tag is folder, to load the sub dir and file
                if (System.IO.Directory.Exists(tag) && e.Node.Nodes.Count <= 0)
                {
                    //dir node
                    string[] subDirs = System.IO.Directory.GetDirectories(tag);
                    foreach (string dir in subDirs)
                    {
                        string[] dirName = dir.Split('\\');
                        TreeNode dirNode = new TreeNode(dirName[dirName.Count() - 1]);
                        dirNode.ImageIndex = 0;
                        dirNode.Tag = dir;
                        e.Node.Nodes.Add(dirNode);
                    }
                    //file node
                    string[] files = System.IO.Directory.GetFiles(tag);
                    foreach (string file in files)
                    {
                        string[] fileName = file.Split('\\');
                        TreeNode fileNode = new TreeNode(fileName[fileName.Count() - 1]);
                        fileNode.ImageIndex = 1;
                        fileNode.Tag = file;
                        e.Node.Nodes.Add(fileNode);
                    }
                }
                //if tag is file , then send
                if (System.IO.File.Exists(tag) && !string.IsNullOrEmpty(this.sourceComboBox.SelectedItem + ""))
                {
                    this.OnNodeClicked(sender, e);
                    ToolStripMenuItem item = sender as ToolStripMenuItem;
                    int timeout;
                    if (!int.TryParse(timeoutTxt.Text, out timeout)) timeout = -1;
                    string source=this.sourceComboBox.SelectedItem + "";
                    SendFileRequestEventArgs args = new SendFileRequestEventArgs(source, tag, autoTxIdChkBox.Checked, timeout);
                    ebroker.GetEvent<SendFileRequestEvent>().Publish(args);
                }
            }
        }

        private void OnNodeChecked(object sender, TreeViewEventArgs e)
        {
            foreach (TreeNode tn in e.Node.Nodes)
            {
                tn.Checked = e.Node.Checked;
            }
        }

        private void OnEditFile(object sender, EventArgs e)
        {
            TreeNode td = this.fileTreeView.SelectedNode;
            if (td != null && System.IO.File.Exists(td.Tag+""))
            {
                System.Diagnostics.Process.Start("notepad", td.Tag+"");
            }
        }

        private void GetSelectNodes(TreeNodeCollection nodes, IList<string> list)
        {
            foreach(TreeNode td in nodes)
            {
                string tag=td.Tag+"";
                if((td.Nodes==null || td.Nodes.Count==0 )&&System.IO.File.Exists(tag)){
                    if(td.Checked) list.Add(tag);
                }
                GetSelectNodes(td.Nodes,list);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using TIBCO.Rendezvous;
using AMAT.RVAdapter.CommonData;
using AMAT.RVAdapter.CommonData.Events;
using AMAT.RVAdapter.CommonData.EventArgs;
using AMAT.RVAdapter.Log;

using EIS.XML.Parser;
using EIS.XML.Parser.Adapter;
using EIS.XML.Parser.Structure;

using AMAT.RVAdapter.RVComponentAdapter;
using AMAT.RVAdapter.TransactionPool;
using SimpleEventBroker;
using IntegrationGUI.Control;

namespace IntegrationGUI
{
    public partial class IntegrationForm : Form
    {
        private TransactionFactory factory = null;
        private EventBroker ebroker;

        public IntegrationForm()
        {
            //regist event
            ebroker = EventBroker.GetInstance();
            ebroker.RegisterEvents<PublicRVMessageArrivedEvent>();
            ebroker.RegisterEvents<SendMessageRequestEvent>();
            ebroker.RegisterEvents<SendFileRequestEvent>();
            ebroker.RegisterEvents<SendFilesRequestEvent>();
            ebroker.RegisterEvents<DisplayMessageEvent>();

            InitializeComponent();

            try
            {
                //to get the channels settings
                IList<string> channels = new List<string>();
                string chn = System.Configuration.ConfigurationSettings.AppSettings["TargetChannels"];
                if (!string.IsNullOrEmpty(chn))
                {
                    channels=chn.Split(',').ToArray();
                }
                
                //init dropdown menu
                foreach (string channel in channels)
                {
                    ToolStripItem item = new System.Windows.Forms.ToolStripMenuItem();
                    item.Text = channel;
                    item.Click += new EventHandler(this.OnClickChannelItem);
                    this.loadItem.DropDownItems.Add(item);
                }

                //init message control 
                this.messageControl.SetSourceApplication(channels.ToArray());
                this.messageControl.StatusChangedHandler += new EventHandler(this.OnStatusChanged);

                //init command control 
                this.commandControl.SetSourceApplication(channels.ToArray());
                string folder = System.Configuration.ConfigurationSettings.AppSettings["MessageFolder"];
                this.commandControl.SetFolder(folder);

                //create transaction factory
                string transactionPoolMaxCount = System.Configuration.ConfigurationManager.AppSettings["TransactionPoolMaxCount"];
                int poolCount = 100;
                int.TryParse(transactionPoolMaxCount, out poolCount);
                factory = TransactionFactory.OpenFactory("Transaction", poolCount);
            }
            catch (Exception ex)
            {

            }
        }

        private void OnClickChannelItem(Object sender, EventArgs arg)
        {
            ToolStripItem item = sender as ToolStripItem;
            item.Enabled = false;
            TabPage tp=new TabPage(item.Text);
            this.tabChannels.TabPages.Add(tp);


            RVManagerConfig config = ReadConfigFile();
            RVConnectInfo rvConnectInfo = null;
            
            try
            {
                rvConnectInfo = System.Configuration.ConfigurationManager.GetSection("RVConnectInfo") as RVConnectInfo;
            }
            catch (Exception ex)
            {

            }

            string formatXML = System.Configuration.ConfigurationManager.AppSettings["FormatXML"];

            RVProxy proxy = null;
            foreach (RVNodeConfig nodeConfig in config.RVAdapterConfigList)
            {
                if (item.Text.Equals(nodeConfig.SystemName))
                {
                    proxy = new RVProxy(nodeConfig);
                    nodeConfig.ConnectionInfo = rvConnectInfo;
                    bool formatFlag = false;
                    if (Boolean.TryParse(formatXML, out formatFlag)) nodeConfig.FormatXML = true;
                    else nodeConfig.FormatXML = false;

                    break;
                }
            }

            if (proxy != null)
            {
                ChannelControl cc = new ChannelControl();
                cc.StatusChangedHandler += new EventHandler(this.OnStatusChanged);

                tp.Controls.Add(cc);
                //cc.Location = new System.Drawing.Point(8, 3);
                cc.Name = "channelControl1";
                //cc.Size = new System.Drawing.Size(416, 309);
                cc.TabIndex = 0;
                cc.Dock = DockStyle.Fill;
                cc.SetProxy(proxy.Config.SystemName, proxy);
            }            
        }

        private RVManagerConfig ReadConfigFile()
        {
            RVManagerConfig config = new RVManagerConfig();
            string filePath = System.Configuration.ConfigurationManager.AppSettings["SimLocation"];
            using (System.IO.StreamReader sr = new System.IO.StreamReader(filePath))
            {
                string message;
                while ((message = sr.ReadLine()) != null)
                {
                    RVNodeConfig nodeConfig = new RVNodeConfig();
                    if (message.StartsWith("SYNC"))
                    {

                        char[] split = { ':' };
                        char[] split2 = { ';' };
                        string[] messageList = message.Split(split);
                        string[] syncMessage = messageList[1].Split(split2);
                        config.ReplyMessageList.AddRange(syncMessage);
                    }
                    else
                    {
                        char[] split = { ';' };
                        char[] split2 = { ',' };
                        string[] messages = message.Split(split);
                        foreach (string s in messages)
                        {
                            string[] pair = s.Split(split2);
                            switch (pair[0])
                            {
                                case "SystemName":
                                    nodeConfig.SystemName = pair[1];
                                    break;
                                case "SystemCategory":
                                    nodeConfig.SystemCategory = pair[1];
                                    break;
                                case "ListenSubject":
                                    nodeConfig.ListenSubject = pair[1];
                                    break;
                                case "TargetSubject":
                                    nodeConfig.TargetSubject = pair[1];
                                    break;
                                case "GroupName":
                                    nodeConfig.GroupName = pair[1];
                                    break;
                                case "Service":
                                    nodeConfig.Service = pair[1];
                                    break;
                                case "Network":
                                    nodeConfig.Network = string.IsNullOrEmpty(pair[1]) ? null : string.Format(";{0}", pair[1]);
                                    break;
                                case "Daemon":
                                    nodeConfig.Daemon = pair[1];
                                    break;
                                case "Target_Daemon":
                                    nodeConfig.TargetDaemon = pair[1];
                                    break;
                                case "Target_Network":
                                    nodeConfig.TargetNetwork = string.IsNullOrEmpty(pair[1]) ? null : string.Format(";{0}", pair[1]);
                                    break;
                                case "Target_Service":
                                    nodeConfig.TargetService = pair[1];
                                    break;
                            }
                        }

                        config.RVAdapterConfigList.Add(nodeConfig);
                    }
                }
            }
            return config;
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void OnStatusChanged(object sender, EventArgs e)
        {
            StatusChangedtEventArgs args = e as StatusChangedtEventArgs;
            this.toolStripStatusLabel.Text = args.Status;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EIS.XML.Parser;
using EIS.XML.Parser.Adapter;
using EIS.XML.Parser.Structure;
using AMAT.RVAdapter.TransactionPool;
using AMAT.RVAdapter.RVComponentAdapter;

namespace IntegrationGUI
{
    public class ReceivedMessageHandle
    {
        private TransactionFactory factory = TransactionFactory.GetFactory();

        public string HandleReceiveMessage(string serviceName,RVProxy proxy,string requestXml, string replyTarget, string replyTargetSubject,out int retCode,out string retMessage)
        {
            retCode = 0 ;
            retMessage="";
            string replyMessage = "";
            if (XmlSpecType.RandomQuery.ToString().Equals(serviceName))
            {
                replyMessage = TestRandomQuery(requestXml, proxy, replyTarget, replyTargetSubject, out retCode, out retMessage);
            }
            else if (XmlSpecType.AlarmReportEvent.ToString().Equals(serviceName))
            {
                replyMessage = TestSendAlarm(requestXml, proxy, replyTarget, replyTargetSubject, out retCode, out retMessage);
            }
            else if (XmlSpecType.QueryLotInfo.ToString().Equals(serviceName))
            {
                replyMessage = TestQueryLotInfo(requestXml, proxy, replyTarget, replyTargetSubject, out retCode, out retMessage);
            }
            else if (XmlSpecType.BSReqHoldLot.ToString().Equals(serviceName))
            {
                replyMessage = TestBSReqHoldLot(requestXml, proxy, replyTarget, replyTargetSubject, out retCode, out retMessage);
            }
            else if (XmlSpecType.R2RReqHoldLot.ToString().Equals(serviceName))
            {
                replyMessage = TestBSReqHoldLot(requestXml, proxy, replyTarget, replyTargetSubject, out retCode, out retMessage);
            }
            else if (XmlSpecType.R2RReqLISResult.ToString().Equals(serviceName))
            {
                replyMessage = TestR2RReqLISResult(requestXml, proxy, replyTarget, replyTargetSubject, out retCode, out retMessage);
            }

            else
            {
                retCode = -1;
                retMessage = serviceName + "  not supported";

                replyMessage = retMessage;
            }
            return replyMessage;
        }
        //Test Method: xxx
        public string TestSendAlarm(string requestXml, RVProxy proxy, string replyTarget, string replyTargetSubject ,out int retCode,out string retMessage)
        {
            EIS.XML.Parser.Adapter.AlarmReportEventR.msgType r = EIS.XML.Parser.Adapter.AlarmReportEventR.msgType.Deserialize(requestXml);

            r.msgBody.AlarmHeader = new EIS.XML.Parser.Adapter.AlarmReportEventR.AlarmHeaderType();
            r.msgBody.AlarmBody = new EIS.XML.Parser.Adapter.AlarmReportEventR.AlarmBodyType();
            r.msgBody.AlarmBody.ReturnStatus = "OK";
            r.msgBody.AlarmBody.Comments = "";
            r.msgBody.AlarmReturn = new EIS.XML.Parser.Adapter.AlarmReportEventR.AlarmReturnType();
            r.msgBody.AlarmReturn.ReturnCode = "0";
            r.msgBody.AlarmReturn.ReturnMessage = "";

            string replyXml = r.SerializeXmlSpec(true, r);
            retCode = 0;
            retMessage = "";
            if (!string.IsNullOrEmpty(replyTargetSubject))
            {
                string[] replyes = replyTargetSubject.Split(',');
                foreach (string reply in replyes)
                {
                    if (!string.IsNullOrEmpty(reply) && !string.IsNullOrEmpty(reply.Trim()))
                        proxy.SendPrivateMessage(replyXml, reply.Trim(), out retCode, out retMessage);
                }
            } 

            return replyXml;
        }

        //Test Methos: xxx
        public string TestRandomQuery(string requestXml, RVProxy proxy, string replyTarget, string replyTargetSubject, out int retCode, out string retMessage)
        {
            EIS.XML.Parser.Adapter.RandomQueryR.msgType r = EIS.XML.Parser.Adapter.RandomQueryR.msgType.Deserialize(requestXml);

            foreach (EIS.XML.Parser.Adapter.RandomQueryR.vidInfoType vid in r.msgBody.vidInfo)
            {
                vid.value = (new System.Random(10).NextDouble()) + "";
            }
            r.msgBody.retCode = "0";
            r.msgBody.retMessage = "";
            
            string replyXml = r.SerializeXmlSpec(true, r);
            
            retCode = 0;
            retMessage = "";
            if (!string.IsNullOrEmpty(replyTargetSubject))
            {
                string[] replyes = replyTargetSubject.Split(',');
                foreach (string reply in replyes)
                {
                    if(!string.IsNullOrEmpty(reply) && !string.IsNullOrEmpty(reply.Trim()))
                        proxy.SendPrivateMessage(replyXml, reply.Trim(), out retCode, out retMessage);
                }
            } 
            return replyXml;
        }

        //TestQueryLotInfo
        public string TestQueryLotInfo(string requestXml, RVProxy proxy, string replyTarget, string replyTargetSubject, out int retCode, out string retMessage)
        {
            EIS.XML.Parser.Adapter.QueryLotInfo.msgType request=EIS.XML.Parser.Adapter.QueryLotInfo.msgType.Deserialize(requestXml);
            EIS.XML.Parser.Adapter.QueryLotInfoR.msgType r = EIS.XML.Parser.Adapter.QueryLotInfoR.msgType.Deserialize(requestXml);

            string lotId=request.msgBody.lotId;
            string fabName=request.msgBody.fabName;

            r.msgBody.retCode = "0";
            r.msgBody.retMessage = "";

            r.msgBody.lot = new EIS.XML.Parser.Adapter.QueryLotInfoR.lotType();
            r.msgBody.lot.lotId = lotId;
            r.msgBody.lot.fabName = fabName;
            r.msgBody.lot.layerName = "Layer01";
            r.msgBody.lot.lotQty = "23";
            r.msgBody.lot.processingStatus = "WAIT";
            r.msgBody.lot.lotType1 = "ENG";
            r.msgBody.lot.motherLot = "";
            r.msgBody.lot.rootLotId = "";
            r.msgBody.lot.pilotFlag = "N";
            r.msgBody.lot.runcardFlag = "N";
            r.msgBody.lot.stage = "Stage01";
            r.msgBody.lot.stepName = "StepName01";
            r.msgBody.lot.stepSequence = "100200";
            r.msgBody.lot.subPlanId = "subPlanId01";
            r.msgBody.lot.technology = "Technology01";
            r.msgBody.lot.planId = "Plan01";
            r.msgBody.lot.runcardFlag = "Y";
            r.msgBody.lot.runcardId = "run-001";
            r.msgBody.lot.splitId = "run-001-0001";
            
            r.msgBody.lot.wafer = new List<EIS.XML.Parser.Adapter.QueryLotInfoR.waferType>();

            EIS.XML.Parser.Adapter.QueryLotInfoR.waferType w1 = new EIS.XML.Parser.Adapter.QueryLotInfoR.waferType();
            w1.waferId = lotId + "#01";
            w1.slotId = "01";
            w1.waferScribe = "111#111";
            r.msgBody.lot.wafer.Add(w1);


            EIS.XML.Parser.Adapter.QueryLotInfoR.waferType w2 = new EIS.XML.Parser.Adapter.QueryLotInfoR.waferType();
            w2.waferId = lotId + "#02";
            w2.slotId = "02";
            w2.waferScribe = "222#222";
            r.msgBody.lot.wafer.Add(w2);

            EIS.XML.Parser.Adapter.QueryLotInfoR.waferType w3 = new EIS.XML.Parser.Adapter.QueryLotInfoR.waferType();
            w3.waferId = lotId + "#25";
            w3.slotId = "25";
            w3.waferScribe = "333#333";
            r.msgBody.lot.wafer.Add(w3);

            string replyXml = r.SerializeXmlSpec(true, r);
            retCode = 0;
            retMessage = "";
            if (!string.IsNullOrEmpty(replyTargetSubject))
            {
                string[] replyes = replyTargetSubject.Split(',');
                foreach (string reply in replyes)
                {
                    if (!string.IsNullOrEmpty(reply) && !string.IsNullOrEmpty(reply.Trim()))
                        proxy.SendPrivateMessage(replyXml, reply.Trim(), out retCode, out retMessage);
                }
            }  

            return replyXml;
        }

        public string TestBSReqHoldLot(string requestXml, RVProxy proxy, string replyTarget, string replyTargetSubject, out int retCode, out string retMessage)
        {
            EIS.XML.Parser.Adapter.BSReqHoldLot.msgType request = EIS.XML.Parser.Adapter.BSReqHoldLot.msgType.Deserialize(requestXml);
            EIS.XML.Parser.Adapter.BSReqHoldLotR.msgType reply = EIS.XML.Parser.Adapter.BSReqHoldLotR.msgType.Deserialize(requestXml);

            reply.msgBody.result = "0";
            reply.msgBody.errorDesc = "NA";
            reply.msgBody.lotListNo = request.msgBody.lotListNo;
            reply.msgBody.lotList = new List<EIS.XML.Parser.Adapter.BSReqHoldLotR.lotListType>();
            EIS.XML.Parser.Adapter.BSReqHoldLotR.lotListType lot = new EIS.XML.Parser.Adapter.BSReqHoldLotR.lotListType();
            lot.lotId = request.msgBody.lotList[0].lotId;
            lot.errorDesc = "XXXERR";
            lot.result = "-1";
            reply.msgBody.lotList.Add(lot);

            string replyXml = reply.SerializeXmlSpec(true, reply);
            retCode = 0;
            retMessage = "";
            if (!string.IsNullOrEmpty(replyTargetSubject))
            {
                string[] replyes = replyTargetSubject.Split(',');
                foreach (string replyAdd in replyes)
                {
                    if (!string.IsNullOrEmpty(replyAdd) && !string.IsNullOrEmpty(replyAdd.Trim()))
                        proxy.SendPrivateMessage(replyXml, replyAdd.Trim(), out retCode, out retMessage);
                }
            }

            return replyXml;
        }

        public string TestR2RReqLISResult(string requestXml, RVProxy proxy, string replyTarget, string replyTargetSubject, out int retCode, out string retMessage)
        {
            EIS.XML.Parser.Adapter.R2RReqLISResult.msgType request = EIS.XML.Parser.Adapter.R2RReqLISResult.msgType.Deserialize(requestXml);
            EIS.XML.Parser.Adapter.R2RReqLISResultR.msgType reply = EIS.XML.Parser.Adapter.R2RReqLISResultR.msgType.Deserialize(requestXml);

            reply.msgBody.retCode = "0";
            reply.msgBody.retMessage = "NA";
            reply.msgBody.lotId=request.msgBody.lotId;

            string replyXml = reply.SerializeXmlSpec(true, reply);
            retCode = 0;
            retMessage = "NA";
            if (!string.IsNullOrEmpty(replyTargetSubject))
            {
                string[] replyes = replyTargetSubject.Split(',');
                foreach (string replyAdd in replyes)
                {
                    if (!string.IsNullOrEmpty(replyAdd) && !string.IsNullOrEmpty(replyAdd.Trim()))
                        proxy.SendPrivateMessage(replyXml, replyAdd.Trim(), out retCode, out retMessage);
                }
            }
            
            return replyXml;
        }

        public string TestR2RReqHoldLot(string requestXml, RVProxy proxy, string replyTarget, string replyTargetSubject, out int retCode, out string retMessage)
        {
            EIS.XML.Parser.Adapter.R2RReqHoldLot.msgType request = EIS.XML.Parser.Adapter.R2RReqHoldLot.msgType.Deserialize(requestXml);
            EIS.XML.Parser.Adapter.R2RReqHoldLotR.msgType reply = EIS.XML.Parser.Adapter.R2RReqHoldLotR.msgType.Deserialize(requestXml);

            reply.msgBody.eqpId = request.msgBody.eqpId;
            reply.msgBody.userId = request.msgBody.userId;
            reply.msgBody.lotListNo = request.msgBody.lotListNo;
            reply.msgBody.lotList = new List<EIS.XML.Parser.Adapter.R2RReqHoldLotR.lotListType>();
            EIS.XML.Parser.Adapter.R2RReqHoldLotR.lotListType lot = new EIS.XML.Parser.Adapter.R2RReqHoldLotR.lotListType();
            lot.lotId = request.msgBody.lotList[0].lotId;
            lot.result = "-1";
            lot.errorDesc = "XXXERR";
            reply.msgBody.lotList.Add(lot);

            string replyXml = reply.SerializeXmlSpec(true, reply);
            retCode = 0;
            retMessage = "";
            if (!string.IsNullOrEmpty(replyTargetSubject))
            {
                string[] replyes = replyTargetSubject.Split(',');
                foreach (string replyAdd in replyes)
                {
                    if (!string.IsNullOrEmpty(replyAdd) && !string.IsNullOrEmpty(replyAdd.Trim()))
                        proxy.SendPrivateMessage(replyXml, replyAdd.Trim(), out retCode, out retMessage);
                }
            }

            return replyXml;
        }

    }
}

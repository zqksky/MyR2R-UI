﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SimpleEventBroker;

namespace IntegrationGUI
{

    public class SendFilesRequestEvent : EventBase
    {
    }

    public class SendFileRequestEvent : EventBase
    {
    }

    public class SendMessageRequestEvent : EventBase
    {
    }

    public class DisplayMessageEvent : EventBase
    {
    }

    public class Events
    {
    }

    public class SendFilesRequestEventArgs : EventArgs
    {
        private string[] fileNames;
        private string sourceApplication;
        private bool autoTxId;
        private int timeout;

        public bool AutoTxId
        {
            get { return autoTxId; }
            set { autoTxId = value; }
        }

        public int Timeout
        {
            get { return timeout; }
            set { timeout = value; }
        }

        public string SourceApplication
        {
            get { return sourceApplication; }
        }


        public SendFilesRequestEventArgs(string sourceApplication, string[] fileNames,bool autoTxId,int timeout)
        {
            this.sourceApplication = sourceApplication;
            this.fileNames = fileNames;
            this.autoTxId = autoTxId;
            this.timeout = timeout;
        }

        public string[] FileNames
        {
            get { return this.fileNames; }
        }
    }

    public class SendFileRequestEventArgs : EventArgs
    {
        private string fileName;
        private string sourceApplication;
        private bool autoTxId;
        private int timeout;

        public bool AutoTxId
        {
            get { return autoTxId; }
            set { autoTxId = value; }
        }

        public int Timeout
        {
            get { return timeout; }
            set { timeout = value; }
        }
        public string SourceApplication
        {
            get { return sourceApplication; }
        }

        public SendFileRequestEventArgs(string sourceApplication, string fileName, bool autoTxId, int timeout)
        {
            this.sourceApplication = sourceApplication;
            this.fileName = fileName;
            this.autoTxId = autoTxId;
            this.timeout = timeout;
        }

        public string FileName
        {
            get { return this.fileName; }
        }
    }

    public class SendMessageRequestEventArgs : EventArgs
    {
        private string message;
        private bool autoTxId;
        private int timeout;

        public bool AutoTxId
        {
            get { return autoTxId; }
            set { autoTxId = value; }
        }

        public int Timeout
        {
            get { return timeout; }
            set { timeout = value; }
        }

        public SendMessageRequestEventArgs(string sourceApplication, string message, bool autoTxId, int timeout)
        {
            this.sourceApplication = sourceApplication;
            this.message = message;
            this.autoTxId = autoTxId;
            this.timeout = timeout;
        }

        private string sourceApplication;

        public string SourceApplication
        {
            get { return sourceApplication; }
        }

        public string Message
        {
            get { return this.message; }
        }
    }

    public class StatusChangedtEventArgs : EventArgs
    {
        private string status;

        public StatusChangedtEventArgs(string status)
        {
            this.status = status;
        }

        public string Status
        {
            get { return this.status; }
        }
    }

    public class DisplayMessageEventArgs : EventArgs
    {
        private string transContent;
        private string[] xmlContent;
        private string file;

        public DisplayMessageEventArgs(string transContent, string[] xmlContent, string file)
        {
            this.transContent = transContent;
            this.xmlContent = xmlContent;
            this.file = file;
        }

        public string TransContent
        {
            get { return this.transContent; }
        }

        public string[] XmlContent
        {
            get { return this.xmlContent; }
        }

        public string File
        {
            get { return this.file; }
        }
    }

}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AMAT.RVAdapter.CommonData;

namespace IntegrationGUI
{
    public class ChannelTransItem
    {
        private string direction;
        private string sourceApplication;
        private string sourceAddress;
        private string destinationApplication;
        private string destinationAddress;
        private IList<AddressInfo> replyAddress;

        private string serviceName;
        private int timeout;
        private DateTime requestTime;
        private DateTime replyTime;
        //private double timespan;
        private string txId;
        private string err;
        private string requestContent;
        private string replyContent;
        private string status;


        public ChannelTransItem(string txId, string source, string sourceAddress,string destination,string destinationAddress,IList<AddressInfo> replyAddress,string service,int timeout,DateTime requestTime)
        {
            this.txId = txId;
            this.sourceApplication = source;
            this.sourceAddress=sourceAddress;
            this.destinationApplication = destination;
            this.destinationAddress = destinationAddress;
            this.replyAddress = replyAddress;
            this.serviceName = service;
            this.timeout = timeout;
            this.requestTime = requestTime;
            this.replyTime = requestTime;

            this.status = "";
        }

        public string Direction
        {
            get {

                if (this.replyAddress == null || this.replyAddress.Count()==0)
                {
                    this.direction = string.Format("{0}->{1}", this.sourceApplication, this.destinationApplication);
                }
                else
                {
                    this.direction = string.Format("{0}<->{1}", this.sourceApplication, this.destinationApplication);
                }
                return this.direction;
            }
        }

        public string SourceApplication
        {
            get { return sourceApplication; }
            set { sourceApplication = value; }
        }

        public string SourceAddress
        {
            get { return this.sourceAddress; }
            set { this.sourceAddress = value;}
        }

        public string DestinationApplication
        {
            get { return destinationApplication; }
            set { destinationApplication = value; }
        }

        public string DestinationAddress
        {
            get { return this.destinationAddress; }
            set { this.destinationAddress = value; }
        }


        public IList<AddressInfo> ReplyAddress
        {
            get { return replyAddress; }
            set { replyAddress = value; }
        }

        public string ServiceName
        {
            get { return serviceName; }
            set { serviceName = value; }
        }

        public int Timeout
        {
            get { return timeout; }
            set { timeout = value; }
        }

        public DateTime RequestTime
        {
            get { return requestTime; }
            set { requestTime = value; }
        }

        public DateTime ReplyTime
        {
            get { return replyTime; }
            set { replyTime = value; }
        }

        public double Timespan
        {
            get {
                return (this.replyTime.Equals(this.requestTime)) ? (DateTime.Now - this.requestTime).TotalSeconds : (this.replyTime - this.requestTime).TotalSeconds;
                }
        }

        public string TxId
        {
            get { return txId; }
            set { txId = value; }
        }

        public string Err
        {
            get { return err; }
            set { err = value; }
        }

        public string Status
        {
            get { return status; }
            set { status = value; }
        }

        public string RequestContent
        {
            get { return this.requestContent; }
            set { this.requestContent = value; }
        }

        public string ReplyContent
        {
            get { return this.replyContent; }
            set { this.replyContent = value; }
        }

        public override string ToString()
        {
            string prefix = string.IsNullOrEmpty(Status) ? Status : Status + "->";
            return string.Format("{0}{1}:{2}",prefix,ServiceName,TxId);
        }

        public string Content()
        {
            string replyTo = "";
            foreach (AddressInfo info in this.replyAddress)
            {
                replyTo += (info.ToString()+",");
            }

            return string.Format("Direction: {0}\r\nSource: {1}\r\nDestination: {2}\r\nReplyTo: {3}\r\nService: {4}\r\nTimeout: {5}\r\nRequestTime: {6}\r\nReplyTime: {7}\r\nTimeSpan: {8}\r\nTxId: {9}",
                this.Direction,
                this.SourceApplication + "," + this.SourceAddress,
                this.DestinationApplication + "," + this.DestinationAddress,
                replyTo,
                this.ServiceName,
                this.Timeout,
                this.RequestTime,
                (this.ReplyTime.Equals(this.RequestTime)) ? "":this.ReplyTime.ToString(),
                (this.ReplyTime.Equals(this.RequestTime)) ? "" : (this.ReplyTime - this.RequestTime).TotalSeconds+"",
                this.TxId);
        }
    }
}

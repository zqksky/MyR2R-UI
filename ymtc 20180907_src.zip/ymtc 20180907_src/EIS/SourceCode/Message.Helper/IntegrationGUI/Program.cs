﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Configuration;
using System.Windows.Forms;
using IntegrationGUI.Control;
using AMAT.RVAdapter.CommonData;

namespace IntegrationGUI
{
    public class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Program prog = new Program();
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new IntegrationForm());

        }

        private CommandMapping cmds = CommandMapping.Instance;
        public Program()
        {

            Application.ApplicationExit += new EventHandler(Application_ApplicationExit);
            //get the cmd mapping
            foreach (EIS.XML.Parser.Adapter.CmdList cmd in Enum.GetValues(typeof(EIS.XML.Parser.Adapter.CmdList)))
            {
                if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings[cmd.ToString()]))
                {
                    cmds.Add(cmd.ToString(), ConfigurationManager.AppSettings[cmd.ToString()]);
                }
            }

            //
        }

        private void Application_ApplicationExit(object sender, EventArgs e)
        {
            try
            {
                if (ChannelControl.tibcoOpened)
                {
                    TIBCO.Rendezvous.Environment.Close();
                    ChannelControl.tibcoOpened = false;
                }
                
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message,"Warn");
            }
            
            Environment.Exit(0);
        }
    }
}

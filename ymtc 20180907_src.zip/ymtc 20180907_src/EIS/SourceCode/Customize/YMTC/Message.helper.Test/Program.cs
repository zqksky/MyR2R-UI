﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EIS.XML.Parser.Structure;
using EIS.XML.Parser;
using EIS.XML.Parser.Adapter;
using System.Xml;
using EIS.XML.Message.Helper;
using AMAT.RVAdapter.CommonData;
namespace Test
{
    class Program
    {
        public void TestCalcPh()
        {
            EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgType calc = EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgType.LoadFromFile(@"./message/test/calcph2.xml");
            string xmlString = calc.SerializeXmlSpec(false, calc);

            IList<string> ovlParameters=new List<string>();
            ovlParameters.Add("EXP_X");
            ovlParameters.Add("EXP_Y");
            ovlParameters.Add("NON_ORT");
            ovlParameters.Add("WFR_ROT");
            ovlParameters.Add("TRANS_X");
            ovlParameters.Add("TRANS_Y");
            ovlParameters.Add("ASYM_MAG");
            ovlParameters.Add("ASYM_ROT");
            ovlParameters.Add("SHT_MAG");
            ovlParameters.Add("SHT_ROT");          

            CalcRecipeSettingsPhR ph = EIS.XML.Message.Helper.XmlSpec4Calc.Xml2CalcRecipeSettingsPhR("", "", xmlString, "Energy", "Focus","CPEMode" ,ovlParameters.ToArray());

            Console.WriteLine(EIS.XML.Parser.StructureUitily.SerializeToXml(true,ph));

            Console.WriteLine("\r\n" + ph.Err);
        }

        public void TestUsedPh()
        {
            EIS.XML.Parser.Adapter.UsedSettings.msgType used = EIS.XML.Parser.Adapter.UsedSettings.msgType.LoadFromFile(@"./message/test/usedph.xml");
            string xmlString = used.SerializeXmlSpec(false, used);

            IList<string> ovlParameters = new List<string>();
            ovlParameters.Add("EXP_X");
            ovlParameters.Add("EXP_Y");
            ovlParameters.Add("NON_ORT");
            ovlParameters.Add("WFR_ROT");
            ovlParameters.Add("TRANS_X");
            ovlParameters.Add("TRANS_Y");
            ovlParameters.Add("ASYM_MAG");
            ovlParameters.Add("ASYM_ROT");
            ovlParameters.Add("SHT_MAG");
            ovlParameters.Add("SHT_ROT");
            ovlParameters.Add("Tx20");
            ovlParameters.Add("Tx02");
            ovlParameters.Add("Tx11");
            ovlParameters.Add("Tx21");
            ovlParameters.Add("Tx12");
            ovlParameters.Add("Tx30");
            ovlParameters.Add("Tx03");
            ovlParameters.Add("Ty20");
            ovlParameters.Add("Ty02");
            ovlParameters.Add("Ty11");
            ovlParameters.Add("Ty21");
            ovlParameters.Add("Ty12");
            ovlParameters.Add("Ty30");
            ovlParameters.Add("Ty03");
            ovlParameters.Add("K7");
            ovlParameters.Add("K8");
            ovlParameters.Add("K9");
            ovlParameters.Add("K10");
            ovlParameters.Add("K11");
            ovlParameters.Add("K12");
            ovlParameters.Add("K13");
            ovlParameters.Add("K14");
            ovlParameters.Add("K15");
            ovlParameters.Add("K16");
            ovlParameters.Add("K17");
            ovlParameters.Add("K18");
            ovlParameters.Add("K19");
            ovlParameters.Add("K20");    
            UsedSettingsPh ph = EIS.XML.Message.Helper.XmlSpec4Used.Xml2UsedSettingsPh("", "", xmlString, "Energy", "Focus", "CPEModeName",ovlParameters.ToArray());

            Console.WriteLine(EIS.XML.Parser.StructureUitily.SerializeToXml(true, ph));

            Console.WriteLine("\r\n" + ph.Err);
        }

        public void TestMetCd()
        {
            EIS.XML.Parser.Adapter.Metrology.msgType met = EIS.XML.Parser.Adapter.Metrology.msgType.LoadFromFile(@"./message/test/metcd.xml");
            string xmlString = met.SerializeXmlSpec(false, met);

            IList<string> originalParameters = new List<string>();
            originalParameters.Add("CDP1x");
            originalParameters.Add("CDP2x");

            IList<string> mappingParameters = new List<string>();
            mappingParameters.Add("P1");
            mappingParameters.Add("P2");

            Metrology cd = EIS.XML.Message.Helper.XmlSpec4lMetrology.Xml2Metrology(xmlString, originalParameters.ToArray(), mappingParameters.ToArray());

            Console.WriteLine(EIS.XML.Parser.StructureUitily.SerializeToXml(true,cd));

            Console.WriteLine("\r\n" + cd.Err);

        }

        public void TestMetCd2()
        {
            EIS.XML.Parser.Adapter.Metrology.msgType met = EIS.XML.Parser.Adapter.Metrology.msgType.LoadFromFile(@"./message/test/metcd.xml");
            string xmlString = met.SerializeXmlSpec(false, met);

            IList<string> originalParameters = new List<string>();
            originalParameters.Add("CDP1x");
            originalParameters.Add("CDP2x");
            originalParameters.Add("CDP3");

            IList<string> mappingParameters = new List<string>();
            mappingParameters.Add("P1");
            mappingParameters.Add("P2");
            mappingParameters.Add("P3");

            Metrology cd = EIS.XML.Message.Helper.XmlSpec4lMetrology.Xml2Metrology2(xmlString, originalParameters.ToArray(), mappingParameters.ToArray());

            Console.WriteLine(EIS.XML.Parser.StructureUitily.SerializeToXml(true, cd));

            Console.WriteLine("\r\n" + cd.Err);

        }

        public void TestMetConvert()
       {
            EIS.XML.Parser.Adapter.Metrology.msgType met = EIS.XML.Parser.Adapter.Metrology.msgType.LoadFromFile(@"./message/test/metcd.xml");
            string xmlString = met.SerializeXmlSpec(false, met);

            IList<string> mesNames = new List<string>();
            mesNames.Add("CDP1");
            mesNames.Add("CDP2");
            mesNames.Add("CDP3x");

            IList<string> r2rNames = new List<string>();
            r2rNames.Add("CDP1y");
            r2rNames.Add("CDP2y");
            r2rNames.Add("CDP3y");

            IList<string> mappingParameters = new List<string>();

            Metrology cd = EIS.XML.Message.Helper.XmlSpec4lMetrology.Xml2Metrology(xmlString, new string[] { }, new string[] { });


            EIS.XML.Message.Helper.Parameter.ConvertorMetrologyOutput output = EIS.XML.Message.Helper.Parameter.Convertor.ConvertMetrologyToE3Name(cd.Name[0].Split(','), mesNames.ToArray<string>(), r2rNames.ToArray<string>());
            
            Console.WriteLine(EIS.XML.Parser.StructureUitily.SerializeToXml(true, cd));

            Console.WriteLine(EIS.XML.Parser.StructureUitily.SerializeToXml(true, output));

            Console.WriteLine("\r\n" + output.Err);

        }

        public void TestMetOvl()
        {
            EIS.XML.Parser.Adapter.Metrology.msgType met = EIS.XML.Parser.Adapter.Metrology.msgType.LoadFromFile(@"./message/test/metovl.xml");
            string xmlString = met.SerializeXmlSpec(false, met);

            IList<string> originalParameters = new List<string>();
            originalParameters.Add("EXP_X");
            originalParameters.Add("EXP_Y");
            originalParameters.Add("NON_ORT");
            originalParameters.Add("WFR_ROT");
            originalParameters.Add("TRANS_X");
            originalParameters.Add("TRANS_Y");
            originalParameters.Add("ASYM_MAG");
            originalParameters.Add("ASYM_ROT");
            originalParameters.Add("SHT_MAG");
            originalParameters.Add("SHT_ROT");  

            IList<string> mappingParameters = new List<string>();
            mappingParameters.Add("");
            mappingParameters.Add("");
            mappingParameters.Add("");
            mappingParameters.Add("");
            mappingParameters.Add("");
            mappingParameters.Add("");
            mappingParameters.Add("");
            mappingParameters.Add("");

            Metrology ovl = EIS.XML.Message.Helper.XmlSpec4lMetrology.Xml2Metrology(xmlString, originalParameters.ToArray(), mappingParameters.ToArray());

            Console.WriteLine(EIS.XML.Parser.StructureUitily.SerializeToXml(true, ovl));

            Console.WriteLine("\r\n" + ovl.Err);
        }

        public void TestMetThk()
        {
            EIS.XML.Parser.Adapter.Metrology.msgType met = EIS.XML.Parser.Adapter.Metrology.msgType.LoadFromFile(@"./message/test/metthk.xml");
            string xmlString = met.SerializeXmlSpec(false, met);

            IList<string> originalParameters = new List<string>();
            originalParameters.Add("");
            originalParameters.Add("");
            originalParameters.Add("");
            originalParameters.Add("");
            originalParameters.Add("");
            originalParameters.Add("");
            originalParameters.Add("");
            originalParameters.Add("");

            IList<string> mappingParameters = new List<string>();
            mappingParameters.Add("");
            mappingParameters.Add("");
            mappingParameters.Add("");
            mappingParameters.Add("");
            mappingParameters.Add("");
            mappingParameters.Add("");
            mappingParameters.Add("");
            mappingParameters.Add("");

            MetrologyCmpThk thk = EIS.XML.Message.Helper.XmlSpec4lMetrology.Xml2MetrologyCmpThk(xmlString, originalParameters.ToArray(), mappingParameters.ToArray());

            Console.WriteLine(EIS.XML.Parser.StructureUitily.SerializeToXml(true,thk));

            Console.WriteLine("\r\n" + thk.Err);
        }

        public void TestCalcCmp()
        {
            EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgType calc = EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgType.LoadFromFile(@"./message/test/calccmp.xml");
            string xmlString = calc.SerializeXmlSpec(false, calc);

            CalcRecipeSettingsCmpR cmp = EIS.XML.Message.Helper.XmlSpec4Calc.Xml2CalcRecipeSettingsCmpR("", "", xmlString);

            Console.WriteLine(EIS.XML.Parser.StructureUitily.SerializeToXml(true,cmp));

            Console.WriteLine("\r\n" + cmp.Err);
        }

        public void TestUsedCmp()
        {
            
            EIS.XML.Parser.Adapter.UsedSettings.msgType used = EIS.XML.Parser.Adapter.UsedSettings.msgType.LoadFromFile(@"./message/test/usedcmp.xml");
            string xmlString = used.SerializeXmlSpec(false, used);

            UsedSettingsCmp cmp = EIS.XML.Message.Helper.XmlSpec4Used.Xml2UsedSettingsCmp("", "", xmlString);

            Console.WriteLine(EIS.XML.Parser.StructureUitily.SerializeToXml(true,cmp));

            Console.WriteLine("\r\n" + cmp.Err);
        }

        public void TestExpo()
        {
            EIS.XML.Parser.Adapter.SendExposureContextR.msgType expoXml = EIS.XML.Parser.Adapter.SendExposureContextR.msgType.LoadFromFile(@"./message/test/expo.xml");
            string xmlString = expoXml.SerializeXmlSpec(false, expoXml);

            SendExposureContextR expo = EIS.XML.Message.Helper.XmlSpec.Xml2SendExposureContextR("", "", xmlString);

            Console.WriteLine(EIS.XML.Parser.StructureUitily.SerializeToXml(true,expo));

            Console.WriteLine("\r\n" + expo.Err);
        }

        public void TestGetResult4Ph()
        {
            
            string retCode="0";
            string retMsg="OK";
            string lotId="A0001";
            string energyName="Energy";
            string focusName="Foucs";
            string[] Energy;//=new List<string>().Add("r1c1").toArray();
            IList<string> tmp=new List<string>();
            tmp.Clear();
            tmp.Add("e_r1c1");
            Energy=tmp.ToArray();
            string[] Focus;
            tmp.Clear();
            tmp.Add("f_r1c1");
            Focus=tmp.ToArray();
            string[] OVLNAMEs; 
            tmp.Clear();
            tmp.Add("x");
            tmp.Add("y");
            tmp.Add("ori");
            tmp.Add("rot");
            OVLNAMEs=tmp.ToArray();
            string[] OVLValues; 
            tmp.Clear();
            tmp.Add("x11,y11,ori11,rot11;x12,y12,ori12,rot12");
            OVLValues=tmp.ToArray();
            string CPEModeName="CPEModeSubRecipe";
            string CPEModeValue="safkasfd"; 
            string[] Reticles;
            tmp.Clear();
            tmp.Add("reticle1");
            Reticles=tmp.ToArray();
            string[] Chucks;
            tmp.Clear();
            tmp.Add("C1");
            tmp.Add("C2");
            Chucks=tmp.ToArray();
            int DedicationType=3;
            string[] ChuckDedication=new string[]{"C1","C2","C1","C2"};
            string[] waferIds = new string[] {"Lot#01","Lot#02","Lot#03","Lot#04" };
            string[] slotIds = new  string[] { "001", "002", "003", "004" };

            ResultString rs = EIS.XML.Message.Helper.XmlSpec4Calc.GetResultString4CalcPhR(retCode, retMsg, lotId, energyName, focusName, Energy, Focus, OVLNAMEs, OVLValues, CPEModeName, CPEModeValue, Reticles, Chucks,true, DedicationType, ChuckDedication, slotIds,waferIds);
            Console.WriteLine(rs.ResultXmlString);
        }

        public void TestXml2UsedSettingsCmp()
        {
            EIS.XML.Parser.Adapter.UsedSettings.msgType used =EIS.XML.Parser.Adapter.UsedSettings.msgType.LoadFromFile(@"./message/used.xml");
            string xmlString = used.SerializeXmlSpec(false,used);

            UsedSettingsCmp cmp = EIS.XML.Message.Helper.XmlSpec4Used.Xml2UsedSettingsCmp("", "", xmlString);
            
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(EIS.XML.Parser.StructureUitily.SerializeToXml(cmp));
            Console.WriteLine(xmlDoc.InnerXml);

            Console.WriteLine("\r\n"+cmp.Err);
        }

        public void TestXml2UsedSettingPh()
        {
            EIS.XML.Parser.Adapter.UsedSettings.msgType used = EIS.XML.Parser.Adapter.UsedSettings.msgType.LoadFromFile(@"./message/used.xml");
            string xmlString = used.SerializeXmlSpec(false, used);

            UsedSettingsCmp cmp = EIS.XML.Message.Helper.XmlSpec4Used.Xml2UsedSettingsCmp("", "", xmlString);

            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(EIS.XML.Parser.StructureUitily.SerializeToXml(cmp));
            Console.WriteLine(xmlDoc.InnerXml);

            Console.WriteLine("\r\n"+cmp.Err);
        }

        public void GetString4AlarmMessage()
        {
            SortedList<string, string> alarm = new SortedList<string, string>();

            alarm["MessageName"]="MessageName1";
            alarm["FactoryID"] = "FactoryID1";
            alarm["SystemID"] = "SystemID1";
            alarm["ToolGroup"] = "ToolGroup1";
            alarm["ToolID"] = "ToolID1";
            alarm["AlarmCode"] = "AlarmCode1";
            alarm["TransactionTime"] = "TransactionTime1";
            alarm["AlarmSubject"] = "AlarmSubject1";
            alarm["AlarmContent"] = "AlarmContent1";
            alarm["ChamberID"] = "ChamberID1";
            alarm["ProductID"] = "ProductID1";
            alarm["LotID"] = "LotID1";
            alarm["PlanId"] = "PlanId1";
            alarm["AlarmDate"] = "AlarmDate1";
            alarm["AlarmDescription"] = "AlarmDescription1";
            alarm["Priority"] = "Priority1";
            alarm["AlarmLevel"] = "AlarmLevel1";
            alarm["TimeInterval"] = "TimeInterval1";
            alarm["ErrorCode"] = "ErrorCode1";

            string alarmStr=EIS.XML.Message.Helper.XmlSpec.GetString4AlarmMessage(alarm.Keys.ToArray(),alarm.Values.ToArray()).ResultXmlString;

            Console.WriteLine(alarmStr);
        }

        public void TestGetExpoResult1()
        {
            SortedList<string, string> expoStr = new SortedList<string, string>();

            expoStr["EXP_StepSequence"] = "EXP_StepSequence";
            expoStr["EXP_Product"] = "EXP_Product";
            expoStr["Exp_Reticle"] = "Exp_Reticle";
            expoStr["Exp_PreTool"] = "Exp_PreTool";
            expoStr["Exp_PreReticle"] = "Exp_PreReticle";
            expoStr["Exp_RecipeName"] = "Exp_RecipeName";
            expoStr["Exp_TimeStamp"] = "Exp_TimeStamp";
            expoStr["Exp_Chuck1_WaferList"] = "Exp_Chuck1_WaferList";
            expoStr["Exp_Chuck2_WaferList"] = "Exp_Chuck2_WaferList";
            expoStr["Exp_Chuck1_SlotIdList"] = "Exp_Chuck1_SlotIdList";
            expoStr["Exp_Chuck2_SlotIdList"] = "Exp_Chuck2_SlotIdList";


            SortedList<string, string> add = new SortedList<string, string>();

            add["OVL_X"] = "0.00023";
            add["OVL_Y"] = "0.003984";



            string resStr = EIS.XML.Message.Helper.XmlSpec.GetResultString4ExposureContexR("0", "OK", expoStr.Keys.ToArray(), expoStr.Values.ToArray(), add.Keys.ToArray(), add.Values.ToArray()).ResultXmlString;

            Console.WriteLine(resStr);
        }

        public void TestGetExpoResult()
        {
            SortedList<string, string> expoStr = new SortedList<string, string>();

            expoStr["EXP_StepSequence"] = "EXP_StepSequence";
            expoStr["EXP_Product"] = "EXP_Product";
            expoStr["Exp_Reticle"] = "Exp_Reticle";
            expoStr["Exp_PreTool"] = "Exp_PreTool";
            expoStr["Exp_PreReticle"] = "Exp_PreReticle";
            expoStr["Exp_RecipeName"] = "Exp_RecipeName";
            expoStr["Exp_TimeStamp"] = "Exp_TimeStamp";
            expoStr["Exp_Chuck1_WaferList"] = "Exp_Chuck1_WaferList";
            expoStr["Exp_Chuck2_WaferList"] = "Exp_Chuck2_WaferList";
            expoStr["Exp_Chuck1_SlotIdList"] = "Exp_Chuck1_SlotIdList";
            expoStr["Exp_Chuck2_SlotIdList"] = "Exp_Chuck2_SlotIdList";
             

            SortedList<string, string> add = new SortedList<string, string>();

            add["OVL_X"] = "0.00023";
            add["OVL_Y"] = "0.003984";
             


            string resStr = EIS.XML.Message.Helper.XmlSpec.GetResultString4ExposureContexR("0","OK",expoStr.Keys.ToArray(),expoStr.Values.ToArray(),add.Keys.ToArray(),add.Values.ToArray()).ResultXmlString;

            Console.WriteLine(resStr);
        }
        
        static void Main(string[] args)
        {
            string t = "CCCCC_C1_xxx";
            string y = "";

            y = t.IndexOf("_")>=0? t.Substring(0,t.IndexOf("_")):t;

            t = "_Ccccc1";
            y = t.IndexOf("_") >= 0 ? t.Substring(0, t.IndexOf("_")) : t;

            t = "CCCCC1";
            y = t.IndexOf("_") >= 0 ? t.Substring(0, t.IndexOf("_")) : t;

            CommandMapping cmds = CommandMapping.Instance;
            foreach (EIS.XML.Parser.Adapter.CmdList cmdx in Enum.GetValues(typeof(EIS.XML.Parser.Adapter.CmdList)))
            {
                if (!string.IsNullOrEmpty(System.Configuration.ConfigurationSettings.AppSettings[cmdx.ToString()]))
                {
                    cmds.Add(cmdx.ToString(), System.Configuration.ConfigurationSettings.AppSettings[cmdx.ToString()]);
                }
                Console.WriteLine(string.Format("Loaded Command Mapping ,Cmd:{0}  Value:{1}", cmdx.ToString(), cmds.FindValue(cmdx.ToString(), cmdx.ToString())));
            }   

            Program prog = new Program();
            //test SplitArray
            /// int: [x11,y11,ori11,rot11;x12,y12,ori12,rot12] reticle 1 , c1;c2
            ///      [x21,y21,ori21,rot21;x22,y22,ori22,rot22] reticle 2 , c1;c2
            ///out:   [x11;x12]   [y11;y12]   [ori11;ori12] [rot11;rot12]
            ///       [x21;x22]   [y21;y22]   [ori21;ori22] [rot21;rot22]

            IList<string> x = new List<string>();
            x.Add("x11,y11,ori11,rot11;x12,y12,ori12,rot12");
            Console.WriteLine("x11,y11,ori11,rot11;x12,y12,ori12,rot12");
            x.Add("x21,y21,ori21,rot21;x22,y22,ori22,rot22");
            Console.WriteLine("x21,y21,ori21,rot21;x22,y22,ori22,rot22");
            string err1;
            IList<string[]> res =new List<string[]>();
            res= EIS.XML.Parser.StructureUitily.SplitArray(x.ToArray(), out err1);
            //test BuildStringFromArray
            Console.WriteLine("------------------");
            foreach (string[] r in res)
            {
                foreach (string s in r)
                {
                    Console.WriteLine(s);
                }
                Console.WriteLine("1-1->"+EIS.XML.Parser.StructureUitily.BuildStringFromArray(r, 1, ";".ToArray(), 1, "@".ToArray(), out err1));
                Console.WriteLine("1-2->" + EIS.XML.Parser.StructureUitily.BuildStringFromArray(r, 1, ";".ToArray(), 2, "@".ToArray(), out err1));
                Console.WriteLine("1-3->" + EIS.XML.Parser.StructureUitily.BuildStringFromArray(r, 1, ";".ToArray(), 3, "@".ToArray(), out err1));
                Console.WriteLine("3-1->" + EIS.XML.Parser.StructureUitily.BuildStringFromArray(r, 3, ";".ToArray(), 1, "@".ToArray(), out err1));
                Console.WriteLine("3-2->" + EIS.XML.Parser.StructureUitily.BuildStringFromArray(r, 3, ";".ToArray(), 2, "@".ToArray(), out err1));
                Console.WriteLine("3-3->" + EIS.XML.Parser.StructureUitily.BuildStringFromArray(r, 3, ";".ToArray(), 3, "@".ToArray(), out err1));
                Console.WriteLine("2-2->" + EIS.XML.Parser.StructureUitily.BuildStringFromArray(r, 2, ";".ToArray(), 2, "@".ToArray(), out err1));
                Console.WriteLine("1-2->" + EIS.XML.Parser.StructureUitily.BuildStringFromArray(r, 1, ";".ToArray(), 2, "@".ToArray(), out err1));
                Console.WriteLine("0-2->" + EIS.XML.Parser.StructureUitily.BuildStringFromArray(r, 0, ";".ToArray(), 2, "@".ToArray(), out err1));
                
                Console.WriteLine("////////////////////////");
            }

            string err="";
            string[] result1 = EIS.XML.Parser.StructureUitily.BuildArrayFromString("1.11;1.12", 2,";".ToCharArray(), 2, ",".ToCharArray(),out err);
            string[] result2 = EIS.XML.Parser.StructureUitily.BuildArrayFromString("2.21;2.22", 2, ";".ToCharArray(), 2, ",".ToCharArray(), out err);
            string[] result3 = EIS.XML.Parser.StructureUitily.BuildArrayFromString("3.31;3.32", 2, ";".ToCharArray(), 2, ",".ToCharArray(), out err);
            IList<string[]> temp = new List<string[]>();
            temp.Add(result1);
            temp.Add(result2);
            temp.Add(result3);
            string[] rr = EIS.XML.Parser.StructureUitily.MergeArray(temp, out err);

            Console.WriteLine(">TestGetResult4Ph,TestCalcPh,TestUsedPh,TestMetCd,TestMetOvl,TestMetThk,TestCalcCmp,TestUsedCmp,TestExpo");
            Console.Write(">");
            string cmd = Console.ReadLine();
            while (!string.IsNullOrEmpty(cmd))
            {
                Type type = Type.GetType("Test.Program");
                System.Reflection.MethodInfo mi=null;
                
                if (cmd.Equals("used cmp"))
                {
                    prog.TestXml2UsedSettingsCmp();
                    Console.WriteLine("");
                }
                else if (cmd.Equals("used ph"))
                {
                }
                else if (cmd.Equals("calc ph"))
                {
                }
                else if (cmd.Equals("calc cmp"))
                {
                }
                else if (cmd.Equals("met"))
                {
                }
                else if (cmd.Equals("exposure"))
                {
                }
                else if (cmd.Equals("queryLot"))
                {
                }
                else if (cmd.Equals("?"))
                {
                    Console.WriteLine(">TestGetResult4Ph,TestCalcPh,TestUsedPh,TestMetCd,TestMetOvl,TestMetThk,TestCalcCmp,TestUsedCmp,TestExpo");
                }
                else if (cmd.Equals("alarm"))
                {
                    prog.GetString4AlarmMessage();
                    Console.WriteLine("");
                }
                else {
                    try
                    {
                        mi = type.GetMethod(cmd);
                        if (mi == null) throw new Exception(cmd +" not found.");

                        mi.Invoke(prog, null);

                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }

                Console.Write("\r\n>");

                cmd = Console.ReadLine();
            } 
        
        
        }
    }
}

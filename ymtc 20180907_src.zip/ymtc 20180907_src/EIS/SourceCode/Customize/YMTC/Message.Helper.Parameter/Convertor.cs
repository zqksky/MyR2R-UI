﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EIS.XML.Message.Helper.Parameter
{
    public class Convertor
    {
        /*
        public static ConvertorOutput ConvertMetrologyToE3NameValuexx(string[] MES_VARIABLE_NAMES, string[] MES_VARIABLE_VALUES, string[] R2R_VAR_NAMES, string[] CHAMBERS, string[] RETICLES, string[] STEPS)
        {
            ConvertorOutput output = new ConvertorOutput();
            IList<string> out_r2rVarNames = new List<string>();
            IList<string> out_chambers = new List<string>();
            IList<string> out_reticles = new List<string>();
            IList<string> out_steps = new List<string>();
            string err = "OK";


            try
            {
                if (R2R_VAR_NAMES == null || CHAMBERS == null || RETICLES == null || STEPS == null)
                {
                    throw new Exception("Some Input R2R mapping is null ");
                }
                if (MES_VARIABLE_NAMES == null || MES_VARIABLE_VALUES == null)
                {
                    throw new Exception("Some Input MES mapping is null ");
                }







            }
            catch (Exception ex)
            {
                err = ex.Message;
            }

            output.OUT_VAR_NAMES = out_r2rVarNames.ToArray<string>();
            output.OUT_CHAMBERS = out_chambers.ToArray<string>();
            output.OUT_RETICLES = out_reticles.ToArray<string>();
            output.OUT_STEPS = out_steps.ToArray<string>();
            output.Err = err;

            return output;
        }
        */

        public static ConvertorMetrologyOutput ConvertMetrologyToE3Name(string IN_VARIABLE_NAMES_STR, string[] MES_VARIABLE_NAMES, string[] R2R_VARIABLE_NAMES)
        {
            if (string.IsNullOrEmpty(IN_VARIABLE_NAMES_STR))
            {
                ConvertorMetrologyOutput output = new ConvertorMetrologyOutput();
                output.Err = "IN_VARIABLE_NAMES_STR is null or Empty. ";
                output.MES_VAR_NAMES = new string[] { };
                output.R2R_VAR_NAMES = new string[] { };
                return output;
            }
            else
            {
                return Convertor.ConvertMetrologyToE3Name(IN_VARIABLE_NAMES_STR.Split(','), MES_VARIABLE_NAMES, R2R_VARIABLE_NAMES);
            }
        }

        public static ConvertorMetrologyOutput ConvertMetrologyToE3Name(string[] IN_VARIABLE_NAMES, string[] MES_VARIABLE_NAMES, string[] R2R_VARIABLE_NAMES)
        {
            ConvertorMetrologyOutput output = new ConvertorMetrologyOutput();
            IList<string> out_r2rVarNames=new List<string>();
            IList<string> out_VarValues = new List<string>();
            IList<string> out_chambers=new List<string>();
            IList<string> out_reticles=new List<string>();
            IList<string> out_steps=new List<string>();
            string err = "OK";

            SortedDictionary<string, string> mapping = new SortedDictionary<string, string>();
            for (int i = 0; i < MES_VARIABLE_NAMES.Length; i++)
            {
                if (!mapping.ContainsKey(MES_VARIABLE_NAMES[i])) mapping[MES_VARIABLE_NAMES[i]] = R2R_VARIABLE_NAMES[i];
            } 

            try
            {
                if (R2R_VARIABLE_NAMES == null || MES_VARIABLE_NAMES == null || R2R_VARIABLE_NAMES.Length == 0 || MES_VARIABLE_NAMES.Length==0)
                {
                    throw new Exception("Some Input mapping is null or Empty");
                }
                if (IN_VARIABLE_NAMES == null )
                {
                    throw new Exception("Input VARIABLE is null or Empty");
                }

                int k = IN_VARIABLE_NAMES.Length;
                for (int i = 0; i < k; i++)
                {
                    if (mapping.ContainsKey(IN_VARIABLE_NAMES[i]))
                    {
                        out_r2rVarNames.Add(mapping[IN_VARIABLE_NAMES[i]]);
                    }
                    else
                    {
                        err = string.IsNullOrEmpty(err) ? (IN_VARIABLE_NAMES[i]+" not mapping ") : (","+IN_VARIABLE_NAMES[i]+" not mapping ");
                    }
                }
                
            }
            catch (Exception ex)
            {
                err = ex.Message;
            }
            output.MES_VAR_NAMES = IN_VARIABLE_NAMES;
            output.R2R_VAR_NAMES = out_r2rVarNames.ToArray<string>(); 
            output.Err = err;

            return output;
        }
    }
}

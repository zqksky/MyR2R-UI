﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EIS.XML.Message.Helper.Parameter
{
    [Serializable]
    public class ConvertorMetrologyOutput
    {
        public string Err;
        public string[] MES_VAR_NAMES;
        public string[] R2R_VAR_NAMES;
        /**
        public string[] OUT_VAR_VALUES;
        public string[] OUT_CHAMBERS;
        public string[] OUT_RETICLES;
        public string[] OUT_STEPS;
         * */
    }
}

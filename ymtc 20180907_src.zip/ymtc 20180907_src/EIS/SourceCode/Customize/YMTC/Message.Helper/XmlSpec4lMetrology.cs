﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EIS.XML.Parser.Adapter;
using EIS.XML.Parser.Structure;
using EIS.XML.Parser;

namespace EIS.XML.Message.Helper
{
    /// <summary>
    /// XmSpec4lMetrology class is to provide the funcitons for transform between xml spec and xml structure for Metrology
    /// </summary>
    public class XmlSpec4lMetrology
    {
        /// <summary>
        /// Tranafer the xml specification to structure for Metrology Service
        /// </summary>
        /// <param name="xmlString">the original xml specification</param>
        /// <param name="originalParas">the parameter name mapping (in MES)</param>
        /// <param name="mappingParas">the parameter name mapping (in R2R)</param>
        /// <returns>the MetrologyCmpThk structure(specify type for CMP THK metrology)
        /// if none error raised, Err will be assigned as OK 
        /// </returns>
        public static MetrologyCmpThk Xml2MetrologyCmpThk(string xmlString, string[] originalParas, string[] mappingParas)
        {

            MetrologyCmpThk thk = new MetrologyCmpThk();
            thk.Err = "";
            StructureUitily.InitNullStringFileds(thk, "");

            EIS.XML.Parser.Adapter.Metrology.msgType met;
            Exception exception;
            try
            {
                //for Escape xml
                if (xmlString.StartsWith(@"<?xml version="))
                {
                    met = EIS.XML.Parser.Adapter.Metrology.msgType.Deserialize(xmlString);
                }
                else
                {
                    var xmlDoc = new System.Xml.XmlDocument();
                    xmlDoc.LoadXml("<root>" + xmlString + "</root>");
                    met = EIS.XML.Parser.Adapter.Metrology.msgType.Deserialize(xmlDoc.InnerText);
                }

                if (met.msgBody.lot == null || met.msgBody.lot.Count() == 0) throw new Exception("None Lot parsed from the metrology message.");
                EIS.XML.Parser.Adapter.Metrology.lotType lot = met.msgBody.lot[0];

                thk.EventName = met.msgBody.eventName;
                thk.LotId = lot.lotId;
                thk.MotherLotId = lot.motherLot;
                thk.FabName = met.msgBody.fabName;
                thk.Area = met.msgBody.area;
                thk.Technology = lot.technology;
                thk.Product = lot.productId;
                //thk.ReworkCnt = lot.reworkCnt;
                thk.MetrologyRecipeName = lot.metrologyRecipeName;
                thk.MetrologyStepName = lot.metrologyStepName;
                thk.MetrologyStepSequence = lot.metrologyStepSequence;
                thk.MetrologyTool = lot.metrologyToolName;
                thk.R2RControl = lot.r2rMode;
                thk.Rework = string.IsNullOrEmpty(lot.rework) ? "" : lot.rework;
                thk.ReworkCnt = string.IsNullOrEmpty(lot.reworkCnt) ? 0 : int.Parse(lot.reworkCnt);
                thk.RunCardFlag = "Y".Equals(lot.runcardFlag) || "y".Equals(lot.runcardFlag) ? true : false;
                thk.PilotFlag = "Y".Equals(lot.pilotFlag) || "y".Equals(lot.pilotFlag) ? true : false;


                thk.OcapFlag = string.IsNullOrEmpty(lot.ocapFlag) ? "N" : lot.ocapFlag;
                thk.OcapComment = string.IsNullOrEmpty(lot.ocapComment) ? "" : lot.ocapComment;

                thk.WaferIds = string.IsNullOrEmpty(lot.waferIds) ? new string[] { } : lot.waferIds.Split(',');

                IList<string> names = new List<string>();
                IList<string> indexes = new List<string>();
                IList<string> values = new List<string>();
                IList<string> targets = new List<string>();
                IList<string> upperSpecLimits = new List<string>();
                IList<string> lowerSpecLimits = new List<string>();
                IList<string> ooses = new List<string>();
                IList<string> gofes = new List<string>();

                foreach (Parser.Adapter.Metrology.waferType w in lot.wafer)
                {
                    StringBuilder name = new StringBuilder("");
                    StringBuilder index = new StringBuilder("");
                    StringBuilder value = new StringBuilder("");
                    StringBuilder target = new StringBuilder("");
                    StringBuilder upper = new StringBuilder("");
                    StringBuilder lower = new StringBuilder("");
                    StringBuilder oos = new StringBuilder("");
                    StringBuilder gof = new StringBuilder("");// hard code
                    //find the parameter name list
                    SortedList<string, Parser.Adapter.Metrology.parameterType> paras = new SortedList<string, Parser.Adapter.Metrology.parameterType>();
                    foreach (Parser.Adapter.Metrology.parameterType para in w.parameter)
                    {
                        paras.Add(para.name, para);
                    }

                    //the thk->gof mapping; THK replace to GOF
                    foreach (string paraName in paras.Keys)
                    {
                        Parser.Adapter.Metrology.parameterType para=paras[paraName];
                        if (paraName.Contains("GOF")) continue;
                        if(para.site==null || para.site.Count()==0) {
                            thk.Err = thk.Err.StartsWith("OK") ? thk.Err = paraName + " doesn't has site" : "," + paraName + " doesn't has site";
                            continue;
                        }
                        //for thk->gof
                        string gofName = paraName.Replace("THK", "GOF");
                        Parser.Adapter.Metrology.parameterType gofPara = null;
                        if (paras.ContainsKey(gofName)) gofPara = paras[gofName];
                        //add mark to description for check gof 
                        bool matchGof = true;
                        if (gofPara == null || gofPara.site == null || gofPara.site.Count()!=para.site.Count)
                        {
                            matchGof = false;
                            thk.Err = thk.Err.StartsWith("OK") ? thk.Err = paraName + " doesn't has GOF or mismatch" : "," + paraName + " doesn't has GOF or mismatch";
                        }
                        int cnt = para.site.Count();
                        for (int k = 0; k < cnt; k++)
                        {
                            Parser.Adapter.Metrology.siteType s = para.site[k];
                            name = name.Append(",").Append(para.name == null ? "" : para.name);
                            index = index.Append(",").Append(s.index == null ? "" : s.index);
                            //to filter invalid value
                            string value1 = "";
                            try
                            {
                                value1=Decimal.Parse(s.value.ToString(), System.Globalization.NumberStyles.Float).ToString();
                            }
                            catch (Exception ex)
                            {
                                value1 = "NaN";
                            }
                            value = value.Append(",").Append(value1);
                            //value = value.Append(",").Append(s.value == null ? "" : s.value);
                            target = target.Append(",").Append(para.target == null ? "" : para.target);
                            upper = upper.Append(",").Append(para.upperSpecLimit == null ? "" : para.upperSpecLimit);
                            lower = lower.Append(",").Append(para.lowerSpecLimit == null ? "" : para.lowerSpecLimit);
                            oos = oos.Append(",").Append(s.oos == null ? "" : s.oos);
                            if (matchGof)
                            {
                                gof = gof.Append(",").Append(gofPara.site[k].oos == null ? "1" : gofPara.site[k].oos.Equals("N")?"1":"0");
                            }
                            else
                                gof = gof.Append(",");
                        }
                    }

                    names.Add(name.ToString().TrimStart(','));
                    indexes.Add(index.ToString().TrimStart(','));
                    values.Add(value.ToString().TrimStart(','));
                    targets.Add(target.ToString().TrimStart(','));
                    upperSpecLimits.Add(upper.ToString().TrimStart(','));
                    lowerSpecLimits.Add(lower.ToString().TrimStart(','));
                    ooses.Add(oos.ToString().TrimStart(','));
                    gofes.Add(gof.ToString().TrimStart(','));
                }

                thk.Name = names.ToArray<string>();
                thk.Index = indexes.ToArray<string>();
                thk.Value = values.ToArray<string>();
                thk.Target = targets.ToArray<string>();
                thk.UpperSpecLimits = upperSpecLimits.ToArray<string>();
                thk.LowerSpecLimits = lowerSpecLimits.ToArray<string>();
                thk.Oos = ooses.ToArray<string>();
                thk.Gof = gofes.ToArray<string>();
            }
            catch (Exception e)
            {
                thk.Err = e.Message;
            }
            if (string.IsNullOrEmpty(thk.Err)) thk.Err = "OK";
            return thk;
        }
       
        /*
        /// <summary>
        /// convert the xml specification to structure from litho cd
        /// </summary>
        /// <param name="serviceName"></param>
        /// <param name="area"></param>
        /// <param name="xmlString"></param>
        /// <returns></returns>
        public static MetrologyPhCD Xml2MetrologyPhCD(string serviceName, string area, string xmlString)
        {
            MetrologyPhCD cd = new MetrologyPhCD();
            cd.Err = "";
            EIS.XML.Parser.Adapter.Metrology.msgType met=new Parser.Adapter.Metrology.msgType();
            Exception exception;
            try
            {
                //for Escape xml
                if (xmlString.StartsWith(@"<?xml version="))
                {
                    met = EIS.XML.Parser.Adapter.Metrology.msgType.Deserialize(xmlString);
                }
                else
                {
                    var xmlDoc = new System.Xml.XmlDocument();
                    xmlDoc.LoadXml("<root>" + xmlString + "</root>");
                    met = EIS.XML.Parser.Adapter.Metrology.msgType.Deserialize(xmlDoc.InnerText);
                }

                if (met.msgBody.lot == null || met.msgBody.lot.Count() == 0) throw new Exception("None Lot parsed from the metrology message.");
                EIS.XML.Parser.Adapter.Metrology.lotType lot = met.msgBody.lot[0];

                cd.EventName = met.msgBody.eventName;
                cd.LotId = lot.lotId;
                cd.FabName = met.msgBody.fabName;
                cd.Area = met.msgBody.area;
                cd.Technology = lot.technology;
                cd.Product = lot.productId;
                cd.ReworkCnt = lot.reworkCnt;
                cd.MetrologyRecipeName = lot.metrologyRecipeName;
                cd.MetrologyStepName = lot.metrologyStepName;
                cd.MetrologyStepSequence = lot.metrologyStepSequence;
                cd.MetrologyTool = lot.metrologyToolName;
                cd.LayerName = lot.metrologyLayerName;
                cd.R2RControl = lot.r2rMode;

                cd.OcapFlag = string.IsNullOrEmpty(lot.ocapFlag) ? "N" : lot.ocapFlag;
                cd.OcapComment = string.IsNullOrEmpty(lot.ocapComment) ? "" : lot.ocapComment;

                cd.WaferIds = string.IsNullOrEmpty(lot.waferIds) ? new string[] { } : lot.waferIds.Split(',');
                
                IList<string> names = new List<string>();
                IList<string> indexes = new List<string>();
                IList<string> values = new List<string>();
                IList<string> targets = new List<string>();
                IList<string> upperSpecLimits = new List<string>();
                IList<string> lowerSpecLimits = new List<string>();
                IList<string> ooses = new List<string>();

                foreach (Parser.Adapter.Metrology.waferType w in lot.wafer)
                {
                    StringBuilder name = new StringBuilder("");
                    StringBuilder index = new StringBuilder("");
                    StringBuilder value = new StringBuilder("");
                    StringBuilder target = new StringBuilder("");
                    StringBuilder upper = new StringBuilder("");
                    StringBuilder lower = new StringBuilder("");
                    StringBuilder oos = new StringBuilder("");
                    foreach(Parser.Adapter.Metrology.parameterType para in w.parameter){
                        foreach (Parser.Adapter.Metrology.siteType s in para.site)
                        {
                            name = name.Append(",").Append(para.name == null ? "" : para.name);
                            index = index.Append(",").Append(s.index == null ? "" : s.index);
                            value = value.Append(",").Append(s.value == null ? "" : s.value);
                            target = target.Append(",").Append(para.target == null ? "" : para.target);
                            upper = upper.Append(",").Append(para.upperSpecLimit == null ? "" : para.upperSpecLimit);
                            lower = lower.Append(",").Append(para.lowerSpecLimit == null ? "" : para.lowerSpecLimit);
                            oos = oos.Append(",").Append(s.oos == null ? "" : s.oos);
                        }
                    }

                    names.Add(name.ToString().TrimStart(','));
                    indexes.Add(index.ToString().TrimStart(','));
                    values.Add(value.ToString().TrimStart(','));
                    targets.Add(target.ToString().TrimStart(','));
                    upperSpecLimits.Add(upper.ToString().TrimStart(','));
                    lowerSpecLimits.Add(lower.ToString().TrimStart(','));
                    ooses.Add(oos.ToString().TrimStart(','));
                }

                cd.Name = names.ToArray<string>();
                cd.Index = indexes.ToArray<string>();
                cd.Value = values.ToArray<string>();
                cd.Target = targets.ToArray<string>();
                cd.UpperSpecLimits = upperSpecLimits.ToArray<string>();
                cd.LowerSpecLimits = lowerSpecLimits.ToArray<string>();
                cd.Oos = ooses.ToArray<string>();
            }
            catch (Exception e)
            {
                cd.Err = e.Message;
            }
            if (string.IsNullOrEmpty(cd.Err)) cd.Err = "OK";

            return cd;
        }
        */

        /*
        /// <summary>
        /// convert the xml specification to structure from litho ovl
        /// </summary>
        /// <param name="serviceName"></param>
        /// <param name="area"></param>
        /// <param name="xmlString"></param>
        /// <returns></returns>
        public static MetrologyPhOVL Xml2MetrologyPhOVL(string serviceName, string area, string xmlString)
        {
            MetrologyPhOVL ovl = new MetrologyPhOVL();
            ovl.Err = "";
            EIS.XML.Parser.Adapter.Metrology.msgType met = new Parser.Adapter.Metrology.msgType();
            Exception exception;
            try
            {
                //for Escape xml
                if (xmlString.StartsWith(@"<?xml version="))
                {
                    met = EIS.XML.Parser.Adapter.Metrology.msgType.Deserialize(xmlString);
                }
                else
                {
                    var xmlDoc = new System.Xml.XmlDocument();
                    xmlDoc.LoadXml("<root>" + xmlString + "</root>");
                    met = EIS.XML.Parser.Adapter.Metrology.msgType.Deserialize(xmlDoc.InnerText);
                }
                 

                if (met.msgBody.lot == null || met.msgBody.lot.Count() == 0) throw new Exception("None Lot parsed from the metrology message.");
                EIS.XML.Parser.Adapter.Metrology.lotType lot = met.msgBody.lot[0];

                ovl.EventName = met.msgBody.eventName;
                ovl.LotId = lot.lotId;
                ovl.FabName = met.msgBody.fabName;
                ovl.Area = met.msgBody.area;
                ovl.Technology = lot.technology;
                ovl.Product = lot.productId;
                ovl.ReworkCnt = lot.reworkCnt;
                ovl.MetrologyRecipeName = lot.metrologyRecipeName;
                ovl.MetrologyStepName = lot.metrologyStepName;
                ovl.MetrologyStepSequence = lot.metrologyStepSequence;
                ovl.MetrologyTool = lot.metrologyToolName;
                ovl.LayerName = lot.metrologyLayerName;
                ovl.R2RControl = lot.r2rMode;

                ovl.OcapFlag = string.IsNullOrEmpty(lot.ocapFlag) ? "N" : lot.ocapFlag;
                ovl.OcapComment = string.IsNullOrEmpty(lot.ocapComment) ? "" : lot.ocapComment;

                ovl.WaferIds = string.IsNullOrEmpty(lot.waferIds) ? new string[] { } : lot.waferIds.Split(',');

                IList<string> names = new List<string>();
                IList<string> indexes = new List<string>();
                IList<string> values = new List<string>();
                IList<string> targets = new List<string>();
                IList<string> upperSpecLimits = new List<string>();
                IList<string> lowerSpecLimits = new List<string>();
                IList<string> ooses = new List<string>();

                foreach (Parser.Adapter.Metrology.waferType w in lot.wafer)
                {
                    StringBuilder name = new StringBuilder("");
                    StringBuilder index = new StringBuilder("");
                    StringBuilder value = new StringBuilder("");
                    StringBuilder target = new StringBuilder("");
                    StringBuilder upper = new StringBuilder("");
                    StringBuilder lower = new StringBuilder("");
                    StringBuilder oos = new StringBuilder("");
                    foreach (Parser.Adapter.Metrology.parameterType para in w.parameter)
                    {
                        foreach (Parser.Adapter.Metrology.siteType s in para.site)
                        {
                            name = name.Append(",").Append(para.name == null ? "" : para.name);
                            index = index.Append(",").Append(s.index == null ? "" : s.index);
                            value = value.Append(",").Append(s.value == null ? "" : s.value);
                            target = target.Append(",").Append(para.target == null ? "" : para.target);
                            upper = upper.Append(",").Append(para.upperSpecLimit == null ? "" : para.upperSpecLimit);
                            lower = lower.Append(",").Append(para.lowerSpecLimit == null ? "" : para.lowerSpecLimit);
                            oos = oos.Append(",").Append(s.oos == null ? "" : s.oos);
                        }
                    }

                    names.Add(name.ToString().TrimStart(','));
                    indexes.Add(index.ToString().TrimStart(','));
                    values.Add(value.ToString().TrimStart(','));
                    targets.Add(target.ToString().TrimStart(','));
                    upperSpecLimits.Add(upper.ToString().TrimStart(','));
                    lowerSpecLimits.Add(lower.ToString().TrimStart(','));
                    ooses.Add(oos.ToString().TrimStart(','));
                }

                ovl.Name = names.ToArray<string>();
                ovl.Index = indexes.ToArray<string>();
                ovl.Value = values.ToArray<string>();
                ovl.Target = targets.ToArray<string>();
                ovl.UpperSpecLimits = upperSpecLimits.ToArray<string>();
                ovl.LowerSpecLimits = lowerSpecLimits.ToArray<string>();
                ovl.Oos = ooses.ToArray<string>();
            }
            catch (Exception e)
            {
                ovl.Err = e.Message;
            }
            if (string.IsNullOrEmpty(ovl.Err)) ovl.Err = "OK";

            return ovl;
        }
        */

        /*
        /// <summary>
        /// convert the xml specification to structure from etch cd
        /// </summary>
        /// <param name="serviceName"></param>
        /// <param name="area"></param>
        /// <param name="xmlString"></param>
        /// <returns></returns>
        public static MetrologyPhCD Xml2MetrologyEtchCD(string serviceName, string area, string xmlString)
        {
            MetrologyPhCD cd = new MetrologyPhCD();
            cd.Err = "";
            EIS.XML.Parser.Adapter.Metrology.msgType met = new Parser.Adapter.Metrology.msgType();
            Exception exception;
            try
            {
                //for Escape xml
                if (xmlString.StartsWith(@"<?xml version="))
                {
                    met = EIS.XML.Parser.Adapter.Metrology.msgType.Deserialize(xmlString);
                }
                else
                {
                    var xmlDoc = new System.Xml.XmlDocument();
                    xmlDoc.LoadXml("<root>" + xmlString + "</root>");
                    met = EIS.XML.Parser.Adapter.Metrology.msgType.Deserialize(xmlDoc.InnerText);
                }

                if (met.msgBody.lot == null || met.msgBody.lot.Count() == 0) throw new Exception("None Lot parsed from the metrology message.");
                EIS.XML.Parser.Adapter.Metrology.lotType lot = met.msgBody.lot[0];

                cd.EventName = met.msgBody.eventName;
                cd.LotId = lot.lotId;
                cd.FabName = met.msgBody.fabName;
                cd.Area = met.msgBody.area;
                cd.Technology = lot.technology;
                cd.Product = lot.productId;
                cd.ReworkCnt = lot.reworkCnt;
                cd.MetrologyRecipeName = lot.metrologyRecipeName;
                cd.MetrologyStepName = lot.metrologyStepName;
                cd.MetrologyStepSequence = lot.metrologyStepSequence;
                cd.MetrologyTool = lot.metrologyToolName;
                cd.LayerName = lot.metrologyLayerName;
                cd.R2RControl = lot.r2rMode;

                cd.OcapFlag = string.IsNullOrEmpty(lot.ocapFlag) ? "N" : lot.ocapFlag;
                cd.OcapComment = string.IsNullOrEmpty(lot.ocapComment) ? "" : lot.ocapComment;

                cd.WaferIds = string.IsNullOrEmpty(lot.waferIds) ? new string[] { } : lot.waferIds.Split(',');

                IList<string> names = new List<string>();
                IList<string> indexes = new List<string>();
                IList<string> values = new List<string>();
                IList<string> targets = new List<string>();
                IList<string> upperSpecLimits = new List<string>();
                IList<string> lowerSpecLimits = new List<string>();
                IList<string> ooses = new List<string>();

                foreach (Parser.Adapter.Metrology.waferType w in lot.wafer)
                {
                    StringBuilder name = new StringBuilder("");
                    StringBuilder index = new StringBuilder("");
                    StringBuilder value = new StringBuilder("");
                    StringBuilder target = new StringBuilder("");
                    StringBuilder upper = new StringBuilder("");
                    StringBuilder lower = new StringBuilder("");
                    StringBuilder oos = new StringBuilder("");
                    foreach (Parser.Adapter.Metrology.parameterType para in w.parameter)
                    {
                        foreach (Parser.Adapter.Metrology.siteType s in para.site)
                        {
                            name = name.Append(",").Append(para.name == null ? "" : para.name);
                            index = index.Append(",").Append(s.index == null ? "" : s.index);
                            value = value.Append(",").Append(s.value == null ? "" : s.value);
                            target = target.Append(",").Append(para.target == null ? "" : para.target);
                            upper = upper.Append(",").Append(para.upperSpecLimit == null ? "" : para.upperSpecLimit);
                            lower = lower.Append(",").Append(para.lowerSpecLimit == null ? "" : para.lowerSpecLimit);
                            oos = oos.Append(",").Append(s.oos == null ? "" : s.oos);
                        }
                    }

                    names.Add(name.ToString().TrimStart(','));
                    indexes.Add(index.ToString().TrimStart(','));
                    values.Add(value.ToString().TrimStart(','));
                    targets.Add(target.ToString().TrimStart(','));
                    upperSpecLimits.Add(upper.ToString().TrimStart(','));
                    lowerSpecLimits.Add(lower.ToString().TrimStart(','));
                    ooses.Add(oos.ToString().TrimStart(','));
                }

                cd.Name = names.ToArray<string>();
                cd.Index = indexes.ToArray<string>();
                cd.Value = values.ToArray<string>();
                cd.Target = targets.ToArray<string>();
                cd.UpperSpecLimits = upperSpecLimits.ToArray<string>();
                cd.LowerSpecLimits = lowerSpecLimits.ToArray<string>();
                cd.Oos = ooses.ToArray<string>();
            }
            catch (Exception e)
            {
                cd.Err = e.Message;
            }
            if (string.IsNullOrEmpty(cd.Err)) cd.Err = "OK";

            return cd;
        }
        */


        /// <summary>
        /// Tranafer the xml specification to structure for Metrology Service
        /// </summary>
        /// <param name="xmlString">the original xml specification</param>
        /// <param name="originalParas">the parameter name mapping (in MES)</param>
        /// <param name="mappingParas">the parameter name mapping (in R2R)</param>
        /// <returns>the Metrology structure(the basic type for all metrology)
        /// if none error raised, Err will be assigned as OK 
        /// the parameter will be keep as original Parameter name if cann't find it's r2r parameters names
        /// </returns>
        public static Metrology Xml2Metrology(string xmlString, string[] originalParas, string[] mappingParas)
        {

            Metrology normal = new Metrology();
            normal.Err = "";
            StructureUitily.InitNullStringFileds(normal, "");

            EIS.XML.Parser.Adapter.Metrology.msgType met = new Parser.Adapter.Metrology.msgType();
            Exception exception;
            try
            {
                //for Escape xml
                if (xmlString.StartsWith(@"<?xml version="))
                {
                    met = EIS.XML.Parser.Adapter.Metrology.msgType.Deserialize(xmlString);
                }
                else
                {
                    var xmlDoc = new System.Xml.XmlDocument();
                    xmlDoc.LoadXml("<root>" + xmlString + "</root>");
                    met = EIS.XML.Parser.Adapter.Metrology.msgType.Deserialize(xmlDoc.InnerText);
                }

                SortedList<string, string> map = new SortedList<string, string>();
                int i = originalParas == null ? 0 : originalParas.Count();
                for (int j = 0; j < i;j++ )
                {
                    if (mappingParas != null && mappingParas.Count() > j && !string.IsNullOrEmpty(mappingParas[j]))
                        map[originalParas[j]] = mappingParas[j];
                }

                if (met.msgBody.lot == null || met.msgBody.lot.Count() == 0) throw new Exception("None Lot parsed from the metrology message.");
                EIS.XML.Parser.Adapter.Metrology.lotType lot = met.msgBody.lot[0];

                normal.EventName = met.msgBody.eventName;
                normal.LotId = lot.lotId;
                normal.MotherLotId = lot.motherLot;
                normal.FabName = met.msgBody.fabName;
                normal.Area = met.msgBody.area;
                normal.Technology = lot.technology;
                normal.Product = lot.productId;
                //normal.ReworkCnt = lot.reworkCnt;
                normal.MetrologyRecipeName = lot.metrologyRecipeName;
                normal.MetrologyStepName = lot.metrologyStepName;
                normal.MetrologyStepSequence = lot.metrologyStepSequence;
                normal.MetrologyTool = lot.metrologyToolName;
                normal.LayerName = lot.metrologyLayerName;
                normal.R2RControl = lot.r2rMode;
                normal.Rework = string.IsNullOrEmpty(lot.rework) ? "" : lot.rework;
                normal.ReworkCnt = string.IsNullOrEmpty(lot.reworkCnt) ? 0 : int.Parse(lot.reworkCnt);
                normal.RunCardFlag = "Y".Equals(lot.runcardFlag) || "y".Equals(lot.runcardFlag) ? true : false;
                normal.PilotFlag = "Y".Equals(lot.pilotFlag) || "y".Equals(lot.pilotFlag) ? true : false;

                normal.OcapFlag = string.IsNullOrEmpty(lot.ocapFlag) ? "N" : lot.ocapFlag;
                normal.OcapComment = string.IsNullOrEmpty(lot.ocapComment) ? "" : lot.ocapComment;

                normal.WaferIds = string.IsNullOrEmpty(lot.waferIds) ? new string[] { } : lot.waferIds.Split(',');

                IList<string> names = new List<string>();
                IList<string> indexes = new List<string>();
                IList<string> values = new List<string>();
                IList<string> targets = new List<string>();
                IList<string> upperSpecLimits = new List<string>();
                IList<string> lowerSpecLimits = new List<string>();
                IList<string> ooses = new List<string>();

                foreach (Parser.Adapter.Metrology.waferType w in lot.wafer)
                {
                    StringBuilder name = new StringBuilder("");
                    StringBuilder index = new StringBuilder("");
                    StringBuilder value = new StringBuilder("");
                    StringBuilder target = new StringBuilder("");
                    StringBuilder upper = new StringBuilder("");
                    StringBuilder lower = new StringBuilder("");
                    StringBuilder oos = new StringBuilder("");
                    foreach (Parser.Adapter.Metrology.parameterType para in w.parameter)
                    {
                        foreach (Parser.Adapter.Metrology.siteType s in para.site)
                        {
                            name = name.Append(",").Append(string.IsNullOrEmpty(para.name) ? "NA" : map.ContainsKey(para.name)?map[para.name]:para.name);
                            index = index.Append(",").Append(string.IsNullOrEmpty(s.index) ? "NaN" : s.index);
                            //to filter invalid value
                            string value1 = "";
                            try
                            {
                                value1 = Decimal.Parse(s.value.ToString(), System.Globalization.NumberStyles.Float).ToString();
                            }
                            catch (Exception ex)
                            {
                                value1 = "NaN";
                            }
                            value = value.Append(",").Append(value1);
                            //value = value.Append(",").Append(string.IsNullOrEmpty(s.value) ? "NaN" : s.value);
                            target = target.Append(",").Append(string.IsNullOrEmpty(para.target) ? "NaN" : para.target);
                            upper = upper.Append(",").Append(string.IsNullOrEmpty(para.upperSpecLimit) ? "NaN" : para.upperSpecLimit);
                            lower = lower.Append(",").Append(string.IsNullOrEmpty(para.lowerSpecLimit ) ? "NaN" : para.lowerSpecLimit);
                            oos = oos.Append(",").Append( ("Y".Equals(s.oos)||string.IsNullOrEmpty(s.oos)) ? "true" : "false");
                        }
                    }

                    names.Add(name.ToString().TrimStart(','));
                    indexes.Add(index.ToString().TrimStart(','));
                    values.Add(value.ToString().TrimStart(','));
                    targets.Add(target.ToString().TrimStart(','));
                    upperSpecLimits.Add(upper.ToString().TrimStart(','));
                    lowerSpecLimits.Add(lower.ToString().TrimStart(','));
                    ooses.Add(oos.ToString().TrimStart(','));
                }

                normal.Name = names.ToArray<string>();
                normal.Index = indexes.ToArray<string>();
                normal.Value = values.ToArray<string>();
                normal.Target = targets.ToArray<string>();
                normal.UpperSpecLimits = upperSpecLimits.ToArray<string>();
                normal.LowerSpecLimits = lowerSpecLimits.ToArray<string>();
                normal.Oos = ooses.ToArray<string>();
            }
            catch (Exception e)
            {
                normal.Err = e.Message;
            }
            if (string.IsNullOrEmpty(normal.Err)) normal.Err = "OK";
            return normal;
        }


        /// <summary>
        /// Tranafer the xml specification to structure for Metrology Service
        /// </summary>
        /// <param name="xmlString">the original xml specification</param>
        /// <param name="originalParas">the parameter name mapping (in MES)</param>
        /// <param name="mappingParas">the parameter name mapping (in R2R)</param>
        /// <returns>the Metrology structure(the basic type for all metrology)
        /// if none error raised, Err will be assigned as OK 
        /// the parameter will be removed if cann't find it's r2r parameters names
        /// if none parameter mapping for any one of the metrolgy wafer, Err will be assigned the error details description.     
        /// </returns>
        public static Metrology Xml2Metrology2(string xmlString, string[] originalParas, string[] mappingParas)
        {

            Metrology normal = new Metrology();
            normal.Err = "";
            StructureUitily.InitNullStringFileds(normal, "");

            EIS.XML.Parser.Adapter.Metrology.msgType met = new Parser.Adapter.Metrology.msgType();
            Exception exception;
            try
            {
                //for Escape xml
                if (xmlString.StartsWith(@"<?xml version="))
                {
                    met = EIS.XML.Parser.Adapter.Metrology.msgType.Deserialize(xmlString);
                }
                else
                {
                    var xmlDoc = new System.Xml.XmlDocument();
                    xmlDoc.LoadXml("<root>" + xmlString + "</root>");
                    met = EIS.XML.Parser.Adapter.Metrology.msgType.Deserialize(xmlDoc.InnerText);
                }

                SortedList<string, string> map = new SortedList<string, string>();
                int i = originalParas == null ? 0 : originalParas.Count();
                for (int j = 0; j < i; j++)
                {
                    if (mappingParas != null && mappingParas.Count() > j && !string.IsNullOrEmpty(mappingParas[j]))
                        map[originalParas[j]] = mappingParas[j];
                }

                if (met.msgBody.lot == null || met.msgBody.lot.Count() == 0) throw new Exception("None Lot parsed from the metrology message.");
                EIS.XML.Parser.Adapter.Metrology.lotType lot = met.msgBody.lot[0];

                normal.EventName = met.msgBody.eventName;
                normal.LotId = lot.lotId;
                normal.MotherLotId = lot.motherLot;
                normal.FabName = met.msgBody.fabName;
                normal.Area = met.msgBody.area;
                normal.Technology = lot.technology;
                normal.Product = lot.productId;
                //normal.ReworkCnt = lot.reworkCnt;
                normal.MetrologyRecipeName = lot.metrologyRecipeName;
                normal.MetrologyStepName = lot.metrologyStepName;
                normal.MetrologyStepSequence = lot.metrologyStepSequence;
                normal.MetrologyTool = lot.metrologyToolName;
                normal.LayerName = lot.metrologyLayerName;
                normal.R2RControl = lot.r2rMode;
                normal.Rework = string.IsNullOrEmpty(lot.rework) ? "" : lot.rework;
                normal.ReworkCnt = string.IsNullOrEmpty(lot.reworkCnt) ? 0 : int.Parse(lot.reworkCnt);
                normal.RunCardFlag = "Y".Equals(lot.runcardFlag) || "y".Equals(lot.runcardFlag) ? true : false;
                normal.PilotFlag = "Y".Equals(lot.pilotFlag) || "y".Equals(lot.pilotFlag) ? true : false;

                normal.OcapFlag = string.IsNullOrEmpty(lot.ocapFlag) ? "N" : lot.ocapFlag;
                normal.OcapComment = string.IsNullOrEmpty(lot.ocapComment) ? "" : lot.ocapComment;

                normal.WaferIds = string.IsNullOrEmpty(lot.waferIds) ? new string[] { } : lot.waferIds.Split(',');

                IList<string> names = new List<string>();
                IList<string> indexes = new List<string>();
                IList<string> values = new List<string>();
                IList<string> targets = new List<string>();
                IList<string> upperSpecLimits = new List<string>();
                IList<string> lowerSpecLimits = new List<string>();
                IList<string> ooses = new List<string>();

                string checkResult = "";
                foreach (Parser.Adapter.Metrology.waferType w in lot.wafer)
                {
                    StringBuilder name = new StringBuilder("");
                    StringBuilder index = new StringBuilder("");
                    StringBuilder value = new StringBuilder("");
                    StringBuilder target = new StringBuilder("");
                    StringBuilder upper = new StringBuilder("");
                    StringBuilder lower = new StringBuilder("");
                    StringBuilder oos = new StringBuilder("");
                    foreach (Parser.Adapter.Metrology.parameterType para in w.parameter)
                    {
                        foreach (Parser.Adapter.Metrology.siteType s in para.site)
                        {
                            if (map.ContainsKey(para.name))
                            {
                                name = name.Append(",").Append(map[para.name]);
                                index = index.Append(",").Append(string.IsNullOrEmpty(s.index) ? "NaN" : s.index);
                                //to filter invalid value
                                string value1 = "";
                                try
                                {
                                    value1 = Decimal.Parse(s.value.ToString(), System.Globalization.NumberStyles.Float).ToString();
                                }
                                catch (Exception ex)
                                {
                                    value1 = "NaN";
                                }
                                value = value.Append(",").Append(value1);
                                //value = value.Append(",").Append(string.IsNullOrEmpty(s.value) ? "NaN" : s.value);
                                target = target.Append(",").Append(string.IsNullOrEmpty(para.target) ? "NaN" : para.target);
                                upper = upper.Append(",").Append(string.IsNullOrEmpty(para.upperSpecLimit) ? "NaN" : para.upperSpecLimit);
                                lower = lower.Append(",").Append(string.IsNullOrEmpty(para.lowerSpecLimit) ? "NaN" : para.lowerSpecLimit);
                                oos = oos.Append(",").Append(("Y".Equals(s.oos) || string.IsNullOrEmpty(s.oos)) ? "true" : "false");
                            }
                        }
                    }

                    names.Add(name.ToString().TrimStart(','));
                    indexes.Add(index.ToString().TrimStart(','));
                    values.Add(value.ToString().TrimStart(','));
                    targets.Add(target.ToString().TrimStart(','));
                    upperSpecLimits.Add(upper.ToString().TrimStart(','));
                    lowerSpecLimits.Add(lower.ToString().TrimStart(','));
                    ooses.Add(oos.ToString().TrimStart(','));

                    //if the mapping parameters is empty
                    if (string.IsNullOrEmpty(name.ToString()))
                    {
                        checkResult=string.IsNullOrEmpty(checkResult)?"":(checkResult+",");
                        checkResult = checkResult + w.waferId + " has none paramters mapping"; 
                    }
                }

                normal.Name = names.ToArray<string>();
                normal.Index = indexes.ToArray<string>();
                normal.Value = values.ToArray<string>();
                normal.Target = targets.ToArray<string>();
                normal.UpperSpecLimits = upperSpecLimits.ToArray<string>();
                normal.LowerSpecLimits = lowerSpecLimits.ToArray<string>();
                normal.Oos = ooses.ToArray<string>();

                if (!string.IsNullOrEmpty(checkResult))
                {
                    throw new Exception(checkResult);
                }
            }
            catch (Exception e)
            {
                normal.Err = e.Message;
            }
            if (string.IsNullOrEmpty(normal.Err)) normal.Err = "OK";
            return normal;
        }

    }
}

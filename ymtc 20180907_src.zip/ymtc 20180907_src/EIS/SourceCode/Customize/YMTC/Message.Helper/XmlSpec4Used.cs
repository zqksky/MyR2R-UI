﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EIS.XML.Parser.Adapter;
using EIS.XML.Parser.Structure;
using EIS.XML.Parser;

namespace EIS.XML.Message.Helper
{
    /// <summary>
    /// XmSpec4Used class is to provide the funcitons for transform between xml spec and xml structure for UsedSettings
    /// </summary>
    public class XmlSpec4Used
    {
        /// <summary>
        /// Tranafer the xml specification to structure for UsedSettings Service
        /// </summary>
        /// <param name="serviceName">the service name : UsedSettings</param>
        /// <param name="area">the area name :pH,CMP,DE etc</param>
        /// <param name="xmlString">the original xml specification</param>
        /// <returns>the UsedSettings structure(the basic format for each Area)
        /// if none error raised, Err will be assigned as OK 
        /// </returns>
        public static UsedSettings Xml2UsedSettings(string serviceName, string area, string xmlString)
        {
            UsedSettings used = new UsedSettings();
            used.Err = "";
            StructureUitily.InitNullStringFileds(used, "");

            EIS.XML.Parser.Adapter.UsedSettings.msgType usedXml = new Parser.Adapter.UsedSettings.msgType();
            Exception exception;
            try
            {
                //for Escape xml
                if (xmlString.StartsWith(@"<?xml version="))
                {
                    usedXml = EIS.XML.Parser.Adapter.UsedSettings.msgType.Deserialize(xmlString);
                }
                else
                {
                    var xmlDoc = new System.Xml.XmlDocument();
                    xmlDoc.LoadXml("<root>" + xmlString + "</root>");
                    usedXml = EIS.XML.Parser.Adapter.UsedSettings.msgType.Deserialize(xmlDoc.InnerText);
                }

                if (usedXml.msgBody.lot == null || usedXml.msgBody.lot.Count() == 0) throw new Exception("None Lot parsed from the metrology message.");
                EIS.XML.Parser.Adapter.UsedSettings.lotType lot = usedXml.msgBody.lot[0];
                //
                used.EventName = usedXml.msgBody.eventName;
                used.LotId = lot.lotId;
                used.FabName = usedXml.msgBody.fabName;
                used.MotherLotId = lot.motherLot;
                used.Area = usedXml.msgBody.area;
                used.Technology = lot.technology;
                used.Product = lot.productId;
                used.LayerName = lot.layerName;
                used.ProcessStepName = lot.stepName;
                used.ProcessStepSequence = lot.stepSequence;
                used.RecipeName = lot.recipeId;
                used.Rework = string.IsNullOrEmpty(lot.rework) ? "" : lot.rework;
                used.ReworkCnt = string.IsNullOrEmpty(lot.reworkCnt) ? 0 : int.Parse(lot.reworkCnt);
                used.RunCardFlag = "Y".Equals(lot.runcardFlag) || "y".Equals(lot.runcardFlag) ? true : false;
                used.PilotFlag = "Y".Equals(lot.pilotFlag) || "y".Equals(lot.pilotFlag) ? true : false;
                used.ToolId = lot.eqpId;
                used.Chambers = new string[1] { "NA"};
                used.R2RControl = lot.r2rMode;
                //
                used.WaferIds = new string[] { };
                used.SlotIds = new string[] { };
                used.WaferProcessLocations = new string[] { };
                used.ParameterName = new string[] { };
                used.ParameterValue_Setpoint = new string[] { };
                used.ParameterValue_Lot_Actual = new string[] { };
                used.ParameterValue_Wafer_Actual = new string[][] { };
                //
                IList<string> paraNameList = new List<string>();
                IList<string> paraValueList_Setpoint = new List<string>();
                IList<string> paraValueList_LotActual = new List<string>();
                IList<string[]> paraValueList_WaferActual = new List<string[]>();

                //setpoints
                foreach (Parser.Adapter.UsedSettings.parameterType para in lot.setpoints)
                {
                    if (string.IsNullOrEmpty(para.paraName)) continue;
                    if (paraNameList.Contains(para.paraName))
                    {
                        used.Err = "OK".Equals(used.Err) ?
                            para.paraName + " duplicated of setpoints " :
                            used.Err + "," + para.paraName + " duplicated of setpoints";
                        continue;
                    }
                    paraNameList.Add(para.paraName);
                    paraValueList_Setpoint.Add(para.paraValue);
                }

                //lot actual values
                IDictionary<string, string> lotValues = new Dictionary<string, string>();
                foreach (Parser.Adapter.UsedSettings.parameterType para in lot.lotProcessedValues)
                {
                    if (string.IsNullOrEmpty(para.paraName)) continue;
                    lotValues[para.paraName] = para.paraValue;
                }
                foreach (string paraName in paraNameList)
                {
                    string paraValue = "";
                    if (lotValues.ContainsKey(paraName))
                    {
                        paraValue = lotValues[paraName];
                    }
                    /* skip the empty value check since not all tool can report the lot level process value
                    else
                    {
                        used.Err = "OK".Equals(used.Err) ?
                            paraName + " not found in lotProcessedValues" :
                            used.Err + "," + paraName + " not found in lotProcessedValues";
                    }
                     */
                    paraValueList_LotActual.Add(paraValue);
                }

                //wafer actual values
                IList<string> waferIdList = new List<string>();
                IList<string> slotIdList = new List<string>();
                IList<string> usedChamberList = new List<string>();
                IList<string> waferActualList = new List<string>();
                foreach (Parser.Adapter.UsedSettings.waferType wt in lot.waferProcessedValues)
                {
                    if (string.IsNullOrEmpty(wt.waferId)) continue;
                    waferIdList.Add(wt.waferId);
                    slotIdList.Add(wt.slotId);
                    usedChamberList.Add(string.IsNullOrEmpty(wt.processedChambers) ? "NA" : wt.processedChambers);
                    IList<string> waferProcessValues = new List<string>();
                    IDictionary<string, string> waferValues = new Dictionary<string, string>();
                    foreach (Parser.Adapter.UsedSettings.parameterType para in wt.parameter)
                    {
                        if (string.IsNullOrEmpty(para.paraName)) continue;
                        waferValues[para.paraName] = para.paraValue;
                    }
                    foreach (string paraName in paraNameList)
                    {
                        string paraValue = "";
                        if (waferValues.ContainsKey(paraName))
                        {
                            paraValue = waferValues[paraName];
                        }
                        /*skip the empty value check since not all tool can report the wafer level process value
                    
                        else
                        {
                            used.Err = "OK".Equals(used.Err) ?
                            "[" + wt.waferId + "]" + paraName + " not found in waferProcessedValues" :
                            used.Err + "," + "[" + wt.waferId + "]" + paraName + " not found in waferProcessedValues";
                        }
                         * */
                        waferProcessValues.Add(paraValue);
                    }
                    
                    paraValueList_WaferActual.Add(waferProcessValues.ToArray());
                }
                //
                used.WaferIds = waferIdList.ToArray<string>();
                used.SlotIds = slotIdList.ToArray<string>();
                //in the base class, WaferProcessLocations saved as usedChamber for each wafer.
                used.WaferProcessLocations = usedChamberList.ToArray();
                used.ParameterName = paraNameList.ToArray();
                used.ParameterValue_Setpoint = paraValueList_Setpoint.ToArray();
                used.ParameterValue_Lot_Actual = paraValueList_LotActual.ToArray();
                used.ParameterValue_Wafer_Actual = paraValueList_WaferActual.ToArray();

                //in the base class, WaferProcessLocations saved as usedChamber for each wafer.
                used.Chambers = usedChamberList.Distinct().ToArray();

                #region convert to csv fields
                foreach (string s in used.ParameterName)
                {
                    used.ParameterName_CSV = string.IsNullOrEmpty(used.ParameterName_CSV)?
                        s :
                        used.ParameterName_CSV + "," + s;
                }
                //used.ParameterName_CSV = string.IsNullOrEmpty(used.ParameterName_CSV) ? "" : used.ParameterName_CSV.Trim(',');

                foreach (string s in used.ParameterValue_Setpoint)
                {
                    used.ParameterValue_Setpoint_CSV = string.IsNullOrEmpty(used.ParameterValue_Setpoint_CSV)?
                        s:
                        used.ParameterValue_Setpoint_CSV + "," + s;
                }
                //used.ParameterValue_Setpoint_CSV = string.IsNullOrEmpty(used.ParameterValue_Setpoint_CSV) ? "" : used.ParameterValue_Setpoint_CSV.Trim(',');

                foreach (string s in used.ParameterValue_Lot_Actual)
                {
                    used.ParameterValue_Lot_Actual_CSV = string.IsNullOrEmpty(used.ParameterValue_Lot_Actual_CSV)?
                        s:
                        used.ParameterValue_Lot_Actual_CSV + "," + s;
                }
                //used.ParameterValue_Lot_Actual_CSV = string.IsNullOrEmpty(used.ParameterValue_Lot_Actual_CSV) ? "" : used.ParameterValue_Lot_Actual_CSV.Trim(',');

                IList<string> wafers_csv = new List<string>();
                foreach (string[] w in used.ParameterValue_Wafer_Actual)
                {
                    string wafer_csv = "";
                    foreach (string pv in w)
                    {
                        wafer_csv = string.IsNullOrEmpty(wafer_csv)?pv:wafer_csv + "," + pv;
                    }
                    //wafer_csv = string.IsNullOrEmpty(wafer_csv) ? "" : wafer_csv.Trim(',');
                    wafers_csv.Add(wafer_csv);
                }
                used.ParameterValue_Wafer_Actual_CSV = wafers_csv.ToArray();
                #endregion

            }
            catch (Exception e)
            {
                used.Err = e.Message;
            }
            if (string.IsNullOrEmpty(used.Err)) used.Err = "OK";

            return used;
        }

        /// <summary>
        /// Tranafer the xml specification to structure for UsedSettings Service
        /// </summary>
        /// <param name="serviceName">the service name : UsedSettings</param>
        /// <param name="area">the area name :pH,CMP,DE etc</param>
        /// <param name="xmlString">the original xml specification</param>
        /// <returns>the UsedSettings structure(specify for Cmp), 
        /// if none error raised, Err will be assigned as OK 
        /// </returns>
        public static UsedSettingsCmp Xml2UsedSettingsCmp(string serviceName, string area, string xmlString)
        {
            UsedSettings used = XmlSpec4Used.Xml2UsedSettings(serviceName, area, xmlString);
            UsedSettingsCmp cmp =new UsedSettingsCmp() ;
            try
            {
                cmp = StructureUitily.CopyFrom<UsedSettingsCmp>(used);
                StructureUitily.InitNullStringFileds(cmp, "");
                /*
                //add header Ids
                cmp.WaferProcessLocations = new string[] { };
                IList<string> headers = new List<string>();
                headers=headers.Concat(cmp.Chambers).ToArray();
                cmp.WaferProcessLocations = headers.ToArray();

                //distinct chambers
                cmp.Chambers = cmp.WaferProcessLocations.Distinct().ToArray();
                */
            }
            catch (Exception e)
            {
                cmp.Err = e.Message;
            }
            return cmp;
        }

        /// <summary>
        /// Tranafer the xml specification to structure for UsedSettings Service
        /// </summary>
        /// <param name="serviceName">the service name : UsedSettings</param>
        /// <param name="area">the area name :pH,CMP,DE etc</param>
        /// <param name="xmlString">the original xml specification</param>
        /// <param name="energyName">the parameter name of energy</param>
        /// <param name="focusName">the parameter name of focus</param>
        /// <param name="ovlNames">the parameter names of OVL</param>
        /// <returns>the UsedSettings structure(specify for Ph), 
        /// if none error raised, Err will be assigned as OK 
        /// </returns>
        public static UsedSettingsPh Xml2UsedSettingsPh(string serviceName, string area, string xmlString, string energyName, string focusName, string CPEModeName, string[] ovlParameters)
        {
            UsedSettings used = XmlSpec4Used.Xml2UsedSettings(serviceName, area, xmlString);
            UsedSettingsPh ph = new UsedSettingsPh();
            try
            {
                ph = StructureUitily.CopyFrom<UsedSettingsPh>(used);
                StructureUitily.InitNullStringFileds(ph,"");

                EIS.XML.Parser.Adapter.UsedSettings.msgType usedXml = new Parser.Adapter.UsedSettings.msgType();
                Exception exception;
                //to make or parse the paramter value
                char[] reticleChars = ";".ToCharArray();
                char[] chuckChars = "@".ToCharArray();

                //for Escape xml
                if (xmlString.StartsWith(@"<?xml version="))
                {
                    usedXml = EIS.XML.Parser.Adapter.UsedSettings.msgType.Deserialize(xmlString);
                }
                else
                {
                    var xmlDoc = new System.Xml.XmlDocument();
                    xmlDoc.LoadXml("<root>" + xmlString + "</root>");
                    usedXml = EIS.XML.Parser.Adapter.UsedSettings.msgType.Deserialize(xmlDoc.InnerText);
                }

                if (usedXml.msgBody.lot == null || usedXml.msgBody.lot.Count() == 0) throw new Exception("None Lot parsed from the metrology message.");
                EIS.XML.Parser.Adapter.UsedSettings.lotType lot = usedXml.msgBody.lot[0];

                ph.Reticle=string.IsNullOrEmpty(lot.reticleId) ? new string[] { } : lot.reticleId.Split(',');

                //update chucks -- chuck will updated by parameters post fix
                //ph.Chucks = ph.WaferProcessLocations.ToArray();

                //===============================================
                //to parse Dose/energy/ovl
                //set point
                //IList<string> ovlParaList = new List<string>();
                //IList<string[]> ovlParaVList = new List<string[]>();
                //IList<string[]> ovlParaVList_Actual = new List<string[]>();
                string error = "";
                StringBuilder sb = new StringBuilder("");

                #region parse chucks via ovlParameters
                IDictionary<string, SortedList<string, string>> matchedResult_setpoint = new Dictionary<string, SortedList<string, string>>();
                IDictionary<string, SortedList<string, string>> matchedResult_lot_actual = new Dictionary<string, SortedList<string, string>>();
                
                SortedList<string, string> uniquePostfixList = new SortedList<string, string>();
                IDictionary<string, string> parameter2Prefix = new Dictionary<string, string>();

                for (int k = 0; k < ph.ParameterName.Count(); k++)
                {
                    string matchedPerfix = "";
                    string usedName=ph.ParameterName[k];
                    foreach (string prefixParameter in ovlParameters)
                    {
                        if (usedName.StartsWith(prefixParameter))
                        {
                            matchedPerfix = prefixParameter;
                            break;
                        }
                    }
                    if (!string.IsNullOrEmpty(matchedPerfix))
                    {
                        parameter2Prefix.Add(usedName, matchedPerfix);
                        //remove _
                        string postfix = usedName.Remove(0, matchedPerfix.Length);
                        if (postfix.Length > 0 && postfix.StartsWith("_")) postfix = postfix.Remove(0, 1);
                        //add to matchedResult_setpoint
                        if (!matchedResult_setpoint.ContainsKey(matchedPerfix)) matchedResult_setpoint[matchedPerfix] = new SortedList<string, string>();
                        if (string.IsNullOrEmpty(postfix)) postfix = "NA";
                        matchedResult_setpoint[matchedPerfix].Add(postfix, ph.ParameterValue_Setpoint[k]);

                        //add to matchedResult_lot_actual
                        if (!matchedResult_lot_actual.ContainsKey(matchedPerfix)) matchedResult_lot_actual[matchedPerfix] = new SortedList<string, string>();
                        if (string.IsNullOrEmpty(postfix)) postfix = "NA";
                        matchedResult_lot_actual[matchedPerfix].Add(postfix, ph.ParameterValue_Lot_Actual[k]);

                        //add to postfixList
                        if (!uniquePostfixList.Keys.Contains(postfix)) uniquePostfixList.Add(postfix, postfix);
                    }
                }

                //to check if each item in matchedResult has same postfix list
                foreach (string matchedPerfix in matchedResult_setpoint.Keys)
                {
                    SortedList<string, string> postfix = matchedResult_setpoint[matchedPerfix];
                    if (postfix.Count() != uniquePostfixList.Count())
                    {
                        error = matchedPerfix + " chuck doesn't match,";
                        break;
                    }
                    else
                    {
                        for (int i = 0; i < postfix.Count; i++)
                        {
                            if (!postfix.Keys[i].Equals(uniquePostfixList.Keys[i]))
                            {
                                error = matchedPerfix + " chuck doesn't match,";
                                break;
                            }
                        }
                    }
                }
                if (string.IsNullOrEmpty(error))
                {
                    ph.Chucks = uniquePostfixList.Keys.ToArray();
                }
                else
                {
                    throw new Exception(error);
                }
                #endregion

                #region make OVLValues and OVLValues_LotActual , the parameter in ovlParameters
                IList<string> paraList = new List<string>();
                IList<string[]> paraVList = new List<string[]>();
                IList<string[]> paraVList_Lot_Actual = new List<string[]>();
                error = "";
                IList<string> tmpParsed = new List<string>();

                for (int k = 0; k < ph.ParameterName.Count(); k++)
                {
                    string usedName = ph.ParameterName[k];
                    if (parameter2Prefix.Keys.Contains(usedName))
                    {
                        //v1@v2@v3;v4@v5@v6--r1c1@r1c2@r1c3;r2c1@r2c2@r2c3
                        //prefixParameters parameters,usually for ovl names
                        if (tmpParsed.Contains(parameter2Prefix[usedName])) continue;
                        tmpParsed.Add(parameter2Prefix[usedName]);

                        paraList.Add(parameter2Prefix[usedName]);
                        #region for setpoint
                        SortedList<string, string> postfix = matchedResult_setpoint[parameter2Prefix[usedName]];
                        //C1 r1;r2
                        //C2 r1;r2
                        //NA r1;r2
                        //->v1@v2@v3;v4@v5@v6
                        IList<string> val = new List<string>();//array by reticle
                        string valStr = "";
                        for (int i = 0; i < ph.Reticle.Count(); i++)
                        {
                            string retValue = "";
                            foreach (string ch in postfix.Keys)
                            {
                                string chVals = postfix[ch]; //contain multi values on reticles , r1;r2
                                string[] chValsOnRetile = chVals.Split(reticleChars);
                                retValue = retValue + new string(chuckChars) + ((chValsOnRetile != null && chValsOnRetile.Length > i) ? chValsOnRetile[i] : chValsOnRetile[chValsOnRetile.Length - 1]);
                            }
                            valStr = string.IsNullOrEmpty(valStr) ? retValue.Trim(chuckChars) : (valStr + new string(reticleChars) + retValue.Trim(chuckChars));
                        }

                        paraVList.Add(StructureUitily.BuildArrayFromString(valStr, ph.Reticle.Count(), reticleChars, ph.Chucks.Count(), chuckChars, out error));
                        sb = sb.Append(error);
                        #endregion

                        #region for lot_actual
                        postfix = matchedResult_lot_actual[parameter2Prefix[usedName]];
                        //C1 r1;r2
                        //C2 r1;r2
                        //NA r1;r2
                        //->v1@v2@v3;v4@v5@v6
                        val = new List<string>();//array by reticle
                        valStr = "";
                        for (int i = 0; i < ph.Reticle.Count(); i++)
                        {
                            string retValue = "";
                            foreach (string ch in postfix.Keys)
                            {
                                string chVals = postfix[ch]; //contain multi values on reticles , r1;r2
                                string[] chValsOnRetile = chVals.Split(reticleChars);
                                retValue = retValue + new string(chuckChars) + ((chValsOnRetile != null && chValsOnRetile.Length > i) ? chValsOnRetile[i] : chValsOnRetile[chValsOnRetile.Length - 1]);
                            }
                            valStr = string.IsNullOrEmpty(valStr) ? retValue.Trim(chuckChars) : (valStr + new string(reticleChars) + retValue.Trim(chuckChars));
                        }

                        paraVList_Lot_Actual.Add(StructureUitily.BuildArrayFromString(valStr, ph.Reticle.Count(), reticleChars, ph.Chucks.Count(), chuckChars, out error));
                        sb = sb.Append(error);
                        #endregion
                    }
                    if (usedName.Equals(energyName))
                    {
                        //this is energy parameter
                        ph.Energy = StructureUitily.BuildArrayFromString(ph.ParameterValue_Setpoint[k], ph.Reticle.Count(), reticleChars, ph.Chucks.Count(), chuckChars, out error);
                        ph.Energy_Actual = StructureUitily.BuildArrayFromString(ph.ParameterValue_Lot_Actual[k], ph.Reticle.Count(), reticleChars, ph.Chucks.Count(), chuckChars, out error); 
                    }
                    else if (usedName.Equals(focusName))
                    {
                        ph.Focus = StructureUitily.BuildArrayFromString(ph.ParameterValue_Setpoint[k], ph.Reticle.Count(), reticleChars, ph.Chucks.Count(), chuckChars, out error);
                        ph.Focus_Actual = StructureUitily.BuildArrayFromString(ph.ParameterValue_Lot_Actual[k], ph.Reticle.Count(), reticleChars, ph.Chucks.Count(), chuckChars, out error); 
                    }
                    else if (usedName.Equals(CPEModeName))
                    {
                        ph.CPEModeName = ph.ParameterValue_Lot_Actual[k];
                    }
                }
                 
                #endregion

                ph.OVLNames = paraList.ToArray();
                ph.OVLValues = StructureUitily.MergeArray(paraVList, out error);
                sb = sb.Append(error);
                ph.OVLValues_Actual = StructureUitily.MergeArray(paraVList_Lot_Actual, out error);
                sb = sb.Append(error);

                //make default value
                if (string.IsNullOrEmpty(ph.CPEModeName)) ph.CPEModeName = "NA";
                //
                if (!string.IsNullOrEmpty(error)) throw new Exception(sb.ToString());

                //so some data check
                if (ph.OVLValues_Actual == null || ph.OVLValues_Actual.Count() == 0 ||
                    ph.OVLValues == null || ph.OVLValues.Count() == 0 ||
                    ph.OVLValues.Count() != ph.OVLValues_Actual.Count()) throw new Exception("OVL values doesn't match");

                if (ph.Energy==null || ph.Energy.Count()==0 ) throw new Exception("Energy setpoint value not valid");
                if (ph.Energy_Actual == null || ph.Energy_Actual.Count() == 0) throw new Exception("Energy lot actual value not valid");
                if (ph.Focus == null || ph.Focus.Count() == 0) throw new Exception("Focus setpoint value not valid");
                if (ph.Focus_Actual == null || ph.Focus_Actual.Count() == 0) throw new Exception("Focus lot actual value not valid");

                //WaferProcessLocations splited by _ (temp solution pre Jun)
                int j = ph.WaferProcessLocations.Length;
                for (int k = 0; k < j; k++)
                {
                    if (!string.IsNullOrEmpty(ph.WaferProcessLocations[k]))
                    {
                        string[] chs = ph.WaferProcessLocations[k].Split(',');
                        string newStr="";
                        foreach (string ch in chs)
                        {
                            string[] posts=ch.Split('_');

                            newStr = newStr + "," + posts[posts.Length - 1];
                        }
                        ph.WaferProcessLocations[k] = string.IsNullOrEmpty(newStr) ? newStr : newStr.Remove(0, 1);
                    }
                }
            }
            catch (Exception e)
            {
                ph.Err = ph.Err+","+e.Message;
            }

            return ph;
        }
    }
}

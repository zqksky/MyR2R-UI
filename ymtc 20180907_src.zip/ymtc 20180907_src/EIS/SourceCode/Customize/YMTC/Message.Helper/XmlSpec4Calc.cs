﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EIS.XML.Parser.Adapter;
using EIS.XML.Parser.Structure;
using EIS.XML.Parser;

namespace EIS.XML.Message.Helper
{
    /// <summary>
    /// XmSpec4Calc class is to provide the funcitons for transform between xml spec and xml structure for CalcRecipeSettings
    /// </summary>
    public class XmlSpec4Calc
    {
        /// <summary>
        /// Tranafer the xml specification to structure reply for CalcRecipeSettings Service
        /// </summary>
        /// <param name="serviceName">the service name : CalcRecipeSettings</param>
        /// <param name="area">the area name :pH,CMP,DE etc</param>
        /// <param name="xmlString">the original xml specification</param>
        /// <returns>the CalcRecipeSettings reply structure(the basic format for each Area)
        /// if none error raised, Err will be assigned as OK 
        /// </returns>
        public static CalcRecipeSettingsR Xml2CalcRecipeSettingsR(string serviceName, string area, string xmlString)
        {
            CalcRecipeSettingsR reply = new CalcRecipeSettingsR();
            reply.Err = "";
            StructureUitily.InitNullStringFileds(reply, "");

            EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgType calcR;
            Exception exception;

            //bool result=EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgType.Deserialize(xmlString, out calcR, out exception);
            try
            {
                //for Escape xml
                if (xmlString.StartsWith(@"<?xml version="))
                {
                    calcR = EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgType.Deserialize(xmlString);
                }
                else
                {
                    var xmlDoc = new System.Xml.XmlDocument();
                    xmlDoc.LoadXml("<root>" + xmlString + "</root>");
                    calcR = EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgType.Deserialize(xmlDoc.InnerText);
                }


                if (calcR.msgBody.lot == null || calcR.msgBody.lot.Count() == 0) throw new Exception("None Lot parsed successful");
                EIS.XML.Parser.Adapter.CalcRecipeSettingsR.lotType lot = calcR.msgBody.lot[0];
                if (lot.lotId == null || string.IsNullOrEmpty(lot.lotId.Trim())) throw new Exception("Empty Lot Id");

                reply.Area = calcR.msgBody.area;
                reply.FabName = calcR.msgBody.fabName;
                reply.ToolId = calcR.msgBody.eqpId;
                reply.EventName = string.Format("{0}_{1}", serviceName, calcR.msgBody.eventName);
                reply.Chambers = string.IsNullOrEmpty(lot.chambers) ? new string[1] {"NA" } : lot.chambers.Split(',');
                reply.LayerName = lot.layerName;
                reply.LotId = lot.lotId.Trim();
                reply.MotherLotId = lot.motherLot;
                reply.PilotFlag = "Y".Equals(lot.pilotFlag) || "y".Equals(lot.pilotFlag) ? true : false;
                reply.ProcessStepName = lot.stepName;
                reply.ProcessStepSequence = lot.stepSequence;
                reply.Product = lot.productId;
                reply.R2RControl = lot.r2rMode;
                reply.RecipeName = lot.recipeId;
                reply.Rework = string.IsNullOrEmpty(lot.rework) ? "" : lot.rework;
                reply.ReworkCnt = string.IsNullOrEmpty(lot.reworkCnt) ? 0 : int.Parse(lot.reworkCnt);
                reply.RunCardFlag = "Y".Equals(lot.runcardFlag) || "y".Equals(lot.runcardFlag) ? true : false;
                reply.SlotIds = string.IsNullOrEmpty(lot.slotIds) ? new string[] { } : lot.slotIds.Split(',');
                reply.Technology = lot.technology;
                reply.WaferIds = string.IsNullOrEmpty(lot.waferIds) ? new string[] { } : lot.waferIds.Split(',');

                int count = lot.calcValues.Count();
                IList<string> paraList = new List<string>();
                IList<string> paraVList = new List<string>();
                foreach (EIS.XML.Parser.Adapter.CalcRecipeSettingsR.calcValuesTypeParameter p in lot.calcValues)
                {
                    paraList.Add(p.paraName);
                    paraVList.Add(p.paraValue==null?"":p.paraValue);
                }
                reply.ParameterName = paraList.ToArray<string>();
                reply.ParameterValue = paraVList.ToArray<string>();

                reply.RetCode = calcR.msgBody.retCode;
                reply.RetMsg = calcR.msgBody.retMessage;

                //data check
                if (reply.Chambers == null || reply.Chambers.Count() == 0) throw new Exception("None Chamber found");
                if (reply.WaferIds == null || reply.WaferIds.Count() == 0) throw new Exception("None Wafer found");
                if (reply.ParameterName == null || reply.ParameterName.Count() == 0) throw new Exception("None Parameters found");
            }
            catch (Exception e)
            {
                reply.RetCode = "-1";
                reply.RetMsg = e.Message;
                reply.Err = e.Message;
            }

            if (string.IsNullOrEmpty(reply.RetCode)) reply.RetCode = "0";
            if (string.IsNullOrEmpty(reply.RetMsg)) reply.RetMsg = " ";
            if (string.IsNullOrEmpty(reply.Err)) reply.Err = "OK";

            return reply;
        }

        /// <summary>
        /// Tranafer the xml specification to structure reply for CalcRecipeSettings Service
        /// </summary>
        /// <param name="serviceName">the service name : CalcRecipeSettings</param>
        /// <param name="area">the area name :pH,CMP,DE etc</param>
        /// <param name="xmlString">the original xml specification</param>
        /// <returns>the CalcRecipeSettingsCmp reply structure(specify for Cmp), 
        /// if none error raised, Err will be assigned as OK 
        /// </returns>
        public static CalcRecipeSettingsCmpR Xml2CalcRecipeSettingsCmpR(string serviceName,string area,string xmlString)
        {
            CalcRecipeSettingsR calc = XmlSpec4Calc.Xml2CalcRecipeSettingsR(serviceName, area, xmlString);
            CalcRecipeSettingsCmpR cmp = new CalcRecipeSettingsCmpR();
            try
            {
                cmp = StructureUitily.CopyFrom<CalcRecipeSettingsCmpR>(calc);
                StructureUitily.InitNullStringFileds(cmp, "");
            }
            catch (Exception e)
            {
                cmp.Err = e.Message;
            }
            return cmp;
        }

        /// <summary>
        /// Tranafer the xml specification to structure reply for CalcRecipeSettings Service
        /// </summary>
        /// <param name="serviceName">the service name : CalcRecipeSettings</param>
        /// <param name="area">the area name :pH,CMP,DE etc</param>
        /// <param name="xmlString">the original xml specification</param>
        /// <param name="energyName">the parameter name of energy, and need to build array</param>
        /// <param name="focusName">the parameter name of focus,and need to build array</param>
        /// <param name="ovlParameters">the parameters need to build array,also parse chucks from the postfix of the names</param>
        /// <returns>the CalcRecipeSettingsPh reply structure(specify for Ph) , 
        /// if none error raised, Err will be assigned as OK 
        /// </returns>
        public static CalcRecipeSettingsPhR Xml2CalcRecipeSettingsPhR(string serviceName, string area, string xmlString, string energyName, string focusName, string CPEModeName, string[] ovlParameters)
        {
            CalcRecipeSettingsR calc = XmlSpec4Calc.Xml2CalcRecipeSettingsR(serviceName, area, xmlString);
            CalcRecipeSettingsPhR ph = new CalcRecipeSettingsPhR();

            try
            {
                ph = StructureUitily.CopyFrom<CalcRecipeSettingsPhR>(calc);
                StructureUitily.InitNullStringFileds(ph, "");

                //parse for calc ph
                EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgType calcR;
                Exception exception;
                //to make or parse the paramter value
                char[] reticleChars = ";".ToCharArray();
                char[] chuckChars = "@".ToCharArray();
                //for Escape xml
                if (xmlString.StartsWith(@"<?xml version="))
                {
                    calcR = EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgType.Deserialize(xmlString);
                }
                else
                {
                    var xmlDoc = new System.Xml.XmlDocument();
                    xmlDoc.LoadXml("<root>" + xmlString + "</root>");
                    calcR = EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgType.Deserialize(xmlDoc.InnerText);
                }

                if (calcR.msgBody.lot == null || calcR.msgBody.lot.Count() == 0) throw new Exception("None Lot parsed successful");
                EIS.XML.Parser.Adapter.CalcRecipeSettingsR.lotType lot = calcR.msgBody.lot[0];
                if (lot.lotId == null || string.IsNullOrEmpty(lot.lotId.Trim())) throw new Exception("Empty Lot Id");

                #region parse chucks via prefixParameters
                IDictionary<string, SortedList<string, string>> matchedResult = new Dictionary<string, SortedList<string, string>>();
                SortedList<string, string> uniquePostfixList = new SortedList<string,string>();
                IDictionary<string, string> parameter2Prefix = new Dictionary<string, string>();

                foreach (EIS.XML.Parser.Adapter.CalcRecipeSettingsR.calcValuesTypeParameter p in lot.calcValues)
                {
                    string matchedPerfix = "";
                    foreach (string prefixParameter in ovlParameters)
                    {
                        if (p.paraName.StartsWith(prefixParameter))
                        {
                            matchedPerfix = prefixParameter;
                            break;
                        }
                    }

                    if (!string.IsNullOrEmpty(matchedPerfix))
                    {
                        parameter2Prefix.Add(p.paraName, matchedPerfix);
                        //remove _
                        string postfix = p.paraName.Remove(0, matchedPerfix.Length);
                        if (postfix.Length > 0 && postfix.StartsWith("_")) postfix = postfix.Remove(0, 1);
                        //add to matchedResult
                        if(!matchedResult.ContainsKey(matchedPerfix)) matchedResult[matchedPerfix]=new SortedList<string,string>();
                        if (string.IsNullOrEmpty(postfix)) postfix = "NA";
                        matchedResult[matchedPerfix].Add(postfix,string.IsNullOrEmpty(p.paraValue)?"":p.paraValue);

                        //add to postfixList
                        if (!uniquePostfixList.Keys.Contains(postfix)) uniquePostfixList.Add(postfix,postfix);
                    }
                }

                //to check if each item in matchedResult has same postfix list
                string error = "";
                foreach (string matchedPerfix in matchedResult.Keys)
                {
                    SortedList<string, string> postfix = matchedResult[matchedPerfix];
                    if (postfix.Count() != uniquePostfixList.Count())
                    {
                        error = matchedPerfix + " chuck doesn't match,";
                        break;
                    }
                    else
                    {
                        for (int i = 0; i < postfix.Count; i++)
                        {
                            if (!postfix.Keys[i].Equals(uniquePostfixList.Keys[i]))
                            {
                                error = matchedPerfix + " chuck doesn't match,";
                                break;
                            }
                        }
                    }     
                }
                if (string.IsNullOrEmpty(error))
                {
                    ph.Chucks = uniquePostfixList.Keys.ToArray();
                }
                else
                {
                    throw new Exception(error);
                }
                #endregion

                //
                ph.PreLayer = "NA";
                ph.IsCritical = "NA";
                ph.PreLayerMontherLotId = "NA";
                ph.PreLayerLotList = new string[] { "NA" };
                ph.Reticle = string.IsNullOrEmpty(lot.reticleId) ? new string[] { } : lot.reticleId.Split(',');

                //default set energy / focus / CPEModeName to NA
                ph.CPEModeNameParaName = "NA";
                ph.CPEModeNameParaValue = "NA";
                ph.EnergyName = "NA";
                IList<string> tmp = new List<string>();
                for (int i = 0; i<ph.Reticle.Length; i++)
                {
                    tmp.Add("");
                }
                ph.Energy = tmp.ToArray();
                ph.FocusName = "NA";
                ph.Focus = tmp.ToArray();
                //

                #region make ParameterValue2 values , the parameter in ovlParameters
                IList<string> paraList = new List<string>();
                IList<string[]> paraVList = new List<string[]>();
                error = "";
                StringBuilder sb = new StringBuilder();
                IList<string> tmpParsed = new List<string>();
                foreach (EIS.XML.Parser.Adapter.CalcRecipeSettingsR.calcValuesTypeParameter p in lot.calcValues)
                {
                    if (parameter2Prefix.Keys.Contains(p.paraName))
                    {   
                        //v1@v2@v3;v4@v5@v6--r1c1@r1c2@r1c3;r2c1@r2c2@r2c3
                        //prefixParameters parameters,usually for ovl names
                        if(tmpParsed.Contains(parameter2Prefix[p.paraName])) continue;
                        tmpParsed.Add(parameter2Prefix[p.paraName]);

                        paraList.Add(parameter2Prefix[p.paraName]);
                        SortedList<string, string> postfix = matchedResult[parameter2Prefix[p.paraName]];
                        //C1 r1;r2
                        //C2 r1;r2
                        //NA r1;r2
                        //->v1@v2@v3;v4@v5@v6
                        IList<string> val = new List<string>();//array by reticle
                        string valStr="";
                        for (int i = 0; i < ph.Reticle.Count();i++ )
                        {
                            string retValue = "";
                            foreach (string ch in postfix.Keys)
                            {
                                string chVals = postfix[ch]; //contain multi values on reticles , r1;r2
                                chVals = string.IsNullOrEmpty(chVals) ? "" : chVals;
                                string[] chValsOnRetile = chVals.Split(reticleChars);
                                retValue = retValue + new string(chuckChars) + ((chValsOnRetile != null && chValsOnRetile.Length > i) ? chValsOnRetile[i] : chValsOnRetile[chValsOnRetile.Length - 1]);
                            }
                            //valStr = string.IsNullOrEmpty(valStr) ? retValue.Trim(chuckChars) : (valStr + new string(reticleChars) + retValue.Trim(chuckChars));

                            if (!string.IsNullOrEmpty(retValue)) retValue = retValue.Remove(0, 1);
                            valStr = string.IsNullOrEmpty(valStr) ? retValue : (valStr + new string(reticleChars) + retValue);
                        }

                        paraVList.Add(StructureUitily.BuildArrayFromString(valStr, ph.Reticle.Count(), reticleChars, ph.Chucks.Count(), chuckChars, out error));
                        sb = sb.Append(error);
                    }
                    else if (energyName.Equals(p.paraName))
                    {
                        ph.Energy = StructureUitily.BuildArrayFromString(
                            string.IsNullOrEmpty(p.paraValue) ? "" : p.paraValue,
                            ph.Reticle.Count(), reticleChars, ph.Chucks.Count(), chuckChars, out error);
                        ph.EnergyName = energyName;
                        sb = sb.Append(error);
                    }
                    else if (focusName.Equals(p.paraName))
                    {
                        ph.Focus = StructureUitily.BuildArrayFromString(
                            string.IsNullOrEmpty(p.paraValue) ? "" : p.paraValue
                            , ph.Reticle.Count(), reticleChars, ph.Chucks.Count(), chuckChars, out error);
                        ph.FocusName = focusName;
                        sb = sb.Append(error);
                    }
                    else if (CPEModeName.Equals(p.paraName))
                    {
                        ph.CPEModeNameParaName = CPEModeName;
                        ph.CPEModeNameParaValue = string.IsNullOrEmpty(p.paraValue) ? "NA" : p.paraValue;
                        //ph.CPEModeValue = string.IsNullOrEmpty(p.paraValue) ? "" : p.paraValue;
                    }
                    else
                    {

                    }
                }
                #endregion

                
                ph.ParameterValue2 = paraVList.ToArray();
                ph.OVLNames = paraList.ToArray<string>();
                ph.OVLValues = StructureUitily.MergeArray(paraVList, out error);
                sb = sb.Append(error);
                if (!string.IsNullOrEmpty(sb.ToString())) throw new Exception(sb.ToString());

                
                ph.RetCode = calcR.msgBody.retCode;
                ph.RetMsg = calcR.msgBody.retMessage;

                //data check
                if (ph.Reticle == null || ph.Reticle.Count() == 0) throw new Exception("None Reticle found");
                if (ph.Chambers == null || ph.Chambers.Count() == 0) throw new Exception("None Chucks(Chamber) found");
                if (ph.WaferIds == null || ph.WaferIds.Count() == 0) throw new Exception("None Wafer found");
                if (ph.ParameterName == null || ph.ParameterName.Count() == 0) throw new Exception("None Parameters found");
            }
            catch (Exception e)
            {
                ph.Err = "OK".Equals(ph.Err)?  e.Message : ph.Err+"," + e.Message;
            }

            if (string.IsNullOrEmpty(ph.RetCode)) ph.RetCode = "0";
            if (string.IsNullOrEmpty(ph.RetMsg)) ph.RetMsg = "OK";
            if (string.IsNullOrEmpty(ph.Err)) ph.Err = "OK";

            return ph;
        }

        /// <summary>
        /// Tranafer the xml specification to structure reply for CalcRecipeSettings Service
        /// </summary>
        /// <param name="serviceName">the service name : CalcRecipeSettings</param>
        /// <param name="area">the area name :pH,CMP,DE etc</param>
        /// <param name="xmlString">the original xml specification</param>
        /// <param name="energyName">the parameter name of energy</param>
        /// <param name="focusName">the parameter name of focus</param>
        /// <param name="ovlNames">the parameter names of OVL</param>
        /// <returns>the CalcRecipeSettingsPh reply structure(specify for Ph) , 
        /// if none error raised, Err will be assigned as OK 
        /// </returns>
        /*
        public static CalcRecipeSettingsPhR Xml2CalcRecipeSettingsPhR(string serviceName, string area, string xmlString,string energyName,string focusName,string[] ovlNames)
        {
            CalcRecipeSettingsR calc = XmlSpec4Calc.Xml2CalcRecipeSettingsR(serviceName, area, xmlString);
            CalcRecipeSettingsPhR ph = new CalcRecipeSettingsPhR();
            try
            {
                ph = StructureUitily.CopyFrom<CalcRecipeSettingsPhR>(calc);

                //parse for calc ph
                EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgType calcR;
                Exception exception;
                //for Escape xml
                if (xmlString.StartsWith(@"<?xml version="))
                {
                    calcR = EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgType.Deserialize(xmlString);
                }
                else
                {
                    var xmlDoc = new System.Xml.XmlDocument();
                    xmlDoc.LoadXml("<root>" + xmlString + "</root>");
                    calcR = EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgType.Deserialize(xmlDoc.InnerText);
                }

                if (calcR.msgBody.lot == null || calcR.msgBody.lot.Count() == 0) throw new Exception("None Lot parsed successful");
                EIS.XML.Parser.Adapter.CalcRecipeSettingsR.lotType lot = calcR.msgBody.lot[0];
                if (lot.lotId == null || string.IsNullOrEmpty(lot.lotId.Trim())) throw new Exception("Empty Lot Id");

                ph.PreLayer = "NA";
                ph.IsCritical = "NA";
                ph.PreLayerMontherLotId = "NA";
                ph.PreLayerLotList = new string[] { "NA" };
                ph.Reticle = string.IsNullOrEmpty(lot.reticleId) ? new string[] { } : lot.reticleId.Split(',');

                IList<string> paraList = new List<string>();
                IList<string[]> paraVList = new List<string[]>();
                string error = "";
                StringBuilder sb = new StringBuilder();
                foreach (EIS.XML.Parser.Adapter.CalcRecipeSettingsR.calcValuesTypeParameter p in lot.calcValues)
                {
                    if (energyName.Equals(p.paraName))
                    {
                        ph.Energy = p.paraValue;// StructureUitily.BuildArrayFromString(p.paraValue, reply.Reticle.Count(), reply.Chambers.Count(), out error);
                        sb = sb.Append(error);
                    }
                    else if (focusName.Equals(p.paraName))
                    {
                        ph.Focus = p.paraValue;// StructureUitily.BuildArrayFromString(p.paraValue, reply.Reticle.Count(), reply.Chambers.Count(), out error);
                        sb = sb.Append(error);
                    }
                    else if (ovlNames.Contains(p.paraName))
                    {
                        //ovl parameters
                        paraList.Add(p.paraName);
                        paraVList.Add(StructureUitily.BuildArrayFromString(p.paraValue, ph.Reticle.Count(), ph.Chambers.Count(), out error));
                        sb = sb.Append(error);
                    }
                    else
                    {
                    }
                }

                ph.ParameterValue2 = paraVList.ToArray();
                ph.OVLNames = paraList.ToArray<string>();
                ph.OVLValues = StructureUitily.MergeArray(paraVList, out error);
                sb = sb.Append(error);
                if (!string.IsNullOrEmpty(sb.ToString())) throw new Exception(sb.ToString());

                //init each wafer chuck default is NA
                IList<string> dedicated = new List<string>();
                foreach (string w in ph.WaferIds)
                {
                    dedicated.Add("NA");
                }
                ph.Chucks = dedicated.ToArray();

                ph.CPEModeName = "";
                ph.RetCode = calcR.msgBody.retCode;
                ph.RetMsg = calcR.msgBody.retMessage;

                //data check
                if (ph.Reticle == null || ph.Reticle.Count() == 0) throw new Exception("None Reticle found");
                if (ph.Chambers == null || ph.Chambers.Count() == 0) throw new Exception("None Chucks(Chamber) found");
                if (ph.WaferIds == null || ph.WaferIds.Count() == 0) throw new Exception("None Wafer found");
                if (ph.ParameterName == null || ph.ParameterName.Count() == 0) throw new Exception("None Parameters found");
            
            }
            catch (Exception e)
            {
                ph.Err = ph.Err+","+e.Message;
            }

            if (string.IsNullOrEmpty(ph.RetCode)) ph.RetCode = "0";
            if (string.IsNullOrEmpty(ph.RetMsg)) ph.RetMsg = "OK";
            if (string.IsNullOrEmpty(ph.Err)) ph.Err = "OK";

            return ph;
        }
        */

        /// <summary>
        /// 
        /// </summary>
        /// <param name="originalCalcXml"></param>
        /// <param name="lotId"></param>
        /// <param name="parameterNames"></param>
        /// <param name="parameterValue"></param>
        /// <returns></returns>
        /// 
        /*
        public static ResultString GetResutString4CalcCmpR(string originalCalcXml,string lotId,List<string> parameterNames,List<string> parameterValue)
        {
            EIS.XML.Parser.Adapter.CalcRecipeSettings.msgType calc = null;
            ResultString result = new ResultString();
            try
            {
                calc = EIS.XML.Parser.Adapter.CalcRecipeSettings.msgType.Deserialize(originalCalcXml);
                bool flag = false; // found the lotId in the original xml message

                #region the real code here to append the calculated value to the original xml
                try
                {
                    foreach(EIS.XML.Parser.Adapter.CalcRecipeSettings.lotType lot in calc.msgBody.lot)
                    {
                        if (!flag&&lot.lotId.Equals(lotId))
                        {
                            flag = true;
                            //dictionary the input paraname and paravalue
                            IDictionary<string,string> dictParameters= new Dictionary<string,string>();
                            for (int i = 0; i < parameterNames.Count;i++ )
                            {
                                if (dictParameters.ContainsKey(parameterNames[i])) throw new Exception(string.Format("duplicate parameter:{0}", parameterNames[i]));
                                else
                                {
                                    dictParameters[parameterNames[i]] = parameterValue[i];
                                }
                            }
                            
                            foreach(EIS.XML.Parser.Adapter.CalcRecipeSettings.calcValuesTypeParameter para in lot.calcValues)
                            {
                                if (dictParameters.ContainsKey(para.paraName))
                                {
                                    para.paraValue = dictParameters[para.paraName];
                                    dictParameters.Remove(para.paraName);
                                }
                            }
                            //append the remain para in dictParameters
                            foreach (KeyValuePair<string, string> pair in dictParameters.ToList())
                            {
                                EIS.XML.Parser.Adapter.CalcRecipeSettings.calcValuesTypeParameter para = new Parser.Adapter.CalcRecipeSettings.calcValuesTypeParameter();
                                para.paraName = pair.Key;
                                para.paraValue = pair.Value;
                                lot.calcValues.Add(para);
                            }
                        }
                    }
                    if(!flag)
                    {
                        throw new Exception(string.Format("{0} not found in the request message",lotId));
                    }
                }
                catch (Exception ex)
                {
                    result.sucess = false;
                    result.errorMessage = ex.Message;
                    result.resultXmlString = originalCalcXml;
                }
                #endregion

                result.resultXmlString = calc.Serialize();
                result.sucess = true;
                result.errorMessage = "";
            }
            catch (Exception e)
            {
                result.resultXmlString = originalCalcXml;
                result.sucess = false;
                result.errorMessage = e.Message;
            }

            return result;
        }
        */

        /// <summary>
        /// Encapsulate information into CalcRecipeSettings reply structure(and Serialize to Xml format),
        /// This is usually invoked when some error found in E3
        /// </summary>
        /// <param name="retCode">the return code</param>
        /// <param name="retMsg">the return message</param>
        /// <param name="lotId">the lot Id</param>
        /// <returns>the result error and result string
        /// if none error raised, Err will be assigned as OK 
        /// </returns>
        public static ResultString GetResultString4CalcR(string retCode, string retMsg, string lotId)
        {
            CalcRecipeSettingsR calcR = new CalcRecipeSettingsR();
            calcR.Err = "";

            calcR.LotId = lotId;

            //the result string field
            calcR.RetCode = retCode;
            calcR.RetMsg = retMsg;

            //to complextype string
            //return cmpR.GetResultXmlString();
            if (string.IsNullOrEmpty(calcR.Err)) calcR.Err = "OK";

            return new ResultString(calcR.Err, StructureUitily.SerializeToXml(calcR));
        }

        /// <summary>
        /// Encapsulate information into CalcRecipeSettings reply structure(and Serialize to Xml format),
        /// </summary>
        /// <param name="retCode">the return code</param>
        /// <param name="retMsg">the return message</param>
        /// <param name="lotId">the lot Id</param>
        /// <param name="parameterNames">the calculated parameter names</param>
        /// <param name="parameterValue">the calculated parameter values</param>
        /// <returns>the result error and result string
        /// if none error raised, Err will be assigned as OK 
        /// </returns>
        public static ResultString GetResultString4CalcR(string retCode, string retMsg, string lotId, string[] parameterNames, string[] parameterValue)
        {
            CalcRecipeSettingsR calcR = new CalcRecipeSettingsR();
            calcR.Err = "";

            calcR.LotId = lotId;

            //the result string field
            calcR.RetCode = retCode;
            calcR.RetMsg = retMsg;
            calcR.ParameterName = parameterNames;
            calcR.ParameterValue = parameterValue;
            //to complextype string
            //return cmpR.GetResultXmlString();
            if (string.IsNullOrEmpty(calcR.Err)) calcR.Err = "OK";

            return new ResultString(calcR.Err, StructureUitily.SerializeToXml(calcR));
        }

        /// <summary>
        /// Encapsulate information into CalcRecipeSettingsCmp reply structure(and Serialize to Xml format),
        /// This is usually invoked when some error found in E3
        /// </summary>
        /// <param name="retCode">the return code</param>
        /// <param name="retMsg">the return message</param>
        /// <param name="lotId">the lot Id</param>
        /// <returns>the result error and result string
        /// if none error raised, Err will be assigned as OK 
        /// </returns>
        public static ResultString GetResultString4CalcCmpR(string retCode, string retMsg, string lotId)
        {
            CalcRecipeSettingsCmpR cmpR = new CalcRecipeSettingsCmpR();
            cmpR.Err = "";

            cmpR.LotId = lotId;

            //the result string field
            cmpR.RetCode = retCode;
            cmpR.RetMsg = retMsg;

            //to complextype string
            //return cmpR.GetResultXmlString();
            if (string.IsNullOrEmpty(cmpR.Err)) cmpR.Err = "OK";

            return new ResultString(cmpR.Err, StructureUitily.SerializeToXml(cmpR));
        }

        /// <summary>
        /// Encapsulate information into CalcRecipeSettingsCmp reply structure(and Serialize to Xml format),
        /// </summary>
        /// <param name="retCode">the return code</param>
        /// <param name="retMsg">the return message</param>
        /// <param name="lotId">the lot Id</param>
        /// <param name="parameterNames">the calculated parameter names</param>
        /// <param name="parameterValue">the calculated parameter values</param>
        /// <returns>the result error and result string
        /// if none error raised, Err will be assigned as OK 
        /// </returns>
        public static ResultString GetResultString4CalcCmpR(string retCode, string retMsg, string lotId, string[] parameterNames, string[] parameterValue)
        {
            CalcRecipeSettingsCmpR cmpR = new CalcRecipeSettingsCmpR();
            cmpR.Err = "";

            cmpR.LotId = lotId;

            //the result string field
            cmpR.RetCode = retCode;
            cmpR.RetMsg = retMsg;
            cmpR.ParameterName = parameterNames;
            cmpR.ParameterValue = parameterValue;

            //to complextype string
            //return cmpR.GetResultXmlString();
            if (string.IsNullOrEmpty(cmpR.Err)) cmpR.Err = "OK";

            return new ResultString(cmpR.Err, StructureUitily.SerializeToXml(cmpR));
        }

        /// <summary>
        /// Encapsulate information into CalcRecipeSettingsPh reply structure(and Serialize to Xml format),
        /// This is usually invoked when some error found in E3
        /// </summary>
        /// <param name="retCode">the return code</param>
        /// <param name="retMsg">the return message</param>
        /// <param name="lotId">the lot Id</param>
        /// <returns>the result error and result string
        /// if none error raised, Err will be assigned as OK 
        /// </returns>
        public static ResultString GetResultString4CalcPhR(string retCode, string retMsg, string lotId)
        {
            CalcRecipeSettingsPhR phR = new CalcRecipeSettingsPhR();
            phR.Err = "";

            phR.LotId = lotId;

            //the result string field
            phR.RetCode = retCode;
            phR.RetMsg = retMsg;

            //to complextype string
            //return phR.GetResultXmlString();
            //return StructureUitily.SerializeToXml(phR);

            if (string.IsNullOrEmpty(phR.Err)) phR.Err = "OK";

            return new ResultString(phR.Err, StructureUitily.SerializeToXml(phR));
        }


        /// <summary>
        /// Encapsulate information into CalcRecipeSettingsPh reply structure(and Serialize to Xml format),
        /// </summary>
        /// <param name="retCode">the return code</param>
        /// <param name="retMsg">the return message</param>
        /// <param name="lotId">the lot Id</param>
        /// <param name="Energy">the calculated values for energy values</param>
        /// <param name="Focus">the calculated valus value for focus </param>
        /// <param name="OVLNAMEs">the calculated OVL parameter name (separated by comma )</param>
        /// <param name="OVLValues">the calculated OVL parameter values (in the format of r1c1,r1c2;r2c1,r2c2)</param>
        /// <param name="CPEModeName">the calculated CPEModeName</param>
        /// <param name="Chucks">the calculated wafer chuck dedication , sepatated by comma , NA mean none dedicated</param>
        /// <returns>the result error and result string
        /// if none error raised, Err will be assigned as OK 
        /// </returns>
        /*
        public static ResultString GetResultString4CalcPhR(string retCode, string retMsg, string lotId, string Energy, string Focus, string[] OVLNAMEs, string[] OVLValues, string CPEModeName, string[] Chucks)
        {
            CalcRecipeSettingsPhR phR = new CalcRecipeSettingsPhR();
            phR.Err = "";

            phR.LotId = lotId;

            //the result string field
            phR.RetCode = retCode;
            phR.RetMsg = retMsg;
            phR.Energy = Energy;
            phR.Focus = Focus;
            phR.OVLNames = OVLNAMEs;
            phR.OVLValues = OVLValues;
            phR.Chucks = Chucks;

            phR.CPEModeName = CPEModeName;
            //to complextype string
            //return phR.GetResultXmlString();
            //return StructureUitily.SerializeToXml(phR);

            if (string.IsNullOrEmpty(phR.Err)) phR.Err = "OK";

            return new ResultString(phR.Err, StructureUitily.SerializeToXml(phR));

        }*/

        public static ResultString GetResultString4CalcPhR(string retCode, string retMsg, string lotId, string energyName, string focusName, string[] Energy, string[] Focus, string[] OVLNAMEs, string[] OVLValues, string CPEModeName, string CPEModeValue, string[] Reticles, string[] Chucks, bool DedicationFlag, int DedicationType, string[] ChuckDedication, string[] slotIds, string[] waferIds)
        {
            CalcRecipeSettingsPhR phR = new CalcRecipeSettingsPhR();
            phR.Err = "";

            phR.LotId = lotId;

            //the result string field
            phR.RetCode = retCode;
            phR.RetMsg = retMsg;
            phR.OVLNames = OVLNAMEs;
            phR.OVLValues = OVLValues;
            phR.Chucks = Chucks;
            phR.EnergyName = energyName;
            phR.Energy = Energy;
            phR.FocusName = focusName;
            phR.Focus = Focus;
            phR.CPEModeNameParaValue = CPEModeValue;
            phR.CPEModeNameParaName = CPEModeName;
            phR.Reticle = Reticles;

            IList<string> parametersName = new List<string>();
            IList<string> parametersValue = new List<string>();

            char[] reticleChars=";".ToArray();
            char[] chuckChars="@".ToArray();
            string error="";

            if (!string.IsNullOrEmpty(energyName) && !"NA".Equals(energyName))
            {
                parametersName.Add(energyName);
                //[21;22]  - retile 1 value on chucks
                //[24;23]  - retile 2 value on chucks
                //-> 21@24;22@23 -r1c1@r1c2;r2c1@r2c2
                parametersValue.Add(StructureUitily.BuildStringFromArray(Energy,Reticles.Count(),reticleChars,1,chuckChars, out error));//
            }
            if (!string.IsNullOrEmpty(focusName) && !"NA".Equals(focusName))
            {
                parametersName.Add(focusName);
                parametersValue.Add(StructureUitily.BuildStringFromArray(Focus, Reticles.Count(), reticleChars, 1, chuckChars, out error));//
            }
            if (!string.IsNullOrEmpty(CPEModeName) && !"NA".Equals(CPEModeName))
            {
                parametersName.Add(CPEModeName);
                parametersValue.Add(CPEModeValue);//
            }

            if (DedicationFlag)
            {
                //the waferIds/dedicationParameter are in the same sequence as slotIds 
                //and the solotId has been sorted in control from a-z
                string DedicationTypeName = "Dedication_Type";
                string ChuckDedicationParameterName = "Chuck_Dedication";
                //string ChuckDedicationParameterValue = "";

                //need dedicaiton
                if (ChuckDedication == null || ChuckDedication.Count() == 0)
                {
                    phR.Err = phR.Err + "," + "DedicationChuck Error";
                }
                else if (waferIds == null || slotIds == null)
                {
                    phR.Err = phR.Err + "," + "WaferId or SlotId can't be empty";
                }
                else if (ChuckDedication.Count() != waferIds.Count() || ChuckDedication.Count() != slotIds.Count())
                {
                    phR.Err = phR.Err + "," + "DedicationChuck doesn't match to WaferIds or slotIds";
                }
                else
                {
                    parametersName.Add(DedicationTypeName);
                    parametersValue.Add(DedicationType + "");//

                    parametersName.Add(ChuckDedicationParameterName);
                    string tmp = "";
                    foreach (string c in ChuckDedication)
                    {
                        tmp = string.IsNullOrEmpty(tmp) ? c : tmp + "," + c;
                    }
                    parametersValue.Add(tmp);//

                    //link the the waferIds when need dedication
                    phR.WaferIds = waferIds; // sorted waferIds
                    phR.SlotIds = slotIds; // sorted slotids
                }
            }
            

            #region make string for ovl names
            error = "";
            IList<string[]> ovls = StructureUitily.SplitArray(OVLValues, out error);
            if (OVLNAMEs.Count() != ovls.Count())
            {
                error = "Ovl vlaues doesn't match";
            }
            else
            {
                try
                {
                    for (int i = 0; i < OVLNAMEs.Count(); i++)
                    {
                        //[21;22]  - retile 1 value on chucks
                        //[24;23]  - retile 2 value on chucks
                        //-> 21@24 -c1 value on multi retiles
                        //-> 22@23 -c2 value on multi retiles
                        string[] ovl = ovls[i];
                        for (int k_ch = 0; k_ch < Chucks.Count();k_ch++ )
                        {
                            string chs_value = "";
                            for (int j_retile = 0; j_retile < Reticles.Count(); j_retile++)
                            {
                                string retValues = ovl[j_retile];
                                string[] chs= retValues.Split(';');
                                chs_value = chs_value + new string(reticleChars) + (k_ch < chs.Count() ? chs[k_ch] : chs[chs.Count()-1]);
                            }
                            //add to paramters for this chuck
                            parametersName.Add(string.IsNullOrEmpty(Chucks[k_ch]) || "NA".Equals(Chucks[k_ch]) ? OVLNAMEs[i] : OVLNAMEs[i]+"_"+Chucks[k_ch]);
                            parametersValue.Add(chs_value.Trim(reticleChars));//
                        }
                    }
                }
                catch (Exception e)
                {
                    error = e.Message;
                }
            }
            #endregion

            phR.ParameterName = parametersName.ToArray();
            phR.ParameterValue = parametersValue.ToArray();
            //to complextype string
            //return phR.GetResultXmlString();
            //return StructureUitily.SerializeToXml(phR);

            phR.Err = string.IsNullOrEmpty(phR.Err)? error:phR.Err+","+error;
            if (string.IsNullOrEmpty(phR.Err)) phR.Err = "OK";

            return new ResultString(phR.Err, StructureUitily.SerializeToXml(phR));

        }
    }
}

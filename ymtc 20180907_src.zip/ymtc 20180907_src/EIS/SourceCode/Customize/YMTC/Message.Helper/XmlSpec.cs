﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EIS.XML.Parser.Structure;
using EIS.XML.Parser.Adapter;
using EIS.XML.Parser;

namespace EIS.XML.Message.Helper
{
    /// <summary>
    /// XmlSpec class is to provide some general funcitons for transform between xml spec and xml structure
    /// </summary>
    public class XmlSpec
    {
        /// <summary>
        /// Tranafer the xml specification to structure for SendExposureContext Service
        /// </summary>
        /// <param name="serviceName">the service name : CalcRecipeSettings,UsedSettings, etc</param>
        /// <param name="area">the area name :pH,CMP,DE etc</param>
        /// <param name="xmlString">the original xml specification</param>
        /// <returns>the SendExposureContext reply structure , 
        /// if none error raised, Err will be assigned as OK 
        /// </returns>
        public static SendExposureContextR Xml2SendExposureContextR(string serviceName, string area,string xmlString)
        {
            SendExposureContextR expo = new SendExposureContextR();
            expo.Err = "";
            StructureUitily.InitNullStringFileds(expo,"");

            EIS.XML.Parser.Adapter.SendExposureContextR.msgType expoXml;
            try
            {
                if (xmlString.StartsWith(@"<?xml version="))
                {
                    expoXml = EIS.XML.Parser.Adapter.SendExposureContextR.msgType.Deserialize(xmlString);
                }
                else
                {
                    var xmlDoc = new System.Xml.XmlDocument();
                    xmlDoc.LoadXml("<root>" + xmlString + "</root>");
                    expoXml = EIS.XML.Parser.Adapter.SendExposureContextR.msgType.Deserialize(xmlDoc.InnerText);
                }
                
                expo.RetCode = string.IsNullOrEmpty(expoXml.msgBody.retCode) ? "0" : expoXml.msgBody.retCode;
                expo.RetMsg = string.IsNullOrEmpty(expoXml.msgBody.retMessage) ? "OK" : expoXml.msgBody.retMessage;
                EIS.XML.Parser.Adapter.SendExposureContextR.lotType lot = expoXml.msgBody.lot[0];

                expo.LotId = lot.lotId;
                expo.EventName = expoXml.msgBody.eventName;
                expo.MotherLotId = lot.motherLot;
                expo.FabName = lot.fabName;
                expo.Area = lot.area;
                expo.Technology = lot.technology;
                expo.Product = lot.productId;
                expo.MetrologyLayerName = lot.layerName;

                expo.Exp_StepSequence = "";
                expo.Exp_Tool="";
                expo.Exp_Reticle = "";
                expo.Exp_PreTool = "";
                expo.Exp_PreReticle = "";
                expo.Exp_RecipeName = "";
                expo.Exp_TimeStamp = "";
                expo.Exp_Chuck1_WaferList = "";
                expo.Exp_Chuck2_WaferList = "";
                expo.Exp_Chuck1_SlotIdList = "";
                expo.Exp_Chuck2_SlotIdList = "";

                expo.addItemNames = new string[] { };
                expo.addItemValues = new string[] { };

            }
            catch (Exception ex)
            {
                expo.RetCode = "-1";
                expo.RetMsg = expo.RetMsg + " Error:" + ex.Message;

                expo.Err = ex.Message;
            }

            if (string.IsNullOrEmpty(expo.Err)) expo.Err = "OK";
            return expo;

        }

        /// <summary>
        /// Tranafer the xml specification to structure for RandomQuery Service
        /// </summary>
        /// <param name="xmlString">the original xml specification</param>
        /// <returns>the RandomQuery reply structure
        /// if none error raised, Err will be assigned as OK 
        /// </returns>
        public static RandomQueryR Xml2RandomQueryR(string xmlString)
        {
            RandomQueryR replyQuery = new RandomQueryR();
            replyQuery.Err = "";
            StructureUitily.InitNullStringFileds(replyQuery, "");

            Parser.Adapter.RandomQueryR.msgType reply;
            try
            {
                if (xmlString.StartsWith(@"<?xml version="))
                {
                    reply = Parser.Adapter.RandomQueryR.msgType.Deserialize(xmlString);
                }
                else
                {
                    var xmlDoc = new System.Xml.XmlDocument();
                    xmlDoc.LoadXml("<root>" + xmlString + "</root>");
                    reply = EIS.XML.Parser.Adapter.RandomQueryR.msgType.Deserialize(xmlDoc.InnerText);
                }

                replyQuery.Err = "";
                replyQuery.RetCode = reply.msgBody.retCode;
                replyQuery.RetMsg = string.IsNullOrEmpty(reply.msgBody.retMessage) ? "NA" : reply.msgBody.retMessage;

                replyQuery.FabName = reply.msgBody.fabName;
                replyQuery.ToolId = reply.msgBody.eqpId;

                if (reply.msgBody.vidInfo == null || reply.msgBody.vidInfo.Count() == 0)
                {
                    replyQuery.VIDNames = new string[] { };
                    replyQuery.VIDChannels = new string[] { };
                    replyQuery.VIDValues = new string[] { };
                }
                else
                {
                    IList<string> vidNames=new List<string>();
                    IList<string> vidValues = new List<string>();
                    IList<string> vidChannels = new List<string>();
                    foreach (EIS.XML.Parser.Adapter.RandomQueryR.vidInfoType vidInfo in reply.msgBody.vidInfo)
                    {
                        vidNames.Add(vidInfo.name);
                        vidChannels.Add(vidInfo.vid);
                        vidValues.Add(vidInfo.value);
                    }
                    replyQuery.VIDNames = vidNames.ToArray();
                    replyQuery.VIDChannels = vidChannels.ToArray();
                    replyQuery.VIDValues = vidValues.ToArray();
                }
            }
            catch (Exception ex)
            {
                replyQuery.VIDNames = new string[] { };
                replyQuery.VIDChannels = new string[] { };
                replyQuery.VIDValues = new string[] { };
                replyQuery.FabName = "";
                replyQuery.ToolId = "";
                replyQuery.RetCode = "-1";
                replyQuery.RetMsg = replyQuery.RetMsg + ":" + ex.Message;
                replyQuery.Err = ex.Message;
            }
            if (string.IsNullOrEmpty(replyQuery.Err)) replyQuery.Err = "OK";
            return replyQuery;
        }

        /// <summary>
        /// Transfer the xml specification to structure for AlarmReportEvent Service
        /// </summary>
        /// <param name="xmlString">the original xml specification</param>
        /// <returns>the AlarmReportEvent reply structure
        /// if none error raised, Err will be assigned as OK 
        /// </returns>
        public static AlarmReportEventR Xml2AlarmMessageR(string xmlString)
        {
            AlarmReportEventR replyQuery = new AlarmReportEventR();
            replyQuery.Err = "";
            StructureUitily.InitNullStringFileds(replyQuery, "");

            Parser.Adapter.AlarmReportEventR.msgType reply;
            try
            {
                if (xmlString.StartsWith(@"<?xml version="))
                {
                    reply = Parser.Adapter.AlarmReportEventR.msgType.Deserialize(xmlString);
                }
                else
                {
                    var xmlDoc = new System.Xml.XmlDocument();
                    xmlDoc.LoadXml("<root>" + xmlString + "</root>");
                    reply = EIS.XML.Parser.Adapter.AlarmReportEventR.msgType.Deserialize(xmlDoc.InnerText);
                }

                replyQuery.ReturnStatus = string.IsNullOrEmpty(reply.msgBody.AlarmBody.ReturnStatus) ? "OK" : reply.msgBody.AlarmBody.ReturnStatus;
                replyQuery.Comments = string.IsNullOrEmpty(reply.msgBody.AlarmBody.Comments) ? "NA" : reply.msgBody.AlarmBody.Comments;
                replyQuery.ReturnCode = string.IsNullOrEmpty(reply.msgBody.AlarmReturn.ReturnCode) ? "0" : reply.msgBody.AlarmReturn.ReturnCode;
                replyQuery.ReturnMessage = string.IsNullOrEmpty(reply.msgBody.AlarmReturn.ReturnMessage) ? "NA" : reply.msgBody.AlarmReturn.ReturnMessage;

            }
            catch (Exception ex)
            {
                replyQuery.ReturnStatus = "";
                replyQuery.Comments = "";
                replyQuery.ReturnCode = "-1";
                replyQuery.ReturnMessage=ex.Message;
                replyQuery.Err = ex.Message;
            }
            if (string.IsNullOrEmpty(replyQuery.Err)) replyQuery.Err = "OK";

            return replyQuery;
        }

        /// <summary>
        /// Transfer the xml specification to structure for QueryLotInfo Service
        /// </summary>
        /// <param name="xmlString">the original xml specification</param>
        /// <returns>the QueryLotInfo reply structure
        /// if none error raised, Err will be assigned as OK 
        /// </returns>
        public static QueryLotInfoR Xml2QueryLotInfoR(string xmlString)
        {
            QueryLotInfoR replyQuery = new QueryLotInfoR();
            replyQuery.Err = "";
            StructureUitily.InitNullStringFileds(replyQuery, "");

            Parser.Adapter.QueryLotInfoR.msgType reply;
            try
            {
                if (xmlString.StartsWith(@"<?xml version="))
                {
                    reply = Parser.Adapter.QueryLotInfoR.msgType.Deserialize(xmlString);
                }
                else
                {
                    var xmlDoc = new System.Xml.XmlDocument();
                    xmlDoc.LoadXml("<root>" + xmlString + "</root>");
                    reply = EIS.XML.Parser.Adapter.QueryLotInfoR.msgType.Deserialize(xmlDoc.InnerText);
                }

                replyQuery.Err = "";
                replyQuery.RetCode = reply.msgBody.retCode;
                replyQuery.RetMsg = string.IsNullOrEmpty(reply.msgBody.retMessage) ? "NA" : reply.msgBody.retMessage;

                if(!"0".Equals(reply.msgBody.retCode)){
                }
                else{
                    replyQuery.Area = reply.msgBody.lot.area;
                    replyQuery.FabName = reply.msgBody.lot.fabName;
                    replyQuery.LayerName = reply.msgBody.lot.layerName;
                    replyQuery.LotId = reply.msgBody.lot.lotId;
                    replyQuery.LotQty = reply.msgBody.lot.lotQty;
                    replyQuery.LotStatus = reply.msgBody.lot.processingStatus;
                    replyQuery.LotType = reply.msgBody.lot.lotType1;
                    replyQuery.MotherLotId = reply.msgBody.lot.motherLot;
                    replyQuery.PilotFlag = "Y".Equals(reply.msgBody.lot.pilotFlag) || "y".Equals(reply.msgBody.lot.pilotFlag) ? true : false ;
                    replyQuery.PlanId = reply.msgBody.lot.planId;
                    replyQuery.ProductId = reply.msgBody.lot.productId;
                    replyQuery.ProductType = reply.msgBody.lot.productType;
                    replyQuery.RecipeId = reply.msgBody.lot.recipeId;
                    replyQuery.Rework = reply.msgBody.lot.rework;
                    replyQuery.ReworkCnt = string.IsNullOrEmpty(reply.msgBody.lot.reworkCnt)?0:int.Parse(reply.msgBody.lot.reworkCnt);
                    replyQuery.RootLotId = reply.msgBody.lot.rootLotId;
                    replyQuery.RunCardFlag = "Y".Equals(reply.msgBody.lot.runcardFlag) || "y".Equals(reply.msgBody.lot.runcardFlag)?true:false;
                    replyQuery.Stage = reply.msgBody.lot.stage;
                    replyQuery.StepName = reply.msgBody.lot.stepName;
                    replyQuery.StepSequence = reply.msgBody.lot.stepSequence;
                    replyQuery.SubPlanId = reply.msgBody.lot.subPlanId;
                    replyQuery.Technology = reply.msgBody.lot.technology;
                    //replyQuery.waferIds=(string.IsNullOrEmpty(reply.msgBody.lot.wafer
                    IList<string> wafers = new List<string>();
                    IList<string> slots = new List<string>();
                    foreach (EIS.XML.Parser.Adapter.QueryLotInfoR.waferType w in reply.msgBody.lot.wafer)
                    {
                        wafers.Add(w.waferId);
                        slots.Add(w.slotId);
                    }
                    replyQuery.waferIds = wafers.ToArray();
                    replyQuery.SlotIds = slots.ToArray();
                }
            }
            catch (Exception ex)
            {
                replyQuery.Err = ex.Message;
                replyQuery.RetCode = "-1";
                replyQuery.RetMsg = replyQuery.RetMsg+":"+ex.Message;
            }
            if (string.IsNullOrEmpty(replyQuery.Err)) replyQuery.Err = "OK";

            return replyQuery;
        }

        /// <summary>
        /// Transfer the xml specification to structure for BSReqHoldLot service
        /// </summary>
        /// <param name="xmlString">the original xml specification</param>
        /// <returns>the 2BSReqHoldLot reply structure
        /// if none error raised, Err will be assigned as OK 
        /// </returns>
        public static BSReqHoldLotR Xml2BSReqHoldLotR(string xmlString)
        {
            BSReqHoldLotR holdR = new BSReqHoldLotR();
            holdR.Err = "OK";
            StructureUitily.InitNullStringFileds(holdR, "");

            Parser.Adapter.BSReqHoldLotR.msgType reply;
            try
            {
                if (xmlString.StartsWith(@"<?xml version="))
                {
                    reply = Parser.Adapter.BSReqHoldLotR.msgType.Deserialize(xmlString);
                }
                else
                {
                    var xmlDoc = new System.Xml.XmlDocument();
                    xmlDoc.LoadXml("<root>" + xmlString + "</root>");
                    reply = EIS.XML.Parser.Adapter.BSReqHoldLotR.msgType.Deserialize(xmlDoc.InnerText);
                }

                holdR.Result = reply.msgBody.result;
                holdR.ErrorDesc = reply.msgBody.errorDesc;
                if (reply.msgBody.lotList == null || reply.msgBody.lotList.Count() == 0)
                {
                    holdR.Err = "None Lot found";
                }
                else
                {
                    holdR.LotId = reply.msgBody.lotList[0].lotId;
                }
            }
            catch (Exception ex)
            {
                holdR.Err = ex.Message;
                holdR.Result = "-1";
                holdR.ErrorDesc = ex.Message;
            }

            if (string.IsNullOrEmpty(holdR.Err)) holdR.Err = "OK";

            return holdR;
        }

        /// <summary>
        /// Transfer the xml specification to structure for EAPReqToolSecsData service
        /// </summary>
        /// <param name="xmlString">the original xml specification</param>
        /// <returns>the EAPReqToolSecsData structure
        /// if none error raised, Err will be assigned as OK 
        /// </returns>
        public static EAPReqToolSecsData Xml2EAPReqToolSecsData(string xmlString)
        {
            EAPReqToolSecsData secs = new EAPReqToolSecsData();
            secs.Err = "OK";
            StructureUitily.InitNullStringFileds(secs, "");

            Parser.Adapter.EAPReqToolSecsData.msgType secsXml;
            try
            {
                if (xmlString.StartsWith(@"<?xml version="))
                {
                    secsXml = Parser.Adapter.EAPReqToolSecsData.msgType.Deserialize(xmlString);
                }
                else
                {
                    var xmlDoc = new System.Xml.XmlDocument();
                    xmlDoc.LoadXml("<root>" + xmlString + "</root>");
                    secsXml = EIS.XML.Parser.Adapter.EAPReqToolSecsData.msgType.Deserialize(xmlDoc.InnerText);
                }

                secs.fabName = secsXml.msgBody.fabName;
                secs.eqpId = secsXml.msgBody.eqpId;
                secs.eventName = secsXml.msgBody.eventName;
                secs.secsData = secsXml.msgBody.secsData;

            }
            catch (Exception ex)
            {
                secs.Err = ex.Message;
            }

            if (string.IsNullOrEmpty(secs.Err)) secs.Err = "OK";

            return secs;
        }

        /// <summary>
        /// Encapsulate information into the BSReqHoldLot structure (and Serialize to Xml format)
        /// </summary>
        /// <param name="userId">the hold userId</param>
        /// <param name="SpecialHoldFlag">the specialHoldFlag, deefault:N</param>
        /// <param name="lotId">the lotId</param>
        /// <param name="briefDesc">the hold brief description</param>
        /// <param name="detailDesc">the hold ddetail description</param>
        /// <returns></returns>
        public static ResultString GetString4BSReqHoldLot(string userId, string SpecialHoldFlag, string lotId, string briefDesc, string detailDesc)
        {
            BSReqHoldLot hold = new BSReqHoldLot();
            hold.Err = "";

            hold.UserId = userId;
            hold.SpecialHoldFlag = SpecialHoldFlag;
            hold.LotId = lotId;
            hold.BriefDesc = briefDesc;
            hold.DetailDesc = detailDesc;

            if (string.IsNullOrEmpty(hold.Err)) hold.Err = "OK";
            return new ResultString(hold.Err, StructureUitily.SerializeToXml(hold));
        }


        /// <summary>
        /// Encapsulate Exp_parameter/values and add items into SendExposureContext reply structure(and Serialize to Xml format)
        /// </summary>
        /// <param name="retCode">the return code from E3</param>
        /// <param name="retMessage">the return mesage from E3</param>
        /// <param name="Exp_ParaNames">the input Exp_parameter</param>
        /// <param name="Exp_ParaValues">the input Exp_values</param>
        /// <param name="addItems">the added items</param>
        /// <param name="addValues">the add vlaues</param>
        /// <returns>the result error and result string
        /// if none error raised, Err will be assigned as OK 
        /// </returns>
        public static ResultString GetResultString4ExposureContexR(string retCode, string retMessage, string[] Exp_ParaNames, string[] Exp_ParaValues, string[] addItems, string[] addValues)
        {
            SendExposureContextR exposure = new SendExposureContextR();
            exposure.Err = "";
            StructureUitily.InitNullStringFileds(exposure, "");

            exposure.RetCode = retCode;
            exposure.RetMsg = retMessage;

            System.Reflection.FieldInfo[] fs = exposure.GetType().GetFields();
            IDictionary<string, System.Reflection.FieldInfo> fss = new Dictionary<string, System.Reflection.FieldInfo>();
            foreach (System.Reflection.FieldInfo f in fs)
            {
                fss[f.Name] = f;
            }

            try
            {
                int i = Exp_ParaNames == null ? 0 : Exp_ParaNames.Count();
                int j = Exp_ParaValues == null ? 0 : Exp_ParaValues.Count();
                if (i == 0 || i != j)
                {
                    throw new Exception("Exp Parameter key/value doesn't match");
                }

                for (int k = 0; k < i; k++)
                {
                    /*
                    System.Reflection.FieldInfo f = fs.First(T => T.Name.Equals(keys[k]));
                    if (f != null)
                    {
                        f.SetValue(alarm, values[k]);
                    }*/
                    if (fss.ContainsKey(Exp_ParaNames[k]))
                    {
                        fss[Exp_ParaNames[k]].SetValue(exposure, Exp_ParaValues[k]);
                    }
                }
            }
            catch (Exception e)
            {
                exposure.Err = e.Message;
            }

            exposure.addItemNames = addItems;
            exposure.addItemValues = addValues;

            if (string.IsNullOrEmpty(exposure.Err)) exposure.Err = "OK";

            return new ResultString(exposure.Err, StructureUitily.SerializeToXml(exposure));


        }

        /// <summary>
        /// Encapsulate return Code and Message into SendExposureContext reply structure(and Serialize to Xml format)
        /// This is usually invoked when some error found in E3
        /// </summary>
        /// <param name="retCode">the return code from E3</param>
        /// <param name="retMessage">the return mesage from E3</param>
        /// <returns>the result error and result string
        /// if none error raised, Err will be assigned as OK 
        /// </returns>
        public static ResultString GetResultString4ExposureContexR(string retCode, string retMessage)
        {
            SendExposureContextR exposure = new SendExposureContextR();
            exposure.Err = "";
            StructureUitily.InitNullStringFileds(exposure,"");

            exposure.RetCode = retCode;
            exposure.RetMsg = retMessage;

            if (string.IsNullOrEmpty(exposure.Err)) exposure.Err = "OK";

            return new ResultString(exposure.Err, StructureUitily.SerializeToXml(exposure));
        }


        /// <summary>
        /// Encapsulate Exp_parameter/values and add items into SendExposureContext reply structure(and Serialize to Xml format)
        /// </summary>
        /// <param name="retCode"></param>
        /// <param name="retMessage"></param>
        /// <param name="Exp_StepSequence"></param>
        /// <param name="Exp_Tool"></param>
        /// <param name="Exp_Reticle"></param>
        /// <param name="Exp_PreTool"></param>
        /// <param name="Exp_PreReticle"></param>
        /// <param name="Exp_RecipeName"></param>
        /// <param name="Exp_TimeStamp"></param>
        /// <param name="Exp_WaferList">NA to skip make Exp_Chuck1/2_WaferList and Exp_Chuck1/2_SlotIdList</param>
        /// <param name="Exp_SlotIdList">NA to skip make Exp_Chuck1/2_WaferList and Exp_Chuck1/2_SlotIdList</param>
        /// <param name="Exp_DedicationList">NA to skip make Exp_Chuck1/2_WaferList and Exp_Chuck1/2_SlotIdList</param>
        /// <returns></returns>
        public static ResultString GetResultString4ExposureContexR(string retCode, string retMessage, 
            string Exp_StepSequence, string Exp_Tool, string Exp_Reticle, 
            string Exp_PreTool, string Exp_PreReticle, string Exp_RecipeName, string Exp_TimeStamp, 
            string Exp_WaferList, string Exp_SlotIdList, string Exp_DedicationList)
        {
            SendExposureContextR exposure = new SendExposureContextR();
            exposure.Err = "";
            StructureUitily.InitNullStringFileds(exposure, "");

            exposure.RetCode = retCode;
            exposure.RetMsg = retMessage;
            try{
                exposure.Exp_StepSequence = Exp_StepSequence;
                exposure.Exp_Tool = Exp_Tool;
                exposure.Exp_Reticle = Exp_Reticle;
                exposure.Exp_PreTool = Exp_PreTool;
                exposure.Exp_PreReticle = Exp_PreReticle;
                exposure.Exp_RecipeName = Exp_RecipeName;
                exposure.Exp_TimeStamp = Exp_TimeStamp;

                if (!"NA".Equals(Exp_WaferList) && !"NA".Equals(Exp_SlotIdList) && !"NA".Equals(Exp_DedicationList))
                {
                    string[] dedi = Exp_DedicationList.Split(',');
                    string[] wafers = Exp_WaferList.Split(',');
                    string[] slots = Exp_SlotIdList.Split(',');

                    if (dedi.Count() != wafers.Count() || dedi.Count() != slots.Count())
                    {
                        throw new Exception("Dedication and wafer doesn't match");
                    }
                    for (int i = 0; i < dedi.Count(); i++)
                    {
                        if ("C1".Equals(dedi[i]))
                        {
                            exposure.Exp_Chuck1_WaferList = string.IsNullOrEmpty(exposure.Exp_Chuck1_WaferList) ? wafers[i] : exposure.Exp_Chuck1_WaferList + "," + wafers[i];
                            exposure.Exp_Chuck1_SlotIdList = string.IsNullOrEmpty(exposure.Exp_Chuck1_SlotIdList) ? wafers[i] : exposure.Exp_Chuck1_SlotIdList + "," + wafers[i];
                        }
                        if ("C2".Equals(dedi[i]))
                        {
                            exposure.Exp_Chuck2_WaferList = string.IsNullOrEmpty(exposure.Exp_Chuck2_WaferList) ? wafers[i] : exposure.Exp_Chuck2_WaferList + "," + wafers[i];
                            exposure.Exp_Chuck2_SlotIdList = string.IsNullOrEmpty(exposure.Exp_Chuck2_SlotIdList) ? wafers[i] : exposure.Exp_Chuck2_SlotIdList + "," + wafers[i];
                        }
                    }

                    if ((string.IsNullOrEmpty(exposure.Exp_Chuck1_WaferList) &&
                        string.IsNullOrEmpty(exposure.Exp_Chuck1_SlotIdList)) ||
                        (string.IsNullOrEmpty(exposure.Exp_Chuck2_WaferList) &&
                        string.IsNullOrEmpty(exposure.Exp_Chuck2_SlotIdList)))
                    {
                        throw new Exception("Wafer Dedication Error");
                    }
                }
                else
                {
                    exposure.Exp_Chuck1_WaferList = "";
                    exposure.Exp_Chuck2_WaferList = "";
                    exposure.Exp_Chuck1_SlotIdList = "";
                    exposure.Exp_Chuck2_SlotIdList = "";
                }
            }
            catch (Exception e)
            {
                exposure.Err = e.Message;
            }

            exposure.addItemNames = new List<string>().ToArray();
            exposure.addItemValues = new List<string>().ToArray();

            if (string.IsNullOrEmpty(exposure.Err)) exposure.Err = "OK";

            return new ResultString(exposure.Err, StructureUitily.SerializeToXml(exposure));

        }


        /// <summary>
        /// Encapsulate information into the RandomQuery structure (and Serialize to Xml format)
        /// </summary>
        /// <param name="fabName">the fab name</param>
        /// <param name="toolId">the tool Id</param>
        /// <param name="VIDNames">the vidnames string separated by comma</param>
        /// <param name="VIDChannels">the vidnames string separated by comma</param>
        /// <returns>the result error and result string    
        /// if none error raised, Err will be assigned as OK 
        /// </returns>
        public static ResultString GetString4RandomQuery(string fabName, string toolId, string[] VIDNames, string[] VIDChannels)
        {
            RandomQuery query = new RandomQuery();
            query.Err = "";
            StructureUitily.InitNullStringFileds(query, "");

            query.FabName = fabName;
            query.ToolId = toolId;
            query.VIDNames = VIDNames;
            query.VIDChannels = VIDChannels;

            if (string.IsNullOrEmpty(query.Err)) query.Err = "OK";
            return new ResultString(query.Err, StructureUitily.SerializeToXml(query));
        }

        /// <summary>
        /// Encapsulate information into the QueryLotInfo structure (and Serialize to Xml format)
        /// </summary>
        /// <param name="fabName">the fab name</param>
        /// <param name="lotId">the lot Id</param>
        /// <returns>the result error and result string      
        /// if none error raised, Err will be assigned as OK 
        /// </returns>
        public static ResultString GetString4QueryLotInfo(string fabName, string lotId)
        {
            QueryLotInfo query = new QueryLotInfo();
            query.Err = "";
            StructureUitily.InitNullStringFileds(query, "");

            query.FabName = fabName;
            query.LotId = lotId;

            if (string.IsNullOrEmpty(query.Err)) query.Err = "OK";

            return new ResultString(query.Err, StructureUitily.SerializeToXml(query));
        }

        /// <summary>
        /// Encapsulate information into the AlarmReportEvent structure (and Serialize to Xml format)
        /// </summary>
        /// <param name="keys">the alarm attribute names</param>
        /// <param name="values">the alarm attribute values</param>
        /// <returns>the result error and result string        
        /// if none error raised, Err will be assigned as OK 
        /// </returns>
        public static ResultString GetString4AlarmMessage(string[] keys, string[] values)
        {
            AlarmReportEvent alarm = new AlarmReportEvent();
            alarm.Err = "";
            StructureUitily.InitNullStringFileds(alarm, "");

            System.Reflection.FieldInfo[] fs = alarm.GetType().GetFields();
            IDictionary<string, System.Reflection.FieldInfo> fss = new Dictionary<string, System.Reflection.FieldInfo>();
            foreach (System.Reflection.FieldInfo f in fs)
            {
                fss[f.Name] = f;
            }

            try
            {
                int i = keys == null ? 0 : keys.Count();
                int j = values == null ? 0 : values.Count();
                if (i == 0 || i != j)
                {
                    throw new Exception("Alarm key/value doesn't match");
                }

                for (int k = 0; k < i; k++)
                {
                    /*
                    System.Reflection.FieldInfo f = fs.First(T => T.Name.Equals(keys[k]));
                    if (f != null)
                    {
                        f.SetValue(alarm, values[k]);
                    }*/
                    if (fss.ContainsKey(keys[k]))
                    {
                        fss[keys[k]].SetValue(alarm, values[k]);
                    }
                }
            }
            catch (Exception e)
            {
                alarm.Err = e.Message;
            }
            if (string.IsNullOrEmpty(alarm.Err)) alarm.Err = "OK";
            return new ResultString(alarm.Err, StructureUitily.SerializeToXml(alarm));
        }


    }
}

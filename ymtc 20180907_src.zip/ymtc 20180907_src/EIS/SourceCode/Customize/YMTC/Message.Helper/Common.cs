﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace EIS.XML.Message.Helper
{
    /// <summary>
    /// Common Class is to provide some basic functions.
    /// </summary>
    public class Common
    {
        /// <summary>
        /// Gset a unique transaction id, format: yyyyMMddHHmmss.fff + HashCode for a new object.
        /// </summary>
        /// <returns>the unique Id</returns>
        public static string GenerateTransId()
        {
            return string.Format("{0}.{1}",DateTime.Now.ToString("yyyyMMddHHmmss.fff"),new Object().GetHashCode().ToString());
        }

        /// <summary>
        /// Translation of special characters in the XML string
        /// </summary>
        /// <param name="xmlString">the input xml string</param>
        /// <returns>xml string without special characters</returns>
        public static string EscapeXml(string xmlString)
        {
            string xml = xmlString;
            try
            {
                var xmlDoc = new System.Xml.XmlDocument();
                xmlDoc.LoadXml("<root>" + xmlString + "</root>");
                xml = xmlDoc.InnerText;
            }
            catch (Exception e)
            {
            }
            return xml;
            
        }

        /// <summary>
        /// Find the target Parameter
        /// </summary>
        /// <param name="parameterNames">The parameter names in array format</param>
        /// <param name="parameterValues">The parameter values in array format</param>
        /// <param name="targetParameter">The target paremeter</param>
        /// <returns>the target value. empty return if not find the target paramter in the parameterNames</returns>
        public static string FindParameterValue(string[] parameterNames, string[] parameterValues, string targetParameter)
        {
            string result = "";
            for (int i = 0; i < parameterNames.Count(); i++)
            {
                if (parameterNames[i].Equals(targetParameter))
                {
                    result = parameterValues[i];
                    break;
                }
            }
            return result;
        }

        /// <summary>
        /// Find the targetParameter
        /// </summary>
        /// <param name="parameterNamesString">the parameter names in string format (splited by the separator)</param>
        /// <param name="parameterValuesString">the parameter values in string format (splited by the separator)</param>
        /// <param name="targetParameter">The target paremeter</param>
        /// <param name="separator">the separator</param>
        /// <returns>the target value. empty return if not find the target paramter in the parameterNames</returns>
        public static string FindParameterValue(string parameterNamesString, string parameterValuesString, string targetParameter, string separator)
        {
            char[] x = separator.ToArray();
            return FindParameterValue(parameterNamesString.Split(x), parameterValuesString.Split(x), targetParameter);
        }

        /// <summary>
        /// Build array from string
        /// </summary>
        /// <param name="value">the input string: v1&v2&v3;v4&v5&v6 </param>
        /// <param name="dim1">the rows array, usually be reticle array</param>
        /// <param name="dim2">the col array,usually be chuck array</param>
        /// <returns>the return value:{[v1;v2;v3],[v4;v5;v6]}</returns>
        public static string[] BuildArrayFromString(string value, int dim1, int dim2)
        {
            string error = "";
            return EIS.XML.Parser.StructureUitily.BuildArrayFromString(value, dim1,";".ToCharArray(), dim2,"@".ToCharArray(),out error);
        }

        /// <summary>
        /// Merge multi array into one array
        /// </summary>
        /// <param name="parasArray">the input list of string array
        /// in:  {[v11;v12;v13]   [v21;v22;v23]}
        ///      {[x11;x12;x13]   [x21;x22;x23]}
        /// </param>
        /// <returns>the output array
        /// out: {[v11,x11;v12,x12;v13,x13] [v21,x21;v22,x22;v23,x23]}
        /// </returns>
        public static string[] MergeArray(IList<string[]> parasArray)
        {
            string error = "";
            return EIS.XML.Parser.StructureUitily.MergeArray(parasArray, out error);
        }

    }


}

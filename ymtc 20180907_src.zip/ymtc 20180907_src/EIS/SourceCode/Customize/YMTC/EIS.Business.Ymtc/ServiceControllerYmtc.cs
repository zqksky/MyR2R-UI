﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using AMAT.RVAdapter.CommonData;
using AMAT.RVAdapter.CommonData.EventArgs;
using EIS.XML.Parser;
using EIS.XML.Parser.Adapter;
using EIS.XML.Parser.Structure;
using EIS.Business.Generic;

namespace EIS.Business.Ymtc
{
    public class ServiceControllerYmtc : ServiceController
    {
        //merge the result from Structure to Xml, 
        //this is usually be used for CalcRecipeSettingsR (area) or SendExposureContextSendR (E3 secondly out message)
        public override bool MergeOutStructureResult2XmlObject(XmlSpec spec, StructureBase structureBase)
        {
            StructureTypeOut stp;
            if (!Enum.TryParse<StructureTypeOut>(structureBase.GetStructureTypeName(), out stp))
                return false ;

            bool result = true;
            switch (stp)
            {
                case StructureTypeOut.CalcRecipeSettingsR:
                    XmlSpec calc = MessageHelperYmtc.BuildCalcRecipeSettingsR2XmlBody(structureBase);
                    result=MessageHelperYmtc.MergeCalcRecipeSettingsCalcValues(calc, spec);
                    break;

                case StructureTypeOut.CalcRecipeSettingsCmpR:
                    XmlSpec cmpR = MessageHelperYmtc.BuildCalcRecipeSettingsCmpR2XmlBody(structureBase);
                    result=MessageHelperYmtc.MergeCalcRecipeSettingsCalcValues(cmpR, spec);
                    break;

                case StructureTypeOut.CalcRecipeSettingsPhR:
                    IList<string> chucks = new List<string>();
                    IList<string> ovlNames = new List<string>();
                    XmlSpec phR = MessageHelperYmtc.BuildCalcRecipeSettingsPhR2XmlBody(structureBase, chucks,ovlNames);
                    result = MessageHelperYmtc.MergeCalcRecipeSettingsCalcValues4Ph(phR, spec, chucks,ovlNames);
                    break;

                case StructureTypeOut.SendExposureContextR:
                    XmlSpec expo = MessageHelperYmtc.BuilSendExposureContextR2XmlBody(structureBase);
                    result=MessageHelperYmtc.MergeSendExposureContextRValues(expo, spec);
                    break;

                default:
                    //nothing to do
                    result = false;
                    break;
            }

            return result;
        }

        //here to make the Xml Spec MsgBody from full structure
        //this is ususally be used for E3 primary out  message
        //obsolete
        public override XmlSpec BuildOutStructureFull2XmlObject(StructureBase structureBase)
        {
            StructureTypeOut stp;
            if (!Enum.TryParse<StructureTypeOut>(structureBase.GetStructureTypeName(), out stp)) 
                return null;

            XmlSpec xmlObj = null;
            switch (stp)
            {
                case StructureTypeOut.AlarmReportEvent:

                    break;

                case StructureTypeOut.RandomQuery:
                    xmlObj = MessageHelperYmtc.BuildRandomQuery2Xml(structureBase);
                    break;

                default:
                    //nothing to do
                    break;
            }

            return xmlObj;

        }

         
    }
}

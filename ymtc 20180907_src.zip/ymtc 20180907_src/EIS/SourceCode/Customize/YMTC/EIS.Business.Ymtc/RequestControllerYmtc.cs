﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using AMAT.RVAdapter.CommonData;
using AMAT.RVAdapter.CommonData.EventArgs;
using EIS.XML.Parser;
using EIS.XML.Parser.Adapter;
using EIS.XML.Parser.Structure;
using EIS.Business.Generic;

namespace EIS.Business.Ymtc
{
    public class RequestControllerYmtc:RequestController
    {
        //this is ususally be used for E3 primary out  message
        public override XmlSpec BuildOutStructureFull2XmlObject(string domain, string txId,string timeOut,StructureBase structureBase)
        {
            StructureTypeOut stp;
            if (!Enum.TryParse<StructureTypeOut>(structureBase.GetStructureTypeName(), out stp))
                return null;

            XmlSpec spec = null;
            switch (stp)
            {
                case StructureTypeOut.AlarmReportEvent:
                    spec = MessageHelperYmtc.BuildAlarmReportEvent2Xml(structureBase);
                    string srvMethod = CommandMapping.Instance.FindValue(StructureTypeOut.AlarmReportEvent.ToString(), StructureTypeOut.AlarmReportEvent.ToString());
                    MessageHelperYmtc.MakeMsgHeader(spec, domain, timeOut, SourceApplication.R2R.ToString(), 
                         //ServiceMethod.AlarmReportEvent.ToString(), 
                         CommandMapping.Instance.FindValue(StructureTypeOut.AlarmReportEvent.ToString(),StructureTypeOut.AlarmReportEvent.ToString()),
                        txId);

                    break;

                case StructureTypeOut.RandomQuery:
                    spec = MessageHelperYmtc.BuildRandomQuery2Xml(structureBase);
                    MessageHelperYmtc.MakeMsgHeader(spec, domain, timeOut,SourceApplication.R2R.ToString(),
                        CommandMapping.Instance.FindValue(StructureTypeOut.RandomQuery.ToString(), StructureTypeOut.RandomQuery.ToString()),
                        txId);

                    break;

                case StructureTypeOut.QueryLotInfo:
                    spec = MessageHelperYmtc.BuildQueryLotInfo2Xml(structureBase);
                    MessageHelperYmtc.MakeMsgHeader(spec, domain, timeOut, SourceApplication.R2R.ToString(),
                        CommandMapping.Instance.FindValue(StructureTypeOut.QueryLotInfo.ToString(), StructureTypeOut.QueryLotInfo.ToString()),
                        txId);

                    break;

                case StructureTypeOut.BSReqHoldLot:
                    spec = MessageHelperYmtc.BuilBSReqHoldLot2Xml(structureBase);
                    MessageHelperYmtc.MakeMsgHeader(spec, domain, timeOut, SourceApplication.R2R.ToString(),
                        CommandMapping.Instance.FindValue(StructureTypeOut.BSReqHoldLot.ToString(), StructureTypeOut.BSReqHoldLot.ToString()),
                        txId);

                    break;

                case StructureTypeOut.R2RReqHoldLot:
                    spec = MessageHelperYmtc.BuilR2RReqHoldLot2Xml(structureBase);
                    MessageHelperYmtc.MakeMsgHeader(spec, domain, timeOut, SourceApplication.R2R.ToString(),
                        CommandMapping.Instance.FindValue(StructureTypeOut.R2RReqHoldLot.ToString(), StructureTypeOut.R2RReqHoldLot.ToString()),
                        txId);

                    break;
                default:
                    //nothing to do
                    break;
            }

            return spec;

        }

    }
}

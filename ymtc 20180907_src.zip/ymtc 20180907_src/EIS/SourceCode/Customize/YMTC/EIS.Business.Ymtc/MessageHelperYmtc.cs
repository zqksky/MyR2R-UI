﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EIS.XML.Parser;
using EIS.XML.Parser.Adapter;
using EIS.XML.Parser.Structure;

namespace EIS.Business.Ymtc
{
    public class MessageHelperYmtc
    {
        /// <summary>
        /// to merge the retcode/retmessage and paramereterName, parameterValue
        /// </summary>
        /// <param name="fromSpec"></param>
        /// <param name="targetSpec"></param>
        /// <returns></returns>
        public static bool MergeCalcRecipeSettingsCalcValues(XmlSpec fromSpec, XmlSpec targetSpec)
        {
            bool result = true;
            EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgType from = (EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgType)fromSpec;
            EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgType target = (EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgType)targetSpec;
            if (target.msgBody.lot == null || target.msgBody.lot[0].calcValues == null) return false;
            if (from.msgBody.lot == null || from.msgBody.lot[0].calcValues == null) return false;
            
            #region bellowing is special for chuck dedication
            /*
            string waferIds = from.msgBody.lot[0].waferIds;
            string slotIds = from.msgBody.lot[0].slotIds;
            if (!string.IsNullOrEmpty(waferIds) && !string.IsNullOrEmpty(slotIds))
            {
                string DedicationTypeName = "Dedication_Type";
                string ChuckDedicationParameterName = "Chuck_Dedication";
                string ChuckDedicationParameterValue = "";
                for (int h = 0; h < from.msgBody.lot[0].calcValues.Count(); h++)
                {
                    if (ChuckDedicationParameterName.Equals(from.msgBody.lot[0].calcValues[h].paraName))
                    {
                        ChuckDedicationParameterValue = from.msgBody.lot[0].calcValues[h].paraValue;
                        break;
                    }
                }
                //the DedicationParameterValue will be merge into the target as a parameters
                target.msgBody.lot[0].slotIds = slotIds;
                target.msgBody.lot[0].waferIds = waferIds;
            }
            */
            #endregion

            Dictionary<string, string> merged = new Dictionary<string, string>();
            foreach (EIS.XML.Parser.Adapter.CalcRecipeSettingsR.calcValuesTypeParameter para in target.msgBody.lot[0].calcValues)
            {
                merged.Add(para.paraName, para.paraValue);
            }

            //override target by the from value
            if(from.msgBody.lot==null || from.msgBody.lot[0].calcValues==null) return false;
            foreach (EIS.XML.Parser.Adapter.CalcRecipeSettingsR.calcValuesTypeParameter para in from.msgBody.lot[0].calcValues)
            {
                merged[para.paraName] = para.paraValue;
            }

            target.msgBody.retCode=from.msgBody.retCode;
            target.msgBody.retMessage=from.msgBody.retMessage;

            //upate the turning value 
            foreach (EIS.XML.Parser.Adapter.CalcRecipeSettingsR.calcValuesTypeParameter para in target.msgBody.lot[0].calcValues)
            {
                if (merged.ContainsKey(para.paraName))
                {
                    para.paraValue = merged[para.paraName];
                    merged.Remove(para.paraName);
                }
            }

            //add the remain paramter to target
            foreach (string key in merged.Keys)
            {
                EIS.XML.Parser.Adapter.CalcRecipeSettingsR.calcValuesTypeParameter para =new XML.Parser.Adapter.CalcRecipeSettingsR.calcValuesTypeParameter();
                para.paraName=key;
                para.paraValue=merged[key];
                target.msgBody.lot[0].calcValues.Add(para);
            }

            return result;
        }

        public static bool MergeCalcRecipeSettingsCalcValues4Ph(XmlSpec fromSpec, XmlSpec targetSpec,IList<string> chucks,IList<string> ovlNames)
        {
            bool result = true;
            EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgType from = (EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgType)fromSpec;
            EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgType target = (EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgType)targetSpec;
            if (target.msgBody.lot == null || target.msgBody.lot[0].calcValues == null) return false;
            if (from.msgBody.lot == null || from.msgBody.lot[0].calcValues == null) return false;

            if (ovlNames == null) ovlNames = new List<string>();
            Dictionary<string, string> ovlFixList = new Dictionary<string, string>();
            foreach(string ovlPrefix in ovlNames)
            {
                ovlFixList[ovlPrefix] = ovlPrefix;
                foreach (string ch in chucks)
                {
                    if (!string.IsNullOrEmpty(ch) && !"NA".Equals(ch))
                    {
                        string chOvlName = ovlPrefix + "_" + ch;
                        ovlFixList[chOvlName] = chOvlName;
                    }
                }
            }

            #region bellowing is special for chuck dedication
            string waferIds = from.msgBody.lot[0].waferIds;
            string slotIds = from.msgBody.lot[0].slotIds;
            if (!string.IsNullOrEmpty(waferIds) && !string.IsNullOrEmpty(slotIds))
            {
                string DedicationTypeName = "Dedication_Type";
                string ChuckDedicationParameterName = "Chuck_Dedication";
                string ChuckDedicationParameterValue = "";
                for (int h = 0; h < from.msgBody.lot[0].calcValues.Count(); h++)
                {
                    if (ChuckDedicationParameterName.Equals(from.msgBody.lot[0].calcValues[h].paraName))
                    {
                        ChuckDedicationParameterValue = from.msgBody.lot[0].calcValues[h].paraValue;
                        break;
                    }
                }
                //the DedicationParameterValue will be merge into the target as a parameters
                target.msgBody.lot[0].slotIds = slotIds;
                target.msgBody.lot[0].waferIds = waferIds;
            }
            #endregion

            Dictionary<string, string> merged = new Dictionary<string, string>();
            foreach (EIS.XML.Parser.Adapter.CalcRecipeSettingsR.calcValuesTypeParameter para in target.msgBody.lot[0].calcValues)
            {
                if (ovlFixList.ContainsKey(para.paraName))
                {
                    //this is ovl parameters
                    //don't add the original ovl parameters(which doesn't has C1 or C2 postfix) to merged list
                }
                else
                {
                    merged.Add(para.paraName, para.paraValue);
                }
            }

            //override target by the from value
            if (from.msgBody.lot == null || from.msgBody.lot[0].calcValues == null) return false;
            foreach (EIS.XML.Parser.Adapter.CalcRecipeSettingsR.calcValuesTypeParameter para in from.msgBody.lot[0].calcValues)
            {
                merged[para.paraName] = para.paraValue;
            }

            target.msgBody.retCode = from.msgBody.retCode;
            target.msgBody.retMessage = from.msgBody.retMessage;

            //let clear the target parameters and add the fill by merged list
            target.msgBody.lot[0].calcValues.Clear();
            //upate the turning value 
            foreach (EIS.XML.Parser.Adapter.CalcRecipeSettingsR.calcValuesTypeParameter para in target.msgBody.lot[0].calcValues)
            {
                if (merged.ContainsKey(para.paraName))
                {
                    para.paraValue = merged[para.paraName];
                    merged.Remove(para.paraName);
                }
            }

            //add the remain paramter to target
            foreach (string key in merged.Keys)
            {
                EIS.XML.Parser.Adapter.CalcRecipeSettingsR.calcValuesTypeParameter para = new XML.Parser.Adapter.CalcRecipeSettingsR.calcValuesTypeParameter();
                para.paraName = key;
                para.paraValue = merged[key];
                target.msgBody.lot[0].calcValues.Add(para);
            }

            return result;
        }

        public static bool MergeSendExposureContextRValues(XmlSpec fromSpec, XmlSpec targetSpec)
        {
            bool result = true;
            EIS.XML.Parser.Adapter.SendExposureContextR.msgType from = (EIS.XML.Parser.Adapter.SendExposureContextR.msgType)fromSpec;
            EIS.XML.Parser.Adapter.SendExposureContextR.msgType target = (EIS.XML.Parser.Adapter.SendExposureContextR.msgType)targetSpec;

            target.msgBody.lot[0].Exp_Chuck1_SlotIdList = from.msgBody.lot[0].Exp_Chuck1_SlotIdList;
            target.msgBody.lot[0].Exp_Chuck1_WaferList = from.msgBody.lot[0].Exp_Chuck1_WaferList;
            target.msgBody.lot[0].Exp_Chuck2_SlotIdList = from.msgBody.lot[0].Exp_Chuck2_SlotIdList;
            target.msgBody.lot[0].Exp_Chuck2_WaferList = from.msgBody.lot[0].Exp_Chuck2_WaferList;
            target.msgBody.lot[0].Exp_PreReticle = from.msgBody.lot[0].Exp_PreReticle;
            target.msgBody.lot[0].Exp_PreTool = from.msgBody.lot[0].Exp_PreTool;
            target.msgBody.lot[0].Exp_Product = from.msgBody.lot[0].Exp_Product;
            target.msgBody.lot[0].Exp_RecipeName = from.msgBody.lot[0].Exp_RecipeName;
            target.msgBody.lot[0].Exp_Reticle = from.msgBody.lot[0].Exp_Reticle;
            target.msgBody.lot[0].Exp_StepSequence = from.msgBody.lot[0].Exp_StepSequence;
            target.msgBody.lot[0].Exp_TimeStamp = from.msgBody.lot[0].Exp_TimeStamp;
            target.msgBody.lot[0].Exp_Tool = from.msgBody.lot[0].Exp_Tool;

            target.msgBody.lot[0].usedexposure = from.msgBody.lot[0].usedexposure;

            target.msgBody.retCode = from.msgBody.retCode;
            target.msgBody.retMessage = from.msgBody.retMessage;

            

            return result;
        }

        public static XmlSpec BuildCalcRecipeSettingsR2XmlBody(StructureBase structureBase)
        {
            CalcRecipeSettingsR cmpr = (CalcRecipeSettingsR)structureBase;

            EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgType calcr = new EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgType();
            calcr.msgBody = new EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgBodyType();
            calcr.msgBody.lot = new List<EIS.XML.Parser.Adapter.CalcRecipeSettingsR.lotType>();
            calcr.msgBody.lot.Add(new EIS.XML.Parser.Adapter.CalcRecipeSettingsR.lotType());
            EIS.XML.Parser.Adapter.CalcRecipeSettingsR.lotType lt = calcr.msgBody.lot[0];

            lt.lotId = cmpr.LotId;
            lt.calcValues = new List<EIS.XML.Parser.Adapter.CalcRecipeSettingsR.calcValuesTypeParameter>();

            int i = cmpr.ParameterName == null ? 0 : cmpr.ParameterName.Count();
            for (int k = 0; k < i; k++)
            {
                EIS.XML.Parser.Adapter.CalcRecipeSettingsR.calcValuesTypeParameter p = new EIS.XML.Parser.Adapter.CalcRecipeSettingsR.calcValuesTypeParameter();
                p.paraName = cmpr.ParameterName[k];
                p.paraValue = cmpr.ParameterValue[k];
                lt.calcValues.Add(p);
            }
            calcr.msgBody.retCode = cmpr.RetCode;
            calcr.msgBody.retMessage = cmpr.RetMsg;

            return calcr;
        }

        public static XmlSpec BuildCalcRecipeSettingsCmpR2XmlBody(StructureBase structureBase)
        {
            CalcRecipeSettingsCmpR cmpr = (CalcRecipeSettingsCmpR)structureBase;

            EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgType calcr = new EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgType();
            calcr.msgBody = new EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgBodyType();
            calcr.msgBody.lot = new List<EIS.XML.Parser.Adapter.CalcRecipeSettingsR.lotType>();
            calcr.msgBody.lot.Add(new EIS.XML.Parser.Adapter.CalcRecipeSettingsR.lotType());
            EIS.XML.Parser.Adapter.CalcRecipeSettingsR.lotType lt = calcr.msgBody.lot[0];

            lt.lotId = cmpr.LotId;
            lt.calcValues = new List<EIS.XML.Parser.Adapter.CalcRecipeSettingsR.calcValuesTypeParameter>();

            int i = cmpr.ParameterName == null ? 0 : cmpr.ParameterName.Count();
            for (int k = 0; k < i; k++)
            {
                EIS.XML.Parser.Adapter.CalcRecipeSettingsR.calcValuesTypeParameter p = new EIS.XML.Parser.Adapter.CalcRecipeSettingsR.calcValuesTypeParameter();
                p.paraName = cmpr.ParameterName[k];
                p.paraValue = cmpr.ParameterValue[k];
                lt.calcValues.Add(p);
            }
            calcr.msgBody.retCode = cmpr.RetCode;
            calcr.msgBody.retMessage = cmpr.RetMsg;

            return calcr;
        }

        public static XmlSpec BuildCalcRecipeSettingsPhR2XmlBody(StructureBase structureBase, IList<string> chucks,IList<string> ovlNames)
        {
            CalcRecipeSettingsPhR phR = (CalcRecipeSettingsPhR)structureBase;
 
            EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgType calcr = new EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgType();
            calcr.msgBody = new EIS.XML.Parser.Adapter.CalcRecipeSettingsR.msgBodyType();
            calcr.msgBody.lot = new List<EIS.XML.Parser.Adapter.CalcRecipeSettingsR.lotType>();
            calcr.msgBody.lot.Add(new EIS.XML.Parser.Adapter.CalcRecipeSettingsR.lotType());
            EIS.XML.Parser.Adapter.CalcRecipeSettingsR.lotType lt = calcr.msgBody.lot[0];

            lt.lotId = phR.LotId;
            lt.calcValues = new List<EIS.XML.Parser.Adapter.CalcRecipeSettingsR.calcValuesTypeParameter>();

            int i = phR.ParameterName == null ? 0 : phR.ParameterName.Count();
            for (int k = 0; k < i; k++)
            {
                EIS.XML.Parser.Adapter.CalcRecipeSettingsR.calcValuesTypeParameter p = new EIS.XML.Parser.Adapter.CalcRecipeSettingsR.calcValuesTypeParameter();
                p.paraName = phR.ParameterName[k];
                p.paraValue = phR.ParameterValue[k];
                lt.calcValues.Add(p);
            }

            //add the ovlnames as r2r control parameters , and let Merge function to filter the original request ovl names
            foreach (string ovl in phR.OVLNames)
            {
                ovlNames.Add(ovl);
            }
            foreach (string ch in phR.Chucks)
            {
                chucks.Add(ch);
            }
            //
            calcr.msgBody.retCode = phR.RetCode;
            calcr.msgBody.retMessage = phR.RetMsg; 

            //dedication details
            //the waferIds/dedicationParameter are in the same sequence as slotIds 
            //and the solotId has been sorted in control from a-z
            if (phR.WaferIds != null && phR.WaferIds.Count() > 0 && 
                phR.SlotIds != null && phR.SlotIds.Count() > 0)
            {
                string DedicationTypeName = "Dedication_Type";
                string ChuckDedicationParameterName = "Chuck_Dedication";
                string ChuckDedicationParameterValue = "";
                for (int h = 0; h < phR.ParameterName.Count(); h++)
                {
                    if (phR.ParameterName[h].Equals(ChuckDedicationParameterName))
                    {
                        ChuckDedicationParameterValue = phR.ParameterValue[h];
                        break;
                    }
                }
                foreach(string w in phR.WaferIds)
                {
                    lt.waferIds = string.IsNullOrEmpty(lt.waferIds) ? w : lt.waferIds + "," + w;
                }
                foreach (string s in phR.SlotIds)
                {
                    lt.slotIds = string.IsNullOrEmpty(lt.slotIds) ? s : lt.slotIds + "," + s;
                }
            }

            return calcr;
        }

        public static XmlSpec BuilSendExposureContextR2XmlBody(StructureBase structureBase)
        {

            SendExposureContextR expo = (SendExposureContextR)structureBase;

            EIS.XML.Parser.Adapter.SendExposureContextR.msgType expoXml = new EIS.XML.Parser.Adapter.SendExposureContextR.msgType();
            expoXml.msgBody = new EIS.XML.Parser.Adapter.SendExposureContextR.msgBodyType();
            expoXml.msgBody.lot = new List<EIS.XML.Parser.Adapter.SendExposureContextR.lotType>();
            expoXml.msgBody.lot.Add(new EIS.XML.Parser.Adapter.SendExposureContextR.lotType());
            EIS.XML.Parser.Adapter.SendExposureContextR.lotType lt = expoXml.msgBody.lot[0];

            //add Exp_parameter and addname
            lt.Exp_Chuck1_SlotIdList = expo.Exp_Chuck1_SlotIdList;
            lt.Exp_Chuck1_WaferList = expo.Exp_Chuck1_WaferList;
            lt.Exp_Chuck2_SlotIdList = expo.Exp_Chuck2_SlotIdList;
            lt.Exp_Chuck2_WaferList = expo.Exp_Chuck2_WaferList;
            lt.Exp_PreReticle = expo.Exp_PreReticle;
            lt.Exp_PreTool = expo.Exp_PreTool;
            lt.Exp_Product = expo.Exp_Product;
            lt.Exp_RecipeName = expo.Exp_RecipeName;
            lt.Exp_Reticle = expo.Exp_Reticle;
            lt.Exp_StepSequence = expo.Exp_StepSequence;
            lt.Exp_TimeStamp = expo.Exp_TimeStamp;
            lt.Exp_Tool = expo.Exp_Tool;

            lt.usedexposure = new List<XML.Parser.Adapter.SendExposureContextR.addItemType>() ;
            for (int i = 0; i < expo.addItemNames.Count(); i++)
            {
                XML.Parser.Adapter.SendExposureContextR.addItemType add = new XML.Parser.Adapter.SendExposureContextR.addItemType();
                add.itemName = expo.addItemNames[i];
                add.itemValue = expo.addItemValues[i];
                lt.usedexposure.Add(add);
            }

            expoXml.msgBody.retCode = expo.RetCode;
            expoXml.msgBody.retMessage = expo.RetMsg;
            
            return expoXml;
        }

        public static XmlSpec BuildAlarmReportEvent2Xml(StructureBase structureBase)
        {
            AlarmReportEvent rq = (AlarmReportEvent)structureBase;

            EIS.XML.Parser.Adapter.AlarmReportEvent.msgType rqXml = new EIS.XML.Parser.Adapter.AlarmReportEvent.msgType();
            rqXml.SetSpecType(XmlSpecType.AlarmReportEvent);

            rqXml.rvHeader = new EIS.XML.Parser.Adapter.AlarmReportEvent.rvHeaderType();
            rqXml.msgHeader = new EIS.XML.Parser.Adapter.AlarmReportEvent.msgHeaderType();
            rqXml.msgBody = new EIS.XML.Parser.Adapter.AlarmReportEvent.msgBodyType();

            rqXml.msgBody.AlarmHeader = new XML.Parser.Adapter.AlarmReportEvent.AlarmHeaderType();
            rqXml.msgBody.AlarmBody = new XML.Parser.Adapter.AlarmReportEvent.AlarmBodyType();
            rqXml.msgBody.AlarmReturn = new XML.Parser.Adapter.AlarmReportEvent.AlarmReturnType();
            //
            rqXml.msgBody.AlarmHeader.AlarmCode = rq.AlarmCode;
            rqXml.msgBody.AlarmHeader.FactoryID = rq.FactoryID;
            rqXml.msgBody.AlarmHeader.MessageName = rq.MessageName;
            rqXml.msgBody.AlarmHeader.SystemID = rq.SystemID;
            rqXml.msgBody.AlarmHeader.ToolGroup = rq.ToolGroup;
            rqXml.msgBody.AlarmHeader.ToolID = rq.ToolID;
            rqXml.msgBody.AlarmHeader.TransactionTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            //
            rqXml.msgBody.AlarmBody.AlarmContent = rq.AlarmContent;
            rqXml.msgBody.AlarmBody.AlarmSubject = rq.AlarmSubject;
            rqXml.msgBody.AlarmBody.ExtendFilters = new XML.Parser.Adapter.AlarmReportEvent.ExtendFiltersType();
            rqXml.msgBody.AlarmBody.ExtendFilters.ruleType = rq.RuleType;
            rqXml.msgBody.AlarmBody.ExtendFilters.lotId = rq.LotId;
            rqXml.msgBody.AlarmBody.ExtendFilters.chamber = rq.ChamberId;
            rqXml.msgBody.AlarmBody.ExtendFilters.foupId = rq.FoupId;
            rqXml.msgBody.AlarmBody.ExtendFilters.loadPort = rq.LoadPort;
            rqXml.msgBody.AlarmBody.ExtendFilters.priority = rq.Priority;
            rqXml.msgBody.AlarmBody.ExtendFilters.internalPriority = rq.InternalPriority;
            rqXml.msgBody.AlarmBody.ExtendFilters.product = rq.ProductId;
            rqXml.msgBody.AlarmBody.ExtendFilters.plan = rq.PlanId;
            rqXml.msgBody.AlarmBody.ExtendFilters.subSystem = rq.SubSystem;
            rqXml.msgBody.AlarmBody.ExtendFilters.@event = rq.EventName;
            rqXml.msgBody.AlarmBody.ExtendFilters.errorCode = rq.ErrorCode;
            rqXml.msgBody.AlarmBody.ExtendFilters.description = rq.Description;
            rqXml.msgBody.AlarmBody.ExtendFilters.txnComment = rq.TxnComment;

            rqXml.msgBody.AlarmBody.AlarmInfo = new XML.Parser.Adapter.AlarmReportEvent.AlarmInfoType();
            rqXml.msgBody.AlarmBody.AlarmInfo.LoadPortListNo = "";
            rqXml.msgBody.AlarmBody.AlarmInfo.LoadPortID = "";
            rqXml.msgBody.AlarmBody.AlarmInfo.ChamberID = rq.ChamberId;
            rqXml.msgBody.AlarmBody.AlarmInfo.ProductID = rq.ProductId;
            rqXml.msgBody.AlarmBody.AlarmInfo.LotID = rq.LotId;
            rqXml.msgBody.AlarmBody.AlarmInfo.FoupId = rq.FoupId;
            rqXml.msgBody.AlarmBody.AlarmInfo.PlanId = rq.PlanId;
            rqXml.msgBody.AlarmBody.AlarmInfo.AlarmDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            rqXml.msgBody.AlarmBody.AlarmInfo.AlarmDescription = rq.AlarmDescription;
            rqXml.msgBody.AlarmBody.AlarmInfo.Priority = rq.Priority;
            rqXml.msgBody.AlarmBody.AlarmInfo.AlarmLevel = "";
            rqXml.msgBody.AlarmBody.AlarmInfo.TimeInterval = "";
            rqXml.msgBody.AlarmBody.AlarmInfo.ErrorCode = rq.ErrorCode;
            rqXml.msgBody.AlarmBody.AlarmInfo.ExtendInfos = new XML.Parser.Adapter.AlarmReportEvent.ExtendInfosType();
            rqXml.msgBody.AlarmBody.AlarmInfo.ExtendInfos.ruleType = rq.RuleType;
            rqXml.msgBody.AlarmBody.AlarmInfo.ExtendInfos.equipmentId = rq.ToolID;
            rqXml.msgBody.AlarmBody.AlarmInfo.ExtendInfos.internalPriority = rq.InternalPriority;
            rqXml.msgBody.AlarmBody.AlarmInfo.ExtendInfos.system = rq.SystemID;
            rqXml.msgBody.AlarmBody.AlarmInfo.ExtendInfos.subSystem = rq.SubSystem;
            rqXml.msgBody.AlarmBody.AlarmInfo.ExtendInfos.@event = rq.EventName;
            rqXml.msgBody.AlarmBody.AlarmInfo.ExtendInfos.txnTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            rqXml.msgBody.AlarmBody.ReturnStatus = "OK";
            rqXml.msgBody.AlarmBody.Comment = "";

            rqXml.msgBody.AlarmReturn.ReturnCode = "";
            rqXml.msgBody.AlarmReturn.ReturnMessage = "";
            return rqXml;
        }

        public static XmlSpec BuildRandomQuery2Xml(StructureBase structureBase)
        {
            RandomQuery rq = (RandomQuery)structureBase;

            EIS.XML.Parser.Adapter.RandomQuery.msgType rqXml = new EIS.XML.Parser.Adapter.RandomQuery.msgType();
            rqXml.SetSpecType( XmlSpecType.RandomQuery);

            rqXml.rvHeader = new EIS.XML.Parser.Adapter.RandomQuery.rvHeaderType();
            rqXml.msgHeader = new EIS.XML.Parser.Adapter.RandomQuery.msgHeaderType();
            rqXml.msgBody = new EIS.XML.Parser.Adapter.RandomQuery.msgBodyType();

            rqXml.msgBody.eqpId = rq.ToolId;
            rqXml.msgBody.fabName = rq.FabName;
            rqXml.msgBody.vidInfo = new List<XML.Parser.Adapter.RandomQuery.vidInfoType>();

            int k = rq.VIDNames == null ? 0 : rq.VIDNames.Count();
            rqXml.msgBody.vidInfoNo = k+ "";
            for (int i = 0; i < k; i++)
            {
                XML.Parser.Adapter.RandomQuery.vidInfoType vid = new XML.Parser.Adapter.RandomQuery.vidInfoType();
                vid.name = rq.VIDNames[i];
                vid.vid = rq.VIDChannels[i];
                vid.xPath = "";
                rqXml.msgBody.vidInfo.Add(vid);
            }

            //make the MsgHeader 
            //MessageHelperYmtc.MakeMsgHeader(args.xmlSpec, domain, SourceApplication.R2R.ToString(), ServiceMethod.RandomQuery.ToString(), txId);

            return rqXml;
        }

        public static XmlSpec BuildQueryLotInfo2Xml(StructureBase structureBase)
        {
            QueryLotInfo rq = (QueryLotInfo)structureBase;

            EIS.XML.Parser.Adapter.QueryLotInfo.msgType rqXml = new EIS.XML.Parser.Adapter.QueryLotInfo.msgType();
            rqXml.SetSpecType(XmlSpecType.QueryLotInfo);

            rqXml.rvHeader = new EIS.XML.Parser.Adapter.QueryLotInfo.rvHeaderType();
            rqXml.msgHeader = new EIS.XML.Parser.Adapter.QueryLotInfo.msgHeaderType();
            rqXml.msgBody = new EIS.XML.Parser.Adapter.QueryLotInfo.msgBodyType();


            rqXml.msgBody.fabName = rq.FabName;
            rqXml.msgBody.lotId = rq.LotId;
            //make the MsgHeader 
            //MessageHelperYmtc.MakeMsgHeader(args.xmlSpec, domain, SourceApplication.R2R.ToString(), ServiceMethod.RandomQuery.ToString(), txId);

            return rqXml;
        }


        public static XmlSpec BuilBSReqHoldLot2Xml(StructureBase structureBase)
        {
            BSReqHoldLot hold = (BSReqHoldLot)structureBase;

            EIS.XML.Parser.Adapter.BSReqHoldLot.msgType rqXml = new EIS.XML.Parser.Adapter.BSReqHoldLot.msgType();
            rqXml.SetSpecType(XmlSpecType.BSReqHoldLot);

            rqXml.rvHeader = new EIS.XML.Parser.Adapter.BSReqHoldLot.rvHeaderType();
            rqXml.msgHeader = new EIS.XML.Parser.Adapter.BSReqHoldLot.msgHeaderType();
            rqXml.msgBody = new EIS.XML.Parser.Adapter.BSReqHoldLot.msgBodyType();

            rqXml.msgBody.userId = hold.UserId;
            rqXml.msgBody.SpecialHoldFlag = hold.SpecialHoldFlag;
            rqXml.msgBody.lotListNo = "1";
            rqXml.msgBody.lotList = new List<XML.Parser.Adapter.BSReqHoldLot.lotListType>();
            XML.Parser.Adapter.BSReqHoldLot.lotListType lot = new XML.Parser.Adapter.BSReqHoldLot.lotListType();
            lot.lotId = hold.LotId;
            lot.briefDesc = hold.BriefDesc;
            lot.detailDesc = hold.DetailDesc;
            rqXml.msgBody.lotList.Add(lot);

            //make the MsgHeader 
            //MessageHelperYmtc.MakeMsgHeader(args.xmlSpec, domain, SourceApplication.R2R.ToString(), ServiceMethod.RandomQuery.ToString(), txId);

            return rqXml;
        }

        public static XmlSpec BuilR2RReqHoldLot2Xml(StructureBase structureBase)
        {
            R2RReqHoldLot hold = (R2RReqHoldLot)structureBase;

            EIS.XML.Parser.Adapter.R2RReqHoldLot.msgType rqXml = new EIS.XML.Parser.Adapter.R2RReqHoldLot.msgType();
            rqXml.SetSpecType(XmlSpecType.R2RReqHoldLot);

            rqXml.rvHeader = new EIS.XML.Parser.Adapter.R2RReqHoldLot.rvHeaderType();
            rqXml.msgHeader = new EIS.XML.Parser.Adapter.R2RReqHoldLot.msgHeaderType();
            rqXml.msgBody = new EIS.XML.Parser.Adapter.R2RReqHoldLot.msgBodyType();

            rqXml.msgBody.userId = hold.UserId;
            rqXml.msgBody.eqpId = hold.EqpId;
            rqXml.msgBody.lotListNo = "1";
            rqXml.msgBody.lotList = new List<XML.Parser.Adapter.R2RReqHoldLot.lotListType>();
            XML.Parser.Adapter.R2RReqHoldLot.lotListType lot = new XML.Parser.Adapter.R2RReqHoldLot.lotListType();
            lot.lotId = hold.LotId;
            lot.reasonCode = hold.ReasonCode;
            lot.txnComment = hold.TxnComment;
            rqXml.msgBody.lotList.Add(lot);

            //make the MsgHeader 
            //MessageHelperYmtc.MakeMsgHeader(args.xmlSpec, domain, SourceApplication.R2R.ToString(), ServiceMethod.RandomQuery.ToString(), txId);

            return rqXml;
        }

        //here to male the xml spec MsgHeader to primary send out via Tibco
        public static bool MakeMsgHeader(XmlSpec xmlSpec, string domain, string timeOut,string sourceSystem, string srvMethod, string txId)
        {
            bool result = false;
            switch (xmlSpec.GetSpecType())
            {
                case XmlSpecType.RandomQuery:
                    EIS.XML.Parser.Adapter.RandomQuery.msgType rqXml = (EIS.XML.Parser.Adapter.RandomQuery.msgType)xmlSpec;
                    rqXml.msgHeader.srvAddr = "";
                    rqXml.msgHeader.reqAddr = domain + "." + System.Net.Dns.GetHostName()+".RandomQuery."+DateTime.Now.ToString("yyyyMMddHHmmss");//"";
                    rqXml.msgHeader.msgOwner = System.Net.Dns.GetHostName() + "." + System.Threading.Thread.CurrentThread.ManagedThreadId.ToString();
                    rqXml.msgHeader.srvMethod = srvMethod;
                    rqXml.msgHeader.srvId = sourceSystem;
                    rqXml.msgHeader.timeStamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    rqXml.msgHeader.timeOut = timeOut;
                    rqXml.msgHeader.txId = txId;
                    rqXml.msgHeader.locale = "EN";
                    rqXml.msgHeader.retCode = "0";
                    rqXml.msgHeader.retMsg = "";

                    result = true;

                    break;

                case XmlSpecType.AlarmReportEvent:
                    EIS.XML.Parser.Adapter.AlarmReportEvent.msgType armXml = (EIS.XML.Parser.Adapter.AlarmReportEvent.msgType)xmlSpec;
                    armXml.msgHeader.srvAddr = "";
                    armXml.msgHeader.reqAddr = domain + "." + System.Net.Dns.GetHostName()+".AlarmMessage."+DateTime.Now.ToString("yyyyMMddHHmmss");//"";
                    armXml.msgHeader.msgOwner = System.Net.Dns.GetHostName()+"."+System.Threading.Thread.CurrentThread.ManagedThreadId.ToString();
                    armXml.msgHeader.srvMethod = srvMethod;
                    armXml.msgHeader.srvId = sourceSystem;
                    armXml.msgHeader.timeStamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    armXml.msgHeader.timeOut = timeOut;
                    armXml.msgHeader.txId = txId;
                    armXml.msgHeader.locale = "EN";
                    armXml.msgHeader.retCode = "0";
                    armXml.msgHeader.retMsg = "";

                    result = true;
                    break;

                case XmlSpecType.QueryLotInfo:
                    EIS.XML.Parser.Adapter.QueryLotInfo.msgType lotXml = (EIS.XML.Parser.Adapter.QueryLotInfo.msgType)xmlSpec;
                    lotXml.msgHeader.srvAddr = "";
                    lotXml.msgHeader.reqAddr = domain + "." + System.Net.Dns.GetHostName() + ".QueryLotInfo." + DateTime.Now.ToString("yyyyMMddHHmmss");//"";
                    lotXml.msgHeader.msgOwner = System.Net.Dns.GetHostName() + "." + System.Threading.Thread.CurrentThread.ManagedThreadId.ToString();
                    lotXml.msgHeader.srvMethod = srvMethod;
                    lotXml.msgHeader.srvId = sourceSystem;
                    lotXml.msgHeader.timeStamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    lotXml.msgHeader.timeOut = timeOut;
                    lotXml.msgHeader.txId = txId;
                    lotXml.msgHeader.locale = "EN";
                    lotXml.msgHeader.retCode = "0";
                    lotXml.msgHeader.retMsg = "";

                    result = true;
                    break;

                case XmlSpecType.BSReqHoldLot:
                    EIS.XML.Parser.Adapter.BSReqHoldLot.msgType holdXml = (EIS.XML.Parser.Adapter.BSReqHoldLot.msgType)xmlSpec;
                    holdXml.msgHeader.srvAddr = "";
                    holdXml.msgHeader.reqAddr = domain + "." + System.Net.Dns.GetHostName() + ".BSReqHoldLot." + DateTime.Now.ToString("yyyyMMddHHmmss");//"";
                    holdXml.msgHeader.msgOwner = System.Net.Dns.GetHostName() + "." + System.Threading.Thread.CurrentThread.ManagedThreadId.ToString();
                    holdXml.msgHeader.srvMethod = srvMethod;
                    holdXml.msgHeader.srvId = sourceSystem;
                    holdXml.msgHeader.timeStamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    holdXml.msgHeader.timeOut = timeOut;
                    holdXml.msgHeader.txId = txId;
                    holdXml.msgHeader.locale = "EN";
                    holdXml.msgHeader.retCode = "0";
                    holdXml.msgHeader.retMsg = "";

                    result = true;
                    break;

                case XmlSpecType.R2RReqHoldLot:
                    EIS.XML.Parser.Adapter.R2RReqHoldLot.msgType hold1Xml = (EIS.XML.Parser.Adapter.R2RReqHoldLot.msgType)xmlSpec;
                    hold1Xml.msgHeader.srvAddr = "";
                    hold1Xml.msgHeader.reqAddr = domain + "." + System.Net.Dns.GetHostName() + ".R2RReqHoldLot." + DateTime.Now.ToString("yyyyMMddHHmmss");//"";
                    hold1Xml.msgHeader.msgOwner = System.Net.Dns.GetHostName() + "." + System.Threading.Thread.CurrentThread.ManagedThreadId.ToString();
                    hold1Xml.msgHeader.srvMethod = srvMethod;
                    hold1Xml.msgHeader.srvId = sourceSystem;
                    hold1Xml.msgHeader.timeStamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    hold1Xml.msgHeader.timeOut = timeOut;
                    hold1Xml.msgHeader.txId = txId;
                    hold1Xml.msgHeader.locale = "EN";
                    hold1Xml.msgHeader.retCode = "0";
                    hold1Xml.msgHeader.retMsg = "";

                    result = true;
                    break;
                default:
                    break;
            }

            return result;
        }
    }
}

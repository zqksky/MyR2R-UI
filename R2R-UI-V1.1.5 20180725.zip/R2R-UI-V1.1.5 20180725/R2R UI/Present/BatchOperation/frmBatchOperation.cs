﻿using R2R_UI.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace R2R_UI.Present.BatchOperation
{
    public partial class frmBatchOperation : Form
    {
        #region
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x0014) // 禁掉清除背景消息
                return;
            base.WndProc(ref m);
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x02000000;
                return cp;
            }
        }

        private void CtlDoubleBuffer()
        {
            this.DoubleBuffered = true;//设置本窗体
            SetStyle(ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true); // 禁止擦除背景.
            SetStyle(ControlStyles.DoubleBuffer, true); // 双缓冲
            //SetStyle(ControlStyles.DoubleBuffer | ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint, true);
            UpdateStyles();
        }
        #endregion

        public frmBatchOperation()
        {
            InitializeComponent();
        }
        public frmBatchOperation(string strFrmServiceAddres, string strCurrentUserName, string strCurrentPwd, string strFrmArea)
        {
            InitializeComponent();

            strArea = strFrmArea;
            strServiceAddress = strFrmServiceAddres;
            strUserName = strCurrentUserName;
            strPassword = strCurrentPwd;
        }
        public frmBatchOperation(string strFrmServiceAddres, string strCurrentUserName, string strCurrentPwd, string strFrmArea,string strFrmProduct,string strFrmLayer,string strFrmTool)
        {
            InitializeComponent();

            strArea = strFrmArea;
            strServiceAddress = strFrmServiceAddres;
            strUserName = strCurrentUserName;
            strPassword = strCurrentPwd;
            strProduct = strFrmProduct;
            strLayer = strFrmLayer;
            strTool = strFrmTool;
        }

        #region Param
        string strArea;
        string strServiceAddress;
        string strUserName;
        string strPassword;

        string strProduct;
        string strLayer;
        string strTool;

        string strCurrentProduct;
        string strCurrentLayer;
        string strCurrentTool;
        List<string> strListProduct = new List<string>();
        List<string> strListLayer = new List<string>();
        List<string> strListTool = new List<string>();

        UIServiceFun.structPH_OVL_Batch_GetContexts structData = new UIServiceFun.structPH_OVL_Batch_GetContexts();
        #endregion

        private float frmLocationX;
        private float frmLocationY;
        AdaptiveSizeResolution AutoSizeFrm = new AdaptiveSizeResolution();
        private void frmBatchOperation_Load(object sender, EventArgs e)
        {
            #region 双缓冲
            CtlDoubleBuffer();
            #endregion

            #region AdaptiveSizeResolution
            //AutoSizeFrm.ControllInitializeSize(this);
            #endregion

            #region  AdaptiveSize
            //this.Resize += new EventHandler(frmBatchOperation_Resize);
            //frmLocationX = this.Width;
            //frmLocationY = this.Height;
            //AdaptiveSize.setTag(this);
            #endregion

            #region Init Lbl
            string strLbl = "This is part of UVL UI-Batch Operations";
            AddControlHelp.SetLable(panLbl, lblContext, strLbl);
            #endregion

            #region Init Cmb
            strListProduct = UIServiceFun.R2R_UI_PH_OVL_Batch_GetProducts(strServiceAddress, strArea);
            cmbProduct.DataSource = strListProduct;

            //cmbProduct.Focus();//can not
            //BeginInvoke((MethodInvoker)delegate { cmbProduct.Focus(); });
            ActiveControl = cmbProduct;
            #endregion

        }

        private void frmBatchOperation_Resize(object sender, EventArgs e)
        {
            #region AdaptiveSize
            //float newx = (this.Width) / frmLocationX;
            //float newy = this.Height / frmLocationY;
            //AdaptiveSize.setControls(newx, newy, this);
            #endregion
        }

        private void frmBatchOperation_SizeChanged(object sender, EventArgs e)
        {
            #region AdaptiveSizeResolution
            //AutoSizeFrm.ControlAutoSize(this);
            #endregion
        }

        private void btnOVLModel_Click(object sender, EventArgs e)
        {
            #region PH_OVL_Batch_GetOVLModel
            UIServiceFun.structPH_OVL_Batch_GetOVLModel structDataNull = new UIServiceFun.structPH_OVL_Batch_GetOVLModel();
            UIServiceFun.structPH_OVL_Batch_GetOVLModel structData = new UIServiceFun.structPH_OVL_Batch_GetOVLModel();
            structData = UIServiceFun.R2R_UI_PH_OVL_Batch_GetOVLModel(strServiceAddress, strCurrentProduct, strCurrentLayer, strCurrentTool);
            #endregion

            if (structData.Equals(structDataNull))
            {
                //MessageBox.Show("Data is empty!");
            }
            else
            {
                #region
                frmBatchOVLModel frm = new frmBatchOVLModel(strServiceAddress, strUserName, strPassword, strCurrentProduct, strCurrentLayer, strCurrentTool, structData);
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    //MessageBox.Show(frm.ovlMode.ToString() + " " + frm.bCPE.ToString());
                }
                else
                {

                }
                #endregion
            }
        }

        private void btnR2RMode_Click(object sender, EventArgs e)
        {
            #region PH_OVL_Batch_R2RMode
            UIServiceFun.structPH_OVL_Batch_GetR2RMode structDataNull = new UIServiceFun.structPH_OVL_Batch_GetR2RMode();
            UIServiceFun.structPH_OVL_Batch_GetR2RMode structData = new UIServiceFun.structPH_OVL_Batch_GetR2RMode();
            structData = UIServiceFun.R2R_UI_PH_OVL_Batch_GetR2RMode(strServiceAddress, strCurrentProduct, strCurrentLayer, strCurrentTool);
            #endregion

            if (structData.Equals(structDataNull))
            {
                //MessageBox.Show("Data is empty!");
            }
            else
            {
                frmBatchR2RMode frm = new frmBatchR2RMode(strServiceAddress, strUserName, strPassword, strCurrentProduct, strCurrentLayer, strCurrentTool, structData);
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    //MessageBox.Show(frm.strListCurrent[0]);
                }
                else
                {

                }
            }
        }

        private void btnPMOffset_Click(object sender, EventArgs e)
        {
            #region PH_OVL_Batch_GetPMOffsets
            UIServiceFun.structPH_OVL_Batch_GetPMOffsets structDataNull = new UIServiceFun.structPH_OVL_Batch_GetPMOffsets();
            UIServiceFun.structPH_OVL_Batch_GetPMOffsets structData = new UIServiceFun.structPH_OVL_Batch_GetPMOffsets();
            structData = UIServiceFun.R2R_UI_PH_OVL_Batch_GetPMOffsets(strServiceAddress, strCurrentTool);
            #endregion

            if (structData.Equals(structDataNull))
            {
                //MessageBox.Show("Data is empty!");
            }
            else
            {
                frmBatchPMOffset frm = new frmBatchPMOffset(strServiceAddress, strUserName, strPassword, strCurrentTool, structData);
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    //MessageBox.Show(frm.strListCurrent[0]);
                }
                else
                {

                }
            }
        }

        private void cmbContext_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox cmb = (ComboBox)sender;
            string strCmbName = cmb.Name;
            switch (strCmbName)
            {
                case "cmbProduct":
                    cmbLayer.DataSource = null;
                    cmbTool.DataSource = null;
                    strCurrentProduct = cmbProduct.Text.ToString();
                    if (cmbProduct.Text.ToString().Equals(""))
                    {
                    }
                    else
                    {
                        strListLayer = UIServiceFun.R2R_UI_PH_OVL_Batch_GetLayers(strServiceAddress, strCurrentProduct);
                        cmbLayer.DataSource = strListLayer;
                    }
                    break;
                case "cmbLayer":
                    cmbTool.DataSource = null;
                    if (cmbProduct.Text.ToString().Equals("") || cmbLayer.Text.ToString().Equals(""))
                    {
                    }
                    else
                    {
                        strCurrentProduct = cmbProduct.Text.ToString();
                        strCurrentLayer = cmbLayer.Text.ToString();
                        strListTool = UIServiceFun.R2R_UI_PH_OVL_Batch_GetTools(strServiceAddress, strCurrentProduct, strCurrentLayer);
                        cmbTool.DataSource = strListTool;
                        strCurrentTool = cmbTool.Text.ToString();
                    }
                    break;
                case "cmbTool":
                    if (cmbProduct.Text.ToString().Equals("") || cmbLayer.Text.ToString().Equals(""))
                    {
                    }
                    else
                    {
                        strCurrentProduct = cmbProduct.Text.ToString();
                        strCurrentLayer = cmbLayer.Text.ToString();
                        strCurrentTool = cmbTool.Text.ToString();
                    }
                    break;
                default:
                    break;
            }
        }

        private void cmbContext_SelectedValueChanged(object sender, EventArgs e)
        {

        }

        private void cmbProduct_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbLayer.DataSource = null;
            cmbTool.DataSource = null;
            cmbProduct.Text = strProduct;
            strCurrentProduct = cmbProduct.Text.ToString();
            if (cmbProduct.Text.ToString().Equals(""))
            {
            }
            else
            {
                strListLayer = UIServiceFun.R2R_UI_PH_OVL_Batch_GetLayers(strServiceAddress, strCurrentProduct);
                cmbLayer.DataSource = strListLayer;
            }
        }

        private void cmbLayer_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbTool.DataSource = null;
            if (cmbProduct.Text.ToString().Equals("") || cmbLayer.Text.ToString().Equals(""))
            {
            }
            else
            {
                cmbLayer.Text = strLayer;
                strCurrentProduct = cmbProduct.Text.ToString();
                strCurrentLayer = cmbLayer.Text.ToString();
                strListTool = UIServiceFun.R2R_UI_PH_OVL_Batch_GetTools(strServiceAddress, strCurrentProduct, strCurrentLayer);
                cmbTool.DataSource = strListTool;
                strCurrentTool = cmbTool.Text.ToString();
            }
        }

        private void cmbTool_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbProduct.Text.ToString().Equals("")|| cmbLayer.Text.ToString().Equals(""))
            {
            }
            else
            {
                cmbTool.Text = strTool;
                strCurrentProduct = cmbProduct.Text.ToString();
                strCurrentLayer=cmbLayer.Text.ToString();
                strCurrentTool = cmbTool.Text.ToString();
            }
        }
    }
}

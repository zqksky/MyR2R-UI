﻿using Microsoft.CSharp.RuntimeBinder;
using R2R_UI.Common;
using R2R_UI.Model;
using R2R_UI.Present.BatchOperation;
using R2R_UI.Present.Common;
using R2R_UI.Present.OVL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace R2R_UI
{
    public partial class frmMain : Form
    {
        #region
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x0014) // 禁掉清除背景消息
                return;
            base.WndProc(ref m);
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x02000000;
                return cp;
            }
        }

        private void CtlDoubleBuffer()
        {
            this.DoubleBuffered = true;//设置本窗体
            SetStyle(ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true); // 禁止擦除背景.
            SetStyle(ControlStyles.DoubleBuffer, true); // 双缓冲
            //SetStyle(ControlStyles.DoubleBuffer | ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint, true);
            UpdateStyles();
        }
        #endregion

        public frmMain()
        {
            #region Login 
            frmLogin frm = new frmLogin();
            if (frm.ShowDialog() != DialogResult.OK)
            {
                System.Environment.Exit(0);
            }
            //LoginFun.LoginManage(frm.strServerAddress, frm.strUserName, frm.strPassword, frm.strDomainName, false);
            strDomainName = frm.strDomainName;
            strUserName = frm.strUserName;
            strPassword = frm.strPassword;
            strServiceAddress = frm.strServerAddress;
            ////LoginFun.LoginManage("localhost","XNi160297", "Amat2018.", "amat", false);
            #endregion

            #region UIService
            strListModule = UIServiceFun.R2R_UI_GetModule(strUserName, strServiceAddress);
            #endregion

            InitializeComponent();
        }

        #region Param Define
        const string STR_VERSION = "Version: V1.1.5";
        const int OVL_LINEAR = 1;
        const int OVL_HOPC = 2;
        const int OVL_IHOPC = 3;
        const int COLUMN_CHART = 1;
        const int LINE_CHART = 2;
        const int INPUT_CHART = 1;
        const int OUTPUT_CHART = 2;

        bool bIsOVLType = false;
        bool bIsOVLCANON = false;
        bool bIsCommonType = false;
        int iRunCount;
        bool bToolVendorASML;
        bool bChuckOne;
        string strChuckId;
        string strReticleId;
        string strToolVendor;

        bool bIsActive = false;
        bool bCDIsActive = false;
        bool bFocusIsActive = false;
        string strCurrentOVLModel;
        string strCurrentR2RMode;

        bool bContextGroupNotClick = true;
        bool bContextGroupClicked = false;
        string strContextText = "Context Group:";

        string strDomainName;
        string strUserName;// = "XNi160297";
        string strPassword;
        string strServiceAddress;// = "localhost";

        string strCurrentModule = "LITHO";
        string strCurrentProduct;
        string strCurrentStage;
        string strCurrentLayer;
        string strCurrentController;
        string strCurrentTool;
        string strArea;
        string strGroup = "";

        List<string> strListCommonGroup = new List<string>();
        List<string> strListR2RContexts = new List<string>();

        List<string> strListChuckDedicationColumnName = new List<string>();
        List<string> strListChuckDedicationValue = new List<string>();

        //List<string> strListColNumTest = new List<string>() { "Module", "Product", "Layer", "Tool" };
        List<string> strListColNum = new List<string>();
        List<string> strListModule = new List<string>();
        List<string> strListProduct = new List<string>();
        List<string> strListStage = new List<string>();// { "*" };
        List<string> strListLayer = new List<string>();
        List<string> strListController = new List<string>();
        List<string> strListTool = new List<string>();

        DataTable dbLinear = new DataTable("dbLinear");
        DataTable dbHOPC = new DataTable("dbHOPC");
        DataTable dbIHOPC = new DataTable("dbIHOPC");
        DataTable dbCPE = new DataTable("dbCPE");
        DataTable dbCD = new DataTable("dbCD");
        DataTable dbFocus = new DataTable("dbFocus");

        DataTable dbCommon1 = new DataTable("dbCommon1");
        DataTable dbCommon2 = new DataTable("dbCommon2");
        DataTable dbCommon3 = new DataTable("dbCommon3");
        DataTable dbCommon4 = new DataTable("dbCommon4");
        DataTable dbCommon5 = new DataTable("dbCommon5");
        DataTable dbCommon6 = new DataTable("dbCommon6");

        List<Chart> ctlListChart = new List<Chart>();
        List<Chart> ctlListChartLinear = new List<Chart>();
        List<Chart> ctlListChartHOPC = new List<Chart>();
        List<Chart> ctlListChartIHOPC = new List<Chart>();
        List<Chart> ctlListChartCDInput = new List<Chart>();
        List<Chart> ctlListChartCDOutput = new List<Chart>();
        List<Chart> ctlListChartFocusInput = new List<Chart>();
        List<Chart> ctlListChartFocusOutput = new List<Chart>();

        List<Chart> ctlListInputChart = new List<Chart>();
        List<Chart> ctlListOutputChart = new List<Chart>();

        List<Chart> ctlListInputChart1 = new List<Chart>();
        List<Chart> ctlListOutputChart1 = new List<Chart>();

        List<Chart> ctlListInputChart2 = new List<Chart>();
        List<Chart> ctlListOutputChart2 = new List<Chart>();

        List<Chart> ctlListInputChart3 = new List<Chart>();
        List<Chart> ctlListOutputChart3 = new List<Chart>();

        List<Chart> ctlListInputChart4 = new List<Chart>();
        List<Chart> ctlListOutputChart4 = new List<Chart>();

        List<Chart> ctlListInputChart5 = new List<Chart>();
        List<Chart> ctlListOutputChart5 = new List<Chart>();

        List<Chart> ctlListInputChart6 = new List<Chart>();
        List<Chart> ctlListOutputChart6 = new List<Chart>();
        #endregion

        #region Set Param
        private void GetOVLChartParam(ref int iOutputCount, ref int iOutputStartIndex, int iOutputSize)
        {
            if (strToolVendor.Equals("ASML"))
            {
                bToolVendorASML = true;
                iOutputCount = iOutputSize / 2;

                //iOutputStartIndex = bChuckOne ? 0 : iOutputSize / 2;
                if (bChuckOne)
                {
                    iOutputStartIndex = 0;
                }
                else
                {
                    iOutputStartIndex = iOutputSize / 2;
                }
            }
            else
            {
                bToolVendorASML = false;
                iOutputCount = iOutputSize;
                iOutputStartIndex = 0;
            }
        }

        private void ClearContextParam()
        {
            strListModule.Clear();
            strListProduct.Clear();
            strListStage.Clear();
            strListLayer.Clear();
            strListController.Clear();
            strListTool.Clear();
        }
        private void ClearLithoChart()
        {
            ctlListChartLinear.Clear();
            ctlListChartHOPC.Clear();
            ctlListChartIHOPC.Clear();
            ctlListChartCDInput.Clear();
            ctlListChartCDOutput.Clear();
            ctlListChartFocusInput.Clear();
            ctlListChartFocusOutput.Clear();
        }

        private void ClearCommonChart()
        {
            ctlListInputChart1.Clear();
            ctlListInputChart2.Clear();
            ctlListInputChart3.Clear();
            ctlListInputChart4.Clear();
            ctlListInputChart5.Clear();
            ctlListInputChart6.Clear();

            ctlListOutputChart1.Clear();
            ctlListOutputChart2.Clear();
            ctlListOutputChart3.Clear();
            ctlListOutputChart4.Clear();
            ctlListOutputChart5.Clear();
            ctlListOutputChart6.Clear();
        }
        private void GetCommonChartToList(int index, List<List<Chart>> ctlListInputChartGroup, List<List<Chart>> ctlListOutputChartGroup)
        {
            ClearCommonChart();

            #region
            if (index == 1)
            {
                ctlListInputChart1 = new List<Chart>(ctlListInputChartGroup[0]);
                ctlListOutputChart1 = new List<Chart>(ctlListOutputChartGroup[0]);
            }
            else if (index == 2)
            {
                ctlListInputChart1 = new List<Chart>(ctlListInputChartGroup[0]);
                ctlListOutputChart1 = new List<Chart>(ctlListOutputChartGroup[0]);
                ctlListInputChart2 = new List<Chart>(ctlListInputChartGroup[1]);
                ctlListOutputChart2 = new List<Chart>(ctlListOutputChartGroup[1]);
            }
            else if (index == 3)
            {
                ctlListInputChart1 = new List<Chart>(ctlListInputChartGroup[0]);
                ctlListOutputChart1 = new List<Chart>(ctlListOutputChartGroup[0]);
                ctlListInputChart2 = new List<Chart>(ctlListInputChartGroup[1]);
                ctlListOutputChart2 = new List<Chart>(ctlListOutputChartGroup[1]);
                ctlListInputChart3 = new List<Chart>(ctlListInputChartGroup[2]);
                ctlListOutputChart3 = new List<Chart>(ctlListOutputChartGroup[2]);
            }
            else if (index == 4)
            {
                ctlListInputChart1 = new List<Chart>(ctlListInputChartGroup[0]);
                ctlListOutputChart1 = new List<Chart>(ctlListOutputChartGroup[0]);
                ctlListInputChart2 = new List<Chart>(ctlListInputChartGroup[1]);
                ctlListOutputChart2 = new List<Chart>(ctlListOutputChartGroup[1]);
                ctlListInputChart3 = new List<Chart>(ctlListInputChartGroup[2]);
                ctlListOutputChart3 = new List<Chart>(ctlListOutputChartGroup[2]);
                ctlListInputChart4 = new List<Chart>(ctlListInputChartGroup[3]);
                ctlListOutputChart4 = new List<Chart>(ctlListOutputChartGroup[3]);
            }
            else if (index == 5)
            {
                ctlListInputChart1 = new List<Chart>(ctlListInputChartGroup[0]);
                ctlListOutputChart1 = new List<Chart>(ctlListOutputChartGroup[0]);
                ctlListInputChart2 = new List<Chart>(ctlListInputChartGroup[1]);
                ctlListOutputChart2 = new List<Chart>(ctlListOutputChartGroup[1]);
                ctlListInputChart3 = new List<Chart>(ctlListInputChartGroup[2]);
                ctlListOutputChart3 = new List<Chart>(ctlListOutputChartGroup[2]);
                ctlListInputChart4 = new List<Chart>(ctlListInputChartGroup[3]);
                ctlListOutputChart4 = new List<Chart>(ctlListOutputChartGroup[3]);
                ctlListInputChart5 = new List<Chart>(ctlListInputChartGroup[4]);
                ctlListOutputChart5 = new List<Chart>(ctlListOutputChartGroup[4]);
            }
            else if (index == 6)
            {
                ctlListInputChart1 = new List<Chart>(ctlListInputChartGroup[0]);
                ctlListOutputChart1 = new List<Chart>(ctlListOutputChartGroup[0]);
                ctlListInputChart2 = new List<Chart>(ctlListInputChartGroup[1]);
                ctlListOutputChart2 = new List<Chart>(ctlListOutputChartGroup[1]);
                ctlListInputChart3 = new List<Chart>(ctlListInputChartGroup[2]);
                ctlListOutputChart3 = new List<Chart>(ctlListOutputChartGroup[2]);
                ctlListInputChart4 = new List<Chart>(ctlListInputChartGroup[3]);
                ctlListOutputChart4 = new List<Chart>(ctlListOutputChartGroup[3]);
                ctlListInputChart5 = new List<Chart>(ctlListInputChartGroup[4]);
                ctlListOutputChart5 = new List<Chart>(ctlListOutputChartGroup[4]);
                ctlListInputChart6 = new List<Chart>(ctlListInputChartGroup[5]);
                ctlListOutputChart6 = new List<Chart>(ctlListOutputChartGroup[5]);
            }
            #endregion
        }

        private void ClearCommonDatableList()
        {
            dbCommon1 = null;
            dbCommon2 = null;
            dbCommon3 = null;
            dbCommon4 = null;
            dbCommon5 = null;
            dbCommon6 = null;
        }
        private void GetCommonDatableList(int index, List<DataTable> dbListCommonGroup)
        {
            ClearCommonDatableList();

            #region
            if (index == 1)
            {
                dbCommon1 = dbListCommonGroup[0];
            }
            else if (index == 2)
            {
                dbCommon1 = dbListCommonGroup[0];
                dbCommon2 = dbListCommonGroup[1];
            }
            else if (index == 3)
            {
                dbCommon1 = dbListCommonGroup[0];
                dbCommon2 = dbListCommonGroup[1];
                dbCommon3 = dbListCommonGroup[2];
            }
            else if (index == 4)
            {
                dbCommon1 = dbListCommonGroup[0];
                dbCommon2 = dbListCommonGroup[1];
                dbCommon3 = dbListCommonGroup[2];
                dbCommon4 = dbListCommonGroup[3];
            }
            else if (index == 5)
            {
                dbCommon1 = dbListCommonGroup[0];
                dbCommon2 = dbListCommonGroup[1];
                dbCommon3 = dbListCommonGroup[2];
                dbCommon4 = dbListCommonGroup[3];
                dbCommon5 = dbListCommonGroup[4];
            }
            else if (index == 6)
            {
                dbCommon1 = dbListCommonGroup[0];
                dbCommon2 = dbListCommonGroup[1];
                dbCommon3 = dbListCommonGroup[2];
                dbCommon4 = dbListCommonGroup[3];
                dbCommon5 = dbListCommonGroup[4];
                dbCommon6 = dbListCommonGroup[5];
            }
            #endregion
        }
        private List<string> GetInputOrOutputChartName(int chartNum, int chartType)
        {
            List<string> strListName = new List<string>();
            for (int i = 0; i < chartNum; i++)
            {
                if (chartType == INPUT_CHART)
                {
                    strListName.Add("Input " + (i + 1));
                }
                else if (chartType == OUTPUT_CHART)
                {
                    strListName.Add("Output " + (i + 1));
                }
            }
            return strListName;
        }
        #endregion

        #region Set Control
        private void DgvDoubleBuffer()
        {
            DataGridViewHelp.DoubleBuffered(grdOptContextGroup, true);
            DataGridViewHelp.DoubleBuffered(grdOptLinear, true);
            DataGridViewHelp.DoubleBuffered(grdOptHOPC, true);
            DataGridViewHelp.DoubleBuffered(grdOptIHOPC, true);
            DataGridViewHelp.DoubleBuffered(grdOptCPE, true);
            DataGridViewHelp.DoubleBuffered(grdOptCD, true);
            DataGridViewHelp.DoubleBuffered(grdOptFocus, true);
            DataGridViewHelp.DoubleBuffered(grdOptCommon1, true);
            DataGridViewHelp.DoubleBuffered(grdOptCommon2, true);
            DataGridViewHelp.DoubleBuffered(grdOptCommon3, true);
            DataGridViewHelp.DoubleBuffered(grdOptCommon4, true);
            DataGridViewHelp.DoubleBuffered(grdOptCommon5, true);
            DataGridViewHelp.DoubleBuffered(grdOptCommon6, true);
        }

        private void InitTabSubShow()
        {
            tabOptSubTab.Visible = false;
            SetTabSubHide();
        }

        private void InitControlVisible()
        {
            btnPreLayerConfig.Visible = true;
            btnChuckDedication.Visible = true;
            btnOptBatchOperation.Visible = true;
            rdoChuck1.Visible = true;
            rdoChuck2.Visible = true;

            grpList.Visible = false;
            grpBtn.Visible = false;
            rdoLotAll.Visible = false;
            rdoMetrology.Visible = false;
            btnOptReset.Visible = false;
            btnOptMode.Visible = false;
            txtCurrentOVLMode.Visible = false;
            txtCurrentR2RMode.Visible = false;
        }

        private void InitControlEnable()
        {
            btnPreLayerConfig.Enabled = false;
            btnChuckDedication.Enabled = false;
            btnOptBatchOperation.Enabled = false;
            rdoChuck1.Enabled = false;
            rdoChuck2.Enabled = false;

            rdoLotAll.Enabled = false;
            rdoMetrology.Enabled = false;
            btnOptReset.Enabled = false;
            btnOptMode.Enabled = false;
            txtCurrentOVLMode.Enabled = false;
            txtCurrentR2RMode.Enabled = false;
        }
        private void InitControl()
        {
            bChuckOne = true;
            iRunCount = int.Parse(txtLots.Text.ToString());

            InitTabSubShow();
            InitControlVisible();
            InitControlEnable();
        }
        private void ClearGrid()
        {
            grdOptContextGroup.DataSource = null;
            ClearOVLGrid();
            ClearCommomGrid();
        }
        private void ClearOVLGrid()
        {
            grdOptLinear.DataSource = null;
            grdOptHOPC.DataSource = null;
            grdOptIHOPC.DataSource = null;
            grdOptCPE.DataSource = null;
            grdOptCD.DataSource = null;
            grdOptFocus.DataSource = null;
        }
        private void ClearCommomGrid()
        {
            grdOptCommon1.DataSource = null;
            grdOptCommon2.DataSource = null;
            grdOptCommon3.DataSource = null;
            grdOptCommon4.DataSource = null;
            grdOptCommon5.DataSource = null;
            grdOptCommon6.DataSource = null;
        }
        private void ClearChartPanel()
        {
            panOptChart.AutoScroll = false;
            panOptChart.Controls.Clear();//清空panel
            panOptChart.AutoScroll = true;
        }
        private void ClearControl()
        {
            ClearGrid();
            //ClearLithoChart();
            //ClearCommonChart();
            ClearChartPanel();
            //panOptChart.Controls.Clear();//清空panel
        }
        private void SetTextShow(string strOVLMode, string strRunMode)
        {
            txtCurrentOVLMode.Text = "Current OVL Mode:" + strOVLMode;
            txtCurrentR2RMode.Text = "Current R2R Mode:" + strRunMode;
        }
        private bool IsActive(string strR2RMode)
        {
            bool flag = false;
            if (strR2RMode.Equals("Active"))
            {
                flag = true;
            }
            else
            {
                //btnOptReset.Enabled = false;
            }
            return flag;
        }

        private string GetTextContextGroup(List<string> strList)
        {
            string strResult = "Context Group:";
            if (strList.Count > 0)
            {
                int i = 0;
                foreach (var str in strList)
                {
                    if (i < 4)
                    {
                        strResult += str + " /";
                        i++;
                    }
                }
            }
            return strResult.TrimEnd('/');
        }
        private void InitContextLable()
        {
            string strLblText = "Context Group:";
            //AddControlHelp.SetLable(panTabsubLbl, lblTabsub, strLblText);
        }

        private void SetChuckType(string strChuckId)
        {
            if (strChuckId == "C1")
            {
                //rdoChuck.CheckedIndex = 0;
                rdoChuck1.Checked = true;
            }
            else
            {
                //rdoChuck.CheckedIndex = 1;
                rdoChuck2.Checked = true;
            }
        }

        private void SetControlShow(bool flgCommon, bool flagOVL, bool flgMode, bool flgRest, bool flgActive)
        {
            SetControlVisible(flgCommon, flagOVL);
            SetControlEnable(flgCommon, flagOVL, flgMode, flgRest, flgActive);
        }
        private void SetControlVisible(bool flgCommonType, bool flgOVLType)
        {
            if (flgCommonType)
            {
                grpList.Visible = flgCommonType;
                rdoLotAll.Visible = flgCommonType;
                rdoMetrology.Visible = flgCommonType;

                txtCurrentOVLMode.Visible = false;
                txtCurrentR2RMode.Visible = flgCommonType;
            }
            else
            {
                if (flgOVLType)
                {
                    grpList.Visible = false;
                    rdoLotAll.Visible = false;
                    rdoMetrology.Visible = false;

                    txtCurrentOVLMode.Visible = flgOVLType;
                    txtCurrentR2RMode.Visible = flgOVLType;
                }
                else
                {
                    grpList.Visible = true;
                    rdoLotAll.Visible = true;
                    rdoMetrology.Visible = true;

                    txtCurrentOVLMode.Visible = false;
                    txtCurrentR2RMode.Visible = true;
                }
            }
            grpBtn.Visible = true;
            btnOptReset.Visible = true;
            btnOptMode.Visible = true;
        }

        private void SetControlEnable(bool flgCommonType, bool flgOVLType, bool flgBtnOptMode, bool flgBtnOptReset, bool flgActive)
        {
            if (flgCommonType)
            {
                btnPreLayerConfig.Enabled = false;
                btnChuckDedication.Enabled = false;
                btnOptBatchOperation.Enabled = false;
                rdoChuck1.Enabled = false;
                rdoChuck2.Enabled = false;
                //rdoList.Enabled = true;
                rdoLotAll.Enabled = true;
                rdoMetrology.Enabled = true;
            }
            else
            {
                if (flgOVLType)
                {
                    btnPreLayerConfig.Enabled = flgOVLType;
                    btnChuckDedication.Enabled = bIsOVLCANON ? false : flgOVLType;
                    btnOptBatchOperation.Enabled = flgOVLType;
                    rdoChuck1.Enabled = flgOVLType;
                    rdoChuck2.Enabled = flgOVLType;
                    //rdoList.Enabled = false;
                    rdoLotAll.Enabled = false;
                    rdoMetrology.Enabled = false;
                }
                else
                {
                    btnPreLayerConfig.Enabled = false;
                    btnChuckDedication.Enabled = false;
                    btnOptBatchOperation.Enabled = false;
                    rdoChuck1.Enabled = false;
                    rdoChuck2.Enabled = false;
                    //rdoList.Enabled = true;
                    rdoLotAll.Enabled = true;
                    rdoMetrology.Enabled = true;
                }
            }

            btnOptReset.Enabled = flgActive ? flgBtnOptReset : false;
            btnOptMode.Enabled = flgBtnOptMode;
        }

        private bool IsCommonType(string strModel)
        {
            bool bFlag = false;
            if (strModel.Equals("LITHO"))
            {
                bFlag = false;
            }
            else
            {
                bFlag = true;
            }
            return bFlag;
        }
        private string GetLayerOrStep(string strModel)
        {
            string str = "Layer";
            if (strModel.Equals("LITHO"))
            {
                str = "Layer";
            }
            else
            {
                str = "Step";
            }
            return str;
        }
        private bool IsOVLType(string strControl)
        {
            bool bFlag = true;
            if (strControl.Contains("PH_OVL"))
            {
                bFlag = true;
            }
            else
            {
                rdoChuck1.Enabled = false;
                rdoChuck2.Enabled = false;
                bFlag = false;
            }
            return bFlag;
        }
        private bool IsOVLCANON(string strControl)
        {
            bool bFlag = false;
            if (strControl.Contains("PH_OVL_CANON"))
            {
                bFlag = true;
                btnChuckDedication.Enabled = false;
            }
            else
            {
                bFlag = false;
            }
            return bFlag;
        }
        private void SetTabSubHide()
        {
            //隐藏：
            tabPage3.Parent = null;
            tabPage4.Parent = null;
            tabPage5.Parent = null;
            tabPage6.Parent = null;
            tabPage7.Parent = null;
            tabPage8.Parent = null;
            tabPage9.Parent = null;
            tabPage10.Parent = null;
            tabPage11.Parent = null;
            tabPage12.Parent = null;
            tabPage13.Parent = null;
            tabPage14.Parent = null;
        }
        private void SetTabSubShow(bool flagCommon, bool flagOVL)
        {
            tabOptSubTab.Visible = true;
            if (flagCommon)
            {
                //显示：
                tabPage9.Parent = tabOptSubTab;
            }
            else
            {
                if (flagOVL)
                {
                    tabPage3.Parent = tabOptSubTab;
                    tabPage4.Parent = tabOptSubTab;
                    tabPage5.Parent = tabOptSubTab;
                }
                else
                {
                    tabPage7.Parent = tabOptSubTab;
                    tabPage8.Parent = tabOptSubTab;
                }
            }
        }

        private void SetCommonTabSub(int iSubNum, List<string> strListSubName)
        {
            switch (iSubNum)
            {
                case 1:
                    tabPage9.Parent = tabOptSubTab;
                    tabPage9.Text = strListSubName[0];
                    tabPage10.Parent = null;
                    tabPage11.Parent = null;
                    tabPage12.Parent = null;
                    tabPage13.Parent = null;
                    tabPage14.Parent = null;
                    break;
                case 2:
                    tabPage9.Parent = tabOptSubTab;
                    tabPage10.Parent = tabOptSubTab;
                    tabPage9.Text = strListSubName[0];
                    tabPage10.Text = strListSubName[1];
                    tabPage11.Parent = null;
                    tabPage12.Parent = null;
                    tabPage13.Parent = null;
                    tabPage14.Parent = null;
                    break;
                case 3:
                    tabPage9.Parent = tabOptSubTab;
                    tabPage10.Parent = tabOptSubTab;
                    tabPage11.Parent = tabOptSubTab;
                    tabPage9.Text = strListSubName[0];
                    tabPage10.Text = strListSubName[1];
                    tabPage11.Text = strListSubName[2];
                    tabPage12.Parent = null;
                    tabPage13.Parent = null;
                    tabPage14.Parent = null;
                    break;
                case 4:
                    tabPage9.Parent = tabOptSubTab;
                    tabPage10.Parent = tabOptSubTab;
                    tabPage11.Parent = tabOptSubTab;
                    tabPage12.Parent = tabOptSubTab;
                    tabPage9.Text = strListSubName[0];
                    tabPage10.Text = strListSubName[1];
                    tabPage11.Text = strListSubName[2];
                    tabPage12.Text = strListSubName[3];
                    tabPage13.Parent = null;
                    tabPage14.Parent = null;
                    break;
                case 5:
                    tabPage9.Parent = tabOptSubTab;
                    tabPage10.Parent = tabOptSubTab;
                    tabPage11.Parent = tabOptSubTab;
                    tabPage12.Parent = tabOptSubTab;
                    tabPage13.Parent = tabOptSubTab;
                    tabPage9.Text = strListSubName[0];
                    tabPage10.Text = strListSubName[1];
                    tabPage11.Text = strListSubName[2];
                    tabPage12.Text = strListSubName[3];
                    tabPage13.Text = strListSubName[4];
                    tabPage14.Parent = null;
                    break;
                case 6:
                    tabPage9.Parent = tabOptSubTab;
                    tabPage10.Parent = tabOptSubTab;
                    tabPage11.Parent = tabOptSubTab;
                    tabPage12.Parent = tabOptSubTab;
                    tabPage13.Parent = tabOptSubTab;
                    tabPage14.Parent = tabOptSubTab;
                    tabPage9.Text = strListSubName[0];
                    tabPage10.Text = strListSubName[1];
                    tabPage11.Text = strListSubName[2];
                    tabPage12.Text = strListSubName[3];
                    tabPage13.Text = strListSubName[4];
                    tabPage14.Text = strListSubName[5];
                    break;
                default:
                    break;
            }
            tabOptSubTab.Refresh();
        }

        public DataTable dbChuckDeditation = new DataTable();
        private void InitDbChuckDeditation(DataTable db, int rowIndex)
        {
            if (rowIndex >= 0)
            {
                strListChuckDedicationValue.Clear();
                strListChuckDedicationColumnName.Clear();
                for (int i = 0; i < db.Columns.Count; i++)
                {

                    strListChuckDedicationValue.Add(grdOptContextGroup.Rows[rowIndex].Cells[i].Value.ToString());

                }
                foreach (DataColumn dc in dbGetContext.Columns)
                {
                    strListChuckDedicationColumnName.Add(dc.ColumnName.ToString());
                }
                dbChuckDeditation = DataTableHelp.CreateChuckDedicationTable(strListChuckDedicationColumnName, strListChuckDedicationValue);
            }
        }
        #endregion

        private float frmLocationX;
        private float frmLocationY;
        AdaptiveSizeResolution AutoSizeFrm = new AdaptiveSizeResolution();
        private void frmMain_Load(object sender, EventArgs e)
        {
            #region test
            //frmTest frm = new frmTest();
            //frm.ShowDialog();
            #endregion

            #region 双缓冲
            DgvDoubleBuffer();
            CtlDoubleBuffer();
            #endregion

            #region AdaptiveSizeResolution
            //AutoSizeFrm.ControllInitializeSize(this);
            #endregion

            #region  AdaptiveSize
            //this.Resize += new EventHandler(frmMain_Resize);
            //frmLocationX = this.Width;
            //frmLocationY = this.Height;
            //AdaptiveSize.setTag(this);
            #endregion

            #region Version Control
            statusStrip1.Items[0].Text = STR_VERSION;
            statusStrip1.Items[1].Text = DateTime.Now.ToString("HH:mm:ss");
            statusStrip1.Items[2].Text = DateTime.Now.Year.ToString() + "/" + DateTime.Now.ToString("MM/dd");
            #endregion

            #region Init Control
            tabPage2.Parent = null;
            InitControl();
            cmbModule.DataSource = strListModule;
            AddControlHelp.SetLable(panContextGroupLbl, lblContextGroup, "List of Context Group");
            #endregion
        }

        private void frmMain_Resize(object sender, EventArgs e)
        {
            #region AdaptiveSize
            //float newx = (this.Width) / frmLocationX;
            //float newy = this.Height / frmLocationY;
            //AdaptiveSize.setControls(newx, newy, this);
            #endregion
        }

        private void frmMain_SizeChanged(object sender, EventArgs e)
        {
            #region AdaptiveSizeResolution
            //AutoSizeFrm.ControlAutoSize(this);
            #endregion
        }

        #region CtlChart Event
        private void chart_DataClicked(object sender, EventArgs e)
        {
            //MessageBox.Show(e.DataValue.ToString());
        }
        private void chart_InputDataClicked(object sender, EventArgs e)
        {
            //MessageBox.Show(e.DataValue.ToString());
        }
        private void chart_OutputDataClicked(object sender, EventArgs e)
        {
            //MessageBox.Show(e.DataValue.ToString());
        }

        private void OVLChartClick(List<Chart> ctlChart)
        {
            if (ctlChart.Count > 0)
            {
                for (int i = 0; i < ctlChart.Count; i++)
                {
                    ctlChart[i].Click += chart_DataClicked;
                }
            }
        }
        private void InputChartClick(List<Chart> ctlInputChart)
        {
            if (ctlInputChart.Count > 0)
            {
                for (int i = 0; i < ctlInputChart.Count; i++)
                {
                    //ctlInputChart[i].Click += chart_InputDataClicked;
                }
            }
        }
        private void OutputChartClick(List<Chart> ctlOutputChart)
        {
            if (ctlOutputChart.Count > 0)
            {
                for (int i = 0; i < ctlOutputChart.Count; i++)
                {
                    //ctlOutputChart[i].Click += chart_OutputDataClicked;
                }
            }
        }

        private void CommonCtlChartClick()
        {
            InputChartClick(ctlListInputChart1);
            InputChartClick(ctlListInputChart2);
            InputChartClick(ctlListInputChart3);
            InputChartClick(ctlListInputChart4);
            InputChartClick(ctlListInputChart5);
            InputChartClick(ctlListInputChart6);

            OutputChartClick(ctlListOutputChart1);
            OutputChartClick(ctlListOutputChart2);
            OutputChartClick(ctlListOutputChart3);
            OutputChartClick(ctlListOutputChart4);
            OutputChartClick(ctlListOutputChart5);
            OutputChartClick(ctlListOutputChart6);
        }
        #endregion

        #region txtLots Event 
        private string strRunCount = "20";
        private string strPattern = @"^[0-9]*$";//只允许输入数字
        private void txtLots_TextChanged(object sender, EventArgs e)
        {
            Match m = Regex.Match(this.txtLots.Text, strPattern);   // 匹配正则表达式

            if (!m.Success)   // 输入的不是数字
            {
                this.txtLots.Text = strRunCount;   // textBox内容不变

                // 将光标定位到文本框的最后
                this.txtLots.SelectionStart = this.txtLots.Text.Length;
                //MessageBox.Show("Please input a number!");
            }
            else   // 输入的是数字
            {
                strRunCount = this.txtLots.Text;   // 将现在textBox的值保存下来
            }
        }

        private void txtLots_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)//如果输入的是回车键
            {
                this.btnOptRun_Click(sender, e);//触发button事件
            }
        }
        #endregion

        #region rdo Event
        private void rdoChuck_CheckedChanged(object sender, EventArgs e)
        {
            ClearOVLGrid();
            if (rdoChuck1.Checked)
            {
                bChuckOne = true;
                strChuckId = "C1";
                //MessageBox.Show("chuck1");
            }
            else if (rdoChuck2.Checked)
            {
                bChuckOne = false;
                strChuckId = "C2";
                //MessageBox.Show("chuck2");
            }
            if (bContextGroupClicked)
            {
                ClearLithoChart();
                ContextGroupDoubleClick_OVL();
            }
        }

        private void rdoChuck1_CheckedChanged(object sender, EventArgs e)
        {
            ClearOVLGrid();
            if (rdoChuck1.Checked)
            {
                bChuckOne = true;
                strChuckId = "C1";
                //MessageBox.Show("chuck1");

                if (bContextGroupClicked)
                {
                    ClearLithoChart();
                    ContextGroupDoubleClick_OVL();
                }
            }
        }

        private void rdoChuck2_CheckedChanged(object sender, EventArgs e)
        {
            ClearOVLGrid();
            if (rdoChuck2.Checked)
            {
                bChuckOne = false;
                strChuckId = "C2";
                //MessageBox.Show("chuck2");

                if (bContextGroupClicked)
                {
                    ClearLithoChart();
                    ContextGroupDoubleClick_OVL();
                }
            }
        }

        private void rdoLotList_CheckedChanged(object sender, EventArgs e)
        {
            //SetTabSubHide();
            #region
            if (rdoLotAll.Checked || rdoMetrology.Checked)
            {
                if (bIsCommonType)
                {
                    ClearCommomGrid();
                    ClearCommonChart();
                    GetLotRunHistory_Common();
                }
                else
                {
                    ClearOVLGrid();
                    ClearLithoChart();
                    GetLotRunHistory_CD();
                    GetLotRunHistory_Focus();
                }
            }
            #endregion
        }


        private void rdoLotAll_CheckedChanged(object sender, EventArgs e)
        {
            #region
            if (rdoLotAll.Checked)
            {
                if (bIsCommonType)
                {
                    ClearCommomGrid();
                    ClearCommonChart();
                    GetLotRunHistory_Common();
                }
                else
                {
                    ClearOVLGrid();
                    ClearLithoChart();
                    GetLotRunHistory_CD();
                    GetLotRunHistory_Focus();
                }
            }
            #endregion
        }

        private void rdoMetrology_CheckedChanged(object sender, EventArgs e)
        {
            #region
            if (rdoMetrology.Checked)
            {
                if (bIsCommonType)
                {
                    ClearCommomGrid();
                    ClearCommonChart();
                    GetLotRunHistory_Common();
                }
                else
                {
                    ClearOVLGrid();
                    ClearLithoChart();
                    GetLotRunHistory_CD();
                    GetLotRunHistory_Focus();
                }
            }
            #endregion
        }
        #endregion

        #region Btn Event
        DataTable dbGetContext = new DataTable("GetContext");
        private void btnOptRun_Click(object sender, EventArgs e)
        {
            rdoChuck1.Checked = true;
            if (bIsOVLType)
            {
                btnPreLayerConfig.Enabled = true;
                btnChuckDedication.Enabled = bIsOVLCANON ? false : true;
                btnOptBatchOperation.Enabled = true;

                rdoChuck1.Enabled = true;
                rdoChuck2.Enabled = true;
            }
            try
            {
                #region GetR2RContext
                iRunCount = int.Parse(txtLots.Text.ToString());
                if (cmbModule.Text.ToString().Equals("") || cmbProduct.Text.ToString().Equals("") || cmbStage.Text.ToString().Equals("") || cmbLayer.Text.ToString().Equals("") || cmbControl.Text.ToString().Equals("") || cmbTool.Text.ToString().Equals("") || iRunCount == 0)
                {
                    MessageBox.Show("The parameter cannot be empty");
                }
                else
                {
                    UIServiceFun.structGetR2RContext structR2RContextNull = new UIServiceFun.structGetR2RContext();
                    UIServiceFun.structGetR2RContext structR2RContext = new UIServiceFun.structGetR2RContext();
                    structR2RContext = UIServiceFun.R2R_UI_GetR2RContext(strServiceAddress, strCurrentProduct, strCurrentLayer, strCurrentController, strCurrentTool, iRunCount);

                    if (structR2RContext.Equals(structR2RContextNull))
                    {
                        MessageBox.Show("Data is empty!");
                    }
                    else
                    {
                        dbGetContext = DataTableHelp.CreateContextGroupTable(structR2RContext);

                        DataTable dbContextGroup = new DataTable("ContextGroup");
                        List<string> strListColumn = new List<string>(structR2RContext.strListContexts);
                        dbContextGroup = DataTableHelp.GetDistinctTable(dbGetContext, strListColumn);

                        DataGridViewHelp.InitDgvGrid(grdOptContextGroup, dbContextGroup);
                        //InitGrdOptContextGroup(structR2RContext);  

                        InitDbChuckDeditation(dbGetContext, 0);
                    }
                }
                #endregion
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }
        }

        private void btnPreLayer_Click(object sender, EventArgs e)
        {
            frmPreLayerConfig frm = new frmPreLayerConfig(strServiceAddress, strUserName, strPassword);
            frm.ShowDialog();
        }

        private void btnChuckDedication_Click(object sender, EventArgs e)
        {
            frmChuckDedication frm = new frmChuckDedication(strServiceAddress, strUserName, strPassword, dbChuckDeditation);
            frm.ShowDialog();
        }

        private void btnBatchOperation_Click(object sender, EventArgs e)
        {
            //strArea = "LITHO";
            //strPassword = "Amat2018.";
            strArea = strCurrentModule;

            //frmBatchOperation frm = new frmBatchOperation(strServiceAddress, strUserName, strPassword, strArea);
            frmBatchOperation frm = new frmBatchOperation(strServiceAddress, strUserName, strPassword, strArea,strCurrentProduct,strCurrentLayer,strCurrentTool);
            frm.ShowDialog();
        }

        private void btnOptCDModeClick()
        {
            #region PH_CD_GetDoseSettings
            UIServiceFun.structPH_CD_GetDoseSettings structSettingsNull = new UIServiceFun.structPH_CD_GetDoseSettings();
            UIServiceFun.structPH_CD_GetDoseSettings structSettings = new UIServiceFun.structPH_CD_GetDoseSettings();
            structSettings = UIServiceFun.R2R_UI_PH_CD_GetDoseSettings(strServiceAddress, strListR2RContexts);

            if (structSettings.Equals(structSettingsNull))
            {
                MessageBox.Show("Data is empty!");
            }
            else
            {
                frmCDMode frm = new frmCDMode(strServiceAddress, strUserName, strPassword, strListR2RContexts, structSettings);
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    //MessageBox.Show(frm.strListCurrent[0]);
                }
                else
                {

                }
            }
            #endregion
        }

        private void btnOptCommonModeClick()
        {
            #region R2R_UI_COMMON_GetInputSettings
            UIServiceFun.structCOMMON_GetInputSettings structCommonInputSettingNull = new UIServiceFun.structCOMMON_GetInputSettings();
            UIServiceFun.structCOMMON_GetInputSettings structCommonInputSetting = new UIServiceFun.structCOMMON_GetInputSettings();
            structCommonInputSetting = UIServiceFun.R2R_UI_COMMON_GetInputSettings(strServiceAddress, strCurrentController, strGroup, strListR2RContexts);

            if (structCommonInputSetting.Equals(structCommonInputSettingNull))
            {
                MessageBox.Show("Data is empty!");
            }
            else
            {
                frmCommonMode frm = new frmCommonMode(strServiceAddress, strUserName, strPassword, strCurrentController, strGroup, strListR2RContexts, structCommonInputSetting);
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    //MessageBox.Show(frm.strListCurrent[0]);
                }
                else
                {

                }
            }
            #endregion
        }
        private void btnOptMode_Click(object sender, EventArgs e)
        {
            #region
            string strTabName = tabOptSubTab.SelectedTab.Name;
            switch (strTabName)
            {
                case "tabPage3":
                    break;
                case "tabPage7":
                    btnOptCDModeClick();
                    break;
                case "tabPage9":
                    strGroup = tabPage9.Text.ToString();
                    btnOptCommonModeClick();
                    break;
                case "tabPage10":
                    strGroup = tabPage10.Text.ToString();
                    btnOptCommonModeClick();
                    break;
                case "tabPage11":
                    strGroup = tabPage11.Text.ToString();
                    btnOptCommonModeClick();
                    break;
                case "tabPage12":
                    strGroup = tabPage12.Text.ToString();
                    btnOptCommonModeClick();
                    break;
                case "tabPage13":
                    strGroup = tabPage13.Text.ToString();
                    btnOptCommonModeClick();
                    break;
                case "tabPage14":
                    strGroup = tabPage14.Text.ToString();
                    btnOptCommonModeClick();
                    break;
                default:
                    break;
            }
            #endregion
        }
        private void btnOptOVLResetClick()
        {
            #region PH_OVL_GetResetValues
            UIServiceFun.structPH_OVL_GetResetValues structResetValuesNull = new UIServiceFun.structPH_OVL_GetResetValues();
            UIServiceFun.structPH_OVL_GetResetValues structResetValues = new UIServiceFun.structPH_OVL_GetResetValues();
            structResetValues = UIServiceFun.R2R_UI_PH_OVL_GetResetValues(strServiceAddress, strCurrentController, strListR2RContexts, strCurrentOVLModel, strCurrentR2RMode);

            if (structResetValues.Equals(structResetValuesNull))
            {
                MessageBox.Show("Data is empty!");
            }
            else
            {
                //frmLinearReset frm = new frmLinearReset(strServiceAddres, strCurrentController, strListR2RContexts, strCurrentOVLModel, strCurrentR2RMode, structResetValues);
                frmOVLReset frm = new frmOVLReset(strServiceAddress, strUserName, strPassword, strCurrentController, strListR2RContexts, strCurrentOVLModel, strCurrentR2RMode, structResetValues);
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    //MessageBox.Show(frm.strListCurrent[0]);
                }
                else
                {

                }
            }
            #endregion
        }
        private void btnOptCDResetClick()
        {
            #region PH_CD_GetDoseResetSettings
            UIServiceFun.structPH_CD_GetDoseResetSettings structResetSettingsNull = new UIServiceFun.structPH_CD_GetDoseResetSettings();
            UIServiceFun.structPH_CD_GetDoseResetSettings structResetSettings = new UIServiceFun.structPH_CD_GetDoseResetSettings();
            structResetSettings = UIServiceFun.R2R_UI_PH_CD_GetDoseResetSettings(strServiceAddress, strListR2RContexts);

            if (structResetSettings.Equals(structResetSettingsNull))
            {
                MessageBox.Show("Data is empty!");
            }
            else
            {
                frmCDReset frm = new frmCDReset(strServiceAddress, strUserName, strPassword, strListR2RContexts, structResetSettings);
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    //MessageBox.Show(frm.strListCurrent[0]);
                }
                else
                {

                }
            }
            #endregion
        }

        private void btnOptFocusResetClick()
        {
            #region R2R_UI_PH_Focus_GetFocusSettings
            double dValue = 0.0;
            dValue = UIServiceFun.R2R_UI_PH_Focus_GetFocusSettings(strServiceAddress, strListR2RContexts);

            frmFocusUpdate frm = new frmFocusUpdate(strServiceAddress, strUserName, strPassword, strListR2RContexts, dValue);
            if (frm.ShowDialog() == DialogResult.OK)
            {
                //MessageBox.Show(frm.strListCurrent[0]);
            }
            else
            {

            }
            #endregion
        }
        private void btnOptCommonResetClick()
        {
            #region R2R_UI_COMMON_GetInputResetSettings
            UIServiceFun.structCOMMON_GetInputResetSettings structCommonInputResetSettingNull = new UIServiceFun.structCOMMON_GetInputResetSettings();
            UIServiceFun.structCOMMON_GetInputResetSettings structCommonInputResetSetting = new UIServiceFun.structCOMMON_GetInputResetSettings();
            structCommonInputResetSetting = UIServiceFun.R2R_UI_COMMON_GetInputResetSettings(strServiceAddress, strCurrentController, strGroup, strListR2RContexts);

            if (structCommonInputResetSetting.Equals(structCommonInputResetSettingNull))
            {
                MessageBox.Show("Data is empty!");
            }
            else
            {
                frmCommonReset frm = new frmCommonReset(strServiceAddress, strUserName, strPassword, strCurrentController, strGroup, strListR2RContexts, structCommonInputResetSetting);
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    //MessageBox.Show(frm.strListCurrent[0]);
                }
                else
                {

                }
            }
            #endregion
        }
        private void btnOptReset_Click(object sender, EventArgs e)
        {
            #region
            string strTabName = tabOptSubTab.SelectedTab.Name;
            switch (strTabName)
            {
                case "tabPage3":
                    btnOptOVLResetClick();
                    break;
                case "tabPage4":
                    btnOptOVLResetClick();
                    break;
                case "tabPage5":
                    btnOptOVLResetClick();
                    break;
                case "tabPage6":
                    btnOptOVLResetClick();
                    break;
                case "tabPage7":
                    btnOptCDResetClick();
                    break;
                case "tabPage8":
                    btnOptFocusResetClick();
                    break;
                case "tabPage9":
                    strGroup = tabPage9.Text.ToString();
                    btnOptCommonResetClick();
                    break;
                case "tabPage10":
                    strGroup = tabPage10.Text.ToString();
                    btnOptCommonResetClick();
                    break;
                case "tabPage11":
                    strGroup = tabPage11.Text.ToString();
                    btnOptCommonResetClick();
                    break;
                case "tabPage12":
                    strGroup = tabPage12.Text.ToString();
                    btnOptCommonResetClick();
                    break;
                case "tabPage13":
                    strGroup = tabPage13.Text.ToString();
                    btnOptCommonResetClick();
                    break;
                case "tabPage14":
                    strGroup = tabPage14.Text.ToString();
                    btnOptCommonResetClick();
                    break;
                default:
                    break;
            }
            #endregion
        }
        #endregion

        #region OptContextGroup Event
        private void grdOptContextGroup_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            //MessageBox.Show(e.RowIndex.ToString());
            if (e.RowIndex >= 0)
            {
                bContextGroupClicked = true;
                ClearChartPanel();
                ClearCommonChart();
                ClearCommonDatableList();
                ClearLithoChart();

                if (bContextGroupNotClick)
                {
                    SetTabSubShow(bIsCommonType, bIsOVLType);
                    SetControlShow(bIsCommonType, bIsOVLType, false, true, bIsActive);
                }

                strListR2RContexts.Clear();
                for (int i = 0; i < dbGetContext.Columns.Count; i++)
                {
                    strListR2RContexts.Add(grdOptContextGroup.Rows[e.RowIndex].Cells[i].Value.ToString());
                }
                strContextText = GetTextContextGroup(strListR2RContexts);

                if (bIsCommonType)
                {
                    //rdoList.CheckedIndex = 0;
                    rdoLotAll.Checked = true;
                    tabOptSubTab.Visible = true;
                    ContextGroupDoubleClick_COMMON();
                }
                else
                {
                    strReticleId = grdOptContextGroup.Rows[e.RowIndex].Cells["RETICLE"].Value.ToString();
                    ContextGroupDoubleClick_OVL();
                }
                bContextGroupNotClick = false;
            }            
        }

        private void grdOptContextGroup_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            InitDbChuckDeditation(dbGetContext, e.RowIndex);
        }
        #endregion

        #region grdOptContextGroup Fun
        private void ContextGroupDoubleClick_OVL()
        {
            ClearLithoChart();
            strContextText = GetTextContextGroup(strListR2RContexts);
            try
            {
                #region
                if (strCurrentController.Contains("PH_OVL"))
                {
                    GetLotRunHistory_OVL();
                }
                else
                {
                    tabOptSubTab.SelectedTab = tabPage7;
                    //tabOptSubTab.SelectedTab = tabOptSubTab.TabPages[0];
                    GetLotRunHistory_CD();
                    GetLotRunHistory_Focus();
                }
                #endregion
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }
        }
        private void ContextGroupDoubleClick_COMMON()
        {
            //GetLotRunHistory_Common();
            GetLotRunHistory_Common();
        }
        #endregion

        #region grdOptContextGroup Fun
        private void GetLotRunHistory_OVL()
        {
            #region
            LotRunHistory_OVL myClass = new LotRunHistory_OVL(strServiceAddress, strCurrentController, strListR2RContexts);
            if (myClass.bNotData)
            {
                MessageBox.Show("Data is empty!");
            }
            else
            {
                strCurrentOVLModel = myClass.strCurrentOVLModel;
                strCurrentR2RMode = myClass.strCurrentR2RMode;
                bIsActive = myClass.bIsActive;

                SetTextShow(strCurrentOVLModel, strCurrentR2RMode);
                SetControlShow(bIsCommonType, bIsOVLType, false, true, bIsActive);

                if (myClass.bLinearMode)
                {
                    tabOptSubTab.SelectedTab = tabPage3;
                    AddControlHelp.SetLable(panLinearLbl, lblLinear, strContextText);

                    dbLinear = myClass.GetTable(OVL_LINEAR);
                    DataGridViewHelp.InitDgvGrid(grdOptLinear, dbLinear);

                    ctlListChartLinear = myClass.AddChartToList(LINE_CHART, OVL_LINEAR, bChuckOne);
                    if (ctlListChartLinear.Count > 0)
                    {
                        panOptChart.Controls.Clear();//清空panel
                        AddControlHelp.AddChartToPanel(panOptChart, ctlListChartLinear);

                        OVLChartClick(ctlListChartLinear);
                    }
                    else
                    {
                        MessageBox.Show("No available Chart");
                    }
                }
                if (myClass.bHOPCMode)
                {
                    tabOptSubTab.SelectedTab = tabPage4;
                    AddControlHelp.SetLable(panHOPCLbl, lblHOPC, strContextText);

                    dbHOPC = myClass.GetTable(OVL_HOPC);
                    DataGridViewHelp.InitDgvGrid(grdOptHOPC, dbHOPC);

                    ctlListChartHOPC = myClass.AddChartToList(LINE_CHART, OVL_HOPC, bChuckOne);

                    if (ctlListChartHOPC.Count > 0)
                    {
                        panOptChart.Controls.Clear();//清空panel
                        AddControlHelp.AddChartToPanel(panOptChart, ctlListChartHOPC);

                        OVLChartClick(ctlListChartHOPC);
                    }
                    else
                    {
                        MessageBox.Show("No available Chart");
                    }
                }

                if (myClass.bIHOPCMode)
                {
                    tabOptSubTab.SelectedTab = tabPage5;
                    AddControlHelp.SetLable(panIHOPCLbl, lblIHOPC, strContextText);

                    dbIHOPC = myClass.GetTable(OVL_IHOPC);
                    DataGridViewHelp.InitDgvGrid(grdOptIHOPC, dbIHOPC);

                    ctlListChartIHOPC = myClass.AddChartToList(LINE_CHART, OVL_IHOPC, bChuckOne);

                    if (ctlListChartIHOPC.Count > 0)
                    {
                        panOptChart.Controls.Clear();//清空panel
                        AddControlHelp.AddChartToPanel(panOptChart, ctlListChartIHOPC);

                        OVLChartClick(ctlListChartIHOPC);
                    }
                    else
                    {
                        MessageBox.Show("No available Chart");
                    }
                }
            }
            #endregion
        }

        private void GetLotRunHistory_CD()
        {
            bool bIsAll = false;
            if (rdoLotAll.Checked)
            {
                bIsAll = true;
            }
            else
            {
                bIsAll = false;
            }
            LotRunHistory_CD myClass = new LotRunHistory_CD(strServiceAddress, strListR2RContexts, bIsAll);
            if (myClass.bNotData)
            {
                MessageBox.Show("Data is empty!");
            }
            else
            {
                //tabOptSubTab.SelectedTab = tabOptSubTab.Tabs[4];
                AddControlHelp.SetLable(panCDLbl, lblCD, strContextText);

                bCDIsActive = myClass.bIsActive;
                strCurrentR2RMode = myClass.strCurrentR2RMode;
                string strTabName = tabOptSubTab.SelectedTab.Name;

                if (strTabName.Equals("tabPage7"))
                {
                    txtCurrentR2RMode.Text = "Current R2R Mode:" + strCurrentR2RMode;
                    SetControlShow(bIsCommonType, bIsOVLType, true, true, bCDIsActive);
                }

                dbCD = myClass.GetTable();
                if (strTabName.Equals("tabPage7"))
                {
                    DataGridViewHelp.InitDgvGrid(grdOptCD, dbCD);
                }

                panOptChart.Controls.Clear();//清空panel
                ctlListChartCDInput = myClass.AddChartToList(INPUT_CHART, LINE_CHART);
                ctlListChartCDOutput = myClass.AddChartToList(OUTPUT_CHART, LINE_CHART);

                if (strTabName.Equals("tabPage7"))
                {
                    bool bHasInputChart = false;
                    bool bHasOutputChart = false;
                    if (ctlListChartCDInput.Count > 0)
                    {
                        bHasInputChart = true;
                    }
                    else
                    {
                        bHasInputChart = false;
                        //MessageBox.Show("PH_CD No available Input chart");
                    }

                    if (ctlListChartCDOutput.Count > 0)
                    {
                        bHasOutputChart = true;
                    }
                    else
                    {
                        bHasOutputChart = false;
                        //MessageBox.Show("PH_CD No available Output chart");
                    }

                    if (bHasInputChart && bHasOutputChart)
                    {
                        if (ctlListChartCDInput.Count < 3)
                        {
                            List<Chart> ctlListInputAndOutputChart = new List<Chart>();
                            for (int i = 0; i < ctlListChartCDInput.Count; i++)
                            {
                                ctlListInputAndOutputChart.Add(ctlListChartCDInput[i]);
                                ctlListInputAndOutputChart.Add(ctlListChartCDOutput[i]);
                            }

                            AddControlHelp.AddChartToPanel(panOptChart, ctlListInputAndOutputChart);
                        }
                        else
                        {
                            AddControlHelp.AddChartToPanel(panOptChart, ctlListChartCDInput, ctlListChartCDOutput);
                        }

                        InputChartClick(ctlListChartCDInput);
                        OutputChartClick(ctlListChartCDOutput);
                    }
                    else
                    {
                        if (bHasInputChart)
                        {
                            AddControlHelp.AddChartToPanel(panOptChart, ctlListChartCDInput);
                            InputChartClick(ctlListChartCDInput);
                            MessageBox.Show("PH_CD No available Output chart");
                        }
                        else if (bHasOutputChart)
                        {
                            AddControlHelp.AddChartToPanel(panOptChart, ctlListChartCDOutput);
                            OutputChartClick(ctlListChartCDOutput);
                            MessageBox.Show("PH_CD No available Input chart");
                        }
                        else
                        {
                            MessageBox.Show("PH_CD No available Input/Output chart");
                        }
                    }
                }
            }
        }

        private void GetLotRunHistory_Focus()
        {
            bool bIsAll = false;
            if (rdoLotAll.Checked)
            {
                bIsAll = true;
            }
            else
            {
                bIsAll = false;
            }
            //bIsAll = rdoList.CheckedIndex == 0 ? true : false;

            LotRunHistory_Focus myClass = new LotRunHistory_Focus(strServiceAddress, strListR2RContexts, bIsAll);
            if (myClass.bNotData)
            {
                MessageBox.Show("Data is empty!");
            }
            else
            {
                //tabOptSubTab.SelectedTab = tabOptSubTab.Tabs[5];

                AddControlHelp.SetLable(panFocusLbl, lblFocus, strContextText);

                bFocusIsActive = myClass.bIsActive;
                string strTabName = tabOptSubTab.SelectedTab.Name;
                if (strTabName.Equals("tabPage8"))
                {
                    strCurrentR2RMode = myClass.strCurrentR2RMode;
                    txtCurrentR2RMode.Text = "Current R2R Mode:" + strCurrentR2RMode;
                    SetControlShow(bIsCommonType, bIsOVLType, false, true, bFocusIsActive);
                    //SetControlShow(bIsCommonType, bIsOVLType, true, true, bIsActive);
                }


                dbFocus = myClass.GetTable();
                if (strTabName.Equals("tabPage8"))
                {
                    DataGridViewHelp.InitDgvGrid(grdOptFocus, dbFocus);
                }

                ctlListChartFocusInput = myClass.AddChartToList(INPUT_CHART, LINE_CHART);
                ctlListChartFocusOutput = myClass.AddChartToList(OUTPUT_CHART, LINE_CHART);

                if (strTabName.Equals("tabPage8"))
                {
                    bool bHasInputChart = false;
                    bool bHasOutputChart = false;
                    if (ctlListChartFocusInput.Count > 0)
                    {
                        bHasInputChart = true;
                    }
                    else
                    {
                        bHasInputChart = false;
                        //MessageBox.Show("PH_Focus No available Input chart");
                    }
                    if (ctlListChartFocusOutput.Count > 0)
                    {
                        bHasOutputChart = true;
                    }
                    else
                    {
                        bHasOutputChart = false;
                        //MessageBox.Show("PH_Focus No available Output chart");
                    }
                    if (bHasInputChart && bHasOutputChart)
                    {
                        if (ctlListChartFocusInput.Count < 3)
                        {
                            List<Chart> ctlListInputAndOutputChart = new List<Chart>();
                            for (int i = 0; i < ctlListChartFocusInput.Count; i++)
                            {
                                ctlListInputAndOutputChart.Add(ctlListChartFocusInput[i]);
                                ctlListInputAndOutputChart.Add(ctlListChartFocusOutput[i]);
                            }
                            AddControlHelp.AddChartToPanel(panOptChart, ctlListInputAndOutputChart);
                        }
                        else
                        {
                            AddControlHelp.AddChartToPanel(panOptChart, ctlListChartFocusInput, ctlListChartFocusOutput);
                        }

                        InputChartClick(ctlListChartFocusInput);
                        OutputChartClick(ctlListChartFocusOutput);
                    }
                    else
                    {
                        if (bHasInputChart)
                        {
                            AddControlHelp.AddChartToPanel(panOptChart, ctlListChartFocusInput);
                            InputChartClick(ctlListChartFocusInput);
                            MessageBox.Show("PH_Focus No available Output chart");
                        }
                        else if (bHasOutputChart)
                        {
                            AddControlHelp.AddChartToPanel(panOptChart, ctlListChartFocusOutput);
                            OutputChartClick(ctlListChartFocusOutput);
                            MessageBox.Show("PH_Focus No available Input chart");
                        }
                        else
                        {
                            MessageBox.Show("PH_Focus No available Input/Output chart");
                        }
                    }

                    //panOptChart.ClientArea.Controls.Clear();//清空panel
                    //AddControlHelp.AddChartToPanel(panOptChart, ctlListChartFocusInput, ctlListChartFocusOutput);

                    //InputChartClick(ctlListChartFocusInput);
                    //OutputChartClick(ctlListChartFocusOutput);
                }
            }
        }
        private void GetLotRunHistory_Common()
        {
            bool bIsAll = false;
            if (rdoLotAll.Checked)
            {
                bIsAll = true;
            }
            else
            {
                bIsAll = false;
            }
            LotRunHistory_Common myClass = new LotRunHistory_Common(strServiceAddress, strCurrentController, strListR2RContexts, bIsAll);
            if (myClass.bNotData)
            {
                MessageBox.Show("Data is empty!");
            }
            else
            {
                string strContextCommonText = "Context Group:";
                strContextCommonText = GetTextContextGroup(strListR2RContexts);
                AddControlHelp.SetLable(panCommon1Lb1, lblCommon1, strContextCommonText);

                strCurrentR2RMode = "Active";
                bIsActive = true;
                //strCurrentR2RMode = myClass.strCurrentR2RMode;
                //bIsActive = myClass.bIsActive;
                txtCurrentR2RMode.Text = "Current R2R Mode:" + strCurrentR2RMode;

                SetControlShow(bIsCommonType, bIsOVLType, true, true, bIsActive);

                btnOptReset.Enabled = true;
                btnOptMode.Enabled = true;
                //tabOptSubTab.SelectedTab = tabOptSubTab.TabPages[6];
                tabOptSubTab.SelectedTab = tabPage9;

                DataTable dbCommonGroup = new DataTable();
                List<DataTable> dbListCommonGroup = new List<DataTable>() { dbCommon1, dbCommon2, dbCommon3, dbCommon4, dbCommon5, dbCommon6 };
                List<List<Chart>> ctlListInputChartGroup = new List<List<Chart>>();
                List<List<Chart>> ctlListOutputChartGroup = new List<List<Chart>>();
                List<DataGridView> grdGroup = new List<DataGridView>() { grdOptCommon1, grdOptCommon2, grdOptCommon3, grdOptCommon4, grdOptCommon5, grdOptCommon6 };

                #region
                int index = myClass.iGroupListIndexs.Count;
                ClearCommonChart();
                SetCommonTabSub(index, myClass.strListGroupNames);

                for (int i = 0; i < index; i++)
                {
                    dbListCommonGroup[i] = myClass.CreateTable(myClass.structGroupData.strListGroupLotIds[i], myClass.structGroupData.strListGroupUsedTimeStamps[i]);
                    //dbCommonGroup= myClass.CreateTable(myClass.structGroupData.strListGroupLotIds[i], myClass.structGroupData.strListGroupUsedTimeStamps[i]);
                    //DataGridViewHelp.InitDgvGrid(grdGroup[i], dbCommonGroup);
                }

                GetCommonDatableList(index, dbListCommonGroup);
                DataGridViewHelp.InitDgvGrid(grdOptCommon1, dbCommon1);

                ctlListInputChartGroup.Clear();
                ctlListOutputChartGroup.Clear();
                myClass.GetCommonGroupChart(index, myClass.GetStructGroupData(), ref ctlListInputChartGroup, ref ctlListOutputChartGroup);
                //myClass.GetCommonGroupChart(index, myClass.GetStructGroupValue(), ref ctlListInputChartGroup, ref ctlListOutputChartGroup);

                GetCommonChartToList(index, ctlListInputChartGroup, ctlListOutputChartGroup);

                panOptChart.Controls.Clear();//清空panel
                AddControlHelp.AddChartToPanel(panOptChart, ctlListInputChart1, ctlListOutputChart1);
                #endregion
            }
        }
        #endregion

        #region TabSub Event
        private void tabOptSubTab_SelectedIndexChanged(object sender, EventArgs e)
        {
            //panOptPicture.ClientArea.Controls.Clear();//清空panel
            if (bContextGroupClicked)
            {
                //int tabIndex = 0;
                //tabIndex = tabOptSubTab.SelectedIndex;
                SetTextShow(strCurrentOVLModel, strCurrentR2RMode);
                string strTabName = tabOptSubTab.SelectedTab.Name;
                switch (strTabName)
                {
                    case "tabPage3":
                        SetControlShow(bIsCommonType, bIsOVLType, false, true, bIsActive);

                        AddControlHelp.SetLable(panLinearLbl, lblLinear, strContextText);

                        DataGridViewHelp.InitDgvGrid(grdOptLinear, dbLinear);

                        ClearChartPanel();
                        if (ctlListChartLinear.Count > 0)
                        {
                            ClearChartPanel();
                            AddControlHelp.AddChartToPanel(panOptChart, ctlListChartLinear);
                        }
                        //MessageBox.Show("tab0-Linear");
                        break;
                    case "tabPage4":
                        SetControlShow(bIsCommonType, bIsOVLType, false, true, bIsActive);

                        AddControlHelp.SetLable(panHOPCLbl, lblHOPC, strContextText);

                        DataGridViewHelp.InitDgvGrid(grdOptHOPC, dbHOPC);

                        ClearChartPanel();
                        if (ctlListChartHOPC.Count > 0)
                        {
                            ClearChartPanel();
                            AddControlHelp.AddChartToPanel(panOptChart, ctlListChartHOPC);
                        }
                        //MessageBox.Show("tab1-HOPC");
                        break;
                    case "tabPage5":
                        SetControlShow(bIsCommonType, bIsOVLType, false, true, bIsActive);

                        AddControlHelp.SetLable(panIHOPCLbl, lblIHOPC, strContextText);

                        DataGridViewHelp.InitDgvGrid(grdOptIHOPC, dbIHOPC);

                        ClearChartPanel();
                        if (ctlListChartIHOPC.Count > 0)
                        {
                            ClearChartPanel();
                            AddControlHelp.AddChartToPanel(panOptChart, ctlListChartIHOPC);
                        }
                        //MessageBox.Show("tab2-IHOPC");
                        break;
                    case "tabPage6":
                        SetControlShow(bIsCommonType, bIsOVLType, true, true, bIsActive);

                        //AddControlHelp.SetLable(panTabsubLbl, lblTabsub, strContextText);

                        DataGridViewHelp.InitDgvGrid(grdOptCPE, dbCPE);

                        ClearChartPanel();
                        //if (ctlListChartCPE.Count > 0)
                        //{
                        //    InitChartPanel();
                        //    AddControlHelp.AddChartToPanel(panOptPicture, ctlListChartCPE);
                        //}
                        //MessageBox.Show("tab3-CPE");
                        break;
                    case "tabPage7":
                        SetControlShow(bIsCommonType, bIsOVLType, true, true, bCDIsActive);
                        if (bCDIsActive)
                        {
                            txtCurrentR2RMode.Text = "Current R2R Mode:Active";
                        }
                        else
                        {
                            txtCurrentR2RMode.Text = "Current R2R Mode:Fixed";
                        }
                        AddControlHelp.SetLable(panCDLbl, lblCD, strContextText);

                        DataGridViewHelp.InitDgvGrid(grdOptCD, dbCD);

                        ClearChartPanel();
                        if (ctlListChartCDInput.Count > 0 && ctlListChartCDOutput.Count > 0)
                        {
                            ClearChartPanel();
                            if (ctlListChartCDInput.Count < 3)
                            {
                                List<Chart> ctlListInputAndOutputChart = new List<Chart>();
                                for (int i = 0; i < ctlListChartCDInput.Count; i++)
                                {
                                    ctlListInputAndOutputChart.Add(ctlListChartCDInput[i]);
                                    ctlListInputAndOutputChart.Add(ctlListChartCDOutput[i]);
                                }
                                AddControlHelp.AddChartToPanel(panOptChart, ctlListInputAndOutputChart);
                            }
                            else
                            {
                                AddControlHelp.AddChartToPanel(panOptChart, ctlListChartCDInput, ctlListChartCDOutput);
                            }
                        }
                        else
                        {
                            if (ctlListChartCDInput.Count > 0)
                            {
                                ClearChartPanel();
                                AddControlHelp.AddChartToPanel(panOptChart, ctlListChartCDInput);
                                //MessageBox.Show("PH_CD No available Output chart");
                            }
                            else if (ctlListChartCDOutput.Count > 0)
                            {
                                ClearChartPanel();
                                AddControlHelp.AddChartToPanel(panOptChart, ctlListChartCDOutput);
                                //MessageBox.Show("PH_CD No available Input chart");
                            }
                            else
                            {
                                //MessageBox.Show("PH_CD No available Input/Output chart");
                            }
                        }
                        //MessageBox.Show("tab4-CD");
                        break;
                    case "tabPage8":
                        SetControlShow(bIsCommonType, bIsOVLType, false, true, bFocusIsActive);
                        if (bFocusIsActive)
                        {
                            txtCurrentR2RMode.Text = "Current R2R Mode:Active";
                        }
                        else
                        {
                            txtCurrentR2RMode.Text = "Current R2R Mode:Fixed";
                        }
                        AddControlHelp.SetLable(panFocusLbl, lblFocus, strContextText);

                        DataGridViewHelp.InitDgvGrid(grdOptFocus, dbFocus);
                        ClearChartPanel();
                        if (ctlListChartFocusInput.Count > 0 && ctlListChartFocusOutput.Count > 0)
                        {
                            ClearChartPanel();
                            if (ctlListChartFocusInput.Count < 3)
                            {
                                List<Chart> ctlListInputAndOutputChart = new List<Chart>();
                                for (int i = 0; i < ctlListChartFocusInput.Count; i++)
                                {
                                    ctlListInputAndOutputChart.Add(ctlListChartFocusInput[i]);
                                    ctlListInputAndOutputChart.Add(ctlListChartFocusOutput[i]);
                                }
                                AddControlHelp.AddChartToPanel(panOptChart, ctlListInputAndOutputChart);
                            }
                            else
                            {
                                AddControlHelp.AddChartToPanel(panOptChart, ctlListChartFocusInput, ctlListChartFocusOutput);
                            }
                        }
                        else
                        {
                            if (ctlListChartFocusInput.Count > 0)
                            {
                                ClearChartPanel();
                                AddControlHelp.AddChartToPanel(panOptChart, ctlListChartFocusInput);
                                //MessageBox.Show("PH_Focus No available Output chart");
                            }
                            else if (ctlListChartFocusOutput.Count > 0)
                            {
                                ClearChartPanel();
                                AddControlHelp.AddChartToPanel(panOptChart, ctlListChartFocusOutput);
                                //MessageBox.Show("PH_Focus No available Input chart");
                            }
                            else
                            {
                                //MessageBox.Show("PH_Focus No available Input/Output chart");
                            }
                        }
                        //MessageBox.Show("tab5-Focus");
                        break;
                    case "tabPage9":
                        SetControlShow(bIsCommonType, bIsOVLType, true, true, bIsActive);

                        AddControlHelp.SetLable(panCommon1Lb1, lblCommon1, strContextText);
                        DataGridViewHelp.InitDgvGrid(grdOptCommon1, dbCommon1);

                        strGroup = tabPage9.Text;
                        if (ctlListInputChart1.Count > 0 && ctlListOutputChart1.Count > 0)
                        {
                            ClearChartPanel();
                            AddControlHelp.AddChartToPanel(panOptChart, ctlListInputChart1, ctlListOutputChart1);
                        }
                        break;
                    case "tabPage10":
                        SetControlShow(bIsCommonType, bIsOVLType, true, true, bIsActive);

                        AddControlHelp.SetLable(panCommon2Lb1, lblCommon2, strContextText);
                        DataGridViewHelp.InitDgvGrid(grdOptCommon2, dbCommon2);

                        strGroup = tabPage10.Text;
                        if (ctlListInputChart2.Count > 0 && ctlListOutputChart2.Count > 0)
                        {
                            ClearChartPanel();
                            AddControlHelp.AddChartToPanel(panOptChart, ctlListInputChart2, ctlListOutputChart2);
                        }
                        break;
                    case "tabPage11":
                        SetControlShow(bIsCommonType, bIsOVLType, true, true, bIsActive);

                        AddControlHelp.SetLable(panCommon3Lb1, lblCommon3, strContextText);
                        DataGridViewHelp.InitDgvGrid(grdOptCommon3, dbCommon3);

                        strGroup = tabPage11.Text;
                        if (ctlListInputChart3.Count > 0 && ctlListOutputChart3.Count > 0)
                        {
                            ClearChartPanel();
                            AddControlHelp.AddChartToPanel(panOptChart, ctlListInputChart3, ctlListOutputChart3);
                        }
                        break;
                    case "tabPage12":
                        SetControlShow(bIsCommonType, bIsOVLType, true, true, bIsActive);

                        AddControlHelp.SetLable(panCommon4Lb1, lblCommon4, strContextText);
                        DataGridViewHelp.InitDgvGrid(grdOptCommon4, dbCommon4);

                        strGroup = tabPage12.Text;
                        if (ctlListInputChart4.Count > 0 && ctlListOutputChart4.Count > 0)
                        {
                            ClearChartPanel();
                            AddControlHelp.AddChartToPanel(panOptChart, ctlListInputChart4, ctlListOutputChart4);
                        }
                        break;
                    case "tabPage13":
                        SetControlShow(bIsCommonType, bIsOVLType, true, true, bIsActive);
                        DataGridViewHelp.InitDgvGrid(grdOptCommon5, dbCommon5);

                        AddControlHelp.SetLable(panCommon5Lb1, lblCommon5, strContextText);

                        strGroup = tabPage13.Text;
                        if (ctlListInputChart5.Count > 0 && ctlListOutputChart5.Count > 0)
                        {
                            ClearChartPanel();
                            AddControlHelp.AddChartToPanel(panOptChart, ctlListInputChart5, ctlListOutputChart5);
                        }
                        break;
                    case "tabPage14":
                        SetControlShow(bIsCommonType, bIsOVLType, true, true, bIsActive);

                        AddControlHelp.SetLable(panCommon6Lb1, lblCommon6, strContextText);
                        DataGridViewHelp.InitDgvGrid(grdOptCommon6, dbCommon6);

                        strGroup = tabPage14.Text;
                        if (ctlListInputChart6.Count > 0 && ctlListOutputChart6.Count > 0)
                        {
                            ClearChartPanel();
                            AddControlHelp.AddChartToPanel(panOptChart, ctlListInputChart6, ctlListOutputChart6);
                        }
                        break;
                    default:
                        break;
                }
            }
        }
        #endregion

        #region cmbContext Event
        private void ClearCmbContext(int index)
        {
            switch (index)
            {
                case 1:
                    cmbProduct.DataSource = null;
                    cmbStage.DataSource = null;
                    cmbLayer.DataSource = null;
                    cmbControl.DataSource = null;
                    cmbTool.DataSource = null;
                    break;
                case 2:
                    cmbStage.DataSource = null;
                    cmbLayer.DataSource = null;
                    cmbControl.DataSource = null;
                    cmbTool.DataSource = null;
                    break;
                case 3:
                    cmbLayer.DataSource = null;
                    cmbControl.DataSource = null;
                    cmbTool.DataSource = null;
                    break;
                case 4:
                    cmbControl.DataSource = null;
                    cmbTool.DataSource = null;
                    break;
                case 5:
                    cmbTool.DataSource = null;
                    break;
                default:
                    break;
            }
        }

        private void cmbContext_SelectedIndexChanged(object sender, EventArgs e)
        {
            bContextGroupNotClick = true;
            bContextGroupClicked = false;

            rdoLotAll.Checked = true;
            ClearControl();
            InitTabSubShow();
            InitControlVisible();
            InitControlEnable();
            ClearCommonChart();
            ClearCommonDatableList();
            ClearLithoChart();

            ComboBox cmb = (ComboBox)sender;
            string strCmbName = cmb.Name;
            switch (strCmbName)
            {
                case "cmbModule":
                    bIsOVLType = false;
                    string strLayerOrStep = "Layer";

                    ClearCmbContext(1);

                    strCurrentModule = cmbModule.Text.ToString();

                    bIsCommonType = IsCommonType(strCurrentModule);
                    strLayerOrStep = GetLayerOrStep(strCurrentModule);
                    txtLayer.Text = strLayerOrStep;

                    if (cmbModule.Text.ToString().Equals(""))
                    {
                    }
                    else
                    {
                        strListProduct = UIServiceFun.R2R_UI_GetProduct(strUserName, strServiceAddress, strCurrentModule);
                        cmbProduct.DataSource = strListProduct;
                    }
                    break;
                case "cmbProduct":
                    ClearCmbContext(2);
                    strCurrentProduct = cmbProduct.Text.ToString();
                    if (cmbProduct.Text.ToString().Equals(""))
                    {
                        strListStage.Clear();
                    }
                    else
                    {
                        strListStage = new List<string>() { "*" };
                        cmbStage.DataSource = strListStage;
                    }
                    break;
                case "cmbStage":
                    ClearCmbContext(3);
                    strCurrentStage = cmbStage.Text.ToString();
                    if (cmbModule.Text.ToString().Equals("") || cmbProduct.Text.ToString().Equals("") || cmbStage.Text.ToString().Equals(""))
                    {
                    }
                    else
                    {
                        strListLayer = UIServiceFun.R2R_UI_GetLayerOrStep(strUserName, strServiceAddress, strCurrentModule, strCurrentProduct, strCurrentStage);
                        cmbLayer.DataSource = strListLayer;
                    }
                    break;
                case "cmbLayer":
                    ClearCmbContext(4);
                    strCurrentLayer = cmbLayer.Text.ToString();
                    if (cmbModule.Text.ToString().Equals("") || cmbProduct.Text.ToString().Equals("") || cmbStage.Text.ToString().Equals("") || cmbLayer.Text.ToString().Equals(""))
                    {
                    }
                    else
                    {
                        strListController = UIServiceFun.R2R_UI_GetController(strUserName, strServiceAddress, strCurrentModule, strCurrentProduct, strCurrentStage, strCurrentLayer);
                        cmbControl.DataSource = strListController;
                    }
                    break;
                case "cmbControl":
                    ClearCmbContext(5);
                    strCurrentController = cmbControl.Text.ToString();

                    bIsOVLType = IsOVLType(strCurrentController);
                    bIsOVLCANON = false;
                    bIsOVLCANON = IsOVLCANON(strCurrentController);

                    if (cmbModule.Text.ToString().Equals("") || cmbProduct.Text.ToString().Equals("") || cmbStage.Text.ToString().Equals("") || cmbLayer.Text.ToString().Equals("") || cmbControl.Text.ToString().Equals(""))
                    {
                    }
                    else
                    {
                        strListTool = UIServiceFun.R2R_UI_GetTool(strUserName, strServiceAddress, strCurrentModule, strCurrentProduct, strCurrentStage, strCurrentLayer, strCurrentController);
                        cmbTool.DataSource = strListTool;
                    }
                    break;
                case "cmbTool":
                    if (cmbTool.Text.ToString().Equals(""))
                    {
                    }
                    else
                    {
                        strCurrentTool = cmbTool.Text.ToString();
                    }
                    break;
                default:
                    break;
            }
        }
        #endregion

        #region Test DataGridView Event
        private void grdOptContextGroup_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            //DataGridViewHelp.dgv_CellPainting(sender,  e);
        }

        private void grdOptContextGroup_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            //DataGridViewHelp.dgv_RowPostPaint(sender, e);
        }

        private void grdOptContextGroup_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            //DataGridViewHelp.dgv_CellFormatting(sender, e);
        }
        #endregion
    }
}

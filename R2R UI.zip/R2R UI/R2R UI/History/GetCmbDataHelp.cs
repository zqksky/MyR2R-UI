﻿using R2R_UI.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace R2R_UI.History
{
    class GetCmbDataHelp
    {
        public static List<string> GetCmbData(DataTable dt, string strKey)
        {
            List<string> strList = new List<string>();
            try
            {
                strList = dt.AsEnumerable().Select(d => d.Field<string>(strKey)).Distinct().ToList();
                if (strList.Contains("*"))
                {
                }
                else
                {
                    //strList.Add("*");
                }
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
            return strList;
        }
    }
}

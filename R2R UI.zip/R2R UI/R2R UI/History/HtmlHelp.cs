﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace R2R_UI.History
{
    class HtmlHelp
    {
        public static string HtmlDecodeTest(string strHTML)
        {
            string s = strHTML;
            while (s.Contains("&amp;"))
            {
                s = s.Replace("&amp;", "&");
            }

            while (s.Contains("&lt;") || s.Contains("&gt;") || s.Contains("&apos;") || s.Contains("&aquot;"))
            {
                s = s.Replace("&lt;", "<");
                s = s.Replace("&gt;", ">");
                s = s.Replace("&apos;", "'");
                s = s.Replace("&aquot;", "\"");
            }

            return s;

        }

        ///<summary>
        ///恢复html中的特殊字符
        ///</summary>
        ///<paramname="strHTML">需要恢复的文本。</param>
        ///<returns>恢复好的文本。</returns>
        public static string HtmlDecode(string strHTML)
        {
            try
            {
                strHTML = Regex.Replace(strHTML, @"([\r\n])[\s]+", "", RegexOptions.IgnoreCase);
                strHTML = Regex.Replace(strHTML, @"-->", "", RegexOptions.IgnoreCase);
                strHTML = Regex.Replace(strHTML, @"<!--.*", "", RegexOptions.IgnoreCase);

                strHTML = Regex.Replace(strHTML, @"&amp;", "&", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                strHTML = Regex.Replace(strHTML, @"amp;", "", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                strHTML = Regex.Replace(strHTML, @"&(lt|#60);", "<", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                strHTML = Regex.Replace(strHTML, @"&(gt|#62);", ">", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                strHTML = Regex.Replace(strHTML, @"&(nbsp|#160);", " ", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                strHTML = Regex.Replace(strHTML, @"&(apos|#39);", "\'", RegexOptions.IgnoreCase | RegexOptions.Multiline);
                strHTML = Regex.Replace(strHTML, @"&(quot|#34);", "\"", RegexOptions.IgnoreCase | RegexOptions.Multiline);

                strHTML = Regex.Replace(strHTML, @"&(iexcl|#161);", "\xa1", RegexOptions.IgnoreCase);
                strHTML = Regex.Replace(strHTML, @"&(cent|#162);", "\xa2", RegexOptions.IgnoreCase);
                strHTML = Regex.Replace(strHTML, @"&(pound|#163);", "\xa3", RegexOptions.IgnoreCase);
                strHTML = Regex.Replace(strHTML, @"&(copy|#169);", "\xa9", RegexOptions.IgnoreCase);
                strHTML = Regex.Replace(strHTML, @"&#(\d+);", "", RegexOptions.IgnoreCase);
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(Common.BaseFun.GetExceptionInformation(err));
            }
            return strHTML;
        }
    }
}

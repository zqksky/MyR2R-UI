﻿
using R2R_UI.Common;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin;
using MaterialSkin.Controls;

namespace R2R_UI.Present.Common
{
    public partial class frmCommonReset : MaterialForm
    {
        //private readonly MaterialSkinManager meterialSkinManager;

        #region
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x0014) // 禁掉清除背景消息
                return;
            base.WndProc(ref m);
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x02000000;
                return cp;
            }
        }

        private void CtlDoubleBuffer()
        {
            this.DoubleBuffered = true;//设置本窗体
            SetStyle(ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true); // 禁止擦除背景.
            SetStyle(ControlStyles.DoubleBuffer, true); // 双缓冲
            //SetStyle(ControlStyles.DoubleBuffer | ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint, true);
            UpdateStyles();
        }
        #endregion

        public frmCommonReset()
        {
            InitializeComponent();
        }
        public frmCommonReset(string strServiceName, string strCurrentUserName, string strCurrentPwd, string strFrmController, string strFrmGroup, List<string> strListFrmR2RContexts, UIServiceFun.structCOMMON_GetInputResetSettings structDataSetting, string strCurrentType)
        {
            InitializeComponent();
            strServiceAddress = strServiceName;
            strUserName = strCurrentUserName;
            strPassword = strCurrentPwd;

            strGroup = strFrmGroup;
            strCurrentController = strFrmController;
            strListR2RContexts = new List<string>(strListFrmR2RContexts);
            structData = structDataSetting;
            iListInputIndex = structDataSetting.iListInputIndex;
            dListInputMax = structDataSetting.dListInputMax;
            dListInputMin = structDataSetting.dListInputMin;
            dListInputPMValues = structDataSetting.dListInputPMValues;
            dListInputResetValues = structDataSetting.dListInputResetValues;
            strListInputParameterNames = structDataSetting.strListInputParameterNames;
            strServiceType = strCurrentType;

            #region SetSkin
            SkinHelp.SkinSet(this, strServiceType);
            #endregion
        }

        #region Param
        bool bIsPM = true;
        bool bIsReset = false;

        string strGroup = "";
        string strCurrentController;
        string strServiceAddress;
        string strUserName;
        string strPassword;
        string strServiceType;

        List<int> iListInputIndex;
        List<double> dListInputMax;
        List<double> dListInputMin;
        List<double> dListInputPMValues;
        List<double> dListInputResetValues;
        List<string> strListInputParameterNames;
        List<string> strListR2RContexts = new List<string>();

        List<int> iRowChangeIndex = new List<int>();
        List<int> iListInputIndexChange = new List<int>();
        List<double> dListInputMaxChange = new List<double>();
        List<double> dListInputMinChange = new List<double>();
        List<double> dListInputPMValuesChange = new List<double>();
        List<double> dListInputResetValuesChange = new List<double>();
        List<string> strListInputParameterNamesChange = new List<string>();

        UIServiceFun.structCOMMON_GetInputResetSettings structData = new UIServiceFun.structCOMMON_GetInputResetSettings();
        UIServiceFun.structCOMMON_UpdateInputResetSettings structDataUpdate = new UIServiceFun.structCOMMON_UpdateInputResetSettings();
        #endregion

        private void frmCommonReset_Load(object sender, EventArgs e)
        {
            #region  Double Buffer
            DataGridViewHelp.DoubleBuffered(dgvSet, true);
            CtlDoubleBuffer();
            #endregion

            #region Set Lbl
            string strDgvLblContext = "List of context group";
            AddControlHelp.SetLable(panDgvLblContext, lblDgvContext, strDgvLblContext);
            #endregion

            #region
            rdoPM.Checked = true;
            DataGridViewHelp.InitDgvSet(dgvSet, DataTableHelp.CreateCommonResetTable(structData, bIsPM),4);
            #endregion
        }

        private void frmCommonReset_Resize(object sender, EventArgs e)
        {

        }

        private void frmCommonReset_SizeChanged(object sender, EventArgs e)
        {

        }

        private void rdoType_CheckedChanged(object sender, EventArgs e)
        {
            List<double> dListInputValues = new List<double>();
            if (rdoPM.Checked)
            {
                bIsPM = true;
                bIsReset = false;
                dListInputValues = new List<double>(dListInputPMValues);
            }
            else if (rdoReset.Checked)
            {
                bIsPM = false;
                bIsReset = true;
                dListInputValues = new List<double>(dListInputResetValues);
            }
            //for (int i = 0; i < ctlNewTxtControl.Count; i++)
            //{
            //    ctlNewTxtControl[i].Text = dListInputValues[i].ToString();
            //}
            structDataUpdate.bIsPM = bIsPM;
            structDataUpdate.bIsReset = bIsReset;
            DataGridViewHelp.InitDgvSet(dgvSet, DataTableHelp.CreateCommonResetTable(structData, bIsPM),4);
        }
        private void GetCellValue()
        {
            //List<double> dListInputValues = new List<double>();
            if (dgvSet.Rows.Count > 0)
            {
                if (rdoPM.Checked)
                {
                    bIsPM = true;
                    bIsReset = false;
                    dListInputPMValues.Clear();
                    for (int i = 0; i < dgvSet.Rows.Count; i++)
                    {
                        dListInputPMValues.Add(double.Parse(dgvSet.Rows[i].Cells[4].Value.ToString()));
                    }
                }
                else if (rdoReset.Checked)
                {
                    bIsPM = false;
                    bIsReset = true;
                    dListInputResetValues.Clear();
                    for (int i = 0; i < dgvSet.Rows.Count; i++)
                    {
                        dListInputResetValues.Add(double.Parse(dgvSet.Rows[i].Cells[4].Value.ToString()));
                    }
                }
            }
        }

        private bool IsCellValueChange(string strInputValue, int rowIndex, int colIndex)
        {
            bool flag = false;

            if (rdoPM.Checked)
            {
                flag = strInputValue != dListInputPMValues[rowIndex].ToString() ? true : false;
            }
            else if (rdoReset.Checked)
            {
                flag = strInputValue != dListInputResetValues[rowIndex].ToString() ? true : false;
            }

            if (flag)
            {
                this.dgvSet.Rows[rowIndex].Cells[4].Style.BackColor = Color.Honeydew;
            }
            else
            {
                this.dgvSet.Rows[rowIndex].Cells[4].Style.BackColor = Color.White;
            }

            return flag;
        }
        private void btnOk_Click(object sender, EventArgs e)
        {
            frmCheckedPwd frmChecked = new frmCheckedPwd(strUserName);
            if (frmChecked.ShowDialog() == DialogResult.OK)
            {
                if (frmChecked.strPassword.Equals(strPassword))
                {
                    #region
                    bool bSuccess;
                    try
                    {
                        //textValueChanged();
                        GetCellValue();
                        #region R2R_UI_COMMON_UpdateInputResetSettings
                        structDataUpdate.bIsPM = bIsPM;
                        structDataUpdate.bIsReset = bIsReset;
                        structDataUpdate.iListInputIndex = new List<int>(iListInputIndexChange);
                        structDataUpdate.dListInputMax = new List<double>(dListInputMaxChange);
                        structDataUpdate.dListInputMin = new List<double>(dListInputMinChange);
                        structDataUpdate.dListInputPMValues = new List<double>(dListInputPMValuesChange);
                        structDataUpdate.dListInputResetValues = new List<double>(dListInputResetValuesChange);

                        bSuccess = UIServiceFun.R2R_UI_COMMON_UpdateInputResetSettings(ref strServiceAddress, strUserName, strCurrentController, strGroup, strListR2RContexts, structDataUpdate);

                        if (bSuccess)
                        {
                            this.Close();
                        }
                        else
                        {
                            //MessageBox.Show("Set Failed!");
                        }
                        this.DialogResult = DialogResult.OK;
                        #endregion
                    }
                    catch (Exception err)
                    {
                        MessageBox.Show(BaseFun.GetExceptionInformation(err));
                    }
                    #endregion
                }
                else
                {
                    MessageBox.Show("Invalid password!");
                }
            }
            else
            {
                //MessageBox.Show("Invalid password!");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #region Test DataGridView Event
        private void dgvContext_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            //DataGridViewHelp.dgv_CellFormatting(sender, e);
        }

        private void dgvContext_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            //DataGridViewHelp.dgv_CellPainting(sender,  e);
        }

        private void dgvContext_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            //DataGridViewHelp.dgv_RowPostPaint(sender, e);
        }
        #endregion

        private Hashtable htRowChange = new Hashtable();
        private void dgvSet_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            #region
            //bool flag;
            //double dMax = 0.0;
            //double dMin = 0.0;
            //double dInputNew = 0.0;
            //dMax = double.Parse(dgvSet.Rows[e.RowIndex].Cells[1].Value.ToString());
            //dMin = double.Parse(dgvSet.Rows[e.RowIndex].Cells[2].Value.ToString());
            //dInputNew = double.Parse(dgvSet.Rows[e.RowIndex].Cells[4].Value.ToString());
            
            //if (dInputNew <= dMax && dInputNew >= dMin)
            //{
            //    flag = IsCellValueChange(dInputNew.ToString(), e.RowIndex, e.ColumnIndex);
            //    if (flag)
            //    {
            //        //iListInputIndexChange.Add(int.Parse(grdCommonMode.Rows[e.Cell.Row.Index].Cells[0].Value.ToString()));
            //        iListInputIndexChange.Add(structData.iListInputIndex[e.RowIndex]);
            //        strListInputParameterNamesChange.Add(dgvSet.Rows[e.RowIndex].Cells[0].Value.ToString());
            //        dListInputMaxChange.Add(double.Parse(dgvSet.Rows[e.RowIndex].Cells[1].Value.ToString()));
            //        dListInputMinChange.Add(double.Parse(dgvSet.Rows[e.RowIndex].Cells[2].Value.ToString()));
            //        if (rdoPM.Checked)
            //        {
            //            dListInputPMValuesChange.Add(double.Parse(dgvSet.Rows[e.RowIndex].Cells[4].Value.ToString()));
            //            dListInputResetValuesChange.Add(structData.dListInputResetValues[e.RowIndex]);
            //            //dListInputResetValuesChange.Add(14);
            //        }
            //        else if (rdoReset.Checked)
            //        {
            //            dListInputResetValuesChange.Add(double.Parse(dgvSet.Rows[e.RowIndex].Cells[4].Value.ToString()));
            //            dListInputPMValuesChange.Add(structData.dListInputPMValues[e.RowIndex]);
            //        }
            //        htRowChange.Add(e.RowIndex.ToString(), strListInputParameterNamesChange.Count - 1);
            //    }
            //}
            //else
            //{
            //    MessageBox.Show("Set values out of range");
            //    dgvSet.Rows[e.RowIndex].Cells[4].Value = dgvSet.Rows[e.RowIndex].Cells[3].Value;
            //}           
            #endregion
        }
        private void dgvSet_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (htRowChange.ContainsKey(e.RowIndex.ToString()))
            {
                int index = int.Parse(htRowChange[e.RowIndex.ToString()].ToString());
                iListInputIndexChange.RemoveAt(index);
                dListInputMaxChange.RemoveAt(index);
                dListInputMinChange.RemoveAt(index);
                strListInputParameterNamesChange.RemoveAt(index);
                if (rdoPM.Checked)
                {
                    dListInputPMValuesChange.RemoveAt(index);
                }
                else if (rdoReset.Checked)
                {
                    dListInputResetValuesChange.RemoveAt(index);
                }
                htRowChange.Remove(e.RowIndex.ToString());
            }

            bool flag;
            double dMax = 0.0;
            double dMin = 0.0;
            double dInputNew = 0.0;
            dMax = double.Parse(dgvSet.Rows[e.RowIndex].Cells[1].Value.ToString());
            dMin = double.Parse(dgvSet.Rows[e.RowIndex].Cells[2].Value.ToString());
            dInputNew = double.Parse(dgvSet.Rows[e.RowIndex].Cells[4].Value.ToString());

            if (dInputNew <= dMax && dInputNew >= dMin)
            {
                flag = IsCellValueChange(dInputNew.ToString(), e.RowIndex, e.ColumnIndex);
                if (flag)
                {
                    //iListInputIndexChange.Add(int.Parse(grdCommonMode.Rows[e.Cell.Row.Index].Cells[0].Value.ToString()));
                    iListInputIndexChange.Add(structData.iListInputIndex[e.RowIndex]);
                    strListInputParameterNamesChange.Add(dgvSet.Rows[e.RowIndex].Cells[0].Value.ToString());
                    dListInputMaxChange.Add(double.Parse(dgvSet.Rows[e.RowIndex].Cells[1].Value.ToString()));
                    dListInputMinChange.Add(double.Parse(dgvSet.Rows[e.RowIndex].Cells[2].Value.ToString()));
                    if (rdoPM.Checked)
                    {
                        dListInputPMValuesChange.Add(double.Parse(dgvSet.Rows[e.RowIndex].Cells[4].Value.ToString()));
                        dListInputResetValuesChange.Add(structData.dListInputResetValues[e.RowIndex]);
                        //dListInputResetValuesChange.Add(14);
                    }
                    else if (rdoReset.Checked)
                    {
                        dListInputResetValuesChange.Add(double.Parse(dgvSet.Rows[e.RowIndex].Cells[4].Value.ToString()));
                        dListInputPMValuesChange.Add(structData.dListInputPMValues[e.RowIndex]);
                    }
                    htRowChange.Add(e.RowIndex.ToString(), strListInputParameterNamesChange.Count - 1);
                }
            }
            else
            {
                MessageBox.Show("Set values out of range");
                dgvSet.Rows[e.RowIndex].Cells[4].Value = dgvSet.Rows[e.RowIndex].Cells[3].Value;
            }
        }
        private void dgvContext_CellEndEdit_Old(object sender, DataGridViewCellEventArgs e)
        {
            #region
            if (iRowChangeIndex.Contains(e.RowIndex))
            {
                iListInputIndexChange.RemoveAt(e.RowIndex);
                dListInputMaxChange.RemoveAt(e.RowIndex);
                dListInputMinChange.RemoveAt(e.RowIndex);
                strListInputParameterNamesChange.RemoveAt(e.RowIndex);
                if (rdoPM.Checked)
                {
                    dListInputPMValuesChange.RemoveAt(e.RowIndex);
                }
                else if (rdoReset.Checked)
                {
                    dListInputResetValuesChange.RemoveAt(e.RowIndex);
                }
            }
            else
            {
                iRowChangeIndex.Add(e.RowIndex);
            }
            bool flag;
            string strInputNew;
            strInputNew = dgvSet.Rows[e.RowIndex].Cells[4].Value.ToString();
            flag = IsCellValueChange(strInputNew, e.RowIndex, e.ColumnIndex);
            if (flag)
            {
                //iListInputIndexChange.Add(int.Parse(grdCommonMode.Rows[e.Cell.Row.Index].Cells[0].Value.ToString()));
                iListInputIndexChange.Add(structData.iListInputIndex[e.RowIndex]);
                strListInputParameterNamesChange.Add(dgvSet.Rows[e.RowIndex].Cells[0].Value.ToString());
                dListInputMaxChange.Add(double.Parse(dgvSet.Rows[e.RowIndex].Cells[1].Value.ToString()));
                dListInputMinChange.Add(double.Parse(dgvSet.Rows[e.RowIndex].Cells[2].Value.ToString()));
                if (rdoPM.Checked)
                {
                    dListInputPMValuesChange.Add(double.Parse(dgvSet.Rows[e.RowIndex].Cells[4].Value.ToString()));
                    dListInputResetValuesChange.Add(structData.dListInputResetValues[e.RowIndex]);
                    //dListInputResetValuesChange.Add(14);
                }
                else if (rdoReset.Checked)
                {
                    dListInputResetValuesChange.Add(double.Parse(dgvSet.Rows[e.RowIndex].Cells[4].Value.ToString()));
                    dListInputPMValuesChange.Add(structData.dListInputPMValues[e.RowIndex]);
                }
            }
            #endregion
        }
    }
}

﻿namespace R2R_UI
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.panMain = new System.Windows.Forms.Panel();
            this.tabMain = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panOptMainTab = new System.Windows.Forms.Panel();
            this.panOptChart = new System.Windows.Forms.Panel();
            this.panOptSub = new System.Windows.Forms.Panel();
            this.panOptTabSub = new System.Windows.Forms.Panel();
            this.tabOptSubTab = new System.Windows.Forms.TabControl();
            this.tabPageLinear = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.grdOptLinear = new System.Windows.Forms.DataGridView();
            this.panLinearLbl = new System.Windows.Forms.Panel();
            this.lblLinear = new System.Windows.Forms.Label();
            this.tabPageHOPC = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.grdOptHOPC = new System.Windows.Forms.DataGridView();
            this.panHOPCLbl = new System.Windows.Forms.Panel();
            this.lblHOPC = new System.Windows.Forms.Label();
            this.tabPageIHOPC = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.grdOptIHOPC = new System.Windows.Forms.DataGridView();
            this.panIHOPCLbl = new System.Windows.Forms.Panel();
            this.lblIHOPC = new System.Windows.Forms.Label();
            this.tabPageCD = new System.Windows.Forms.TabPage();
            this.panel5 = new System.Windows.Forms.Panel();
            this.grdOptCD = new System.Windows.Forms.DataGridView();
            this.panCDLbl = new System.Windows.Forms.Panel();
            this.lblCD = new System.Windows.Forms.Label();
            this.tabPageFocus = new System.Windows.Forms.TabPage();
            this.panel6 = new System.Windows.Forms.Panel();
            this.grdOptFocus = new System.Windows.Forms.DataGridView();
            this.panFocusLbl = new System.Windows.Forms.Panel();
            this.lblFocus = new System.Windows.Forms.Label();
            this.panOptSubBtn = new System.Windows.Forms.Panel();
            this.grpOptSubBtn = new System.Windows.Forms.GroupBox();
            this.panForcePilot = new System.Windows.Forms.Panel();
            this.btnPilotUpdate = new System.Windows.Forms.Button();
            this.chkForcePilot = new System.Windows.Forms.CheckBox();
            this.panBtn = new System.Windows.Forms.Panel();
            this.btnOptMode = new System.Windows.Forms.Button();
            this.btnOptReset = new System.Windows.Forms.Button();
            this.panListLot = new System.Windows.Forms.Panel();
            this.rdoListValid = new System.Windows.Forms.RadioButton();
            this.rdoMetrology = new System.Windows.Forms.RadioButton();
            this.rdoLotAll = new System.Windows.Forms.RadioButton();
            this.lblCurrentOVLMode = new System.Windows.Forms.Label();
            this.lblCurrentR2RMode = new System.Windows.Forms.Label();
            this.panOptContext = new System.Windows.Forms.Panel();
            this.panOptContextGroup = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.grdOptContextGroup = new System.Windows.Forms.DataGridView();
            this.panContextGroupLbl = new System.Windows.Forms.Panel();
            this.lblContextGroup = new System.Windows.Forms.Label();
            this.panOptBtn = new System.Windows.Forms.Panel();
            this.grpOptBtn = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdoChuck2 = new System.Windows.Forms.RadioButton();
            this.rdoChuck1 = new System.Windows.Forms.RadioButton();
            this.btnPreLayerConfig = new System.Windows.Forms.Button();
            this.btnChuckDedication = new System.Windows.Forms.Button();
            this.btnOptBatchOperation = new System.Windows.Forms.Button();
            this.panOptContextGrid = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.cmbTool = new System.Windows.Forms.ComboBox();
            this.btnOptRun = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.txtLots = new System.Windows.Forms.TextBox();
            this.txtModule = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbProduct = new System.Windows.Forms.ComboBox();
            this.cmbControl = new System.Windows.Forms.ComboBox();
            this.cmbLayer = new System.Windows.Forms.ComboBox();
            this.txtStage = new System.Windows.Forms.TextBox();
            this.txtLayer = new System.Windows.Forms.TextBox();
            this.cmbStage = new System.Windows.Forms.ComboBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.cmbModule = new System.Windows.Forms.ComboBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel13 = new System.Windows.Forms.Panel();
            this.tabLog_History = new System.Windows.Forms.TabControl();
            this.tabPageCalculation = new System.Windows.Forms.TabPage();
            this.panel30 = new System.Windows.Forms.Panel();
            this.wbsCalculation_History = new System.Windows.Forms.WebBrowser();
            this.panUserReportLbl_History = new System.Windows.Forms.Panel();
            this.lblUserReport_History = new System.Windows.Forms.Label();
            this.tabPageProcess = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.panel27 = new System.Windows.Forms.Panel();
            this.dgvBasicInformation_History = new System.Windows.Forms.DataGridView();
            this.panBasicInfLbl_History = new System.Windows.Forms.Panel();
            this.lblBasicInf_History = new System.Windows.Forms.Label();
            this.panDetails = new System.Windows.Forms.Panel();
            this.panDetailsDgv = new System.Windows.Forms.Panel();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.tvwDetails = new System.Windows.Forms.TreeView();
            this.panDetailsLbl_History = new System.Windows.Forms.Panel();
            this.lblDetails_History = new System.Windows.Forms.Label();
            this.btnProcess_History = new System.Windows.Forms.Button();
            this.tabPageXML = new System.Windows.Forms.TabPage();
            this.wbsXML_History = new System.Windows.Forms.WebBrowser();
            this.btnXML_History = new System.Windows.Forms.Button();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.dgvContext_History = new System.Windows.Forms.DataGridView();
            this.panContextLbl_History = new System.Windows.Forms.Panel();
            this.lblContext_History = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.chkSort = new System.Windows.Forms.CheckBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.dtpTo_History = new System.Windows.Forms.DateTimePicker();
            this.cmbLotId_History = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbProduct_History = new System.Windows.Forms.ComboBox();
            this.dtpFrom_History = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.cmbLayer_History = new System.Windows.Forms.ComboBox();
            this.cmbModule_History = new System.Windows.Forms.ComboBox();
            this.txtListOfRuns_History = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.cmbTool_History = new System.Windows.Forms.ComboBox();
            this.txtLayer_History = new System.Windows.Forms.TextBox();
            this.cmbStage_History = new System.Windows.Forms.ComboBox();
            this.btnRun_History = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.panInput = new System.Windows.Forms.Panel();
            this.panOutput = new System.Windows.Forms.Panel();
            this.panMain.SuspendLayout();
            this.tabMain.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panOptMainTab.SuspendLayout();
            this.panOptSub.SuspendLayout();
            this.panOptTabSub.SuspendLayout();
            this.tabOptSubTab.SuspendLayout();
            this.tabPageLinear.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdOptLinear)).BeginInit();
            this.panLinearLbl.SuspendLayout();
            this.tabPageHOPC.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdOptHOPC)).BeginInit();
            this.panHOPCLbl.SuspendLayout();
            this.tabPageIHOPC.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdOptIHOPC)).BeginInit();
            this.panIHOPCLbl.SuspendLayout();
            this.tabPageCD.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdOptCD)).BeginInit();
            this.panCDLbl.SuspendLayout();
            this.tabPageFocus.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdOptFocus)).BeginInit();
            this.panFocusLbl.SuspendLayout();
            this.panOptSubBtn.SuspendLayout();
            this.grpOptSubBtn.SuspendLayout();
            this.panForcePilot.SuspendLayout();
            this.panBtn.SuspendLayout();
            this.panListLot.SuspendLayout();
            this.panOptContext.SuspendLayout();
            this.panOptContextGroup.SuspendLayout();
            this.panel14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdOptContextGroup)).BeginInit();
            this.panContextGroupLbl.SuspendLayout();
            this.panOptBtn.SuspendLayout();
            this.grpOptBtn.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panOptContextGrid.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel13.SuspendLayout();
            this.tabLog_History.SuspendLayout();
            this.tabPageCalculation.SuspendLayout();
            this.panel30.SuspendLayout();
            this.panUserReportLbl_History.SuspendLayout();
            this.tabPageProcess.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.panel27.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBasicInformation_History)).BeginInit();
            this.panBasicInfLbl_History.SuspendLayout();
            this.panDetails.SuspendLayout();
            this.panDetailsDgv.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.panDetailsLbl_History.SuspendLayout();
            this.tabPageXML.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvContext_History)).BeginInit();
            this.panContextLbl_History.SuspendLayout();
            this.panel16.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panMain
            // 
            this.panMain.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panMain.Controls.Add(this.tabMain);
            this.panMain.Controls.Add(this.statusStrip1);
            this.panMain.Location = new System.Drawing.Point(0, 64);
            this.panMain.Name = "panMain";
            this.panMain.Size = new System.Drawing.Size(1524, 803);
            this.panMain.TabIndex = 0;
            // 
            // tabMain
            // 
            this.tabMain.Controls.Add(this.tabPage1);
            this.tabMain.Controls.Add(this.tabPage2);
            this.tabMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabMain.Location = new System.Drawing.Point(0, 0);
            this.tabMain.Name = "tabMain";
            this.tabMain.SelectedIndex = 0;
            this.tabMain.Size = new System.Drawing.Size(1524, 781);
            this.tabMain.TabIndex = 0;
            this.tabMain.SelectedIndexChanged += new System.EventHandler(this.tabMain_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.panOptMainTab);
            this.tabPage1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1516, 752);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Operation";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // panOptMainTab
            // 
            this.panOptMainTab.Controls.Add(this.panOptChart);
            this.panOptMainTab.Controls.Add(this.panOptSub);
            this.panOptMainTab.Controls.Add(this.panOptContext);
            this.panOptMainTab.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panOptMainTab.Location = new System.Drawing.Point(3, 3);
            this.panOptMainTab.Name = "panOptMainTab";
            this.panOptMainTab.Size = new System.Drawing.Size(1510, 746);
            this.panOptMainTab.TabIndex = 1;
            // 
            // panOptChart
            // 
            this.panOptChart.AutoScroll = true;
            this.panOptChart.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panOptChart.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panOptChart.Location = new System.Drawing.Point(0, 489);
            this.panOptChart.Name = "panOptChart";
            this.panOptChart.Size = new System.Drawing.Size(1510, 257);
            this.panOptChart.TabIndex = 2;
            // 
            // panOptSub
            // 
            this.panOptSub.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panOptSub.Controls.Add(this.panOptTabSub);
            this.panOptSub.Controls.Add(this.panOptSubBtn);
            this.panOptSub.Dock = System.Windows.Forms.DockStyle.Top;
            this.panOptSub.Location = new System.Drawing.Point(0, 242);
            this.panOptSub.Name = "panOptSub";
            this.panOptSub.Size = new System.Drawing.Size(1510, 247);
            this.panOptSub.TabIndex = 1;
            // 
            // panOptTabSub
            // 
            this.panOptTabSub.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panOptTabSub.Controls.Add(this.tabOptSubTab);
            this.panOptTabSub.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panOptTabSub.Location = new System.Drawing.Point(0, 0);
            this.panOptTabSub.Name = "panOptTabSub";
            this.panOptTabSub.Size = new System.Drawing.Size(1241, 245);
            this.panOptTabSub.TabIndex = 3;
            // 
            // tabOptSubTab
            // 
            this.tabOptSubTab.Controls.Add(this.tabPageLinear);
            this.tabOptSubTab.Controls.Add(this.tabPageHOPC);
            this.tabOptSubTab.Controls.Add(this.tabPageIHOPC);
            this.tabOptSubTab.Controls.Add(this.tabPageCD);
            this.tabOptSubTab.Controls.Add(this.tabPageFocus);
            this.tabOptSubTab.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabOptSubTab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabOptSubTab.Location = new System.Drawing.Point(0, 0);
            this.tabOptSubTab.Name = "tabOptSubTab";
            this.tabOptSubTab.SelectedIndex = 0;
            this.tabOptSubTab.Size = new System.Drawing.Size(1239, 243);
            this.tabOptSubTab.TabIndex = 0;
            this.tabOptSubTab.SelectedIndexChanged += new System.EventHandler(this.tabOptSubTab_SelectedIndexChanged);
            // 
            // tabPageLinear
            // 
            this.tabPageLinear.Controls.Add(this.panel1);
            this.tabPageLinear.Controls.Add(this.panLinearLbl);
            this.tabPageLinear.Location = new System.Drawing.Point(4, 25);
            this.tabPageLinear.Name = "tabPageLinear";
            this.tabPageLinear.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageLinear.Size = new System.Drawing.Size(1231, 214);
            this.tabPageLinear.TabIndex = 0;
            this.tabPageLinear.Text = "Linear";
            this.tabPageLinear.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.grdOptLinear);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 29);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1225, 182);
            this.panel1.TabIndex = 4;
            // 
            // grdOptLinear
            // 
            this.grdOptLinear.AllowUserToAddRows = false;
            this.grdOptLinear.AllowUserToDeleteRows = false;
            this.grdOptLinear.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.grdOptLinear.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.grdOptLinear.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdOptLinear.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdOptLinear.Location = new System.Drawing.Point(0, 0);
            this.grdOptLinear.Name = "grdOptLinear";
            this.grdOptLinear.Size = new System.Drawing.Size(1225, 182);
            this.grdOptLinear.TabIndex = 2;
            // 
            // panLinearLbl
            // 
            this.panLinearLbl.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panLinearLbl.Controls.Add(this.lblLinear);
            this.panLinearLbl.Dock = System.Windows.Forms.DockStyle.Top;
            this.panLinearLbl.Location = new System.Drawing.Point(3, 3);
            this.panLinearLbl.Name = "panLinearLbl";
            this.panLinearLbl.Size = new System.Drawing.Size(1225, 26);
            this.panLinearLbl.TabIndex = 3;
            // 
            // lblLinear
            // 
            this.lblLinear.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblLinear.AutoSize = true;
            this.lblLinear.Location = new System.Drawing.Point(136, 7);
            this.lblLinear.Name = "lblLinear";
            this.lblLinear.Size = new System.Drawing.Size(45, 16);
            this.lblLinear.TabIndex = 0;
            this.lblLinear.Text = "label2";
            // 
            // tabPageHOPC
            // 
            this.tabPageHOPC.Controls.Add(this.panel2);
            this.tabPageHOPC.Controls.Add(this.panHOPCLbl);
            this.tabPageHOPC.Location = new System.Drawing.Point(4, 25);
            this.tabPageHOPC.Name = "tabPageHOPC";
            this.tabPageHOPC.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageHOPC.Size = new System.Drawing.Size(1231, 214);
            this.tabPageHOPC.TabIndex = 1;
            this.tabPageHOPC.Text = "HOPC";
            this.tabPageHOPC.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.grdOptHOPC);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(3, 29);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1225, 182);
            this.panel2.TabIndex = 5;
            // 
            // grdOptHOPC
            // 
            this.grdOptHOPC.AllowUserToAddRows = false;
            this.grdOptHOPC.AllowUserToDeleteRows = false;
            this.grdOptHOPC.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.grdOptHOPC.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.grdOptHOPC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdOptHOPC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdOptHOPC.Location = new System.Drawing.Point(0, 0);
            this.grdOptHOPC.Name = "grdOptHOPC";
            this.grdOptHOPC.Size = new System.Drawing.Size(1225, 182);
            this.grdOptHOPC.TabIndex = 2;
            // 
            // panHOPCLbl
            // 
            this.panHOPCLbl.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panHOPCLbl.Controls.Add(this.lblHOPC);
            this.panHOPCLbl.Dock = System.Windows.Forms.DockStyle.Top;
            this.panHOPCLbl.Location = new System.Drawing.Point(3, 3);
            this.panHOPCLbl.Name = "panHOPCLbl";
            this.panHOPCLbl.Size = new System.Drawing.Size(1225, 26);
            this.panHOPCLbl.TabIndex = 4;
            // 
            // lblHOPC
            // 
            this.lblHOPC.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblHOPC.AutoSize = true;
            this.lblHOPC.Location = new System.Drawing.Point(136, 7);
            this.lblHOPC.Name = "lblHOPC";
            this.lblHOPC.Size = new System.Drawing.Size(45, 16);
            this.lblHOPC.TabIndex = 0;
            this.lblHOPC.Text = "label3";
            // 
            // tabPageIHOPC
            // 
            this.tabPageIHOPC.Controls.Add(this.panel3);
            this.tabPageIHOPC.Controls.Add(this.panIHOPCLbl);
            this.tabPageIHOPC.Location = new System.Drawing.Point(4, 25);
            this.tabPageIHOPC.Name = "tabPageIHOPC";
            this.tabPageIHOPC.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageIHOPC.Size = new System.Drawing.Size(1231, 214);
            this.tabPageIHOPC.TabIndex = 2;
            this.tabPageIHOPC.Text = "IHOPC";
            this.tabPageIHOPC.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.grdOptIHOPC);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(3, 29);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1225, 182);
            this.panel3.TabIndex = 5;
            // 
            // grdOptIHOPC
            // 
            this.grdOptIHOPC.AllowUserToAddRows = false;
            this.grdOptIHOPC.AllowUserToDeleteRows = false;
            this.grdOptIHOPC.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.grdOptIHOPC.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.grdOptIHOPC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdOptIHOPC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdOptIHOPC.Location = new System.Drawing.Point(0, 0);
            this.grdOptIHOPC.Name = "grdOptIHOPC";
            this.grdOptIHOPC.Size = new System.Drawing.Size(1225, 182);
            this.grdOptIHOPC.TabIndex = 2;
            // 
            // panIHOPCLbl
            // 
            this.panIHOPCLbl.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panIHOPCLbl.Controls.Add(this.lblIHOPC);
            this.panIHOPCLbl.Dock = System.Windows.Forms.DockStyle.Top;
            this.panIHOPCLbl.Location = new System.Drawing.Point(3, 3);
            this.panIHOPCLbl.Name = "panIHOPCLbl";
            this.panIHOPCLbl.Size = new System.Drawing.Size(1225, 26);
            this.panIHOPCLbl.TabIndex = 4;
            // 
            // lblIHOPC
            // 
            this.lblIHOPC.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblIHOPC.AutoSize = true;
            this.lblIHOPC.Location = new System.Drawing.Point(136, 7);
            this.lblIHOPC.Name = "lblIHOPC";
            this.lblIHOPC.Size = new System.Drawing.Size(45, 16);
            this.lblIHOPC.TabIndex = 0;
            this.lblIHOPC.Text = "label4";
            // 
            // tabPageCD
            // 
            this.tabPageCD.Controls.Add(this.panel5);
            this.tabPageCD.Controls.Add(this.panCDLbl);
            this.tabPageCD.Location = new System.Drawing.Point(4, 25);
            this.tabPageCD.Name = "tabPageCD";
            this.tabPageCD.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageCD.Size = new System.Drawing.Size(1231, 214);
            this.tabPageCD.TabIndex = 4;
            this.tabPageCD.Text = "CD";
            this.tabPageCD.UseVisualStyleBackColor = true;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.grdOptCD);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(3, 29);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1225, 182);
            this.panel5.TabIndex = 7;
            // 
            // grdOptCD
            // 
            this.grdOptCD.AllowUserToAddRows = false;
            this.grdOptCD.AllowUserToDeleteRows = false;
            this.grdOptCD.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.grdOptCD.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.grdOptCD.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdOptCD.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdOptCD.Location = new System.Drawing.Point(0, 0);
            this.grdOptCD.Name = "grdOptCD";
            this.grdOptCD.Size = new System.Drawing.Size(1225, 182);
            this.grdOptCD.TabIndex = 2;
            // 
            // panCDLbl
            // 
            this.panCDLbl.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panCDLbl.Controls.Add(this.lblCD);
            this.panCDLbl.Dock = System.Windows.Forms.DockStyle.Top;
            this.panCDLbl.Location = new System.Drawing.Point(3, 3);
            this.panCDLbl.Name = "panCDLbl";
            this.panCDLbl.Size = new System.Drawing.Size(1225, 26);
            this.panCDLbl.TabIndex = 6;
            // 
            // lblCD
            // 
            this.lblCD.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblCD.AutoSize = true;
            this.lblCD.Location = new System.Drawing.Point(136, 7);
            this.lblCD.Name = "lblCD";
            this.lblCD.Size = new System.Drawing.Size(45, 16);
            this.lblCD.TabIndex = 0;
            this.lblCD.Text = "label6";
            // 
            // tabPageFocus
            // 
            this.tabPageFocus.Controls.Add(this.panel6);
            this.tabPageFocus.Controls.Add(this.panFocusLbl);
            this.tabPageFocus.Location = new System.Drawing.Point(4, 25);
            this.tabPageFocus.Name = "tabPageFocus";
            this.tabPageFocus.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageFocus.Size = new System.Drawing.Size(1231, 214);
            this.tabPageFocus.TabIndex = 5;
            this.tabPageFocus.Text = "Focus";
            this.tabPageFocus.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.grdOptFocus);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(3, 29);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1225, 182);
            this.panel6.TabIndex = 8;
            // 
            // grdOptFocus
            // 
            this.grdOptFocus.AllowUserToAddRows = false;
            this.grdOptFocus.AllowUserToDeleteRows = false;
            this.grdOptFocus.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.grdOptFocus.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.grdOptFocus.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdOptFocus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdOptFocus.Location = new System.Drawing.Point(0, 0);
            this.grdOptFocus.Name = "grdOptFocus";
            this.grdOptFocus.Size = new System.Drawing.Size(1225, 182);
            this.grdOptFocus.TabIndex = 2;
            // 
            // panFocusLbl
            // 
            this.panFocusLbl.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panFocusLbl.Controls.Add(this.lblFocus);
            this.panFocusLbl.Dock = System.Windows.Forms.DockStyle.Top;
            this.panFocusLbl.Location = new System.Drawing.Point(3, 3);
            this.panFocusLbl.Name = "panFocusLbl";
            this.panFocusLbl.Size = new System.Drawing.Size(1225, 26);
            this.panFocusLbl.TabIndex = 7;
            // 
            // lblFocus
            // 
            this.lblFocus.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblFocus.AutoSize = true;
            this.lblFocus.Location = new System.Drawing.Point(135, 7);
            this.lblFocus.Name = "lblFocus";
            this.lblFocus.Size = new System.Drawing.Size(45, 16);
            this.lblFocus.TabIndex = 0;
            this.lblFocus.Text = "label7";
            // 
            // panOptSubBtn
            // 
            this.panOptSubBtn.Controls.Add(this.grpOptSubBtn);
            this.panOptSubBtn.Dock = System.Windows.Forms.DockStyle.Right;
            this.panOptSubBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panOptSubBtn.Location = new System.Drawing.Point(1241, 0);
            this.panOptSubBtn.Name = "panOptSubBtn";
            this.panOptSubBtn.Size = new System.Drawing.Size(267, 245);
            this.panOptSubBtn.TabIndex = 2;
            // 
            // grpOptSubBtn
            // 
            this.grpOptSubBtn.Controls.Add(this.panForcePilot);
            this.grpOptSubBtn.Controls.Add(this.panBtn);
            this.grpOptSubBtn.Controls.Add(this.panListLot);
            this.grpOptSubBtn.Controls.Add(this.lblCurrentOVLMode);
            this.grpOptSubBtn.Controls.Add(this.lblCurrentR2RMode);
            this.grpOptSubBtn.Location = new System.Drawing.Point(4, 5);
            this.grpOptSubBtn.Name = "grpOptSubBtn";
            this.grpOptSubBtn.Size = new System.Drawing.Size(257, 234);
            this.grpOptSubBtn.TabIndex = 0;
            this.grpOptSubBtn.TabStop = false;
            // 
            // panForcePilot
            // 
            this.panForcePilot.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panForcePilot.Controls.Add(this.btnPilotUpdate);
            this.panForcePilot.Controls.Add(this.chkForcePilot);
            this.panForcePilot.Location = new System.Drawing.Point(32, 106);
            this.panForcePilot.Name = "panForcePilot";
            this.panForcePilot.Size = new System.Drawing.Size(200, 37);
            this.panForcePilot.TabIndex = 16;
            // 
            // btnPilotUpdate
            // 
            this.btnPilotUpdate.Location = new System.Drawing.Point(112, 5);
            this.btnPilotUpdate.Name = "btnPilotUpdate";
            this.btnPilotUpdate.Size = new System.Drawing.Size(75, 25);
            this.btnPilotUpdate.TabIndex = 1;
            this.btnPilotUpdate.Text = "Update";
            this.btnPilotUpdate.UseVisualStyleBackColor = true;
            this.btnPilotUpdate.Click += new System.EventHandler(this.btnPilotUpdate_Click);
            // 
            // chkForcePilot
            // 
            this.chkForcePilot.AutoSize = true;
            this.chkForcePilot.Location = new System.Drawing.Point(14, 8);
            this.chkForcePilot.Name = "chkForcePilot";
            this.chkForcePilot.Size = new System.Drawing.Size(88, 20);
            this.chkForcePilot.TabIndex = 0;
            this.chkForcePilot.Text = "ForcePilot";
            this.chkForcePilot.UseVisualStyleBackColor = true;
            // 
            // panBtn
            // 
            this.panBtn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panBtn.Controls.Add(this.btnOptMode);
            this.panBtn.Controls.Add(this.btnOptReset);
            this.panBtn.Location = new System.Drawing.Point(32, 197);
            this.panBtn.Name = "panBtn";
            this.panBtn.Size = new System.Drawing.Size(200, 36);
            this.panBtn.TabIndex = 15;
            // 
            // btnOptMode
            // 
            this.btnOptMode.Location = new System.Drawing.Point(14, 3);
            this.btnOptMode.Name = "btnOptMode";
            this.btnOptMode.Size = new System.Drawing.Size(75, 25);
            this.btnOptMode.TabIndex = 3;
            this.btnOptMode.Text = "Mode";
            this.btnOptMode.UseVisualStyleBackColor = true;
            this.btnOptMode.Click += new System.EventHandler(this.btnOptMode_Click);
            // 
            // btnOptReset
            // 
            this.btnOptReset.Location = new System.Drawing.Point(112, 3);
            this.btnOptReset.Name = "btnOptReset";
            this.btnOptReset.Size = new System.Drawing.Size(75, 25);
            this.btnOptReset.TabIndex = 4;
            this.btnOptReset.Text = "Reset";
            this.btnOptReset.UseVisualStyleBackColor = true;
            this.btnOptReset.Click += new System.EventHandler(this.btnOptReset_Click);
            // 
            // panListLot
            // 
            this.panListLot.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panListLot.Controls.Add(this.rdoListValid);
            this.panListLot.Controls.Add(this.rdoMetrology);
            this.panListLot.Controls.Add(this.rdoLotAll);
            this.panListLot.Location = new System.Drawing.Point(32, 21);
            this.panListLot.Name = "panListLot";
            this.panListLot.Size = new System.Drawing.Size(200, 79);
            this.panListLot.TabIndex = 14;
            // 
            // rdoListValid
            // 
            this.rdoListValid.AutoSize = true;
            this.rdoListValid.Location = new System.Drawing.Point(14, 30);
            this.rdoListValid.Name = "rdoListValid";
            this.rdoListValid.Size = new System.Drawing.Size(108, 20);
            this.rdoListValid.TabIndex = 10;
            this.rdoListValid.Text = "List Valid Lots";
            this.rdoListValid.UseVisualStyleBackColor = true;
            this.rdoListValid.CheckedChanged += new System.EventHandler(this.rdoListValid_CheckedChanged);
            // 
            // rdoMetrology
            // 
            this.rdoMetrology.AutoSize = true;
            this.rdoMetrology.Location = new System.Drawing.Point(14, 53);
            this.rdoMetrology.Name = "rdoMetrology";
            this.rdoMetrology.Size = new System.Drawing.Size(166, 20);
            this.rdoMetrology.TabIndex = 9;
            this.rdoMetrology.Text = "List Lots With Metrology";
            this.rdoMetrology.UseVisualStyleBackColor = true;
            this.rdoMetrology.CheckedChanged += new System.EventHandler(this.rdoMetrology_CheckedChanged);
            // 
            // rdoLotAll
            // 
            this.rdoLotAll.AutoSize = true;
            this.rdoLotAll.Checked = true;
            this.rdoLotAll.Location = new System.Drawing.Point(14, 7);
            this.rdoLotAll.Name = "rdoLotAll";
            this.rdoLotAll.Size = new System.Drawing.Size(85, 20);
            this.rdoLotAll.TabIndex = 8;
            this.rdoLotAll.TabStop = true;
            this.rdoLotAll.Text = "List All Lot";
            this.rdoLotAll.UseVisualStyleBackColor = true;
            this.rdoLotAll.CheckedChanged += new System.EventHandler(this.rdoLotAll_CheckedChanged);
            // 
            // lblCurrentOVLMode
            // 
            this.lblCurrentOVLMode.AutoSize = true;
            this.lblCurrentOVLMode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCurrentOVLMode.Location = new System.Drawing.Point(32, 149);
            this.lblCurrentOVLMode.Name = "lblCurrentOVLMode";
            this.lblCurrentOVLMode.Size = new System.Drawing.Size(122, 18);
            this.lblCurrentOVLMode.TabIndex = 5;
            this.lblCurrentOVLMode.Text = "Current OVL Mode:";
            // 
            // lblCurrentR2RMode
            // 
            this.lblCurrentR2RMode.AutoSize = true;
            this.lblCurrentR2RMode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCurrentR2RMode.Location = new System.Drawing.Point(32, 173);
            this.lblCurrentR2RMode.Name = "lblCurrentR2RMode";
            this.lblCurrentR2RMode.Size = new System.Drawing.Size(123, 18);
            this.lblCurrentR2RMode.TabIndex = 6;
            this.lblCurrentR2RMode.Text = "Current R2R Mode:";
            // 
            // panOptContext
            // 
            this.panOptContext.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panOptContext.Controls.Add(this.panOptContextGroup);
            this.panOptContext.Controls.Add(this.panOptBtn);
            this.panOptContext.Controls.Add(this.panOptContextGrid);
            this.panOptContext.Dock = System.Windows.Forms.DockStyle.Top;
            this.panOptContext.Location = new System.Drawing.Point(0, 0);
            this.panOptContext.Name = "panOptContext";
            this.panOptContext.Size = new System.Drawing.Size(1510, 242);
            this.panOptContext.TabIndex = 0;
            // 
            // panOptContextGroup
            // 
            this.panOptContextGroup.Controls.Add(this.panel14);
            this.panOptContextGroup.Controls.Add(this.panContextGroupLbl);
            this.panOptContextGroup.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panOptContextGroup.Location = new System.Drawing.Point(332, 0);
            this.panOptContextGroup.Name = "panOptContextGroup";
            this.panOptContextGroup.Size = new System.Drawing.Size(909, 240);
            this.panOptContextGroup.TabIndex = 2;
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.grdOptContextGroup);
            this.panel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel14.Location = new System.Drawing.Point(0, 26);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(909, 214);
            this.panel14.TabIndex = 10;
            // 
            // grdOptContextGroup
            // 
            this.grdOptContextGroup.AllowUserToAddRows = false;
            this.grdOptContextGroup.AllowUserToDeleteRows = false;
            this.grdOptContextGroup.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.grdOptContextGroup.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.grdOptContextGroup.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdOptContextGroup.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdOptContextGroup.Location = new System.Drawing.Point(0, 0);
            this.grdOptContextGroup.Name = "grdOptContextGroup";
            this.grdOptContextGroup.Size = new System.Drawing.Size(909, 214);
            this.grdOptContextGroup.TabIndex = 1;
            this.grdOptContextGroup.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grdOptContextGroup_CellClick);
            this.grdOptContextGroup.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grdOptContextGroup_CellDoubleClick);
            // 
            // panContextGroupLbl
            // 
            this.panContextGroupLbl.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panContextGroupLbl.Controls.Add(this.lblContextGroup);
            this.panContextGroupLbl.Dock = System.Windows.Forms.DockStyle.Top;
            this.panContextGroupLbl.Location = new System.Drawing.Point(0, 0);
            this.panContextGroupLbl.Name = "panContextGroupLbl";
            this.panContextGroupLbl.Size = new System.Drawing.Size(909, 26);
            this.panContextGroupLbl.TabIndex = 9;
            // 
            // lblContextGroup
            // 
            this.lblContextGroup.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblContextGroup.AutoSize = true;
            this.lblContextGroup.Location = new System.Drawing.Point(359, 6);
            this.lblContextGroup.Name = "lblContextGroup";
            this.lblContextGroup.Size = new System.Drawing.Size(52, 16);
            this.lblContextGroup.TabIndex = 0;
            this.lblContextGroup.Text = "label14";
            // 
            // panOptBtn
            // 
            this.panOptBtn.Controls.Add(this.grpOptBtn);
            this.panOptBtn.Dock = System.Windows.Forms.DockStyle.Right;
            this.panOptBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panOptBtn.Location = new System.Drawing.Point(1241, 0);
            this.panOptBtn.Name = "panOptBtn";
            this.panOptBtn.Size = new System.Drawing.Size(267, 240);
            this.panOptBtn.TabIndex = 1;
            // 
            // grpOptBtn
            // 
            this.grpOptBtn.Controls.Add(this.groupBox1);
            this.grpOptBtn.Controls.Add(this.btnPreLayerConfig);
            this.grpOptBtn.Controls.Add(this.btnChuckDedication);
            this.grpOptBtn.Controls.Add(this.btnOptBatchOperation);
            this.grpOptBtn.Location = new System.Drawing.Point(5, 3);
            this.grpOptBtn.Name = "grpOptBtn";
            this.grpOptBtn.Size = new System.Drawing.Size(257, 227);
            this.grpOptBtn.TabIndex = 0;
            this.grpOptBtn.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdoChuck2);
            this.groupBox1.Controls.Add(this.rdoChuck1);
            this.groupBox1.Location = new System.Drawing.Point(31, 175);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(187, 46);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            // 
            // rdoChuck2
            // 
            this.rdoChuck2.AutoSize = true;
            this.rdoChuck2.Location = new System.Drawing.Point(96, 20);
            this.rdoChuck2.Name = "rdoChuck2";
            this.rdoChuck2.Size = new System.Drawing.Size(70, 20);
            this.rdoChuck2.TabIndex = 10;
            this.rdoChuck2.Text = "Chuck2";
            this.rdoChuck2.UseVisualStyleBackColor = true;
            this.rdoChuck2.CheckedChanged += new System.EventHandler(this.rdoChuck2_CheckedChanged);
            // 
            // rdoChuck1
            // 
            this.rdoChuck1.AutoSize = true;
            this.rdoChuck1.Checked = true;
            this.rdoChuck1.Location = new System.Drawing.Point(18, 20);
            this.rdoChuck1.Name = "rdoChuck1";
            this.rdoChuck1.Size = new System.Drawing.Size(70, 20);
            this.rdoChuck1.TabIndex = 9;
            this.rdoChuck1.TabStop = true;
            this.rdoChuck1.Text = "Chuck1";
            this.rdoChuck1.UseVisualStyleBackColor = true;
            this.rdoChuck1.CheckedChanged += new System.EventHandler(this.rdoChuck1_CheckedChanged);
            // 
            // btnPreLayerConfig
            // 
            this.btnPreLayerConfig.Location = new System.Drawing.Point(31, 19);
            this.btnPreLayerConfig.Name = "btnPreLayerConfig";
            this.btnPreLayerConfig.Size = new System.Drawing.Size(187, 46);
            this.btnPreLayerConfig.TabIndex = 3;
            this.btnPreLayerConfig.Text = "PreLayer Config";
            this.btnPreLayerConfig.UseVisualStyleBackColor = true;
            this.btnPreLayerConfig.Click += new System.EventHandler(this.btnPreLayer_Click);
            // 
            // btnChuckDedication
            // 
            this.btnChuckDedication.Location = new System.Drawing.Point(31, 71);
            this.btnChuckDedication.Name = "btnChuckDedication";
            this.btnChuckDedication.Size = new System.Drawing.Size(187, 46);
            this.btnChuckDedication.TabIndex = 4;
            this.btnChuckDedication.Text = "Chuck Dedication";
            this.btnChuckDedication.UseVisualStyleBackColor = true;
            this.btnChuckDedication.Click += new System.EventHandler(this.btnChuckDedication_Click);
            // 
            // btnOptBatchOperation
            // 
            this.btnOptBatchOperation.Location = new System.Drawing.Point(31, 123);
            this.btnOptBatchOperation.Name = "btnOptBatchOperation";
            this.btnOptBatchOperation.Size = new System.Drawing.Size(187, 46);
            this.btnOptBatchOperation.TabIndex = 5;
            this.btnOptBatchOperation.Text = "Batch Operation";
            this.btnOptBatchOperation.UseVisualStyleBackColor = true;
            this.btnOptBatchOperation.Click += new System.EventHandler(this.btnBatchOperation_Click);
            // 
            // panOptContextGrid
            // 
            this.panOptContextGrid.Controls.Add(this.groupBox2);
            this.panOptContextGrid.Dock = System.Windows.Forms.DockStyle.Left;
            this.panOptContextGrid.Location = new System.Drawing.Point(0, 0);
            this.panOptContextGrid.Name = "panOptContextGrid";
            this.panOptContextGrid.Size = new System.Drawing.Size(332, 240);
            this.panOptContextGrid.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox2.Controls.Add(this.textBox2);
            this.groupBox2.Controls.Add(this.cmbTool);
            this.groupBox2.Controls.Add(this.btnOptRun);
            this.groupBox2.Controls.Add(this.textBox4);
            this.groupBox2.Controls.Add(this.txtLots);
            this.groupBox2.Controls.Add(this.txtModule);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.cmbProduct);
            this.groupBox2.Controls.Add(this.cmbControl);
            this.groupBox2.Controls.Add(this.cmbLayer);
            this.groupBox2.Controls.Add(this.txtStage);
            this.groupBox2.Controls.Add(this.txtLayer);
            this.groupBox2.Controls.Add(this.cmbStage);
            this.groupBox2.Controls.Add(this.textBox1);
            this.groupBox2.Controls.Add(this.cmbModule);
            this.groupBox2.Location = new System.Drawing.Point(4, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(320, 224);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            // 
            // textBox2
            // 
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Location = new System.Drawing.Point(16, 164);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(55, 15);
            this.textBox2.TabIndex = 20;
            this.textBox2.Text = "Tool";
            // 
            // cmbTool
            // 
            this.cmbTool.FormattingEnabled = true;
            this.cmbTool.Location = new System.Drawing.Point(77, 159);
            this.cmbTool.Name = "cmbTool";
            this.cmbTool.Size = new System.Drawing.Size(223, 24);
            this.cmbTool.TabIndex = 21;
            this.cmbTool.SelectedIndexChanged += new System.EventHandler(this.cmbContext_SelectedIndexChanged);
            this.cmbTool.TextChanged += new System.EventHandler(this.cmbContext_TextChanged);
            // 
            // btnOptRun
            // 
            this.btnOptRun.Location = new System.Drawing.Point(219, 196);
            this.btnOptRun.Name = "btnOptRun";
            this.btnOptRun.Size = new System.Drawing.Size(75, 23);
            this.btnOptRun.TabIndex = 2;
            this.btnOptRun.Text = "Run";
            this.btnOptRun.UseVisualStyleBackColor = true;
            this.btnOptRun.Click += new System.EventHandler(this.btnOptRun_Click);
            // 
            // textBox4
            // 
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox4.Location = new System.Drawing.Point(16, 136);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(55, 15);
            this.textBox4.TabIndex = 18;
            this.textBox4.Text = "Control";
            // 
            // txtLots
            // 
            this.txtLots.Location = new System.Drawing.Point(95, 197);
            this.txtLots.Name = "txtLots";
            this.txtLots.Size = new System.Drawing.Size(100, 22);
            this.txtLots.TabIndex = 1;
            this.txtLots.Text = "20";
            this.txtLots.TextChanged += new System.EventHandler(this.txtLots_TextChanged);
            this.txtLots.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtLots_KeyDown);
            // 
            // txtModule
            // 
            this.txtModule.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtModule.Location = new System.Drawing.Point(16, 24);
            this.txtModule.Name = "txtModule";
            this.txtModule.ReadOnly = true;
            this.txtModule.Size = new System.Drawing.Size(55, 15);
            this.txtModule.TabIndex = 14;
            this.txtModule.Text = "Module";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 200);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "List of Runs";
            // 
            // cmbProduct
            // 
            this.cmbProduct.FormattingEnabled = true;
            this.cmbProduct.Location = new System.Drawing.Point(77, 47);
            this.cmbProduct.Name = "cmbProduct";
            this.cmbProduct.Size = new System.Drawing.Size(223, 24);
            this.cmbProduct.TabIndex = 11;
            this.cmbProduct.SelectedIndexChanged += new System.EventHandler(this.cmbContext_SelectedIndexChanged);
            this.cmbProduct.TextChanged += new System.EventHandler(this.cmbContext_TextChanged);
            // 
            // cmbControl
            // 
            this.cmbControl.FormattingEnabled = true;
            this.cmbControl.Location = new System.Drawing.Point(77, 131);
            this.cmbControl.Name = "cmbControl";
            this.cmbControl.Size = new System.Drawing.Size(223, 24);
            this.cmbControl.TabIndex = 19;
            this.cmbControl.SelectedIndexChanged += new System.EventHandler(this.cmbContext_SelectedIndexChanged);
            this.cmbControl.TextChanged += new System.EventHandler(this.cmbContext_TextChanged);
            // 
            // cmbLayer
            // 
            this.cmbLayer.FormattingEnabled = true;
            this.cmbLayer.Location = new System.Drawing.Point(77, 103);
            this.cmbLayer.Name = "cmbLayer";
            this.cmbLayer.Size = new System.Drawing.Size(223, 24);
            this.cmbLayer.TabIndex = 12;
            this.cmbLayer.SelectedIndexChanged += new System.EventHandler(this.cmbContext_SelectedIndexChanged);
            this.cmbLayer.TextChanged += new System.EventHandler(this.cmbContext_TextChanged);
            // 
            // txtStage
            // 
            this.txtStage.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtStage.Location = new System.Drawing.Point(16, 80);
            this.txtStage.Name = "txtStage";
            this.txtStage.ReadOnly = true;
            this.txtStage.Size = new System.Drawing.Size(55, 15);
            this.txtStage.TabIndex = 16;
            this.txtStage.Text = "Stage";
            // 
            // txtLayer
            // 
            this.txtLayer.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtLayer.Location = new System.Drawing.Point(16, 108);
            this.txtLayer.Name = "txtLayer";
            this.txtLayer.ReadOnly = true;
            this.txtLayer.Size = new System.Drawing.Size(55, 15);
            this.txtLayer.TabIndex = 10;
            this.txtLayer.Text = "Layer";
            // 
            // cmbStage
            // 
            this.cmbStage.FormattingEnabled = true;
            this.cmbStage.Location = new System.Drawing.Point(77, 75);
            this.cmbStage.Name = "cmbStage";
            this.cmbStage.Size = new System.Drawing.Size(223, 24);
            this.cmbStage.TabIndex = 17;
            this.cmbStage.SelectedIndexChanged += new System.EventHandler(this.cmbContext_SelectedIndexChanged);
            this.cmbStage.TextChanged += new System.EventHandler(this.cmbContext_TextChanged);
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Location = new System.Drawing.Point(16, 52);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(55, 15);
            this.textBox1.TabIndex = 8;
            this.textBox1.Text = "Product";
            // 
            // cmbModule
            // 
            this.cmbModule.FormattingEnabled = true;
            this.cmbModule.Location = new System.Drawing.Point(77, 19);
            this.cmbModule.Name = "cmbModule";
            this.cmbModule.Size = new System.Drawing.Size(223, 24);
            this.cmbModule.TabIndex = 15;
            this.cmbModule.SelectedIndexChanged += new System.EventHandler(this.cmbContext_SelectedIndexChanged);
            this.cmbModule.TextChanged += new System.EventHandler(this.cmbContext_TextChanged);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.panel13);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(1516, 752);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "History";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.tabLog_History);
            this.panel13.Controls.Add(this.panel15);
            this.panel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel13.Location = new System.Drawing.Point(0, 0);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(1516, 752);
            this.panel13.TabIndex = 1;
            // 
            // tabLog_History
            // 
            this.tabLog_History.Controls.Add(this.tabPageCalculation);
            this.tabLog_History.Controls.Add(this.tabPageProcess);
            this.tabLog_History.Controls.Add(this.tabPageXML);
            this.tabLog_History.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabLog_History.Location = new System.Drawing.Point(0, 292);
            this.tabLog_History.Name = "tabLog_History";
            this.tabLog_History.SelectedIndex = 0;
            this.tabLog_History.Size = new System.Drawing.Size(1516, 460);
            this.tabLog_History.TabIndex = 0;
            this.tabLog_History.SelectedIndexChanged += new System.EventHandler(this.tabLog_History_SelectedIndexChanged);
            // 
            // tabPageCalculation
            // 
            this.tabPageCalculation.Controls.Add(this.panel30);
            this.tabPageCalculation.Location = new System.Drawing.Point(4, 25);
            this.tabPageCalculation.Name = "tabPageCalculation";
            this.tabPageCalculation.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageCalculation.Size = new System.Drawing.Size(1508, 431);
            this.tabPageCalculation.TabIndex = 2;
            this.tabPageCalculation.Text = "Calculation Log";
            this.tabPageCalculation.UseVisualStyleBackColor = true;
            // 
            // panel30
            // 
            this.panel30.Controls.Add(this.wbsCalculation_History);
            this.panel30.Controls.Add(this.panUserReportLbl_History);
            this.panel30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel30.Location = new System.Drawing.Point(3, 3);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(1502, 425);
            this.panel30.TabIndex = 4;
            // 
            // wbsCalculation_History
            // 
            this.wbsCalculation_History.Dock = System.Windows.Forms.DockStyle.Fill;
            this.wbsCalculation_History.Location = new System.Drawing.Point(0, 33);
            this.wbsCalculation_History.MinimumSize = new System.Drawing.Size(20, 20);
            this.wbsCalculation_History.Name = "wbsCalculation_History";
            this.wbsCalculation_History.Size = new System.Drawing.Size(1502, 392);
            this.wbsCalculation_History.TabIndex = 11;
            this.wbsCalculation_History.Navigated += new System.Windows.Forms.WebBrowserNavigatedEventHandler(this.wbsCalculation_History_Navigated);
            // 
            // panUserReportLbl_History
            // 
            this.panUserReportLbl_History.BackColor = System.Drawing.SystemColors.Control;
            this.panUserReportLbl_History.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panUserReportLbl_History.Controls.Add(this.lblUserReport_History);
            this.panUserReportLbl_History.Dock = System.Windows.Forms.DockStyle.Top;
            this.panUserReportLbl_History.Location = new System.Drawing.Point(0, 0);
            this.panUserReportLbl_History.Name = "panUserReportLbl_History";
            this.panUserReportLbl_History.Size = new System.Drawing.Size(1502, 33);
            this.panUserReportLbl_History.TabIndex = 10;
            // 
            // lblUserReport_History
            // 
            this.lblUserReport_History.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblUserReport_History.AutoSize = true;
            this.lblUserReport_History.Location = new System.Drawing.Point(740, 9);
            this.lblUserReport_History.Name = "lblUserReport_History";
            this.lblUserReport_History.Size = new System.Drawing.Size(92, 16);
            this.lblUserReport_History.TabIndex = 0;
            this.lblUserReport_History.Text = "User Report";
            // 
            // tabPageProcess
            // 
            this.tabPageProcess.Controls.Add(this.splitContainer1);
            this.tabPageProcess.Controls.Add(this.btnProcess_History);
            this.tabPageProcess.Location = new System.Drawing.Point(4, 25);
            this.tabPageProcess.Name = "tabPageProcess";
            this.tabPageProcess.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageProcess.Size = new System.Drawing.Size(1508, 431);
            this.tabPageProcess.TabIndex = 0;
            this.tabPageProcess.Text = "Process Log";
            this.tabPageProcess.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(3, 37);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.panel27);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.panDetails);
            this.splitContainer1.Panel2.Controls.Add(this.panDetailsLbl_History);
            this.splitContainer1.Size = new System.Drawing.Size(1502, 391);
            this.splitContainer1.SplitterDistance = 553;
            this.splitContainer1.TabIndex = 12;
            // 
            // panel27
            // 
            this.panel27.Controls.Add(this.dgvBasicInformation_History);
            this.panel27.Controls.Add(this.panBasicInfLbl_History);
            this.panel27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel27.Location = new System.Drawing.Point(0, 0);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(553, 391);
            this.panel27.TabIndex = 2;
            // 
            // dgvBasicInformation_History
            // 
            this.dgvBasicInformation_History.AllowUserToAddRows = false;
            this.dgvBasicInformation_History.AllowUserToDeleteRows = false;
            this.dgvBasicInformation_History.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvBasicInformation_History.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvBasicInformation_History.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvBasicInformation_History.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBasicInformation_History.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvBasicInformation_History.Location = new System.Drawing.Point(0, 33);
            this.dgvBasicInformation_History.Name = "dgvBasicInformation_History";
            this.dgvBasicInformation_History.Size = new System.Drawing.Size(553, 358);
            this.dgvBasicInformation_History.TabIndex = 2;
            // 
            // panBasicInfLbl_History
            // 
            this.panBasicInfLbl_History.BackColor = System.Drawing.SystemColors.Control;
            this.panBasicInfLbl_History.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panBasicInfLbl_History.Controls.Add(this.lblBasicInf_History);
            this.panBasicInfLbl_History.Dock = System.Windows.Forms.DockStyle.Top;
            this.panBasicInfLbl_History.Location = new System.Drawing.Point(0, 0);
            this.panBasicInfLbl_History.Name = "panBasicInfLbl_History";
            this.panBasicInfLbl_History.Size = new System.Drawing.Size(553, 33);
            this.panBasicInfLbl_History.TabIndex = 10;
            // 
            // lblBasicInf_History
            // 
            this.lblBasicInf_History.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblBasicInf_History.AutoSize = true;
            this.lblBasicInf_History.Location = new System.Drawing.Point(245, 9);
            this.lblBasicInf_History.Name = "lblBasicInf_History";
            this.lblBasicInf_History.Size = new System.Drawing.Size(127, 16);
            this.lblBasicInf_History.TabIndex = 0;
            this.lblBasicInf_History.Text = "Basic Information";
            // 
            // panDetails
            // 
            this.panDetails.AutoScroll = true;
            this.panDetails.Controls.Add(this.panDetailsDgv);
            this.panDetails.Controls.Add(this.tvwDetails);
            this.panDetails.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panDetails.Location = new System.Drawing.Point(0, 33);
            this.panDetails.Name = "panDetails";
            this.panDetails.Size = new System.Drawing.Size(945, 358);
            this.panDetails.TabIndex = 11;
            // 
            // panDetailsDgv
            // 
            this.panDetailsDgv.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panDetailsDgv.Controls.Add(this.splitContainer2);
            this.panDetailsDgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panDetailsDgv.Location = new System.Drawing.Point(172, 0);
            this.panDetailsDgv.Name = "panDetailsDgv";
            this.panDetailsDgv.Size = new System.Drawing.Size(773, 358);
            this.panDetailsDgv.TabIndex = 1;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.panInput);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.panOutput);
            this.splitContainer2.Size = new System.Drawing.Size(771, 356);
            this.splitContainer2.SplitterDistance = 379;
            this.splitContainer2.TabIndex = 0;
            // 
            // tvwDetails
            // 
            this.tvwDetails.Dock = System.Windows.Forms.DockStyle.Left;
            this.tvwDetails.Location = new System.Drawing.Point(0, 0);
            this.tvwDetails.Name = "tvwDetails";
            this.tvwDetails.Size = new System.Drawing.Size(172, 358);
            this.tvwDetails.TabIndex = 0;
            this.tvwDetails.BeforeCollapse += new System.Windows.Forms.TreeViewCancelEventHandler(this.tvwDetails_BeforeCollapse);
            this.tvwDetails.AfterExpand += new System.Windows.Forms.TreeViewEventHandler(this.tvwDetails_AfterExpand);
            this.tvwDetails.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.tvwDetails_AfterSelect);
            // 
            // panDetailsLbl_History
            // 
            this.panDetailsLbl_History.BackColor = System.Drawing.SystemColors.Control;
            this.panDetailsLbl_History.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panDetailsLbl_History.Controls.Add(this.lblDetails_History);
            this.panDetailsLbl_History.Dock = System.Windows.Forms.DockStyle.Top;
            this.panDetailsLbl_History.Location = new System.Drawing.Point(0, 0);
            this.panDetailsLbl_History.Name = "panDetailsLbl_History";
            this.panDetailsLbl_History.Size = new System.Drawing.Size(945, 33);
            this.panDetailsLbl_History.TabIndex = 10;
            // 
            // lblDetails_History
            // 
            this.lblDetails_History.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblDetails_History.AutoSize = true;
            this.lblDetails_History.Location = new System.Drawing.Point(441, 9);
            this.lblDetails_History.Name = "lblDetails_History";
            this.lblDetails_History.Size = new System.Drawing.Size(153, 16);
            this.lblDetails_History.TabIndex = 0;
            this.lblDetails_History.Text = "Details of key blocks";
            // 
            // btnProcess_History
            // 
            this.btnProcess_History.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnProcess_History.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnProcess_History.Location = new System.Drawing.Point(3, 3);
            this.btnProcess_History.Name = "btnProcess_History";
            this.btnProcess_History.Size = new System.Drawing.Size(1502, 34);
            this.btnProcess_History.TabIndex = 0;
            this.btnProcess_History.Text = "button2";
            this.btnProcess_History.UseVisualStyleBackColor = false;
            this.btnProcess_History.Click += new System.EventHandler(this.btnProcess_History_Click);
            // 
            // tabPageXML
            // 
            this.tabPageXML.Controls.Add(this.wbsXML_History);
            this.tabPageXML.Controls.Add(this.btnXML_History);
            this.tabPageXML.Location = new System.Drawing.Point(4, 25);
            this.tabPageXML.Name = "tabPageXML";
            this.tabPageXML.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageXML.Size = new System.Drawing.Size(1508, 431);
            this.tabPageXML.TabIndex = 1;
            this.tabPageXML.Text = "XML Log";
            this.tabPageXML.UseVisualStyleBackColor = true;
            // 
            // wbsXML_History
            // 
            this.wbsXML_History.Dock = System.Windows.Forms.DockStyle.Fill;
            this.wbsXML_History.Location = new System.Drawing.Point(3, 37);
            this.wbsXML_History.MinimumSize = new System.Drawing.Size(20, 20);
            this.wbsXML_History.Name = "wbsXML_History";
            this.wbsXML_History.Size = new System.Drawing.Size(1502, 391);
            this.wbsXML_History.TabIndex = 0;
            this.wbsXML_History.Navigated += new System.Windows.Forms.WebBrowserNavigatedEventHandler(this.wbsXML_History_Navigated);
            // 
            // btnXML_History
            // 
            this.btnXML_History.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnXML_History.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnXML_History.Location = new System.Drawing.Point(3, 3);
            this.btnXML_History.Name = "btnXML_History";
            this.btnXML_History.Size = new System.Drawing.Size(1502, 34);
            this.btnXML_History.TabIndex = 0;
            this.btnXML_History.Text = "Resent XML";
            this.btnXML_History.UseVisualStyleBackColor = false;
            this.btnXML_History.Click += new System.EventHandler(this.btnXML_History_Click);
            // 
            // panel15
            // 
            this.panel15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel15.Controls.Add(this.panel17);
            this.panel15.Controls.Add(this.panel16);
            this.panel15.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel15.Location = new System.Drawing.Point(0, 0);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(1516, 292);
            this.panel15.TabIndex = 0;
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.dgvContext_History);
            this.panel17.Controls.Add(this.panContextLbl_History);
            this.panel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel17.Location = new System.Drawing.Point(376, 0);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(1138, 290);
            this.panel17.TabIndex = 1;
            // 
            // dgvContext_History
            // 
            this.dgvContext_History.AllowUserToAddRows = false;
            this.dgvContext_History.AllowUserToDeleteRows = false;
            this.dgvContext_History.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvContext_History.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvContext_History.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvContext_History.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvContext_History.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvContext_History.Location = new System.Drawing.Point(0, 33);
            this.dgvContext_History.Name = "dgvContext_History";
            this.dgvContext_History.Size = new System.Drawing.Size(1138, 257);
            this.dgvContext_History.TabIndex = 11;
            this.dgvContext_History.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvContext_History_CellDoubleClick);
            // 
            // panContextLbl_History
            // 
            this.panContextLbl_History.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panContextLbl_History.Controls.Add(this.lblContext_History);
            this.panContextLbl_History.Dock = System.Windows.Forms.DockStyle.Top;
            this.panContextLbl_History.Location = new System.Drawing.Point(0, 0);
            this.panContextLbl_History.Name = "panContextLbl_History";
            this.panContextLbl_History.Size = new System.Drawing.Size(1138, 33);
            this.panContextLbl_History.TabIndex = 10;
            // 
            // lblContext_History
            // 
            this.lblContext_History.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblContext_History.AutoSize = true;
            this.lblContext_History.Location = new System.Drawing.Point(465, 8);
            this.lblContext_History.Name = "lblContext_History";
            this.lblContext_History.Size = new System.Drawing.Size(187, 16);
            this.lblContext_History.TabIndex = 0;
            this.lblContext_History.Text = "R2R history event records";
            // 
            // panel16
            // 
            this.panel16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel16.Controls.Add(this.groupBox3);
            this.panel16.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel16.Location = new System.Drawing.Point(0, 0);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(376, 290);
            this.panel16.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.chkSort);
            this.groupBox3.Controls.Add(this.textBox11);
            this.groupBox3.Controls.Add(this.dtpTo_History);
            this.groupBox3.Controls.Add(this.cmbLotId_History);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.cmbProduct_History);
            this.groupBox3.Controls.Add(this.dtpFrom_History);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.textBox7);
            this.groupBox3.Controls.Add(this.cmbLayer_History);
            this.groupBox3.Controls.Add(this.cmbModule_History);
            this.groupBox3.Controls.Add(this.txtListOfRuns_History);
            this.groupBox3.Controls.Add(this.textBox3);
            this.groupBox3.Controls.Add(this.textBox8);
            this.groupBox3.Controls.Add(this.textBox10);
            this.groupBox3.Controls.Add(this.cmbTool_History);
            this.groupBox3.Controls.Add(this.txtLayer_History);
            this.groupBox3.Controls.Add(this.cmbStage_History);
            this.groupBox3.Controls.Add(this.btnRun_History);
            this.groupBox3.Location = new System.Drawing.Point(2, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(367, 279);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            // 
            // chkSort
            // 
            this.chkSort.AutoSize = true;
            this.chkSort.Checked = true;
            this.chkSort.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkSort.Location = new System.Drawing.Point(175, 246);
            this.chkSort.Name = "chkSort";
            this.chkSort.Size = new System.Drawing.Size(110, 20);
            this.chkSort.TabIndex = 44;
            this.chkSort.Text = "Descending";
            this.chkSort.UseVisualStyleBackColor = true;
            this.chkSort.CheckedChanged += new System.EventHandler(this.chkSort_CheckedChanged);
            // 
            // textBox11
            // 
            this.textBox11.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox11.Location = new System.Drawing.Point(23, 75);
            this.textBox11.Name = "textBox11";
            this.textBox11.ReadOnly = true;
            this.textBox11.Size = new System.Drawing.Size(55, 15);
            this.textBox11.TabIndex = 42;
            this.textBox11.Text = "Lot Id";
            this.textBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dtpTo_History
            // 
            this.dtpTo_History.Location = new System.Drawing.Point(104, 39);
            this.dtpTo_History.Name = "dtpTo_History";
            this.dtpTo_History.Size = new System.Drawing.Size(257, 22);
            this.dtpTo_History.TabIndex = 41;
            this.dtpTo_History.ValueChanged += new System.EventHandler(this.dtp_History_ValueChanged);
            // 
            // cmbLotId_History
            // 
            this.cmbLotId_History.FormattingEnabled = true;
            this.cmbLotId_History.Location = new System.Drawing.Point(104, 70);
            this.cmbLotId_History.Name = "cmbLotId_History";
            this.cmbLotId_History.Size = new System.Drawing.Size(257, 24);
            this.cmbLotId_History.TabIndex = 43;
            this.cmbLotId_History.DropDown += new System.EventHandler(this.cmb_History_DropDown);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 16);
            this.label3.TabIndex = 37;
            this.label3.Text = "Time From";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cmbProduct_History
            // 
            this.cmbProduct_History.FormattingEnabled = true;
            this.cmbProduct_History.Location = new System.Drawing.Point(104, 126);
            this.cmbProduct_History.Name = "cmbProduct_History";
            this.cmbProduct_History.Size = new System.Drawing.Size(257, 24);
            this.cmbProduct_History.TabIndex = 27;
            this.cmbProduct_History.DropDown += new System.EventHandler(this.cmb_History_DropDown);
            // 
            // dtpFrom_History
            // 
            this.dtpFrom_History.Location = new System.Drawing.Point(104, 13);
            this.dtpFrom_History.Name = "dtpFrom_History";
            this.dtpFrom_History.Size = new System.Drawing.Size(257, 22);
            this.dtpFrom_History.TabIndex = 40;
            this.dtpFrom_History.Value = new System.DateTime(2018, 10, 24, 9, 58, 1, 0);
            this.dtpFrom_History.ValueChanged += new System.EventHandler(this.dtp_History_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 248);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 16);
            this.label2.TabIndex = 22;
            this.label2.Text = "List of Runs";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 47);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 16);
            this.label4.TabIndex = 39;
            this.label4.Text = "TIme To";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox7
            // 
            this.textBox7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox7.Location = new System.Drawing.Point(23, 103);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(55, 15);
            this.textBox7.TabIndex = 29;
            this.textBox7.Text = "Module";
            this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // cmbLayer_History
            // 
            this.cmbLayer_History.FormattingEnabled = true;
            this.cmbLayer_History.Location = new System.Drawing.Point(104, 182);
            this.cmbLayer_History.Name = "cmbLayer_History";
            this.cmbLayer_History.Size = new System.Drawing.Size(257, 24);
            this.cmbLayer_History.TabIndex = 28;
            this.cmbLayer_History.DropDown += new System.EventHandler(this.cmb_History_DropDown);
            // 
            // cmbModule_History
            // 
            this.cmbModule_History.FormattingEnabled = true;
            this.cmbModule_History.Location = new System.Drawing.Point(104, 98);
            this.cmbModule_History.Name = "cmbModule_History";
            this.cmbModule_History.Size = new System.Drawing.Size(257, 24);
            this.cmbModule_History.TabIndex = 30;
            // 
            // txtListOfRuns_History
            // 
            this.txtListOfRuns_History.Location = new System.Drawing.Point(105, 245);
            this.txtListOfRuns_History.Name = "txtListOfRuns_History";
            this.txtListOfRuns_History.Size = new System.Drawing.Size(58, 22);
            this.txtListOfRuns_History.TabIndex = 23;
            this.txtListOfRuns_History.Text = "20";
            // 
            // textBox3
            // 
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox3.Location = new System.Drawing.Point(23, 215);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(55, 15);
            this.textBox3.TabIndex = 35;
            this.textBox3.Text = "Tool";
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox8
            // 
            this.textBox8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox8.Location = new System.Drawing.Point(23, 159);
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(55, 15);
            this.textBox8.TabIndex = 31;
            this.textBox8.Text = "Stage";
            this.textBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox10
            // 
            this.textBox10.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox10.Location = new System.Drawing.Point(23, 131);
            this.textBox10.Name = "textBox10";
            this.textBox10.ReadOnly = true;
            this.textBox10.Size = new System.Drawing.Size(55, 15);
            this.textBox10.TabIndex = 25;
            this.textBox10.Text = "Product";
            this.textBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // cmbTool_History
            // 
            this.cmbTool_History.FormattingEnabled = true;
            this.cmbTool_History.Location = new System.Drawing.Point(104, 210);
            this.cmbTool_History.Name = "cmbTool_History";
            this.cmbTool_History.Size = new System.Drawing.Size(257, 24);
            this.cmbTool_History.TabIndex = 36;
            this.cmbTool_History.DropDown += new System.EventHandler(this.cmb_History_DropDown);
            // 
            // txtLayer_History
            // 
            this.txtLayer_History.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtLayer_History.Location = new System.Drawing.Point(23, 187);
            this.txtLayer_History.Name = "txtLayer_History";
            this.txtLayer_History.ReadOnly = true;
            this.txtLayer_History.Size = new System.Drawing.Size(55, 15);
            this.txtLayer_History.TabIndex = 26;
            this.txtLayer_History.Text = "Layer";
            this.txtLayer_History.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // cmbStage_History
            // 
            this.cmbStage_History.FormattingEnabled = true;
            this.cmbStage_History.Location = new System.Drawing.Point(104, 154);
            this.cmbStage_History.Name = "cmbStage_History";
            this.cmbStage_History.Size = new System.Drawing.Size(257, 24);
            this.cmbStage_History.TabIndex = 32;
            this.cmbStage_History.DropDown += new System.EventHandler(this.cmb_History_DropDown);
            // 
            // btnRun_History
            // 
            this.btnRun_History.Location = new System.Drawing.Point(287, 245);
            this.btnRun_History.Name = "btnRun_History";
            this.btnRun_History.Size = new System.Drawing.Size(73, 23);
            this.btnRun_History.TabIndex = 24;
            this.btnRun_History.Text = "Run";
            this.btnRun_History.UseVisualStyleBackColor = true;
            this.btnRun_History.Click += new System.EventHandler(this.btnRun_History_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel3});
            this.statusStrip1.Location = new System.Drawing.Point(0, 781);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 15, 0);
            this.statusStrip1.Size = new System.Drawing.Size(1524, 22);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(1437, 17);
            this.toolStripStatusLabel1.Spring = true;
            this.toolStripStatusLabel1.Text = "Version";
            this.toolStripStatusLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(37, 17);
            this.toolStripStatusLabel2.Text = "Time";
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(34, 17);
            this.toolStripStatusLabel3.Text = "Data";
            // 
            // panInput
            // 
            this.panInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panInput.Location = new System.Drawing.Point(0, 0);
            this.panInput.Name = "panInput";
            this.panInput.Size = new System.Drawing.Size(379, 356);
            this.panInput.TabIndex = 0;
            // 
            // panOutput
            // 
            this.panOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panOutput.Location = new System.Drawing.Point(0, 0);
            this.panOutput.Name = "panOutput";
            this.panOutput.Size = new System.Drawing.Size(388, 356);
            this.panOutput.TabIndex = 0;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1524, 867);
            this.Controls.Add(this.panMain);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmMain";
            this.Padding = new System.Windows.Forms.Padding(3, 40, 3, 3);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "R2R-UI";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.panMain.ResumeLayout(false);
            this.panMain.PerformLayout();
            this.tabMain.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panOptMainTab.ResumeLayout(false);
            this.panOptSub.ResumeLayout(false);
            this.panOptTabSub.ResumeLayout(false);
            this.tabOptSubTab.ResumeLayout(false);
            this.tabPageLinear.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdOptLinear)).EndInit();
            this.panLinearLbl.ResumeLayout(false);
            this.panLinearLbl.PerformLayout();
            this.tabPageHOPC.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdOptHOPC)).EndInit();
            this.panHOPCLbl.ResumeLayout(false);
            this.panHOPCLbl.PerformLayout();
            this.tabPageIHOPC.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdOptIHOPC)).EndInit();
            this.panIHOPCLbl.ResumeLayout(false);
            this.panIHOPCLbl.PerformLayout();
            this.tabPageCD.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdOptCD)).EndInit();
            this.panCDLbl.ResumeLayout(false);
            this.panCDLbl.PerformLayout();
            this.tabPageFocus.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdOptFocus)).EndInit();
            this.panFocusLbl.ResumeLayout(false);
            this.panFocusLbl.PerformLayout();
            this.panOptSubBtn.ResumeLayout(false);
            this.grpOptSubBtn.ResumeLayout(false);
            this.grpOptSubBtn.PerformLayout();
            this.panForcePilot.ResumeLayout(false);
            this.panForcePilot.PerformLayout();
            this.panBtn.ResumeLayout(false);
            this.panListLot.ResumeLayout(false);
            this.panListLot.PerformLayout();
            this.panOptContext.ResumeLayout(false);
            this.panOptContextGroup.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdOptContextGroup)).EndInit();
            this.panContextGroupLbl.ResumeLayout(false);
            this.panContextGroupLbl.PerformLayout();
            this.panOptBtn.ResumeLayout(false);
            this.grpOptBtn.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panOptContextGrid.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.tabLog_History.ResumeLayout(false);
            this.tabPageCalculation.ResumeLayout(false);
            this.panel30.ResumeLayout(false);
            this.panUserReportLbl_History.ResumeLayout(false);
            this.panUserReportLbl_History.PerformLayout();
            this.tabPageProcess.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.panel27.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvBasicInformation_History)).EndInit();
            this.panBasicInfLbl_History.ResumeLayout(false);
            this.panBasicInfLbl_History.PerformLayout();
            this.panDetails.ResumeLayout(false);
            this.panDetailsDgv.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.panDetailsLbl_History.ResumeLayout(false);
            this.panDetailsLbl_History.PerformLayout();
            this.tabPageXML.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvContext_History)).EndInit();
            this.panContextLbl_History.ResumeLayout(false);
            this.panContextLbl_History.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panMain;
        private System.Windows.Forms.TabControl tabMain;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Panel panOptMainTab;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Panel panOptContext;
        private System.Windows.Forms.Panel panOptContextGroup;
        private System.Windows.Forms.Panel panOptBtn;
        private System.Windows.Forms.Panel panOptContextGrid;
        private System.Windows.Forms.Panel panOptChart;
        private System.Windows.Forms.Panel panOptSub;
        private System.Windows.Forms.Panel panOptTabSub;
        private System.Windows.Forms.Panel panOptSubBtn;
        private System.Windows.Forms.TabControl tabOptSubTab;
        private System.Windows.Forms.TabPage tabPageLinear;
        private System.Windows.Forms.TabPage tabPageHOPC;
        private System.Windows.Forms.DataGridView grdOptLinear;
        private System.Windows.Forms.RadioButton rdoMetrology;
        private System.Windows.Forms.RadioButton rdoLotAll;
        private System.Windows.Forms.Label lblCurrentR2RMode;
        private System.Windows.Forms.Label lblCurrentOVLMode;
        private System.Windows.Forms.Button btnOptReset;
        private System.Windows.Forms.Button btnOptMode;
        private System.Windows.Forms.DataGridView grdOptContextGroup;
        private System.Windows.Forms.Button btnOptBatchOperation;
        private System.Windows.Forms.Button btnChuckDedication;
        private System.Windows.Forms.Button btnPreLayerConfig;
        private System.Windows.Forms.Button btnOptRun;
        private System.Windows.Forms.TextBox txtLots;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdoChuck2;
        private System.Windows.Forms.RadioButton rdoChuck1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;

        private System.Windows.Forms.TabPage tabPageIHOPC;
        private System.Windows.Forms.TabPage tabPageCD;
        private System.Windows.Forms.TabPage tabPageFocus;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panLinearLbl;
        private System.Windows.Forms.Label lblLinear;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView grdOptHOPC;
        private System.Windows.Forms.Panel panHOPCLbl;
        private System.Windows.Forms.Label lblHOPC;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView grdOptIHOPC;
        private System.Windows.Forms.Panel panIHOPCLbl;
        private System.Windows.Forms.Label lblIHOPC;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DataGridView grdOptCD;
        private System.Windows.Forms.Panel panCDLbl;
        private System.Windows.Forms.Label lblCD;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.DataGridView grdOptFocus;
        private System.Windows.Forms.Panel panFocusLbl;
        private System.Windows.Forms.Label lblFocus;
        private System.Windows.Forms.DataGridViewTextBoxColumn test;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox txtLayer;
        private System.Windows.Forms.ComboBox cmbLayer;
        private System.Windows.Forms.ComboBox cmbProduct;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.ComboBox cmbControl;
        private System.Windows.Forms.TextBox txtStage;
        private System.Windows.Forms.ComboBox cmbStage;
        private System.Windows.Forms.TextBox txtModule;
        private System.Windows.Forms.ComboBox cmbModule;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panContextGroupLbl;
        private System.Windows.Forms.Label lblContextGroup;
        private System.Windows.Forms.GroupBox grpOptBtn;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox grpOptSubBtn;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.ComboBox cmbTool;
        private System.Windows.Forms.Panel panListLot;
        private System.Windows.Forms.RadioButton rdoListValid;
        private System.Windows.Forms.Panel panBtn;
        private System.Windows.Forms.Panel panForcePilot;
        private System.Windows.Forms.CheckBox chkForcePilot;
        private System.Windows.Forms.Button btnPilotUpdate;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.TabControl tabLog_History;
        private System.Windows.Forms.TabPage tabPageCalculation;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.WebBrowser wbsCalculation_History;
        private System.Windows.Forms.Panel panUserReportLbl_History;
        private System.Windows.Forms.Label lblUserReport_History;
        private System.Windows.Forms.TabPage tabPageProcess;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.DataGridView dgvBasicInformation_History;
        private System.Windows.Forms.Panel panBasicInfLbl_History;
        private System.Windows.Forms.Label lblBasicInf_History;
        private System.Windows.Forms.Panel panDetails;
        private System.Windows.Forms.Panel panDetailsLbl_History;
        private System.Windows.Forms.Label lblDetails_History;
        private System.Windows.Forms.Button btnProcess_History;
        private System.Windows.Forms.TabPage tabPageXML;
        private System.Windows.Forms.WebBrowser wbsXML_History;
        private System.Windows.Forms.Button btnXML_History;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.DataGridView dgvContext_History;
        private System.Windows.Forms.Panel panContextLbl_History;
        private System.Windows.Forms.Label lblContext_History;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.ComboBox cmbLotId_History;
        private System.Windows.Forms.DateTimePicker dtpTo_History;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbProduct_History;
        private System.Windows.Forms.DateTimePicker dtpFrom_History;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.ComboBox cmbLayer_History;
        private System.Windows.Forms.ComboBox cmbModule_History;
        private System.Windows.Forms.TextBox txtListOfRuns_History;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.ComboBox cmbTool_History;
        private System.Windows.Forms.TextBox txtLayer_History;
        private System.Windows.Forms.ComboBox cmbStage_History;
        private System.Windows.Forms.Button btnRun_History;
        private System.Windows.Forms.TreeView tvwDetails;
        private System.Windows.Forms.Panel panDetailsDgv;
        private System.Windows.Forms.CheckBox chkSort;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.Panel panInput;
        private System.Windows.Forms.Panel panOutput;
    }
}


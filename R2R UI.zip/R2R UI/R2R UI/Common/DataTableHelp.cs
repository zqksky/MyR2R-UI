﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static R2R_UI.Common.UIServiceFun;

namespace R2R_UI.Common
{
    class DataTableHelp
    {
        #region CreateHistoryContextTable
        public static DataTable CreateHistoryProcessTable(List<string> strListName, List<string> strListValue)
        {
            DataTable db = new DataTable("Process");
            db.Columns.Add("Name", Type.GetType("System.String"));
            db.Columns.Add("Value", Type.GetType("System.String"));

            for (int i = 0; i < strListName.Count; i++)
            {
                db.Rows.Add();
                db.Rows[i][0] = strListName[i];
                db.Rows[i][1] = strListValue[i];
            }

            return db;
        }
        #endregion

        #region CreateHistoryContextTable
        public static DataTable CreateHistoryContextTable()//(structContextHistory structData)
        {
            DataTable db = new DataTable("HistoryContext");
            db.Columns.Add("Lot_Id", Type.GetType("System.String"));
            db.Columns.Add("Service Method", Type.GetType("System.String"));
            db.Columns.Add("Timestamp", Type.GetType("System.String"));
            db.Columns.Add("RetCode", Type.GetType("System.String"));
            db.Columns.Add("RetMessage", Type.GetType("System.String"));

            for (int i = 0; i < 5; i++)
            {
                db.Rows.Add();
                db.Rows[i][0] = 1;
                db.Rows[i][1] = 2;
                db.Rows[i][2] = 3;
                db.Rows[i][3] = 4;
                db.Rows[i][4] = 5;
            }

            //for (int i = 0; i < structData.strListLotId.Count; i++)
            //{
            //    db.Rows.Add();
            //    db.Rows[i][0] = structData.strListLotId[i];
            //    db.Rows[i][1] = structData.strListServiceMethod[i];
            //    db.Rows[i][2] = structData.strListTimestamp[i];
            //    db.Rows[i][3] = structData.strListRetCode[i];
            //    db.Rows[i][4] = structData.strListRetMessage[i];
            //}

            return db;
        }
        #endregion

        #region CreateRawMetrologyTable
        public static DataTable CreateRawMetrologyTable(structCOMMON_GetRawMetrology structData)
        {
            DataTable db = new DataTable("RawMetrology");
            db.Columns.Add("WaferIds", Type.GetType("System.String"));
            db.Columns.Add("MeasDataItemNames", Type.GetType("System.String"));
            db.Columns.Add("MeasSiteCSV", Type.GetType("System.String"));
            db.Columns.Add("MeasValidityCSV", Type.GetType("System.String"));
            db.Columns.Add("MeasValueCSV", Type.GetType("System.String"));

            for (int i = 0; i < structData.strListMeasDataItemNames.Count; i++)
            {
                db.Rows.Add();
                db.Rows[i][0] = structData.strListWaferIds[i];
                db.Rows[i][1] = structData.strListMeasDataItemNames[i];
                db.Rows[i][2] = structData.strListMeasSiteCSV[i];
                db.Rows[i][3] = structData.strListMeasValidityCSV[i];
                db.Rows[i][4] = structData.strListMeasValueCSV[i];
            }

            return db;
        }
        #endregion

        #region CreatePrelayerTable
        //public static DataTable CreatePrelayerTable(structGetFFOVLSettings structData)
        //{
        //    DataTable db = new DataTable("Prelayer");

        //    db.Columns.Add("PreLayer_priority", Type.GetType("System.String"));
        //    db.Columns.Add("PreLayer", Type.GetType("System.String"));
        //    db.Columns.Add("AlignmentLayer", Type.GetType("System.String"));
        //    //db.Columns.Add("OVLModel", Type.GetType("System.String"));

        //    for (int i = 0; i < structData.strListPreLayerPriority.Count; i++)
        //    {
        //        db.Rows.Add();
        //        db.Rows[i][0] = structData.strListPreLayerPriority[i];
        //        db.Rows[i][1] = structData.strListPreLayer[i];
        //        db.Rows[i][2] = structData.strListAlignmentLayer[i];
        //    }

        //    return db;
        //}

        //public static DataTable CreatePrelayerTable_Old(structGetFFOVLSettings structData)
        //{
        //    DataTable db = new DataTable("Prelayer");

        //    db.Columns.Add("CHUCK_ID", Type.GetType("System.String"));
        //    db.Columns.Add("RETICLE_ID", Type.GetType("System.String"));

        //    db.Columns.Add("PreLayer_priority", Type.GetType("System.String"));
        //    db.Columns.Add("PreLayer", Type.GetType("System.String"));
        //    db.Columns.Add("AlignmentLayer", Type.GetType("System.String"));
        //    //db.Columns.Add("OVLModel", Type.GetType("System.String"));

        //    for (int i = 0; i < structData.strListVarNames.Count; i++)
        //    {
        //        db.Rows.Add();
        //        db.Rows[i][0] = structData.strListChucks[i];
        //        db.Rows[i][1] = structData.strListReticles[i];
        //        db.Rows[i][2] = structData.strListPreLayerPriority[i];
        //        db.Rows[i][3] = structData.strListPreLayer[i];
        //        db.Rows[i][4] = structData.strListAlignmentLayer[i];
        //        //db.Rows[i][5] = structData.strListOVLModel[i];
        //    }

        //    return db;
        //}
        #endregion

        #region CreateFFOVLSetTable
        //public static DataTable CreateFFOVLTable(DataTable dbFFOVLContext, string strChuckId, string strReticleId)
        //{
        //    DataTable db = new DataTable("FFOVL");

        //    try
        //    {
        //        if (dbFFOVLContext.Rows.Count > 0)
        //        {
        //            var query = from p in dbFFOVLContext.AsEnumerable()
        //                        where p.Field<string>(dbFFOVLContext.Columns[0]) == strChuckId && p.Field<string>(dbFFOVLContext.Columns[1]) == strReticleId
        //                        select p;

        //            //通过CopyToDataTable()方法创建新的副本
        //            db = query.CopyToDataTable<DataRow>();
        //            db.Columns.Remove("CHUCK_ID");
        //            db.Columns.Remove("RETICLE_ID");
        //        }
        //    }
        //    catch (Exception err)
        //    {
        //        // MessageBox.Show(BaseFun.GetExceptionInformation(err));
        //    }
        //    return db;
        //}

        //public static DataTable CreateFFOVLSetTable(structGetFFOVLSettings structData)
        //{
        //    DataTable db = new DataTable("FFOVLSet");

        //    db.Columns.Add("CHUCK_ID", Type.GetType("System.String"));
        //    db.Columns.Add("RETICLE_ID", Type.GetType("System.String"));

        //    db.Columns.Add("OVLModel", Type.GetType("System.String"));
        //    db.Columns.Add("OVL Variables", Type.GetType("System.String"));
        //    db.Columns.Add("G1", Type.GetType("System.String"));
        //    db.Columns.Add("G2", Type.GetType("System.String"));
        //    db.Columns.Add("G3", Type.GetType("System.String"));

        //    db.Columns.Add("MS_Current", Type.GetType("System.String"));
        //    db.Columns.Add("OVL_Offsets", Type.GetType("System.String"));
        //    db.Columns.Add("New OVL_Offsets", Type.GetType("System.String"));
        //    db.Columns.Add("MS_Flags", Type.GetType("System.String"));
        //    db.Columns.Add("New MS_Flags", Type.GetType("System.String"));


        //    for (int i = 0; i < structData.strListVarNames.Count; i++)
        //    {
        //        db.Rows.Add();
        //        db.Rows[i][0] = structData.strListChucks[i];
        //        db.Rows[i][1] = structData.strListReticles[i];
        //        db.Rows[i][2] = structData.strListOVLModel[i];
        //        db.Rows[i][3] = structData.strListVarNames[i];
        //        db.Rows[i][4] = structData.dListG1[i];
        //        db.Rows[i][5] = structData.dListG2[i];
        //        db.Rows[i][6] = structData.dListG3[i];
        //        db.Rows[i][7] = structData.strListMSCurrent[i];
        //        db.Rows[i][8] = structData.dListOVLOffsets[i];
        //        db.Rows[i][9] = structData.dListOVLOffsets[i];
        //        db.Rows[i][10] = structData.bListMSFlags[i];
        //        db.Rows[i][11] = structData.bListMSFlags[i];
        //    }

        //    return db;
        //}

        //public static DataTable CreateFFOVLSetTableTest(structGetFFOVLSettings structData)
        //{
        //    DataTable db = new DataTable("FFOVLSet");

        //    db.Columns.Add("CHUCK_ID", Type.GetType("System.String"));
        //    db.Columns.Add("RETICLE_ID", Type.GetType("System.String"));

        //    db.Columns.Add("OVL Variables", Type.GetType("System.String"));
        //    db.Columns.Add("G1", Type.GetType("System.String"));
        //    db.Columns.Add("G2", Type.GetType("System.String"));
        //    db.Columns.Add("G3", Type.GetType("System.String"));

        //    db.Columns.Add("MS_Current", Type.GetType("System.String"));
        //    db.Columns.Add("OVL_Offsets", Type.GetType("System.String"));
        //    db.Columns.Add("New OVL_Offsets", Type.GetType("System.String"));
        //    db.Columns.Add("MS_Flags", Type.GetType("System.String"));
        //    db.Columns.Add("New MS_Flags", Type.GetType("System.String"));
        //    db.Columns.Add("OVLModel", Type.GetType("System.String"));
        //    db.Columns.Add("New OVLModel", Type.GetType("System.String"));

        //    for (int i = 0; i < structData.strListVarNames.Count; i++)
        //    {
        //        db.Rows.Add();
        //        db.Rows[i][0] = structData.strListChucks[i];
        //        db.Rows[i][1] = structData.strListReticles[i];
        //        db.Rows[i][2] = structData.strListVarNames[i];
        //        db.Rows[i][3] = structData.dListG1[i];
        //        db.Rows[i][4] = structData.dListG2[i];
        //        db.Rows[i][5] = structData.dListG3[i];
        //        db.Rows[i][6] = structData.strListMSCurrent[i];
        //        db.Rows[i][7] = structData.dListOVLOffsets[i];
        //        db.Rows[i][8] = structData.dListOVLOffsets[i];
        //        db.Rows[i][9] = structData.bListMSFlags[i];
        //        db.Rows[i][10] = structData.bListMSFlags[i];
        //        db.Rows[i][11] = structData.strListOVLModel[i];
        //        db.Rows[i][12] = structData.strListOVLModel[i];
        //    }

        //    return db;
        //}
        #endregion

        #region CreateFFOVLTable
        //public static DataTable CreateFFOVLGroupTable(structGetFFOVLSettings structData)
        //{
        //    DataTable db = new DataTable("FFOVLGroup");

        //    db.Columns.Add("CHUCK_ID", Type.GetType("System.String"));
        //    db.Columns.Add("RETICLE_ID", Type.GetType("System.String"));

        //    db.Columns.Add("PreLayer_priority", Type.GetType("System.String"));
        //    db.Columns.Add("PreLayer", Type.GetType("System.String"));
        //    db.Columns.Add("AlignmentLayer", Type.GetType("System.String"));

        //    db.Columns.Add("OVL Variables", Type.GetType("System.String"));
        //    db.Columns.Add("G1", Type.GetType("System.String"));
        //    db.Columns.Add("G2", Type.GetType("System.String"));
        //    db.Columns.Add("G3", Type.GetType("System.String"));

        //    db.Columns.Add("OVL_Offsets", Type.GetType("System.String"));
        //    db.Columns.Add("New OVL_Offsets", Type.GetType("System.String"));
        //    db.Columns.Add("MS_Current", Type.GetType("System.String"));
        //    db.Columns.Add("MS_Flags", Type.GetType("System.String"));
        //    db.Columns.Add("New MS_Flags", Type.GetType("System.String"));
        //    db.Columns.Add("OVLModel", Type.GetType("System.String"));

        //    for (int i = 0; i < structData.strListVarNames.Count; i++)
        //    {
        //        db.Rows.Add();
        //        db.Rows[i][0] = structData.strListChucks[i];
        //        db.Rows[i][1] = structData.strListReticles[i];
        //        db.Rows[i][2] = structData.strListPreLayerPriority[i];
        //        db.Rows[i][3] = structData.strListPreLayer[i];
        //        db.Rows[i][4] = structData.strListAlignmentLayer[i];
        //        db.Rows[i][5] = structData.strListVarNames[i];
        //        db.Rows[i][6] = structData.dListG1[i];
        //        db.Rows[i][7] = structData.dListG2[i];
        //        db.Rows[i][8] = structData.dListG3[i];
        //        db.Rows[i][9] = structData.dListOVLOffsets[i];
        //        db.Rows[i][10] = structData.strListMSCurrent[i];
        //        db.Rows[i][11] = structData.bListMSFlags[i];
        //        db.Rows[i][12] = structData.strListOVLModel[i];
        //    }

        //    return db;
        //}
        #endregion

        #region CreateLinearResetTable
        public static DataTable CreateLinearResetTable(DataTable dbLinearResetGroup, string strOVLMode)
        {
            DataTable db = new DataTable("LinearReset");

            try
            {
                if (dbLinearResetGroup.Rows.Count > 0)
                {
                    var query = from p in dbLinearResetGroup.AsEnumerable()
                                where p.Field<string>(dbLinearResetGroup.Columns["OVL_MODEL"]) == strOVLMode
                                select p;

                    //通过CopyToDataTable()方法创建新的副本
                    db = query.CopyToDataTable<DataRow>();
                }
            }
            catch (Exception err)
            {                
                System.Windows.Forms.MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
            return db;
        }

        public static DataTable CreateLinearResetGroupTable(UIServiceFun.structPH_OVL_GetResetValues structData)
        {
            DataTable db = new DataTable("LinearReset");

            db.Columns.Add("INPUT_INDEX", Type.GetType("System.Int16"));
            db.Columns.Add("INPUT_NAME", Type.GetType("System.String"));
            db.Columns.Add("CHUCK_ID", Type.GetType("System.String"));
            db.Columns.Add("OVL_MODEL", Type.GetType("System.String"));
            db.Columns.Add("INPUT_MAX_VALUE", Type.GetType("System.Double"));
            db.Columns.Add("INPUT_MIN_VALUE", Type.GetType("System.Double"));
            db.Columns.Add("INPUT_VALUE_CURRENT", Type.GetType("System.Double"));
            db.Columns.Add("INPUT_VALUE_NEW", Type.GetType("System.Double"));

            for (int i = 0; i < structData.iListInputIndex.Count; i++)
            {
                db.Rows.Add();
                db.Rows[i][0] = structData.iListInputIndex[i];
                db.Rows[i][1] = structData.strListInputNames[i];
                db.Rows[i][2] = structData.strListChuckIds[i];
                db.Rows[i][3] = structData.strListOVLModels[i];
                db.Rows[i][4] = structData.dListInputMax[i];
                db.Rows[i][5] = structData.dListInputMin[i];
                db.Rows[i][6] = structData.dListInputValues[i];
                db.Rows[i][7] = structData.dListInputValues[i];
            }

            return db;
        }
        #endregion

        #region CreateCommonResetTable
        public static DataTable CreateCommonResetTable(UIServiceFun.structCOMMON_GetInputResetSettings structData, bool bPM)
        {
            DataTable db = new DataTable("CommonMode");

            //db.Columns.Add("INPUT_INDEX", Type.GetType("System.Int16"));
            db.Columns.Add("INPUT_PARAMETERS_NAME", Type.GetType("System.String"));
            db.Columns.Add("INPUT_MAX", Type.GetType("System.Double"));
            db.Columns.Add("INPUT_MIN", Type.GetType("System.Double"));
            if (bPM)
            {
                db.Columns.Add("Input PM Value - Current", Type.GetType("System.Double"));
                db.Columns.Add("Input PM Value - New", Type.GetType("System.Double"));
            }
            else
            {
                db.Columns.Add("Input Reset Value - Current", Type.GetType("System.Double"));
                db.Columns.Add("Input Reset Value - New", Type.GetType("System.Double"));
            }

            for (int i = 0; i < structData.iListInputIndex.Count; i++)
            {
                db.Rows.Add();
                //db.Rows[i][0] = structData.iListInputIndex[i];
                db.Rows[i][0] = structData.strListInputParameterNames[i];
                db.Rows[i][1] = structData.dListInputMax[i];
                db.Rows[i][2] = structData.dListInputMin[i];
                if (bPM)
                {
                    db.Rows[i][3] = structData.dListInputPMValues[i];
                    db.Rows[i][4] = structData.dListInputPMValues[i];
                }
                else
                {
                    db.Rows[i][3] = structData.dListInputResetValues[i];
                    db.Rows[i][4] = structData.dListInputResetValues[i];
                }
            }

            return db;
        }
        #endregion

        #region CreateCommonModeTable
        public static DataTable CreateCommonModeTable(UIServiceFun.structCOMMON_GetInputSettings structData)
        {
            string strR2RMode;
            strR2RMode = structData.strR2RMode;

            DataTable db = new DataTable("CommonMode");

            //db.Columns.Add("INPUT_INDEX", Type.GetType("System.Int16"));
            db.Columns.Add("INPUT_PARAMETERS_NAME", Type.GetType("System.String"));
            db.Columns.Add("INPUT_MAX", Type.GetType("System.Double"));
            db.Columns.Add("INPUT_MIN", Type.GetType("System.Double"));
            db.Columns.Add("CURRENT_VALUE", Type.GetType("System.Double"));
            db.Columns.Add("Fixed_VALUE", Type.GetType("System.Double"));
            db.Columns.Add("NEW_VALUE", Type.GetType("System.Double"));

            for (int i = 0; i < structData.iListInputIndex.Count; i++)
            {
                db.Rows.Add();
                //db.Rows[i][0] = structData.iListInputIndex[i];
                db.Rows[i][0] = structData.strListInputParameterNames[i];
                db.Rows[i][1] = structData.dListInputMax[i];
                db.Rows[i][2] = structData.dListInputMin[i];
                db.Rows[i][3] = structData.dListInputCurrentValues[i];
                db.Rows[i][4] = structData.dListInputFixedValues[i];
                if (strR2RMode.Equals("Fixed"))
                {
                    db.Rows[i][5] = structData.dListInputFixedValues[i];
                }
                else
                {
                    db.Rows[i][5] = structData.dListInputCurrentValues[i];
                }
            }

            return db;
        }
        #endregion

        #region CreateBatchR2RModeTable
        public static DataTable CreateBatchR2RModeTable(DataTable dbR2RModeContext, string strChuckId, string strReticleId)
        {
            DataTable db = new DataTable("BatchR2RMode");

            try
            {
                if (dbR2RModeContext.Rows.Count > 0)
                {
                    var query = from p in dbR2RModeContext.AsEnumerable()
                                where p.Field<string>(dbR2RModeContext.Columns[0]) == strChuckId && p.Field<string>(dbR2RModeContext.Columns[1]) == strReticleId
                                select p;

                    //通过CopyToDataTable()方法创建新的副本
                    db = query.CopyToDataTable<DataRow>();
                }
            }
            catch (Exception err)
            {        
                System.Windows.Forms.MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
            return db;
        }

        public static DataTable CreateBatchR2RModeGroupTable(List<string> strListInputChuckIds, List<string> strListInputReticleIds, List<string> strListInputParameterNames, List<double> dListInputMax, List<double> dListInputMin, List<double> dListInputFixedValues)
        {
            DataTable db = new DataTable("BatchR2RModeGroup");

            //db.Columns.Add("INPUT_INDEX", Type.GetType("System.Int16"));
            db.Columns.Add("INPUT_CHUCK_ID", Type.GetType("System.String"));
            db.Columns.Add("INPUT_RETICLE_ID", Type.GetType("System.String"));
            db.Columns.Add("INPUT_PARAMETER_NAME", Type.GetType("System.String"));
            db.Columns.Add("Input Max Value", Type.GetType("System.Double"));
            db.Columns.Add("Input Min Value", Type.GetType("System.Double"));
            db.Columns.Add("Input Fixed Value - Current", Type.GetType("System.Double"));
            db.Columns.Add("Input Fixed Value - New", Type.GetType("System.Double"));

            for (int i = 0; i < dListInputFixedValues.Count; i++)
            {
                db.Rows.Add();
                //db.Rows[i][0] = structData.iListInputIndex[i];
                db.Rows[i][0] = strListInputChuckIds[i];
                db.Rows[i][1] = strListInputReticleIds[i];
                db.Rows[i][2] = strListInputParameterNames[i];
                db.Rows[i][3] = dListInputMax[i];
                db.Rows[i][4] = dListInputMin[i];
                db.Rows[i][5] = dListInputFixedValues[i];
                db.Rows[i][6] = dListInputFixedValues[i];
            }

            return db;
        }
        #endregion

        #region CreateBatchPMOffsetTable
        public static DataTable CreateBatchPMOffsetTable(UIServiceFun.structPH_OVL_Batch_GetPMOffsets structData)
        {
            DataTable db = new DataTable("BatchPMOffset");

            //db.Columns.Add("INPUT_INDEX", Type.GetType("System.Int16"));
            db.Columns.Add("INPUT_NAME", Type.GetType("System.String"));
            db.Columns.Add("INPUT_MODEL", Type.GetType("System.String"));
            db.Columns.Add("PM_OFFSETS", Type.GetType("System.Double"));

            for (int i = 0; i < structData.iListInputIndex.Count; i++)
            {
                db.Rows.Add();
                //db.Rows[i][0] = structData.iListInputIndex[i];
                db.Rows[i][0] = structData.strListInputNames[i];
                db.Rows[i][1] = structData.strListInputModels[i];
                db.Rows[i][2] = structData.dListPMOffsets[i];
            }

            return db;
        }
        #endregion

        #region CreateBatchOVLModelTable
        public static DataTable CreateBatchOVLModelTable(UIServiceFun.structPH_OVL_Batch_GetOVLModel structData)
        {
            DataTable db = new DataTable("BatchOVLModel");

            //db.Columns.Add("PRODUCT", Type.GetType("System.String"));
            //db.Columns.Add("LAYER", Type.GetType("System.String"));
            //db.Columns.Add("TOOLS", Type.GetType("System.String"));
            //db.Columns.Add("OVL_MODELS", Type.GetType("System.String"));
            //db.Columns.Add("CPE_MODEL_ON", Type.GetType("System.String"));
            //db.Columns.Add("R2R_MODEL", Type.GetType("System.String"));

            //for (int i = 0; i < structData.strListProducts.Count; i++)
            //{
            //    db.Rows.Add();
            //    db.Rows[i][0] = structData.strListProducts[i];
            //    db.Rows[i][1] = structData.strListLayers[i];
            //    db.Rows[i][2] = structData.strListTools[i];
            //    db.Rows[i][3] = structData.strListOVLModels[i];
            //    db.Rows[i][4] = structData.bListIsCPEModelOn[i];
            //    db.Rows[i][5] = structData.strListR2RMode[i];
            //}

            return db;
        }
        #endregion

        #region CreateChuckDedicationTable
        public static DataTable CreateChuckDedicationTable(List<string> strListColumnName, List<string> strListVaue)
        {
            DataTable db = new DataTable("Chuck");

            foreach (var str in strListColumnName)
            {
                db.Columns.Add(str, Type.GetType("System.String"));
            }

            db.Rows.Add();
            for (int i = 0; i < strListVaue.Count; i++)
            {
                db.Rows[0][i] = strListVaue[i];
            }

            return db;
        }

        public static DataTable CreateQueryLotInfoTable(UIServiceFun.structPH_OVL_QueryLotInfo structData)
        {
            DataTable db = new DataTable("QueryLotInfo");

            db.Columns.Add("WAFER_ID", Type.GetType("System.String"));
            db.Columns.Add("SLOT_ID", Type.GetType("System.String"));
            db.Columns.Add("CHUCK", Type.GetType("System.String"));

            for (int i = 0; i < structData.strListWaferIds.Count; i++)
            {
                db.Rows.Add();
                db.Rows[i][0] = structData.strListWaferIds[i];
                db.Rows[i][1] = structData.strListSlotIds[i];
                db.Rows[i][2] = structData.strListChuckIds[i];
            }

            return db;
        }

        #endregion

        #region CreatChartDataTable
        public static List<DataTable> CreatChartDataTable(List<List<double>> strListItemValues, List<string> strListColName)
        {
            List<DataTable> dbs = new List<DataTable>();

            for (int i = 0; i < strListItemValues.Count; i++)
            {
                DataTable db = new DataTable();
                db = ListToDataTable(strListItemValues[i], strListColName);
                dbs.Add(db);
            }

            return dbs;
        }
        public static DataTable ListToDataTable(List<double> strList, List<string> strListColName)
        {
            DataTable db = new DataTable();
            if (strList.Count > 0)
            {
                db.Columns.Add("LOT_ID", Type.GetType("System.String"));
                for (int i = 0; i < strList.Count; i++)
                {
                    db.Columns.Add(strListColName[i], Type.GetType("System.Double"));
                }

                object[] colValue = new object[strList.Count + 1];
                colValue[0] = "LOT_ID";
                for (int i = 0; i < strList.Count; i++)
                {
                    colValue[i + 1] = strList[i];
                }
                db.Rows.Add(colValue);
            }

            return db;
        }
        #endregion

        #region CreateCommonTable
        public static DataTable CreateCommonTableNew(List<string> strListLotId, List<string> strListTimeStamp, List<string> strListInputValue,  List<string> strListOutputValue, List<string> strListInputName, List<string> strListOutputName, List<int> iListActuallInputSize, List<int> iListActuallOutputSize)
        {
            List<List<string>> strListGroupInput = new List<List<string>>();
            List<List<string>> strListGroupOutput = new List<List<string>>();
            strListGroupInput = BaseFun.GetItemValues(strListInputValue);
            strListGroupOutput = BaseFun.GetItemValues(strListOutputValue);

            DataTable db = new DataTable("CommonChamber");

            db.Columns.Add("LOT_IDS", Type.GetType("System.String"));
            db.Columns.Add("USED_TIME_STAMPS", Type.GetType("System.String"));
            if (strListGroupInput.Count > 0)
            {
                if (iListActuallInputSize[0] == 1)
                {
                    db.Columns.Add(strListInputName[0], Type.GetType("System.String"));
                }
                else
                {
                    for (int i = 0; i < iListActuallInputSize[0]; i++)
                    {
                        //db.Columns.Add(strListInputName[0] + "_Input_" + (i + 1), Type.GetType("System.String"));
                        db.Columns.Add(strListInputName[i], Type.GetType("System.String"));
                    }
                }

            }
            if (strListGroupOutput.Count > 0)
            {
                if (iListActuallOutputSize[0]==1)
                {
                    db.Columns.Add(strListOutputName[0], Type.GetType("System.String"));
                }
                else
                {
                    for (int i = 0; i < iListActuallOutputSize[0]; i++)
                    {
                        //db.Columns.Add(strListOutputName[0] + "_Output_" + (i + 1), Type.GetType("System.String"));
                        db.Columns.Add(strListOutputName[i], Type.GetType("System.String"));
                    }
                }

            }

            for (int i = 0; i < strListLotId.Count; i++)
            {
                db.Rows.Add();
                db.Rows[i]["LOT_IDS"] = strListLotId[i];
                db.Rows[i]["USED_TIME_STAMPS"] = strListTimeStamp[i];
                if (iListActuallOutputSize[0] == 1)
                {
                    db.Rows[i][strListInputName[0]] = strListGroupInput[i][0];
                }
                else
                {
                    for (int n = 0; n < iListActuallInputSize[0]; n++)
                    {
                        //db.Rows[i][strListInputName[0] + "_Input_" + (n + 1)] = strListGroupInput[i][n];
                        db.Rows[i][strListInputName[n]] = strListGroupInput[i][n];
                    }
                }
                if (iListActuallOutputSize[0] == 1)
                {
                    db.Rows[i][strListOutputName[0]] = strListGroupOutput[i][0];
                }
                else
                {
                    for (int n = 0; n < iListActuallOutputSize[0]; n++)
                    {
                        //db.Rows[i][strListOutputName[0] + "_Output_" + (n + 1)] = strListGroupOutput[i][n];
                        db.Rows[i][strListOutputName[n]] = strListGroupOutput[i][n];
                    }
                }
            }

            return db;
        }

        public static DataTable CreateCommonTable(List<string> strListLotId, List<string> strListTimeStamp, List<string> strListInputValue, List<string> strListOutputValue, List<string> strListInputName, List<string> strListOutputName)
        {
            List<List<string>> strListGroupInput = new List<List<string>>();
            List<List<string>> strListGroupOutput = new List<List<string>>();
            strListGroupInput = BaseFun.GetItemValues(strListInputValue);
            strListGroupOutput = BaseFun.GetItemValues(strListOutputValue);

            DataTable db = new DataTable("CommonChamber");

            db.Columns.Add("LOT_IDS", Type.GetType("System.String"));
            db.Columns.Add("USED_TIME_STAMPS", Type.GetType("System.String"));
            if (strListGroupInput.Count > 0)
            {
                for (int i = 0; i < strListGroupInput[0].Count; i++)
                {
                    db.Columns.Add(strListInputName[0]+"_Input_"+(i+1), Type.GetType("System.String"));
                }
            }
            if (strListGroupOutput.Count > 0)
            {
                for (int i = 0; i < strListGroupOutput[0].Count; i++)
                {
                    db.Columns.Add(strListOutputName[0]+"_Output_"+(i + 1), Type.GetType("System.String"));
                }
            }

            for (int i = 0; i < strListLotId.Count; i++)
            {
                db.Rows.Add();
                db.Rows[i]["LOT_IDS"] = strListLotId[i];
                db.Rows[i]["USED_TIME_STAMPS"] = strListTimeStamp[i];
                for (int n = 0; n < strListGroupInput[i].Count; n++)
                {
                    db.Rows[i][strListInputName[0] + "_Input_" + (n+1)] = strListGroupInput[i][n];
                }
                for (int n = 0; n < strListGroupOutput[i].Count; n++)
                {
                    db.Rows[i][strListOutputName[0] + "_Output_" + (n + 1)] = strListGroupOutput[i][n];
                }
            }

            return db;
        }

        public static DataTable CreateCommonTable(List<string> strListLotId, List<string> strListTimeStamp, List<string> strListInputValue, List<string> strListOutputValue)
        {
            List<List<string>> strListGroupInput = new List<List<string>>();
            List<List<string>> strListGroupOutput = new List<List<string>>();
            strListGroupInput = BaseFun.GetItemValues(strListInputValue);
            strListGroupOutput = BaseFun.GetItemValues(strListOutputValue);

            DataTable db = new DataTable("CommonChamber");

            db.Columns.Add("LOT_IDS", Type.GetType("System.String"));
            db.Columns.Add("USED_TIME_STAMPS", Type.GetType("System.String"));
            if (strListGroupInput.Count > 0)
            {
                for (int i = 0; i < strListGroupInput[0].Count; i++)
                {
                    db.Columns.Add("Input" + (i + 1), Type.GetType("System.String"));
                }
            }
            if (strListGroupOutput.Count > 0)
            {
                for (int i = 0; i < strListGroupOutput[0].Count; i++)
                {
                    db.Columns.Add("Output" + (i + 1), Type.GetType("System.String"));
                }
            }

            for (int i = 0; i < strListLotId.Count; i++)
            {
                db.Rows.Add();
                db.Rows[i]["LOT_IDS"] = strListLotId[i];
                db.Rows[i]["USED_TIME_STAMPS"] = strListTimeStamp[i];
                for (int n = 0; n < strListGroupInput[i].Count; n++)
                {
                    db.Rows[i]["Input" + (n + 1)] = strListGroupInput[i][n];
                }
                for (int n = 0; n < strListGroupOutput[i].Count; n++)
                {
                    db.Rows[i]["Output" + (n + 1)] = strListGroupOutput[i][n];
                }
            }

            return db;
        }
        #endregion

        #region CreateCDFocusTable
        public static DataTable CreateCDFocusTableNew(List<string> strListLotId, List<string> strListTimeStamps, List<string> strListInputValue, List<string> strListOutputValue, string strInputName, string strOutputName)
        {
            List<List<string>> strListGroupInput = new List<List<string>>();
            List<List<string>> strListGroupOutput = new List<List<string>>();
            strListGroupInput = BaseFun.GetItemValues(strListInputValue);
            strListGroupOutput = BaseFun.GetItemValues(strListOutputValue);

            DataTable db = new DataTable("CdFocus");

            db.Columns.Add("LOT_IDS", Type.GetType("System.String"));
            db.Columns.Add("USED_TIME_STAMPS", Type.GetType("System.String"));
            if (strListGroupInput.Count > 0)
            {
                if (strListGroupInput[0].Count == 1)
                {
                    db.Columns.Add(strInputName, Type.GetType("System.String"));
                }
                else
                {
                    for (int i = 0; i < strListGroupInput[0].Count; i++)
                    {
                        db.Columns.Add(strInputName + "_" + (i + 1), Type.GetType("System.String"));
                    }
                }

            }
            if (strListGroupOutput.Count > 0)
            {
                if (strListGroupOutput[0].Count == 1)
                {
                    db.Columns.Add(strOutputName, Type.GetType("System.String"));
                }
                else
                {
                    for (int i = 0; i < strListGroupOutput[0].Count; i++)
                    {
                        db.Columns.Add(strOutputName + "_" + (i + 1), Type.GetType("System.String"));
                    }
                }

            }
            for (int i = 0; i < strListLotId.Count; i++)
            {
                db.Rows.Add();
                db.Rows[i]["LOT_IDS"] = strListLotId[i];
                db.Rows[i]["USED_TIME_STAMPS"] = strListTimeStamps[i];

                if (strListGroupInput[0].Count == 1)
                {
                    db.Rows[i][strInputName] = strListGroupInput[i][0];
                }
                else
                {
                    for (int n = 0; n < strListGroupInput[i].Count; n++)
                    {
                        db.Rows[i][strInputName + "_" + (n + 1)] = strListGroupInput[i][n];
                    }
                }
                if (strListGroupOutput[0].Count == 1)
                {
                    db.Rows[i][strOutputName] = strListGroupOutput[i][0];
                }
                else
                {
                    for (int n = 0; n < strListGroupOutput[i].Count; n++)
                    {
                        db.Rows[i][strOutputName + "_" + (n + 1)] = strListGroupOutput[i][n];
                    }
                }
            }

            return db;
        }

        public static DataTable CreateCDFocusTable(List<string> strListLotId, List<string> strListTimeStamps, List<string> strListInputValue, List<string> strListOutputValue,string strInputName,string strOutputName)
        {
            List<List<string>> strListGroupInput = new List<List<string>>();
            List<List<string>> strListGroupOutput = new List<List<string>>();
            strListGroupInput = BaseFun.GetItemValues(strListInputValue);
            strListGroupOutput = BaseFun.GetItemValues(strListOutputValue);

            DataTable db = new DataTable("CdFocus");

            db.Columns.Add("LOT_IDS", Type.GetType("System.String"));
            db.Columns.Add("USED_TIME_STAMPS", Type.GetType("System.String"));
            if (strListGroupInput.Count > 0)
            {
                //if (strListGroupInput[0].Count == 1)
                //{
                //    db.Columns.Add(strInputName, Type.GetType("System.String"));
                //}
                //else
                //{
                for (int i = 0; i < strListGroupInput[0].Count; i++)
                {
                    db.Columns.Add(strInputName + "_" + (i + 1), Type.GetType("System.String"));
                }
                //}

            }
            if (strListGroupOutput.Count > 0)
            {
                //if (strListGroupOutput[0].Count == 1)
                //{
                //    db.Columns.Add(strOutputName, Type.GetType("System.String"));
                //}
                //else
                //{
                for (int i = 0; i < strListGroupOutput[0].Count; i++)
                {
                    db.Columns.Add(strOutputName + "_" + (i + 1), Type.GetType("System.String"));
                }
                //}

            }
            for (int i = 0; i < strListLotId.Count; i++)
            {
                db.Rows.Add();
                db.Rows[i]["LOT_IDS"] = strListLotId[i];
                db.Rows[i]["USED_TIME_STAMPS"] = strListTimeStamps[i];
                for (int n = 0; n < strListGroupInput[i].Count; n++)
                {
                    db.Rows[i][strInputName + "_" + (n + 1)] = strListGroupInput[i][n];
                }
                for (int n = 0; n < strListGroupOutput[i].Count; n++)
                {
                    db.Rows[i][strOutputName + "_" + (n + 1)] = strListGroupOutput[i][n];
                }
            }

            return db;
        }

        public static DataTable CreateCDFocusTable(List<string> strListLotId, List<string> strListTimeStamps, List<string> strListInputValue, List<string> strListOutputValue)
        {
            List<List<string>> strListGroupInput = new List<List<string>>();
            List<List<string>> strListGroupOutput = new List<List<string>>();
            strListGroupInput = BaseFun.GetItemValues(strListInputValue);
            strListGroupOutput = BaseFun.GetItemValues(strListOutputValue);

            DataTable db = new DataTable("OVL");

            db.Columns.Add("LOT_IDS", Type.GetType("System.String"));
            db.Columns.Add("USED_TIME_STAMPS", Type.GetType("System.String"));
            if (strListGroupInput.Count > 0)
            {
                for (int i = 0; i < strListGroupInput[0].Count; i++)
                {
                    db.Columns.Add("Focus" + (i + 1), Type.GetType("System.String"));
                }
            }
            if (strListGroupOutput.Count > 0)
            {
                for (int i = 0; i < strListGroupOutput[0].Count; i++)
                {
                    db.Columns.Add("CD" + (i + 1), Type.GetType("System.String"));
                }
            }
            for (int i = 0; i < strListLotId.Count; i++)
            {
                db.Rows.Add();
                db.Rows[i]["LOT_IDS"] = strListLotId[i];
                db.Rows[i]["USED_TIME_STAMPS"] = strListTimeStamps[i];
                for (int n = 0; n < strListGroupInput[i].Count; n++)
                {
                    db.Rows[i]["Focus" + (n + 1)] = strListGroupInput[i][n];
                }
                for (int n = 0; n < strListGroupOutput[i].Count; n++)
                {
                    db.Rows[i]["CD" + (n + 1)] = strListGroupOutput[i][n];
                }
            }

            return db;
        }
        #endregion

        #region CreateOVLTable
        public static DataTable CreateOVLTable(List<string> strListLotId, List<string> strListTimeStamps)
        {
            DataTable db = new DataTable("OVL");

            db.Columns.Add("LOT_IDS", Type.GetType("System.String"));
            db.Columns.Add("USED_TIME_STAMPS", Type.GetType("System.String"));

            for (int i = 0; i < strListLotId.Count; i++)
            {
                db.Rows.Add();
                db.Rows[i]["LOT_IDS"] = strListLotId[i];
                db.Rows[i]["USED_TIME_STAMPS"] = strListTimeStamps[i];
            }

            return db;
        }

        public static DataTable CreateOVLTable(List<string> strListLotId, List<string> strListTimeStamps, List<string> strListInputName, List<string> strListInputValue, int outputIndex, int outputCount)
        {
            List<List<string>> strListGroupInput = new List<List<string>>();
            strListGroupInput = BaseFun.GetItemValues(strListInputValue);

            DataTable db = new DataTable("OVL");

            db.Columns.Add("LOT_IDS", Type.GetType("System.String"));
            db.Columns.Add("USED_TIME_STAMPS", Type.GetType("System.String"));
            for (int i = 0; i < strListInputName.Count; i++)
            {
                db.Columns.Add(strListInputName[i], Type.GetType("System.String"));
            }

            for (int i = 0; i < strListLotId.Count; i++)
            {
                db.Rows.Add();
                db.Rows[i]["LOT_IDS"] = strListLotId[i];
                db.Rows[i]["USED_TIME_STAMPS"] = strListTimeStamps[i];
                for (int n = outputIndex; n < outputIndex + outputCount; n++)
                {
                    db.Rows[i][strListInputName[n - outputIndex]] = strListGroupInput[i][n];
                }
            }

            return db;
        }

        public static DataTable CreateOVLTable(List<string> strListLotId, List<string> strListTimeStamps, List<string> strListInputName, List<string> strListInputValue, List<string> strListOutputValue, int outputIndex, int outputCount)
        {
            List<List<string>> strListGroupInput = new List<List<string>>();
            List<List<string>> strListGroupOutput = new List<List<string>>();
            strListGroupInput = BaseFun.GetItemValues(strListInputValue);
            strListGroupOutput = BaseFun.GetItemValues(strListOutputValue);

            DataTable db = new DataTable("OVL");

            db.Columns.Add("LOT_IDS", Type.GetType("System.String"));
            db.Columns.Add("USED_TIME_STAMPS", Type.GetType("System.String"));
            for (int i = 0; i < strListInputName.Count; i++)
            {
                db.Columns.Add(strListInputName[i]+"_I", Type.GetType("System.String"));
            }
            for (int i = 0; i < strListInputName.Count; i++)
            {
                db.Columns.Add(strListInputName[i] + "_O", Type.GetType("System.String"));
            }
            for (int i = 0; i < strListLotId.Count; i++)
            {
                db.Rows.Add();
                db.Rows[i]["LOT_IDS"] = strListLotId[i];
                db.Rows[i]["USED_TIME_STAMPS"] = strListTimeStamps[i];
                for (int n = outputIndex; n < outputIndex + outputCount; n++)
                {
                    if (strListGroupInput.Count > i && strListGroupInput[i].Count > n)
                    {
                        db.Rows[i][strListInputName[n - outputIndex] + "_I"] = strListGroupInput[i][n];
                    }
                    else
                    {
                        db.Rows[i][strListInputName[n - outputIndex] + "_I"] = "NaN";
                    }

                }
                for (int n = outputIndex; n < outputIndex + outputCount; n++)
                {
                    if (strListGroupOutput.Count > i && strListGroupOutput[i].Count > n)
                    {
                        db.Rows[i][strListInputName[n - outputIndex] + "_O"] = strListGroupOutput[i][n];
                    }
                    else
                    {
                        db.Rows[i][strListInputName[n - outputIndex] + "_O"] = "NaN";
                    }

                }
            }

            return db;
        }
        #endregion

        #region CreateContextTable
        public static DataTable CreateContextTable()
        {
            DataTable db = new DataTable("TabContextGroup");

            db.Columns.Add("Name", Type.GetType("System.String"));
            db.Columns.Add("Value", Type.GetType("System.String"));

            db.Rows.Add();
            db.Rows[0]["Name"] = "Module";
            db.Rows.Add();
            db.Rows[1]["Name"] = "Product";
            db.Rows.Add();
            db.Rows[2]["Name"] = "Stage";
            db.Rows.Add();
            db.Rows[3]["Name"] = "Layer";
            db.Rows.Add();
            db.Rows[4]["Name"] = "Control System";
            db.Rows.Add();
            db.Rows[5]["Name"] = "Tool";

            db.Rows[0]["Value"] = "";
            db.Rows[1]["Value"] = "";
            db.Rows[2]["Value"] = "";
            db.Rows[3]["Value"] = "";
            db.Rows[4]["Value"] = "";
            db.Rows[5]["Value"] = "";

            return db;
        }
        #endregion

        #region CreateContextGroupTable
        private static List<string> GetDataContextColumn(structDataContext structData, int index)
        {
            List<string> strList = new List<string>();
            switch (index)
            {
                case 0:
                    return structData.strListData_Context1;
                case 1:
                    return structData.strListData_Context2;
                case 2:
                    return structData.strListData_Context3;
                case 3:
                    return structData.strListData_Context4;
                case 4:
                    return structData.strListData_Context5;
                case 5:
                    return structData.strListData_Context6;
                case 6:
                    return structData.strListData_Context7;
                case 7:
                    return structData.strListData_Context8;
                case 8:
                    return structData.strListData_Context9;
                case 9:
                    return structData.strListData_Context10;
                case 10:
                    return structData.strListData_Context11;
                case 11:
                    return structData.strListData_Context12;
                case 12:
                    return structData.strListData_Context13;
                case 13:
                    return structData.strListData_Context14;
                case 14:
                    return structData.strListData_Context15;
                case 15:
                    return structData.strListData_Context16;
                case 16:
                    return structData.strListData_Context17;
                case 17:
                    return structData.strListData_Context18;
                case 18:
                    return structData.strListData_Context19;
                case 19:
                    return structData.strListData_Context20;
                default:
                    return strList;
            }
        }
        public static DataTable CreateContextGroupTable(structDataContext structData)
        {
            string strColumnName;
            List<string> strListColumnValue = new List<string>();

            DataTable db = new DataTable("TabContextGroup");
            if (structData.strListContexts.Count > 0)
            {
                for (int i = 0; i < structData.strListContexts.Count; i++)
                {
                    strColumnName = structData.strListContexts[i];
                    db.Columns.Add(strColumnName, Type.GetType("System.String"));
                    strListColumnValue = GetDataContextColumn(structData, i);
                    for (int m = 0; m < strListColumnValue.Count; m++)
                    {
                        if (db.Rows.Count < m + 1)
                        {
                            db.Rows.Add();
                        }
                        db.Rows[m][strColumnName] = strListColumnValue[m];
                    }
                }
            }
            return db;
        }
        #endregion

        #region datatable去重 
        public static DataTable GetDistinctTable(DataTable dtSource, List<string> strListColumnName)
        {
            DataTable distinctTable = dtSource.Clone();
            try
            {
                if (dtSource != null && dtSource.Rows.Count > 0)
                {
                    DataView dv = new DataView(dtSource);
                    distinctTable = dv.ToTable(true, strListColumnName.ToArray());
                }
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
            return distinctTable;
        }

        public static DataTable GetDistinctTable(DataTable dtSource)
        {
            DataTable distinctTable = null;
            try
            {
                if (dtSource != null && dtSource.Rows.Count > 0)
                {
                    string[] columnNames = GetTableColumnName(dtSource);
                    DataView dv = new DataView(dtSource);
                    distinctTable = dv.ToTable(true, columnNames);
                }
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
            return distinctTable;
        }

        //获取表中所有列名
        public static string[] GetTableColumnName(DataTable dt)
        {
            string cols = string.Empty;
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                cols += (dt.Columns[i].ColumnName + ",");
            }
            cols = cols.TrimEnd(',');
            return cols.Split(',');
        }
        #endregion
    }
}

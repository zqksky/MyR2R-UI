﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace R2R_UI.Common
{
    class ReadLoginConfig
    {
        #region 获取xml文件中的数据
        public static List<string> GetResendXmlConfig(string xmlPath)
        {
            List<string> strList = new List<string>();

            XElement xe = XElement.Load(xmlPath);

            IEnumerable<XElement> elements = from ele in xe.Elements("Config").Elements("ResendConfig").Elements("StrConfig")
                                             select ele;

            foreach (var ele in elements)
            {
                string strKey;
                string strValue;

                strKey = ele.Attribute("Key").Value;
                strValue = ele.Attribute("Value").Value;

                strList.Add(strValue);
            }
            return strList;
        }

        public static List<string> GetDomainNameData(string xmlPath)
        {
            List<string> strList = new List<string>();

            XElement xe = XElement.Load(xmlPath);

            IEnumerable<XElement> elements = from ele in xe.Elements("Config").Elements("DomainConfig").Elements("DomainName")
                                             select ele;

            foreach (var ele in elements)
            {
                string strKey;
                string strValue;

                strKey = ele.Attribute("Key").Value;
                //strValue = ele.Attribute("Value").Value;

                //if (ele.LastAttribute.Name == "VALUE_TXT")
                //{
                //    strValue += ";" + ele.Attribute("VALUE_TXT").Value;
                //}
                //MessageBox.Show("strKey=" + strKey + "; strValue=" + strValue);

                strList.Add(strKey);
            }
            return strList;
        }

        //public static Hashtable GetServerAddressData(string xmlPath)
        //{
        //    Hashtable ht = new Hashtable();

        //    XElement xe = XElement.Load(xmlPath);

        //    IEnumerable<XElement> elements = from ele in xe.Elements("Config").Elements("ServerConfig").Elements("ServerAddress")
        //                                     select ele;

        //    foreach (var ele in elements)
        //    {
        //        string strKey;
        //        string strValue;

        //        strKey = ele.Attribute("Key").Value;
        //        strValue = ele.Attribute("Value").Value;

        //        //if (ele.LastAttribute.Name == "VALUE_TXT")
        //        //{
        //        //    strValue += ";" + ele.Attribute("VALUE_TXT").Value;
        //        //}
        //        //MessageBox.Show("strKey=" + strKey + "; strValue=" + strValue);

        //        ht.Add(strKey, strValue);
        //    }
        //    return ht;
        //}

        public static Dictionary<string,string> GetServerAddressData(string xmlPath)
        {
            Dictionary<string, string> dt = new Dictionary<string, string>();

            XElement xe = XElement.Load(xmlPath);

            IEnumerable<XElement> elements = from ele in xe.Elements("Config").Elements("ServerConfig").Elements("ServerAddress")
                                             select ele;

            foreach (var ele in elements)
            {
                string strKey;
                string strValue;

                strKey = ele.Attribute("Key").Value;
                strValue = ele.Attribute("Value").Value;

                //if (ele.LastAttribute.Name == "VALUE_TXT")
                //{
                //    strValue += ";" + ele.Attribute("VALUE_TXT").Value;
                //}
                //MessageBox.Show("strKey=" + strKey + "; strValue=" + strValue);

                dt.Add(strKey, strValue);
            }
            return dt;
        }
        #endregion
    }
}

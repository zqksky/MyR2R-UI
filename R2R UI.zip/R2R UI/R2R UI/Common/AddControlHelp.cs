﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace R2R_UI.Common
{
    class AddControlHelp
    {
        #region AddTabControlToPanel
        public static void AddTabControlToPanel(Panel ctlPanel, List<string> strListInstanceId, List<string> strListInputLbl, List<string> strListOutputLbl, List<DataTable> dtListInput, List<DataTable> dtListOutput)
        {
            TabControl tabControl = new TabControl()
            {
                Name = "tabDetails",
                Dock = DockStyle.Fill,
            };

            ctlPanel.AutoScroll = true;
            ctlPanel.Controls.Add(tabControl);

            for (int i = 0; i < dtListInput.Count; i++)
            {
                TabPage tabPage = new TabPage()
                {
                    Name = "page"+i,
                    Text = strListInstanceId[i]
                };
                tabControl.Controls.Add(tabPage);

                Panel ctlPanelPage = new Panel()
                {
                    Dock = DockStyle.Fill,
                    AutoScroll = true,
                    BorderStyle = BorderStyle.None,
                };
                AddControlToTabPanel(ctlPanelPage, strListInputLbl[i], strListOutputLbl[i], dtListInput[i], dtListOutput[i]);

                //添加到相应容器
                tabPage.Controls.Add(ctlPanelPage);
            }
        }

        public static void AddControlToTabPanel(Panel ctlPanel, string strInputLbl, string strOutputLbl, DataTable dtInput, DataTable dtOutput)
        {
            try
            {
                TableLayoutPanel ctlTabPanel = new TableLayoutPanel();
                ctlTabPanel.Dock = DockStyle.Fill;
                ctlPanel.Controls.Add(ctlTabPanel);
                ctlTabPanel.ColumnCount = 2;
                ctlTabPanel.CellBorderStyle = TableLayoutPanelCellBorderStyle.None;

                for (int i = 0; i < 2; i++)
                {
                    ctlTabPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, ctlTabPanel.Width * 0.5f));    //利用百分比计算，0.2f表示占用本行长度的20%
                }

                ctlTabPanel.RowStyles.Add(new RowStyle(SizeType.Percent, ctlTabPanel.Height));

                SetRowValue(ctlTabPanel, 0, strInputLbl, dtInput);
                SetRowValue(ctlTabPanel, 1, strOutputLbl, dtOutput);

                ctlTabPanel.Dock = DockStyle.Fill;
            }
            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
        }
        private static void SetRowValue(TableLayoutPanel ctlTabPanel, int col, string strLbl, DataTable dt)
        {
            try
            {
                Panel ctlPanel = new Panel();
                AddDgvAndLbelToTabPanel(ctlPanel, strLbl, dt);
                ctlTabPanel.Controls.Add(ctlPanel, col, 0);
                ctlPanel.Dock = DockStyle.Fill;
                ctlPanel.AutoScroll = true;
                ctlPanel.BorderStyle = BorderStyle.None;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

        }
        #endregion

        #region Add Control To TabPanel
        public static void AddControlToTabPanel(Panel ctlPanel, List<string> strListInputLbl, List<string> strListOutputLbl, List<DataTable> dtListInput, List<DataTable> dtListOutput)
        {
            try
            {
                int number = dtListInput.Count;
                TableLayoutPanel ctlTabPanel = new TableLayoutPanel();
                ctlTabPanel.Dock = DockStyle.Fill;
                ctlPanel.Controls.Add(ctlTabPanel);
                ctlTabPanel.ColumnCount = number;
                //ctlTabPanel.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
                float fNum = 1 / float.Parse(number.ToString());

                //ctlTabPanel.Height = ctlTabPanel.RowCount * 40; //table的整体高度，每行40

                for (int n = 0; n < number; n++)
                {
                    ctlTabPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, ctlTabPanel.Width * fNum));    //利用百分比计算，0.2f表示占用本行长度的20%
                }

                for (int i = 0; i < 2; i++)
                {
                    ctlTabPanel.RowStyles.Add(new RowStyle(SizeType.Percent, ctlTabPanel.Height * 0.5f));
                }

                SetRowValue(ctlTabPanel, 0, strListInputLbl, dtListInput);
                SetRowValue(ctlTabPanel, 1, strListOutputLbl, dtListOutput);

                ctlTabPanel.Dock = DockStyle.Fill;
            }
            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
        }

        private static void SetRowValue(TableLayoutPanel ctlTabPanel, int row, List<string> strListLbl, List<DataTable> dtList)
        {
            try
            {
                // 动态添加一行
                //ctlTabPanel.RowCount++;
                for (int i = 0; i < dtList.Count; i++)
                {
                    //Panel ctlPanel = new Panel();
                    //AddDataGridViewToPanel(ctlPanel, dtList[i], strListLbl[i]);
                    //ctlTabPanel.Controls.Add(ctlPanel, i, row);
                    //ctlPanel.Dock = DockStyle.Fill;

                    Panel ctlPanel = new Panel();
                    AddDgvAndLbelToTabPanel(ctlPanel, strListLbl[i], dtList[i]);
                    ctlTabPanel.Controls.Add(ctlPanel, i, row);
                    ctlPanel.Dock = DockStyle.Fill;
                    ctlPanel.BorderStyle = BorderStyle.FixedSingle;
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

        }

        public static void AddDgvAndLbelToTabPanel(Panel ctlPanel, string strLbl, DataTable db)
        {
            TableLayoutPanel ctlTabPanel = new TableLayoutPanel();
            ctlTabPanel.Dock = DockStyle.Fill;
            ctlTabPanel.ColumnCount = 1;
            ctlTabPanel.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;

            ctlTabPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, ctlTabPanel.Width));    //利用百分比计算，0.2f表示占用本行长度的20%

            ctlTabPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 30));
            ctlTabPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            try
            {
                Label lbl = new Label();
                lbl = GetLbl(strLbl);
                ctlTabPanel.Controls.Add(lbl, 0, 0);

                Panel dgvPanel = new Panel();
                dgvPanel = GetDgvPanel(db);
                ctlTabPanel.Controls.Add(dgvPanel, 0, 1);

                ctlPanel.Controls.Add(ctlTabPanel);
            }
            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
        }

        private static void AddDataGridViewToPanel(Panel ctlPanel, DataTable dt, string strLbl)
        {
            try
            {
                Label ctlLable = new Label();

                Panel panLbl = new Panel();
                panLbl.Dock = DockStyle.Top;

                panLbl.Controls.Add(ctlLable);
                ctlPanel.Controls.Add(panLbl);

                Panel panDgv = new Panel();
                panDgv.Dock = DockStyle.Fill;
                panDgv.AutoScroll = true;
                ctlPanel.Controls.Add(panDgv);


                panLbl.Height = 25;
                panLbl.BorderStyle = BorderStyle.FixedSingle;

                ctlLable.Text = strLbl;
                ctlLable.Location = new Point(Convert.ToInt32(panLbl.Width - ctlLable.Width) / 2,
                                           Convert.ToInt32(panLbl.Height - ctlLable.Height) / 2);


                DataGridView dgv = new DataGridView();
                dgv.AllowUserToAddRows = false;
                dgv.ReadOnly = true;
                dgv.DataSource = dt;
                dgv.Dock = DockStyle.Fill;
                panDgv.Controls.Add(dgv);
            }
            catch (Exception err)
            {
                MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
        }
        #endregion

        #region AddTabPageToTabControl
        public static void AddTabPageToTabControl(TabControl tabControl, int tabPageNum, List<string> strListTabPageName)
        {
            // 实例化tabPage
            for (int i = 0; i < tabPageNum; i++)
            {
                TabPage tabPage = new TabPage()
                {
                    Name = strListTabPageName[i],
                    Text = strListTabPageName[i]
                };

                tabControl.Controls.Add(tabPage);
            }

        }
        public static void AddPanelToTabPage(TabPage tabPage, string strLblTxt, DataTable dbDgv)
        {
            Panel ctlPanel = new Panel()
            {
                Dock = DockStyle.Fill
            };

            AddControlToTabPanel(ctlPanel, strLblTxt, dbDgv);

            //添加到相应容器
            tabPage.Controls.Add(ctlPanel);
        }

        public static void AddPanelToTabPage(TabControl tabControl, string strTabPageName, string strLblTxt, DataTable dbDgv)
        {
            // 实例化tabPage
            TabPage tabPage = new TabPage()
            {
                Name = strTabPageName,
                Text = strTabPageName
            };

            Panel ctlPanel = new Panel()
            {
                Dock = DockStyle.Fill
            };

            AddControlToTabPanel(ctlPanel, strLblTxt, dbDgv);

            //添加到相应容器
            tabPage.Controls.Add(ctlPanel);
            tabControl.Controls.Add(tabPage);
        }

        public static void AddControlToTabPanel(Panel ctlPanel, string strLbl, DataTable db)
        {
            try
            {
                TableLayoutPanel ctlTabPanel = new TableLayoutPanel();

                ctlPanel.Controls.Clear();//Add by zqk Important
                ctlTabPanel.Dock = DockStyle.Fill;
                ctlPanel.Controls.Add(ctlTabPanel);
                ctlTabPanel.ColumnCount = 1;
                ctlTabPanel.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;

                //ctlTabPanel.Height = ctlTabPanel.RowCount * 40; //table的整体高度，每行40

                ctlTabPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 1));    //利用百分比计算，0.2f表示占用本行长度的20%

                ctlTabPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 28));
                ctlTabPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));

                SetRowValue(ctlTabPanel, strLbl, db);

                ctlTabPanel.Dock = DockStyle.Fill;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        private static void SetRowValue(TableLayoutPanel ctlTabPanel, string strLbl, DataTable db)
        {
            try
            {
                Label lbl = new Label();
                lbl = GetLbl(strLbl);
                ctlTabPanel.Controls.Add(lbl, 0, 0);

                Panel dgvPanel = new Panel();
                dgvPanel = GetDgvPanel(db);
                ctlTabPanel.Controls.Add(dgvPanel, 0, 1);

            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

        }

        private static Label GetLbl(string strLblTxt)
        {
            Label ctlLable;

            ctlLable = new Label()
            {
                AutoSize=true,
                Text = strLblTxt,
                Width = 1225,
                Height = 30,
                Font = new Font("隶书", 10, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleCenter,
				//Anchor = AnchorStyles.None,
				Dock = DockStyle.Fill,
                //Location = new Point(10, 200)
            };

            return ctlLable;
        }

        private static Panel GetDgvPanel(DataTable db)
        {
            Panel panDgv = new Panel()
            {
                Name = "panDgv",
                TabIndex = 1,
                Tag = 1,
                //Anchor= AnchorStyles.Top & AnchorStyles.Right & AnchorStyles.Left & AnchorStyles.Right,

                Dock = DockStyle.Fill,
                BorderStyle = BorderStyle.FixedSingle,
                AutoScroll = true
            };

            DataGridView dgv = new DataGridView()
            {
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells,
                AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells,
                AllowUserToAddRows = false,
                ReadOnly = true,
                DataSource = db,
                Dock = DockStyle.Fill
            };

            panDgv.Controls.Add(dgv);

            return panDgv;
        }
        #endregion

        #region Set Lable Location
        public static void SetLable(Panel ctlPanel, Label ctlLable, string strLblTxt)
        {
            ctlLable.Text = strLblTxt;
            ctlLable.Location = new Point(Convert.ToInt32(ctlPanel.Width - ctlLable.Width) / 2,
                                        Convert.ToInt32(ctlPanel.Height - ctlLable.Height) / 2);
        }
        #endregion

        #region Get Chart
        public static List<Chart> GetOVLChart(int chartType, int valueType, List<string> strListChartName, List<List<double>> dListValues, List<List<string>> strGroupListChartColumn, int pmNum, int resetNum)
        {
            List<Chart> listChart = new List<Chart>();
            for (int n = 0; n < dListValues.Count; n++)
            {
                Chart chart = new Chart();
                if (chartType == 1)
                {
                    if (valueType == 1)
                    {
                        chart = ChartHelp.CreateColumnChart(strListChartName[n] + "_I", dListValues[n], strGroupListChartColumn[n]);
                    }
                    else if (valueType == 2)
                    {
                        chart = ChartHelp.CreateColumnChart(strListChartName[n] + "_O", dListValues[n], strGroupListChartColumn[n]);
                    }
                }
                else if (chartType == 2)
                {
                    if (valueType == 1)
                    {
                        chart = ChartHelp.CreateLineChart(strListChartName[n] + "_I", dListValues[n], strGroupListChartColumn[n], pmNum, resetNum);
                    }
                    else if (valueType == 2)
                    {
                        chart = ChartHelp.CreateLineChart(strListChartName[n] + "_O", dListValues[n], strGroupListChartColumn[n], pmNum, resetNum);
                    }
                }

                chart.Name = "chartPanNum" + n;
                listChart.Add(chart);
            }
            return listChart;
        }

        public static List<Chart> GetCDFocusChart(int chartType, List<string> strListChartName, List<List<double>> dListValues, List<List<string>> strGroupListChartColumn, int pmNum, int resetNum)
        {
            List<Chart> listChart = new List<Chart>();
            for (int n = 0; n < dListValues.Count; n++)
            {
                Chart chart = new Chart();
                if (chartType == 1)
                {
                    chart = ChartHelp.CreateColumnChart(strListChartName[n], dListValues[n], strGroupListChartColumn[n]);
                }
                else if (chartType == 2)
                {
                    chart = ChartHelp.CreateLineChart(strListChartName[n], dListValues[n], strGroupListChartColumn[n], pmNum, resetNum);
                }

                chart.Name = "chartPanNum" + n;
                listChart.Add(chart);
            }
            return listChart;
        }

        public static List<Chart> GetCommonChart(int chartType, List<string> strListChartName, List<List<double>> dListValues, List<List<string>> strGroupListChartColumn, int pmNum, int resetNum, int chartCount)
        {
            List<Chart> listChart = new List<Chart>();
            for (int n = 0; n < chartCount; n++)
            {
                Chart chart = new Chart();
                if (chartType == 1)
                {
                    chart = ChartHelp.CreateColumnChart(strListChartName[n], dListValues[n], strGroupListChartColumn[n]);
                }
                else if (chartType == 2)
                {
                    chart = ChartHelp.CreateLineChart(strListChartName[n], dListValues[n], strGroupListChartColumn[n], pmNum, resetNum);
                }

                chart.Name = "chartPanNum" + n;
                listChart.Add(chart);
            }
            return listChart;
        }
        #endregion

        #region Add ChartToList
        public static void AddOVLChartToList(ref List<Chart> listChart, int chartType, int valueType, List<string> strListChartName, List<List<double>> dListValues, List<List<string>> strGroupListChartColumn, int pmNum, int resetNum)
        {
            listChart.Clear();
            for (int n = 0; n < dListValues.Count; n++)
            {
                Chart chart = new Chart();
                if (chartType == 1)
                {
                    if (valueType == 1)
                    {
                        chart = ChartHelp.CreateColumnChart(strListChartName[n] + "_I", dListValues[n], strGroupListChartColumn[n]);
                    }
                    else if (valueType == 2)
                    {
                        chart = ChartHelp.CreateColumnChart(strListChartName[n] + "_O", dListValues[n], strGroupListChartColumn[n]);
                    }
                }
                else if (chartType == 2)
                {
                    if (valueType == 1)
                    {
                        chart = ChartHelp.CreateLineChart(strListChartName[n] + "_I", dListValues[n], strGroupListChartColumn[n], pmNum, resetNum);
                    }
                    else if (valueType == 2)
                    {
                        chart = ChartHelp.CreateLineChart(strListChartName[n] + "_O", dListValues[n], strGroupListChartColumn[n], pmNum, resetNum);
                    }
                }

                chart.Name = "chartPanNum" + n;
                listChart.Add(chart);
            }
        }

        public static void AddCDFocusChartToList(ref List<Chart> listChart, int chartType, List<string> strListChartName, List<List<double>> dListValues, List<List<string>> strGroupListChartColumn, int pmNum, int resetNum)
        {
            listChart.Clear();
            for (int n = 0; n < dListValues.Count; n++)
            {
                Chart chart = new Chart();
                if (chartType == 1)
                {
                    chart = ChartHelp.CreateColumnChart(strListChartName[n], dListValues[n], strGroupListChartColumn[n]);
                }
                else if (chartType == 2)
                {
                    chart = ChartHelp.CreateLineChart(strListChartName[n], dListValues[n], strGroupListChartColumn[n], pmNum, resetNum);
                }

                chart.Name = "chartPanNum" + n;
                listChart.Add(chart);
            }
        }

        public static void AddCommonChartToList(ref List<Chart> listChart, int chartType, List<string> strListChartName, List<List<double>> dListValues, List<List<string>> strGroupListChartColumn, int pmNum, int resetNum, int chartCount)
        {
            listChart.Clear();
            for (int n = 0; n < chartCount; n++)
            {
                Chart chart = new Chart();
                if (chartType == 1)
                {
                    chart = ChartHelp.CreateColumnChart(strListChartName[n], dListValues[n], strGroupListChartColumn[n]);
                }
                else if (chartType == 2)
                {
                    chart = ChartHelp.CreateLineChart(strListChartName[n], dListValues[n], strGroupListChartColumn[n], pmNum, resetNum);
                }

                chart.Name = "chartPanNum" + n;
                listChart.Add(chart);
            }
        }
        #endregion

        #region AddChartToPanel
        public static void AddChartToPanel(Panel ctlPanel, List<Chart> listChart)
        {
            int locationX = 0;
            int locationY = 0;
            int chartWidth = 0;
            for (int n = 0; n < listChart.Count; n++)
            {
                Chart chart = new Chart();
                if (n == 0)
                {
                    chart = listChart[0];
                    locationX = chart.Location.X;
                    locationY = chart.Location.Y;
                    chartWidth = chart.Width + 10;
                }
                else
                {
                    chart = listChart[n];
                    locationX = locationX + chartWidth;
                    locationY = chart.Location.Y;
                    chart.Location = new Point(locationX, locationY);
                }
                chart.Name = "chartPanNum" + n;
                ctlPanel.Controls.Add(chart);
            }
        }

        public static void AddChartToPanel(Panel ctlPanel, List<Chart> listChart, int colCount)
        {
            int locationX = 0;
            int locationY = 0;
            int chartWidth = 0;
            int chartHeight = 0;

            for (int n = 0; n < listChart.Count; n++)
            {
                Chart chart = new Chart();

                if (n == 0)
                {
                    chart = listChart[0];
                    locationX = chart.Location.X;
                    locationY = chart.Location.Y;
                    chartWidth = chart.Width + 10;
                }
                else
                {
                    chart = listChart[n];
                    locationX = locationX + chartWidth;
                    locationY = chart.Location.Y;
                }
                if (colCount == 2)
                {
                    chartHeight = listChart[0].Height;
                    locationY = chartHeight + 10;
                }
                chart.Location = new Point(locationX, locationY);
                //chart.Name = "chartPanNum" + n;
                ctlPanel.Controls.Add(chart);
            }
        }

        public static void AddChartToPanel(Panel ctlPanel, List<Chart> listInputChart, List<Chart> listOutputChart)
        {
            AddChartToPanel(ctlPanel, listInputChart, 1);
            AddChartToPanel(ctlPanel, listOutputChart, 2);
        }

        public static void AddChartToPanel(Panel ctlPanel, List<Chart> ctlListChartInput, List<Chart> ctlListChartOutput, string strMsgType)
        {
            if (ctlListChartInput.Count > 0 && ctlListChartOutput.Count > 0)
            {
                //ClearChartPanel();
                if (ctlListChartInput.Count < 3)
                {
                    List<Chart> ctlListInputAndOutputChart = new List<Chart>();
                    for (int i = 0; i < ctlListChartInput.Count; i++)
                    {
                        ctlListInputAndOutputChart.Add(ctlListChartInput[i]);
                        ctlListInputAndOutputChart.Add(ctlListChartOutput[i]);
                    }
                    AddChartToPanel(ctlPanel, ctlListInputAndOutputChart);
                }
                else
                {
                    AddChartToPanel(ctlPanel, ctlListChartInput, ctlListChartOutput);
                }
            }
            else
            {
                if (ctlListChartInput.Count > 0)
                {
                    //ClearChartPanel();
                    AddChartToPanel(ctlPanel, ctlListChartInput);
                    //MessageBox.Show(strMsgType + " No available Output chart");
                }
                else if (ctlListChartOutput.Count > 0)
                {
                    //ClearChartPanel();
                    AddChartToPanel(ctlPanel, ctlListChartOutput);
                    //MessageBox.Show(strMsgType + " No available Input chart");
                }
                else
                {
                    //MessageBox.Show(strMsgType + " No available Input/Output chart");
                }
            }
        }
        #endregion
    }
}

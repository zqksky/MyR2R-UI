﻿using R2R_UI.Common;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace R2R_UI
{
    public partial class frmLogin : Form
    {

        #region
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x0014) // 禁掉清除背景消息
                return;
            base.WndProc(ref m);
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x02000000;
                return cp;
            }
        }

        private void CtlDoubleBuffer()
        {
            this.DoubleBuffered = true;//设置本窗体
            SetStyle(ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true); // 禁止擦除背景.
            SetStyle(ControlStyles.DoubleBuffer, true); // 双缓冲
            //SetStyle(ControlStyles.DoubleBuffer | ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint, true);
            UpdateStyles();
        }
        #endregion

        public frmLogin()
        {
            InitializeComponent();
        }

        #region Parm Define
        public string strDomainName
        {
            set
            {
                //txtDomainName.Text = value;
                cmbDomainName.Text = value;
            }

            get
            {
                //return txtDomainName.Text;
                return cmbDomainName.Text.ToString();
            }
        }

        public string strUserName
        {
            get
            {
                return txtUserName.Text;
            }
            set
            {
                txtUserName.Text = value;
            }
        }

        public string strPassword
        {
            set
            {
                txtPassword.Text = value;
            }

            get
            {
                return txtPassword.Text;
            }
        }

        public string strServerAddress
        {
            get
            {
                return cmbServerAddress.SelectedValue.ToString();
                //return cmbServerAddress.Text.ToString();
            }

            set
            {
                cmbServerAddress.Text = value;
            }
        }

        public string strServerAddressNew;
  
        public string strServerType
        {
            get
            {
                return cmbServerAddress.Text.ToString();
            }

            set
            {
                //cmbServerAddress.Text = value;
            }
        }

        public bool bAutoLogin
        {
            get
            {
                return chkAutoLogin.Checked;
            }

            set
            {
                chkAutoLogin.Checked = value;
            }
        }
        #endregion


        private void frmLogin_Load(object sender, EventArgs e)
        {
            this.KeyPreview = true;

            #region  Double Buffer
            CtlDoubleBuffer();
            #endregion

            #region
            List<string> strList = new List<string>();
            strList = ReadLoginConfig.GetDomainNameData(Environment.CurrentDirectory + "\\LoginConfigFile.xml");
            bindDomainNameCmbox(strList);
            cmbDomainName.SelectedIndex = 0;
           
            Dictionary<string, string> dt = new Dictionary<string, string>();
            dt = ReadLoginConfig.GetServerAddressData(Environment.CurrentDirectory + "\\LoginConfigFile.xml");
            bindServerAddressCmbox(dt);
            cmbServerAddress.SelectedIndex = 0;        //  设置为默认选中第一个
            #endregion
        }

        #region
        private void bindDomainNameCmbox(List<string> strList)
        {
            //cmbDomainName.DataSource = strList;

            foreach (var str in strList)
            {
                cmbDomainName.Items.Add(str);
            }

            //BindingSource bs = new BindingSource();
            //bs.DataSource = strList;
            //cmbDomainName.DataSource = bs;
            ////cmbDomainName.ValueMember = "Key";
            //cmbDomainName.DisplayMember = "Value";
        }

        private void bindServerAddressCmbox(Hashtable ht)
        {
            BindingSource bs = new BindingSource();
            bs.DataSource = ht;
            cmbServerAddress.DataSource = bs;
            cmbServerAddress.ValueMember = "Value";
            cmbServerAddress.DisplayMember = "Key";
        }

        private void bindServerAddressCmbox(Dictionary<string, string> dt)
        {
            BindingSource bs = new BindingSource();
            bs.DataSource = dt;
            cmbServerAddress.DataSource = bs;
            cmbServerAddress.ValueMember = "Value";
            cmbServerAddress.DisplayMember = "Key";
        }
        #endregion

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(cmbDomainName.Text))
            {
                MessageBox.Show("Domain Name is mandatory");
            }

            else if (string.IsNullOrEmpty(txtUserName.Text))
            {
                MessageBox.Show("User name is mandatory");
            }

            else if (string.IsNullOrEmpty(txtPassword.Text))
            {
                MessageBox.Show("Password is mandatory");
            }

            else if (string.IsNullOrEmpty(cmbServerAddress.Text))
            {
                MessageBox.Show("E3 Server address is mandatory");
            }
            else
            {
                bool bSuccess = false;
                int operationType=0;
                string strServerAddressTmp = string.Empty;
                strServerAddressNew = strServerAddress;
                bSuccess = LoginServiceFun.LoginManage(ref strServerAddressNew, strUserName, strPassword, strDomainName, false, ref operationType);
                if (bSuccess)
                {
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                else
                {
                    //txtUserName.Text = "";
                    //txtPassword.Text = "";
                }           
            }
            //SendKeys.Send("{ENTER}");
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void frmLogin_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)//判断回车键
            {
                //this.btnLogin.Focus();
                this.btnOk_Click(sender, e);//触发按钮事件
            }
        }

        private void frmLogin_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (this.DialogResult != DialogResult.OK)
            {
                return;
            }
        }   
    }
}

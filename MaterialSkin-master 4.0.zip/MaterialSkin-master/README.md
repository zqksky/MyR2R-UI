# MaterialSkin for .NET WinForms (.NET 4.0)

Theming .NET WinForms, C# or VB.Net, to Google's Material Design Principles.

<a href="https://www.youtube.com/watch?v=A8osVM_SXlg" target="_blank">![alt tag](http://i.imgur.com/JAttoOo.png)</a>

[Main Repository](https://github.com/IgnaceMaes/MaterialSkin)

# Nuget

View in Nuget : [Material Skin 4.0](https://www.nuget.org/packages/MaterialSkin.Net4/)  

```bash
Install-Package MaterialSkin.Net4
```
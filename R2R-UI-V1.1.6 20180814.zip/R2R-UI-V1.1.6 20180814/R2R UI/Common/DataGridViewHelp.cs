﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace R2R_UI.Common
{
    class DataGridViewHelp
    {
        public static void InitDgvGrid(DataGridView ctlDgv, DataTable tb)
        {
            ctlDgv.DataSource = tb;

            //禁止编辑
            ctlDgv.ReadOnly = true;
            for (int i = 0; i < ctlDgv.ColumnCount; i++)
            {
                ctlDgv.Columns[i].ReadOnly = true;
                //ctlDgv.Columns[i].DefaultCellStyle.BackColor = Color.LightGray;
            }
        }

        public static void InitDgvSet(DataGridView ctlDgv, DataTable tb)
        {
            ctlDgv.DataSource = tb;

            //禁止编辑
            //ctlDgv.ReadOnly = true;
            ctlDgv.ReadOnly = false;
            ctlDgv.EditMode = DataGridViewEditMode.EditOnEnter;

            // 设置边框样式（上边框）,枚举：双线内陷边框
            ctlDgv.AdvancedCellBorderStyle.Top = DataGridViewAdvancedCellBorderStyle.InsetDouble;

            //边框线 颜色
            ctlDgv.GridColor = Color.SeaGreen; 

        }

        public static void InitDgvSet(DataGridView ctlDgv, DataTable tb,int colCount)
        {
            ctlDgv.DataSource = tb;

            //禁止编辑
            //ctlDgv.ReadOnly = true;
            ctlDgv.ReadOnly = false;
            ctlDgv.EditMode = DataGridViewEditMode.EditOnEnter;
            for (int i = 0; i < colCount; i++)
            {
                ctlDgv.Columns[i].ReadOnly = true;
                ctlDgv.Columns[i].DefaultCellStyle.BackColor = Color.LightGray;
            }

        }

        public static void InitDgvSet(DataGridView ctlDgv, DataTable tb, List<int> colListCount)
        {
            BindingSource bs = new BindingSource();
            bs.DataSource = tb;
            ctlDgv.DataSource = bs;
            ctlDgv.EndEdit();
            bs.EndEdit();

            //禁止编辑
            //ctlDgv.ReadOnly = true;
            ctlDgv.ReadOnly = false;
            for (int i = 0; i < colListCount.Count; i++)
            {
                ctlDgv.Columns[colListCount[i]].ReadOnly = true;
                ctlDgv.Columns[colListCount[i]].DefaultCellStyle.BackColor = Color.LightGray;
            }
            ctlDgv.EditMode = DataGridViewEditMode.EditOnEnter;
        }

        //自动排序功能禁用
        public static void dgvSortModeSet(DataGridView dgv)
        {
            for (int i = 0; i < dgv.Columns.Count; i++)
            {
                dgv.Columns[i].SortMode = DataGridViewColumnSortMode.NotSortable;
            }
        }

        public static List<string> GetDgvColumnToList(DataGridView dgv, int colIndex)
        {
            List<string> strList = new List<string>();
            if (dgv.RowCount > 0)
            {
                for (int i = 0; i < dgv.RowCount; i++)
                {
                    strList.Add(dgv.Rows[i].Cells[colIndex].Value.ToString());
                }
            }
            return strList;
        }

        private void SetDgvCmb(DataGridView dgv, int rowIndex, int colIndex)
        {
            List<string> strList = new List<string>() { "NA", "C1", "C2" };
            dgv.Rows[rowIndex].Cells[colIndex] = new DataGridViewComboBoxCell();

            ((DataGridViewComboBoxCell)dgv.Rows[rowIndex].Cells[colIndex]).DataSource = strList;
            //((DataGridViewComboBoxCell)dgvSet.Rows[rowIndex].Cells[colIndex]).DisplayMember = "Key";
            //((DataGridViewComboBoxCell)dgvSet.Rows[rowIndex].Cells[colIndex]).ValueMember = "Value";
            //((DataGridViewComboBoxCell)dgvSet.Rows[rowIndex].Cells[colIndex]).Value= strList[0];
            //((DataGridViewComboBoxCell)dgvSet.Rows[rowIndex].Cells[colIndex]).Items[0] = strList[0];
            dgv.Rows[rowIndex].Cells[colIndex].Value = strList[0];
        }

        public static void SetDgvCmb(DataGridView dgv, List<string> strList, int rowIndex, int colIndex,string strValue)
        {
            //strList = new List<string>() { "NA", "C1", "C2" };
            dgv.Rows[rowIndex].Cells[colIndex] = new DataGridViewComboBoxCell();

            ((DataGridViewComboBoxCell)dgv.Rows[rowIndex].Cells[colIndex]).DataSource = strList;
            dgv.Rows[rowIndex].Cells[colIndex].Value = strValue;
        }

        public static void SetDgvCmb(DataGridView dgv, int colIndex, List<string> strList, string strColName)
        {
            if (dgv.Columns.Contains(strColName))
            {
                dgv.Columns.Remove(strColName);
            }
            if (dgv.Columns.Contains(strColName))
            {       
                dgv.Columns.Remove("New OVLModel");
            }

            DataGridViewColumn myCol = new DataGridViewComboBoxColumn();
            myCol.Name = strColName;
            myCol.HeaderText = strColName;

            dgv.AllowUserToAddRows = false;
            dgv.AutoGenerateColumns = false;

            dgv.Columns.Insert(colIndex, myCol);

            ((DataGridViewComboBoxColumn)dgv.Columns[colIndex]).DataSource = strList;

        }

        public static void SetDgvCmb(DataGridView dgv, int colIndex, List<string> strList)
        {
            DataGridViewColumn myCol = new DataGridViewComboBoxColumn();
            myCol.Name = "选择框";
            myCol.HeaderText = "选择框";
            //dgv.Columns.Add(myCol);

            //strList = new List<string>() { "NA", "C1", "C2" };
            dgv.AllowUserToAddRows = false;
            dgv.AutoGenerateColumns = false;

            dgv.Columns.Insert(colIndex, myCol);

            ((DataGridViewComboBoxColumn)dgv.Columns[colIndex]).DataSource = strList;
            //((DataGridViewComboBoxColumn)dgv.Columns[colIndex]).DefaultCellStyle.NullValue = strList;
        }

        public static void SetDgvCmb(DataGridView dgv, int colIndex, List<string> strList, string strColName, string strVlaue)
        {
            DataGridViewColumn myCol = new DataGridViewComboBoxColumn();
            myCol.Name = strColName;
            myCol.HeaderText = strColName;
            //dgv.Columns.Add(myCol);

            //strList = new List<string>() { "NA", "C1", "C2" };
            dgv.AllowUserToAddRows = false;
            dgv.AutoGenerateColumns = false;

            dgv.Columns.Insert(colIndex, myCol);

            ((DataGridViewComboBoxColumn)dgv.Columns[colIndex]).DataSource = strList;
            ((DataGridViewComboBoxColumn)dgv.Columns[colIndex]).DefaultCellStyle.NullValue = strVlaue;
        }

        public static void dgvAttributeSet(DataGridView dgv)
        {
            //1.禁用最后一行空白。
            dgv.AllowUserToAddRows = false;

            //2.禁用‘delete'键的删除功能。默认情况，鼠标选中一整行，按 删除键 可以删除当前一整行
            dgv.AllowUserToDeleteRows = false;

            //上述禁用，仅是将用户界面交互的自动新增行禁了，但还是可以通过代码来删除指定行数据。：
            //dgv.Rows.Remove(DataGridViewRow dataGridViewRow);             
            //dgv.Rows.RemoveAt(int index);

            //6.禁用单元格编辑功能
            dgv.ReadOnly = true;
            // 设置 DataGridView1 的第2列整列单元格为只读 
            dgv.Columns[1].ReadOnly = true;

            // 第一列自动调整 
            dgv.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;

            // 7.点击选中整行、整列
            dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;// 单击选中整行，枚举

            //8.禁用多行 / 多列 / 多单元格选择
            dgv.MultiSelect = false;

            //9.设置表格网格线颜色等样式
            dgv.AdvancedCellBorderStyle.Top = DataGridViewAdvancedCellBorderStyle.InsetDouble;


            //索引0列的单元格的背景色为淡蓝色
            dgv.Columns[0].DefaultCellStyle.BackColor = Color.Aqua;

            //索引0行的单元格的背景色为淡灰色
            dgv.Rows[0].DefaultCellStyle.BackColor = Color.LightGray;

            // 设置边框样式（上边框）,枚举：双线内陷边框
            dgv.GridColor = Color.SeaGreen; //边框线 颜色

            //设置列标题不换行
            dgv.ColumnHeadersDefaultCellStyle.WrapMode = DataGridViewTriState.False;  

            // 设定包括Header和所有单元格的列宽自动调整
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dgv.ColumnHeadersDefaultCellStyle.WrapMode = DataGridViewTriState.False;  //设置列标题不换行
                                                                                      // 设定不包括Header所有单元格的行高自动调整
            dgv.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;  //AllCells;设定包括Header和所有单元格的行高自动调整

        }

        //DataGridView减少闪烁的解决办法 
        public static void DoubleBuffered(DataGridView dgv, bool bSet)
        {
            Type dgvType = dgv.GetType();
            PropertyInfo pi = dgvType.GetProperty("DoubleBuffered", BindingFlags.Instance | BindingFlags.NonPublic);
            pi.SetValue(dgv, bSet, null);
        }


        /// <summary> 
        /// IBindingListView接口（如BindingSource类） 
        /// </summary> 
        /// <returns></returns> 
        private BindingSource DataBindingByBindingSource(List<string> strList)
        {
            Dictionary<string, string> dic = new Dictionary<string, string>();
            for (int i = 0; i < 10; i++)
            {
                dic.Add(i.ToString(), i.ToString() + "_Dictionary");
            }

            return new BindingSource(dic, null);
        }

        //自动行序号
        public static void dgv_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            var dgv = sender as DataGridView;

            if (e.ColumnIndex < 0 && e.RowIndex >= 0) // 绘制 自动序号
            {
                e.Paint(e.ClipBounds, DataGridViewPaintParts.All);
                Rectangle vRect = e.CellBounds;
                vRect.Inflate(-2, 2);
                TextRenderer.DrawText(e.Graphics, (e.RowIndex + 1).ToString(), e.CellStyle.Font, vRect, 
                    e.CellStyle.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
                e.Handled = true;
            }

            // ----- 其它样式设置 -------
            if (e.RowIndex % 2 == 0)
            { 
                // 行序号为双数（含0）时 
                e.CellStyle.BackColor = Color.White;
            }
            else
            {
                e.CellStyle.BackColor = Color.Honeydew;
            }
            e.CellStyle.SelectionBackColor = Color.Gray; // 选中单元格时，背景色
            e.CellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter; //单位格内数据对齐方式
        }

        public static void dgv_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            #region fun1    datagridview显示行号 
            var dgv = sender as DataGridView;
            var rowIdx = (e.RowIndex + 1).ToString();

            var centerFormat = new StringFormat()
            {
                // right alignment might actually make more sense for numbers
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center
            };
            var headerBounds = new System.Drawing.Rectangle(e.RowBounds.Left, e.RowBounds.Top, dgv.RowHeadersWidth, e.RowBounds.Height);
            e.Graphics.DrawString(rowIdx, dgv.RowHeadersDefaultCellStyle.Font, SystemBrushes.ControlText, headerBounds, centerFormat);
            #endregion

            #region fun2    datagridview显示行号 
            //var dgv = sender as DataGridView;
            //Rectangle rectangle = new Rectangle(e.RowBounds.Location.X,
            //    e.RowBounds.Location.Y,
            //    dgv.RowHeadersWidth - 4,
            //    e.RowBounds.Height);


            //TextRenderer.DrawText(e.Graphics, (e.RowIndex + 1).ToString(),
            //    dgv.RowHeadersDefaultCellStyle.Font, rectangle,
            //    dgv.RowHeadersDefaultCellStyle.ForeColor,
            //    TextFormatFlags.VerticalCenter | TextFormatFlags.Right);
            #endregion
        }

        // CellFormatting事件处理器
        public static void dgv_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            //DataGridView dgv = (DataGridView)sender;

            ////确认单元格的列
            //if (dgv.Columns[e.ColumnIndex].Name == "Column1" && e.Value is string)
            //{
            //    e.Value = e.Value.ToString();
            //}
        }
    }
}

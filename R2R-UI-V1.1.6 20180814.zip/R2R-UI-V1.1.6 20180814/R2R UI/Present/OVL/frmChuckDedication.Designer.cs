﻿namespace R2R_UI.Present.OVL
{
    partial class frmChuckDedication
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.dgvSet = new System.Windows.Forms.DataGridView();
            this.panDgvLblParameters = new System.Windows.Forms.Panel();
            this.lblDgvParameters = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnQueryLotInfo = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.txtStepSequence = new System.Windows.Forms.TextBox();
            this.txtLayer = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.txtLotId = new System.Windows.Forms.TextBox();
            this.txtFabName = new System.Windows.Forms.TextBox();
            this.panBtnOk = new System.Windows.Forms.Panel();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOk = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panDgv = new System.Windows.Forms.Panel();
            this.dgvContext = new System.Windows.Forms.DataGridView();
            this.panDgvLblContext = new System.Windows.Forms.Panel();
            this.lblDgvContext = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSet)).BeginInit();
            this.panDgvLblParameters.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panBtnOk.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panDgv.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvContext)).BeginInit();
            this.panDgvLblContext.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.panBtnOk);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1127, 726);
            this.panel1.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Controls.Add(this.panDgvLblParameters);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 351);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1127, 342);
            this.panel4.TabIndex = 14;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.dgvSet);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 26);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1127, 316);
            this.panel5.TabIndex = 5;
            // 
            // dgvSet
            // 
            this.dgvSet.AllowUserToAddRows = false;
            this.dgvSet.AllowUserToDeleteRows = false;
            this.dgvSet.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvSet.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvSet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSet.Location = new System.Drawing.Point(0, 0);
            this.dgvSet.Name = "dgvSet";
            this.dgvSet.Size = new System.Drawing.Size(1127, 316);
            this.dgvSet.TabIndex = 1;
            this.dgvSet.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvContext_CellFormatting);
            this.dgvSet.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.dgvContext_CellPainting);
            this.dgvSet.CurrentCellChanged += new System.EventHandler(this.dgvSet_CurrentCellChanged);
            this.dgvSet.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvContext_RowPostPaint);
            // 
            // panDgvLblParameters
            // 
            this.panDgvLblParameters.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panDgvLblParameters.Controls.Add(this.lblDgvParameters);
            this.panDgvLblParameters.Dock = System.Windows.Forms.DockStyle.Top;
            this.panDgvLblParameters.Location = new System.Drawing.Point(0, 0);
            this.panDgvLblParameters.Name = "panDgvLblParameters";
            this.panDgvLblParameters.Size = new System.Drawing.Size(1127, 26);
            this.panDgvLblParameters.TabIndex = 4;
            // 
            // lblDgvParameters
            // 
            this.lblDgvParameters.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblDgvParameters.AutoSize = true;
            this.lblDgvParameters.Location = new System.Drawing.Point(501, 3);
            this.lblDgvParameters.Name = "lblDgvParameters";
            this.lblDgvParameters.Size = new System.Drawing.Size(91, 13);
            this.lblDgvParameters.TabIndex = 0;
            this.lblDgvParameters.Text = "List of Parameters";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.btnQueryLotInfo);
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Controls.Add(this.textBox2);
            this.panel2.Controls.Add(this.txtStepSequence);
            this.panel2.Controls.Add(this.txtLayer);
            this.panel2.Controls.Add(this.textBox12);
            this.panel2.Controls.Add(this.textBox11);
            this.panel2.Controls.Add(this.txtLotId);
            this.panel2.Controls.Add(this.txtFabName);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 268);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1127, 83);
            this.panel2.TabIndex = 13;
            // 
            // btnQueryLotInfo
            // 
            this.btnQueryLotInfo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnQueryLotInfo.Location = new System.Drawing.Point(906, 33);
            this.btnQueryLotInfo.Name = "btnQueryLotInfo";
            this.btnQueryLotInfo.Size = new System.Drawing.Size(96, 23);
            this.btnQueryLotInfo.TabIndex = 18;
            this.btnQueryLotInfo.Text = "Query LotInfo";
            this.btnQueryLotInfo.UseVisualStyleBackColor = true;
            this.btnQueryLotInfo.Click += new System.EventHandler(this.btnQueryLotInfo_Click);
            // 
            // textBox1
            // 
            this.textBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Location = new System.Drawing.Point(524, 53);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(88, 20);
            this.textBox1.TabIndex = 17;
            this.textBox1.Text = "Step Sequence:";
            // 
            // textBox2
            // 
            this.textBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2.Location = new System.Drawing.Point(524, 15);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(88, 20);
            this.textBox2.TabIndex = 15;
            this.textBox2.Text = "Config Layer:";
            // 
            // txtStepSequence
            // 
            this.txtStepSequence.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtStepSequence.Location = new System.Drawing.Point(628, 53);
            this.txtStepSequence.Name = "txtStepSequence";
            this.txtStepSequence.ReadOnly = true;
            this.txtStepSequence.Size = new System.Drawing.Size(234, 20);
            this.txtStepSequence.TabIndex = 16;
            // 
            // txtLayer
            // 
            this.txtLayer.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtLayer.Location = new System.Drawing.Point(628, 15);
            this.txtLayer.Name = "txtLayer";
            this.txtLayer.Size = new System.Drawing.Size(234, 20);
            this.txtLayer.TabIndex = 14;
            // 
            // textBox12
            // 
            this.textBox12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12.Location = new System.Drawing.Point(126, 54);
            this.textBox12.Name = "textBox12";
            this.textBox12.ReadOnly = true;
            this.textBox12.Size = new System.Drawing.Size(88, 20);
            this.textBox12.TabIndex = 13;
            this.textBox12.Text = "Lot ID:";
            // 
            // textBox11
            // 
            this.textBox11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11.Location = new System.Drawing.Point(126, 16);
            this.textBox11.Name = "textBox11";
            this.textBox11.ReadOnly = true;
            this.textBox11.Size = new System.Drawing.Size(88, 20);
            this.textBox11.TabIndex = 11;
            this.textBox11.Text = "FabName:";
            // 
            // txtLotId
            // 
            this.txtLotId.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtLotId.Location = new System.Drawing.Point(230, 54);
            this.txtLotId.Name = "txtLotId";
            this.txtLotId.Size = new System.Drawing.Size(234, 20);
            this.txtLotId.TabIndex = 12;
            // 
            // txtFabName
            // 
            this.txtFabName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtFabName.Location = new System.Drawing.Point(230, 16);
            this.txtFabName.Name = "txtFabName";
            this.txtFabName.Size = new System.Drawing.Size(234, 20);
            this.txtFabName.TabIndex = 10;
            // 
            // panBtnOk
            // 
            this.panBtnOk.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panBtnOk.Controls.Add(this.btnCancel);
            this.panBtnOk.Controls.Add(this.btnOk);
            this.panBtnOk.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panBtnOk.Location = new System.Drawing.Point(0, 693);
            this.panBtnOk.Name = "panBtnOk";
            this.panBtnOk.Size = new System.Drawing.Size(1127, 33);
            this.panBtnOk.TabIndex = 12;
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.Location = new System.Drawing.Point(993, 5);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(73, 23);
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOk
            // 
            this.btnOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOk.Location = new System.Drawing.Point(898, 5);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(73, 23);
            this.btnOk.TabIndex = 0;
            this.btnOk.Text = "Ok";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.panDgv);
            this.panel3.Controls.Add(this.panDgvLblContext);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1127, 268);
            this.panel3.TabIndex = 11;
            // 
            // panDgv
            // 
            this.panDgv.Controls.Add(this.dgvContext);
            this.panDgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panDgv.Location = new System.Drawing.Point(0, 26);
            this.panDgv.Name = "panDgv";
            this.panDgv.Size = new System.Drawing.Size(1127, 242);
            this.panDgv.TabIndex = 3;
            // 
            // dgvContext
            // 
            this.dgvContext.AllowUserToAddRows = false;
            this.dgvContext.AllowUserToDeleteRows = false;
            this.dgvContext.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvContext.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvContext.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvContext.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvContext.Location = new System.Drawing.Point(0, 0);
            this.dgvContext.Name = "dgvContext";
            this.dgvContext.Size = new System.Drawing.Size(1127, 242);
            this.dgvContext.TabIndex = 0;
            this.dgvContext.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvContext_CellFormatting);
            this.dgvContext.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.dgvContext_CellPainting);
            this.dgvContext.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvContext_RowPostPaint);
            // 
            // panDgvLblContext
            // 
            this.panDgvLblContext.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panDgvLblContext.Controls.Add(this.lblDgvContext);
            this.panDgvLblContext.Dock = System.Windows.Forms.DockStyle.Top;
            this.panDgvLblContext.Location = new System.Drawing.Point(0, 0);
            this.panDgvLblContext.Name = "panDgvLblContext";
            this.panDgvLblContext.Size = new System.Drawing.Size(1127, 26);
            this.panDgvLblContext.TabIndex = 2;
            // 
            // lblDgvContext
            // 
            this.lblDgvContext.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblDgvContext.AutoSize = true;
            this.lblDgvContext.Location = new System.Drawing.Point(495, 8);
            this.lblDgvContext.Name = "lblDgvContext";
            this.lblDgvContext.Size = new System.Drawing.Size(103, 13);
            this.lblDgvContext.TabIndex = 0;
            this.lblDgvContext.Text = "List of context group";
            // 
            // frmChuckDedication
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1127, 726);
            this.Controls.Add(this.panel1);
            this.MinimumSize = new System.Drawing.Size(900, 500);
            this.Name = "frmChuckDedication";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ChuckDedication";
            this.Load += new System.EventHandler(this.frmChuckDedication_Load);
            this.SizeChanged += new System.EventHandler(this.frmChuckDedication_SizeChanged);
            this.Resize += new System.EventHandler(this.frmChuckDedication_Resize);
            this.panel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSet)).EndInit();
            this.panDgvLblParameters.ResumeLayout(false);
            this.panDgvLblParameters.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panBtnOk.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panDgv.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvContext)).EndInit();
            this.panDgvLblContext.ResumeLayout(false);
            this.panDgvLblContext.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panDgv;
        private System.Windows.Forms.DataGridView dgvContext;
        private System.Windows.Forms.Panel panDgvLblContext;
        private System.Windows.Forms.Label lblDgvContext;
        private System.Windows.Forms.Panel panBtnOk;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DataGridView dgvSet;
        private System.Windows.Forms.Panel panDgvLblParameters;
        private System.Windows.Forms.Label lblDgvParameters;
        private System.Windows.Forms.Button btnQueryLotInfo;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox txtStepSequence;
        private System.Windows.Forms.TextBox txtLayer;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox txtLotId;
        private System.Windows.Forms.TextBox txtFabName;
    }
}
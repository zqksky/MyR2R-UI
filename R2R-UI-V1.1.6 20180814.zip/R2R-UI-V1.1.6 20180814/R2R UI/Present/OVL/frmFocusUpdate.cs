﻿using R2R_UI.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace R2R_UI.Present.OVL
{
    public partial class frmFocusUpdate : Form
    {
        #region
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x0014) // 禁掉清除背景消息
                return;
            base.WndProc(ref m);
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x02000000;
                return cp;
            }
        }

        private void CtlDoubleBuffer()
        {
            this.DoubleBuffered = true;//设置本窗体
            SetStyle(ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true); // 禁止擦除背景.
            SetStyle(ControlStyles.DoubleBuffer, true); // 双缓冲
            //SetStyle(ControlStyles.DoubleBuffer | ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint, true);
            UpdateStyles();
        }
        #endregion

        public frmFocusUpdate()
        {
            InitializeComponent();
        }
        public frmFocusUpdate(string strServiceName, string strCurrentUserName, string strCurrentPwd, List<string> strListFrmR2RContexts, double dFrmValue)
        {
            InitializeComponent();
            strServiceAddres = strServiceName;
            strUserName = strCurrentUserName;
            strPassword = strCurrentPwd;

            strListR2RContexts = strListFrmR2RContexts;
            dValue = dFrmValue;


        }
        #region Param
        string strServiceAddres;
        string strUserName;
        string strPassword;

        double dValue;
        double dValueUpdate;
        List<string> strListR2RContexts = new List<string>();
        #endregion

        private float frmLocationX;
        private float frmLocationY;
        AdaptiveSizeResolution AutoSizeFrm = new AdaptiveSizeResolution();
        private void frmFocusUpdate_Load(object sender, EventArgs e)
        {
            #region 双缓冲
            CtlDoubleBuffer();
            #endregion

            #region AdaptiveSizeResolution
            //AutoSizeFrm.ControllInitializeSize(this);
            #endregion

            #region  AdaptiveSize
            //this.Resize += new EventHandler(frmFocusUpdate_Resize);
            //frmLocationX = this.Width;
            //frmLocationY = this.Height;
            //AdaptiveSize.setTag(this);
            #endregion

            txtCurrent.Text = dValue.ToString();
            txtNew.Text = dValue.ToString();
        }

        private void frmFocusUpdate_Resize(object sender, EventArgs e)
        {
            #region AdaptiveSize
            //float newx = (this.Width) / frmLocationX;
            //float newy = this.Height / frmLocationY;
            //AdaptiveSize.setControls(newx, newy, this);
            #endregion
        }

        private void frmFocusUpdate_SizeChanged(object sender, EventArgs e)
        {
            #region AdaptiveSizeResolution
            //AutoSizeFrm.ControlAutoSize(this);
            #endregion
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            frmCheckedPwd frmChecked = new frmCheckedPwd(strUserName);
            if (frmChecked.ShowDialog() == DialogResult.OK)
            {
                if (frmChecked.strPassword.Equals(strPassword))
                {
                    #region
                    bool bSuccess;
                    try
                    {
                        #region PH_Focus_UpdateFocusSettings
                        dValueUpdate = double.Parse(txtNew.Text.ToString());
                        bSuccess = UIServiceFun.R2R_UI_PH_Focus_UpdateFocusSettings(strServiceAddres, strUserName, strListR2RContexts, dValueUpdate);
                        if (bSuccess)
                        {
                            this.Close();
                        }
                        else
                        {
                            //MessageBox.Show("Set Failed!");
                        }
                        this.DialogResult = DialogResult.OK;
                        #endregion
                    }
                    catch (Exception ee)
                    {
                        MessageBox.Show(ee.Message);
                    }
                    #endregion
                }
                else
                {
                    MessageBox.Show("Invalid password!");
                }
            }
            else
            {
                //MessageBox.Show("Invalid password!");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace R2R_UI.Common
{
    class TestAddTab
    {
        #region Add TabPage
        public static DataGridView SetDgv(DataTable dt, string strDgvTxt)
        {
            DataGridView ctlDgv = new DataGridView();
            ctlDgv.Dock = DockStyle.Fill;
            ctlDgv.Text = strDgvTxt;
            ctlDgv.DataSource = dt;

            return ctlDgv;
        }
        public static void AddDgvToPanel(Panel ctlPanel, DataGridView ctlDgv)
        {
            ctlPanel.Dock = DockStyle.Fill;
            ctlDgv.Dock = DockStyle.Fill;

            ctlPanel.Controls.Add(ctlDgv);
        }

        public static void AddPanelToTabpage(TabControl ctlTab, Panel ctlPanel, string strPageTxt)
        {
            int tabCount = 0;
            tabCount = ctlTab.TabCount;

            TabPage Page = new TabPage();
            Page.Name = strPageTxt;
            Page.Text = strPageTxt;
            //Page.TabIndex = tabCount;

            Page.Controls.Add(ctlPanel);
            ctlTab.Controls.Add(Page);
        }

        private static void AddLblToPanel(Panel ctlPanel)
        {
            Label ctlLbl = new Label();
            ctlLbl.Text = "myLbl";
            ctlPanel.Controls.Add(ctlLbl);
            ctlLbl.Location = new System.Drawing.Point(Convert.ToInt32(ctlPanel.Width - ctlLbl.Width) / 2,
                                        Convert.ToInt32(ctlPanel.Height - ctlLbl.Height) / 2);
        }

        private static void AddDgvToPanel(Panel ctlPanel)
        {
            ctlPanel.Dock = DockStyle.Fill;

            DataGridView ctlDgv = new DataGridView();
            ctlDgv.Dock = DockStyle.Fill;
            ctlDgv.Text = "NewGrid";
            ctlPanel.Controls.Add(ctlDgv);

        }
        public static void AddTabpage(TabControl ctlTab, string strPageTxt)
        {
            int tabCount = 0;
            tabCount = ctlTab.TabCount;

            TabPage Page = new TabPage();
            Page.Name = strPageTxt;
            Page.Text = strPageTxt;
            //Page.TabIndex = tabCount;

            Panel panLbl = new Panel();
            panLbl.Width = ctlTab.Width;
            panLbl.Height = 30;
            panLbl.Dock = DockStyle.Top;
            panLbl.BorderStyle = BorderStyle.FixedSingle;
            panLbl.BackColor = System.Drawing.Color.LightSkyBlue;
            AddLblToPanel(panLbl);
            Page.Controls.Add(panLbl);

            Panel panDgv = new Panel();
            panDgv.Dock = DockStyle.Fill;
            panDgv.BorderStyle = BorderStyle.FixedSingle;
            AddDgvToPanel(panDgv);
            Page.Controls.Add(panDgv);

            ctlTab.Controls.Add(Page);

            //for (int i=0;i< tabpageNumer;i++)
            //{
            //    TabPage Page = new TabPage();
            //    Page.Name = "Page" + i.ToString();
            //    Page.Text = "tabPage" + i.ToString();
            //    Page.TabIndex = i;
            //    ctlTab.Controls.Add(Page);
            //}

        }
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace R2R_UI.Common
{
    class AutoReSizeFormTest
    {
        static float SH
        {
            get
            {
                return (float)Screen.PrimaryScreen.Bounds.Height;
                //return (float)Screen.PrimaryScreen.Bounds.Height / Properties.Settings.Default.Y;
            }
        }
        static float SW
        {
            get
            {
                return (float)Screen.PrimaryScreen.Bounds.Width;
                //return (float)Screen.PrimaryScreen.Bounds.Width / Properties.Settings.Default.X;
            }
        }

        public static void SetFormSize(Control fm)
        {
            fm.Location = new Point((int)(fm.Location.X * SW), (int)(fm.Location.Y * SH));
            fm.Size = new Size((int)(fm.Size.Width * SW), (int)(fm.Size.Height * SH));
            fm.Font = new Font(fm.Font.Name, fm.Font.Size * SH, fm.Font.Style, fm.Font.Unit, fm.Font.GdiCharSet, fm.Font.GdiVerticalFont);
            if (fm.Controls.Count != 0)
            {
                SetControlSize(fm);
            }
        }


        private static void SetControlSize(Control InitC)
        {
            foreach (Control c in InitC.Controls)
            {
                c.Location = new Point((int)(c.Location.X * SW), (int)(c.Location.Y * SH));
                c.Size = new Size((int)(c.Size.Width * SW), (int)(c.Size.Height * SH));
                c.Font = new Font(c.Font.Name, c.Font.Size * SH, c.Font.Style, c.Font.Unit, c.Font.GdiCharSet, c.Font.GdiVerticalFont);
                if (c.Controls.Count != 0)
                {
                    SetControlSize(c);
                }
            }
        }

        //1.当两个电脑分辨率相同时，无法显示完全，请检查form的autoscalemode属性是否为none，并设为none
        //2.分辨率不同时，可直接在form的构造函数中调用初始化函数之后， 加上一句AutoReSizeForm.SetFormSize(this);(对于自定义控件usercontrol也适用)

    }
}

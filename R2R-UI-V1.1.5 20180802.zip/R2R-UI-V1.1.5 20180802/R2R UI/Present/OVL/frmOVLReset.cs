﻿using R2R_UI.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static R2R_UI.Common.UIServiceFun;

namespace R2R_UI.Present.OVL
{
    public partial class frmOVLReset : Form
    {
        #region
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x0014) // 禁掉清除背景消息
                return;
            base.WndProc(ref m);
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x02000000;
                return cp;
            }
        }

        private void CtlDoubleBuffer()
        {
            this.DoubleBuffered = true;//设置本窗体
            SetStyle(ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true); // 禁止擦除背景.
            SetStyle(ControlStyles.DoubleBuffer, true); // 双缓冲
            //SetStyle(ControlStyles.DoubleBuffer | ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint, true);
            UpdateStyles();
        }
        #endregion

        public frmOVLReset()
        {
            InitializeComponent();
        }
        public frmOVLReset(string strServiceName, string strCurrentUserName, string strCurrentPwd, string strCurrentController, List<string> strFrmListR2RContexts, string strFrmCurrentOVLModel, string strFrmCurrentR2RMode, structPH_OVL_GetResetValues structOVLResetData)
        {
            InitializeComponent();
            strServiceAddres = strServiceName;
            strUserName = strCurrentUserName;
            strPassword = strCurrentPwd;

            strController = strCurrentController;
            strListR2RContexts = new List<string>(strFrmListR2RContexts);
            strCurrentR2RMode = strFrmCurrentR2RMode;
            strCurrentOVLModel = strFrmCurrentOVLModel;

            structData = structOVLResetData;
            if (structOVLResetData.iListInputIndex.Count > 0)
            {
                dListInputMax = new List<double>(structOVLResetData.dListInputMax);
                dListInputMin = new List<double>(structOVLResetData.dListInputMin);
                dListInputValues = new List<double>(structOVLResetData.dListInputValues);
                iListInputIndex = new List<int>(structOVLResetData.iListInputIndex);
                strListInputNames = new List<string>(structOVLResetData.strListInputNames);
                strListChuckIds = new List<string>(structOVLResetData.strListChuckIds);
                strListOVLModels = new List<string>(structOVLResetData.strListOVLModels);
            }
        }

        #region Param
        string strServiceAddres;
        string strUserName;
        string strPassword;

        string strController;
        string strCurrentR2RMode;
        string strCurrentOVLModel;

        string strSelectOVLModel;
        List<string> strListOVLModel = new List<string>();
        List<string> strListR2RContexts = new List<string>();

        List<int> iListInputIndex = new List<int>();
        List<double> dListInputMax = new List<double>();
        List<double> dListInputMin = new List<double>();
        List<double> dListInputValues = new List<double>();
        List<string> strListChuckIds = new List<string>();
        List<string> strListInputNames = new List<string>();
        List<string> strListOVLModels = new List<string>();

        structPH_OVL_GetResetValues structData = new structPH_OVL_GetResetValues();

        List<int> iListInputIndexChange = new List<int>();
        List<double> dListInputMaxChange = new List<double>();
        List<double> dListInputMinChange = new List<double>();
        List<double> dListInputValuesChange = new List<double>();
        List<string> strListChuckIdsChange = new List<string>();
        List<string> strListInputNamesChange = new List<string>();
        List<string> strListOVLModelsChange = new List<string>();
        structPH_OVL_GetResetModel structResetValues = new structPH_OVL_GetResetModel();
        #endregion

        private void GetOVLModes()
        {
            strListOVLModel = BaseFun.GetGroupName(strListOVLModels);
            cmbOVLMode.DataSource = strListOVLModel;
        }
        private void InitOVLMode()
        {
            cmbOVLMode.SelectedIndex = 0;
            strSelectOVLModel = cmbOVLMode.Text;
        }

        private float frmLocationX;
        private float frmLocationY;
        //AdaptiveSizeResolution AutoSizeFrm = new AdaptiveSizeResolution();
        DataTable dbGetOVLResetGroup = new DataTable("OVLResetGroup");
        private void frmOVLReset_Load(object sender, EventArgs e)
        {
            #region 双缓冲
            DataGridViewHelp.DoubleBuffered(dgvSet, true);
            CtlDoubleBuffer();
            #endregion

            #region AdaptiveSizeResolution
            //AutoSizeFrm.ControllInitializeSize(this);
            #endregion

            #region  AdaptiveSize
            //this.Resize += new EventHandler(frmOVLReset_Resize);
            //frmLocationX = this.Width;
            //frmLocationY = this.Height;
            //AdaptiveSize.setTag(this);
            #endregion

            #region Set Lbl
            string strDgvLblContext = "List of context group";
            AddControlHelp.SetLable(panDgvLblContext, lblDgvContext, strDgvLblContext);
            #endregion

            #region Init Control
            GetOVLModes();
            InitOVLMode();
            #endregion

            #region
            dbGetOVLResetGroup = DataTableHelp.CreateLinearResetGroupTable(structData);

            //strSelectOVLModel = "LINEAR";

            DataTable dbOVLReset = new DataTable("OVLReset");
            dbOVLReset = DataTableHelp.CreateLinearResetTable(dbGetOVLResetGroup, strSelectOVLModel);
            DataGridViewHelp.InitDgvSet(dgvSet, dbOVLReset, 7);

            #endregion
        }

        private void frmOVLReset_Resize(object sender, EventArgs e)
        {
            #region AdaptiveSize
            //float newx = (this.Width) / frmLocationX;
            //float newy = this.Height / frmLocationY;
            //AdaptiveSize.setControls(newx, newy, this);
            #endregion
        }

        private void frmOVLReset_SizeChanged(object sender, EventArgs e)
        {
            #region AdaptiveSizeResolution
            //AutoSizeFrm.ControlAutoSize(this);
            #endregion
        }

        private void cmbOVLMode_SelectedIndexChanged(object sender, EventArgs e)
        {
            OVLModeChanged();
        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            OVLModeChanged();
        }

        private void ClearParam()
        {
            iListInputIndexChange.Clear();
            strListInputNamesChange.Clear();
            strListChuckIdsChange.Clear();
            strListOVLModelsChange.Clear();
            dListInputMaxChange.Clear();
            dListInputMinChange.Clear();
            dListInputValuesChange.Clear();
        }
        private void GetGridValue()
        {
            strSelectOVLModel = cmbOVLMode.Text;

            int rowCount = 0;
            rowCount = dgvSet.Rows.Count;
            if (rowCount > 0)
            {
                ClearParam();
                for (int i = 0; i < rowCount; i++)
                {
                    iListInputIndexChange.Add(int.Parse(dgvSet.Rows[i].Cells[0].Value.ToString()));
                    strListInputNamesChange.Add(dgvSet.Rows[i].Cells[1].Value.ToString());
                    strListChuckIdsChange.Add(dgvSet.Rows[i].Cells[2].Value.ToString());
                    //strListOVLModelsChange.Add(grdOVLReset.Rows[i].Cells[3].Value.ToString());
                    dListInputMaxChange.Add(double.Parse(dgvSet.Rows[i].Cells[4].Value.ToString()));
                    dListInputMinChange.Add(double.Parse(dgvSet.Rows[i].Cells[5].Value.ToString()));
                    dListInputValuesChange.Add(double.Parse(dgvSet.Rows[i].Cells[7].Value.ToString()));
                }
            }
            structResetValues.iListInputIndex = new List<int>(iListInputIndexChange);
            structResetValues.strListInputNames = new List<string>(strListInputNamesChange);
            structResetValues.strListChuckIds = new List<string>(strListChuckIdsChange);
            structResetValues.dListInputMax = new List<double>(dListInputMaxChange);
            structResetValues.dListInputMin = new List<double>(dListInputMinChange);
            structResetValues.dListInputValues = new List<double>(dListInputValuesChange);
            structResetValues.strOVLModel = strSelectOVLModel;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            frmCheckedPwd frmChecked = new frmCheckedPwd(strUserName);
            if (frmChecked.ShowDialog() == DialogResult.OK)
            {
                if (frmChecked.strPassword.Equals(strPassword))
                {
                    #region
                    bool bSuccess;
                    try
                    {
                        #region PH_OVL_ResetModel
                        GetGridValue();
                        if (structResetValues.dListInputValues.Count > 0)
                        {
                            bSuccess = R2R_UI_PH_OVL_ResetModel(strServiceAddres, strUserName, strController, strListR2RContexts, strCurrentOVLModel, strCurrentR2RMode, structResetValues);
                            if (bSuccess)
                            {
                                this.Close();
                            }
                            else
                            {
                                MessageBox.Show("Set Failed!");
                            }
                        }
                        this.DialogResult = DialogResult.OK;
                        #endregion
                    }
                    catch (Exception ee)
                    {
                        MessageBox.Show(ee.Message);
                    }
                    #endregion
                }
                else
                {
                    MessageBox.Show("Invalid password!");
                }
            }
            else
            {
                //MessageBox.Show("Invalid password!");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void OVLModeChanged()
        {
            //if (cmbOVLMode.Text == "")
            //{
            //    cmbOVLMode.SelectedIndex = 0;
            //}
            if (cmbOVLMode.Text.Equals(""))
            {
            }
            else
            {
                strSelectOVLModel = cmbOVLMode.Text;
                if (dbGetOVLResetGroup.Rows.Count > 0)
                {
                    DataTable dbOVLReset = new DataTable("OVLReset");
                    dbOVLReset = DataTableHelp.CreateLinearResetTable(dbGetOVLResetGroup, strSelectOVLModel);
                    DataGridViewHelp.InitDgvSet(dgvSet, dbOVLReset, 7);
                }
            }
        }

        #region Test DataGridView Event
        private void dgvSet_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            //DataGridViewHelp.dgv_CellFormatting(sender, e);
        }

        private void dgvSet_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            //DataGridViewHelp.dgv_CellPainting(sender,  e);
        }

        private void dgvSet_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            //DataGridViewHelp.dgv_RowPostPaint(sender, e);
        }
        #endregion
    }
}

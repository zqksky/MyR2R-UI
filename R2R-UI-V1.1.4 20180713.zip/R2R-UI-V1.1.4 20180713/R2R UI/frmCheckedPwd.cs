﻿using R2R_UI.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace R2R_UI
{
    public partial class frmCheckedPwd : Form
    {
        public frmCheckedPwd()
        {
            InitializeComponent();
        }
        public frmCheckedPwd(string strCurrentUserName)
        {
            InitializeComponent();
            strUserName = strCurrentUserName;
        }

        public string strUserName
        {
            get
            {
                return txtUserName.Text;
            }
            set
            {
                txtUserName.Text = value;
            }
        }

        public string strPassword
        {
            set
            {
                txtPwd.Text = value;
            }

            get
            {
                return txtPwd.Text;
            }
        }

        private float frmLocationX;
        private float frmLocationY;
        AdaptiveSizeResolution AutoSizeFrm = new AdaptiveSizeResolution();
        private void frmCheckedPwd_Load(object sender, EventArgs e)
        {
            #region AdaptiveSizeResolution
            //AutoSizeFrm.ControllInitializeSize(this);
            #endregion

            #region  AdaptiveSize
            //this.Resize += new EventHandler(frmCheckedPwd_Resize);
            //frmLocationX = this.Width;
            //frmLocationY = this.Height;
            //AdaptiveSize.setTag(this);
            #endregion
        }
        private void frmCheckedPwd_Resize(object sender, EventArgs e)
        {
            #region AdaptiveSize
            //float newx = (this.Width) / frmLocationX;
            //float newy = this.Height / frmLocationY;
            //AdaptiveSize.setControls(newx, newy, this);
            #endregion
        }

        private void frmCheckedPwd_SizeChanged(object sender, EventArgs e)
        {
            #region AdaptiveSizeResolution
            //AutoSizeFrm.ControlAutoSize(this);
            #endregion
        }

        private void btnConfrim_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtPwd.Text))
            {
                MessageBox.Show("Please input password!");
            }
            else
            {
                this.DialogResult = DialogResult.OK;
                //this.Close();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace R2R_UI.Common
{
    class RegexHelp
    {
        public static bool IsDoubleValue(string str)
        {
            //double dValue;
            //double.TryParse(str, out dValue); //如果返回True 说明是double 否则不是double 型

            bool bFlag = Regex.IsMatch(str, @"^[+-]?\d*[.]?\d*$");  //如果string字符串可以转换为double，则返回True，反之为False。
            return bFlag;
        }

        public static bool IsIntValue(string str)
        {
            bool bFlag = Regex.IsMatch(str, @"^[+-]?\d*$");  //如果string字符串可以转换为int，则返回true，反之为false。
            return bFlag;
        }
    }
}

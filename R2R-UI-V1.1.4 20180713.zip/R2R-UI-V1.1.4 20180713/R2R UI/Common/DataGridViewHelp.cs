﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace R2R_UI.Common
{
    class DataGridViewHelp
    {
        public static void InitDgvGrid(DataGridView ctlDgv, DataTable tb)
        {
            ctlDgv.DataSource = tb;

            //禁止编辑
            ctlDgv.ReadOnly = true;
        }

        public static void InitDgvSet(DataGridView ctlDgv, DataTable tb)
        {
            ctlDgv.DataSource = tb;

            //禁止编辑
            //ctlDgv.ReadOnly = true;
            ctlDgv.ReadOnly = false;
            ctlDgv.EditMode = DataGridViewEditMode.EditOnEnter;

            // 设置边框样式（上边框）,枚举：双线内陷边框
            ctlDgv.AdvancedCellBorderStyle.Top = DataGridViewAdvancedCellBorderStyle.InsetDouble;

            //边框线 颜色
            ctlDgv.GridColor = Color.SeaGreen; 

        }

        public static void InitDgvSet(DataGridView ctlDgv, DataTable tb,int colCount)
        {
            ctlDgv.DataSource = tb;

            //禁止编辑
            //ctlDgv.ReadOnly = true;
            ctlDgv.ReadOnly = false;
            ctlDgv.EditMode = DataGridViewEditMode.EditOnEnter;
            for (int i = 0; i < colCount; i++)
            {
                ctlDgv.Columns[i].ReadOnly = true;
            }

        }

        public static void InitDgvSet(DataGridView ctlDgv, DataTable tb, List<int> colListCount)
        {
            ctlDgv.DataSource = tb;

            //禁止编辑
            //ctlDgv.ReadOnly = true;
            ctlDgv.ReadOnly = false;
            for (int i = 0; i < colListCount.Count; i++)
            {
                ctlDgv.Columns[colListCount[i]].ReadOnly = true;
            }
            ctlDgv.EditMode = DataGridViewEditMode.EditOnEnter;
        }

        //自动排序功能禁用
        public static void dgvSortModeSet(DataGridView dgv)
        {
            for (int i = 0; i < dgv.Columns.Count; i++)
            {
                dgv.Columns[i].SortMode = DataGridViewColumnSortMode.NotSortable;
            }
        }

        public static void dgvAttributeSet(DataGridView dgv)
        {
            //1.禁用最后一行空白。
            dgv.AllowUserToAddRows = false;

            //2.禁用‘delete'键的删除功能。默认情况，鼠标选中一整行，按 删除键 可以删除当前一整行
            dgv.AllowUserToDeleteRows = false;

            //上述禁用，仅是将用户界面交互的自动新增行禁了，但还是可以通过代码来删除指定行数据。：
            //dgv.Rows.Remove(DataGridViewRow dataGridViewRow);             
            //dgv.Rows.RemoveAt(int index);

            //6.禁用单元格编辑功能
            dgv.ReadOnly = true;
            // 设置 DataGridView1 的第2列整列单元格为只读 
            dgv.Columns[1].ReadOnly = true;

            // 第一列自动调整 
            dgv.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;

            // 7.点击选中整行、整列
            dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;// 单击选中整行，枚举

            //8.禁用多行 / 多列 / 多单元格选择
            dgv.MultiSelect = false;

            //9.设置表格网格线颜色等样式
            dgv.AdvancedCellBorderStyle.Top = DataGridViewAdvancedCellBorderStyle.InsetDouble;

            // 设置边框样式（上边框）,枚举：双线内陷边框
            dgv.GridColor = Color.SeaGreen; //边框线 颜色

            //设置列标题不换行
            dgv.ColumnHeadersDefaultCellStyle.WrapMode = DataGridViewTriState.False;  

            // 设定包括Header和所有单元格的列宽自动调整
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dgv.ColumnHeadersDefaultCellStyle.WrapMode = DataGridViewTriState.False;  //设置列标题不换行
                                                                                      // 设定不包括Header所有单元格的行高自动调整
            dgv.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;  //AllCells;设定包括Header和所有单元格的行高自动调整

        }

        //DataGridView减少闪烁的解决办法 
        public static void DoubleBuffered(DataGridView dgv, bool bSet)
        {
            Type dgvType = dgv.GetType();
            PropertyInfo pi = dgvType.GetProperty("DoubleBuffered", BindingFlags.Instance | BindingFlags.NonPublic);
            pi.SetValue(dgv, bSet, null);
        }


        /// <summary> 
        /// IBindingListView接口（如BindingSource类） 
        /// </summary> 
        /// <returns></returns> 
        private BindingSource DataBindingByBindingSource(List<string> strList)
        {
            Dictionary<string, string> dic = new Dictionary<string, string>();
            for (int i = 0; i < 10; i++)
            {
                dic.Add(i.ToString(), i.ToString() + "_Dictionary");
            }

            return new BindingSource(dic, null);
        }

        //自动行序号
        public static void dgv_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            if (e.ColumnIndex < 0 && e.RowIndex >= 0) // 绘制 自动序号
            {
                e.Paint(e.ClipBounds, DataGridViewPaintParts.All);
                Rectangle vRect = e.CellBounds;
                vRect.Inflate(-2, 2);
                TextRenderer.DrawText(e.Graphics, (e.RowIndex + 1).ToString(), e.CellStyle.Font, vRect, e.CellStyle.ForeColor, TextFormatFlags.Right | TextFormatFlags.VerticalCenter);
                e.Handled = true;
            }

            // ----- 其它样式设置 -------
            if (e.RowIndex % 2 == 0)
            { // 行序号为双数（含0）时 
                e.CellStyle.BackColor = Color.White;
            }
            else
            {
                e.CellStyle.BackColor = Color.Honeydew;
            }
            e.CellStyle.SelectionBackColor = Color.Gray; // 选中单元格时，背景色
            e.CellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter; //单位格内数据对齐方式
        }
    }
}

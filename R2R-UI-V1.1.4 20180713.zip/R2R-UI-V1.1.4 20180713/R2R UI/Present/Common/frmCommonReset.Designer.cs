﻿namespace R2R_UI.Present.Common
{
    partial class frmCommonReset
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panBtnOk = new System.Windows.Forms.Panel();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOk = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panDgv = new System.Windows.Forms.Panel();
            this.dgvContext = new System.Windows.Forms.DataGridView();
            this.panDgvLbl = new System.Windows.Forms.Panel();
            this.lblDgv = new System.Windows.Forms.Label();
            this.panLbl = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdoPM = new System.Windows.Forms.RadioButton();
            this.rdoReset = new System.Windows.Forms.RadioButton();
            this.panel1.SuspendLayout();
            this.panBtnOk.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panDgv.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvContext)).BeginInit();
            this.panDgvLbl.SuspendLayout();
            this.panLbl.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panBtnOk);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panLbl);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(810, 405);
            this.panel1.TabIndex = 1;
            // 
            // panBtnOk
            // 
            this.panBtnOk.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panBtnOk.Controls.Add(this.btnCancel);
            this.panBtnOk.Controls.Add(this.btnOk);
            this.panBtnOk.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panBtnOk.Location = new System.Drawing.Point(0, 366);
            this.panBtnOk.Name = "panBtnOk";
            this.panBtnOk.Size = new System.Drawing.Size(810, 39);
            this.panBtnOk.TabIndex = 11;
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.Location = new System.Drawing.Point(700, 4);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(73, 23);
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOk
            // 
            this.btnOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOk.Location = new System.Drawing.Point(582, 4);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(73, 23);
            this.btnOk.TabIndex = 0;
            this.btnOk.Text = "Ok";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.panDgv);
            this.panel3.Controls.Add(this.panDgvLbl);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 45);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(810, 360);
            this.panel3.TabIndex = 10;
            // 
            // panDgv
            // 
            this.panDgv.Controls.Add(this.dgvContext);
            this.panDgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panDgv.Location = new System.Drawing.Point(0, 26);
            this.panDgv.Name = "panDgv";
            this.panDgv.Size = new System.Drawing.Size(810, 334);
            this.panDgv.TabIndex = 3;
            // 
            // dgvContext
            // 
            this.dgvContext.AllowUserToAddRows = false;
            this.dgvContext.AllowUserToDeleteRows = false;
            this.dgvContext.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvContext.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvContext.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvContext.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvContext.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvContext.Location = new System.Drawing.Point(0, 0);
            this.dgvContext.Name = "dgvContext";
            this.dgvContext.Size = new System.Drawing.Size(810, 334);
            this.dgvContext.TabIndex = 0;
            // 
            // panDgvLbl
            // 
            this.panDgvLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panDgvLbl.Controls.Add(this.lblDgv);
            this.panDgvLbl.Dock = System.Windows.Forms.DockStyle.Top;
            this.panDgvLbl.Location = new System.Drawing.Point(0, 0);
            this.panDgvLbl.Name = "panDgvLbl";
            this.panDgvLbl.Size = new System.Drawing.Size(810, 26);
            this.panDgvLbl.TabIndex = 2;
            // 
            // lblDgv
            // 
            this.lblDgv.AutoSize = true;
            this.lblDgv.Location = new System.Drawing.Point(325, 3);
            this.lblDgv.Name = "lblDgv";
            this.lblDgv.Size = new System.Drawing.Size(103, 13);
            this.lblDgv.TabIndex = 0;
            this.lblDgv.Text = "List of context group";
            // 
            // panLbl
            // 
            this.panLbl.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panLbl.Controls.Add(this.groupBox1);
            this.panLbl.Dock = System.Windows.Forms.DockStyle.Top;
            this.panLbl.Location = new System.Drawing.Point(0, 0);
            this.panLbl.Name = "panLbl";
            this.panLbl.Size = new System.Drawing.Size(810, 45);
            this.panLbl.TabIndex = 8;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdoPM);
            this.groupBox1.Controls.Add(this.rdoReset);
            this.groupBox1.Location = new System.Drawing.Point(300, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(165, 36);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            // 
            // rdoPM
            // 
            this.rdoPM.AutoSize = true;
            this.rdoPM.Location = new System.Drawing.Point(18, 13);
            this.rdoPM.Name = "rdoPM";
            this.rdoPM.Size = new System.Drawing.Size(41, 17);
            this.rdoPM.TabIndex = 15;
            this.rdoPM.Text = "PM";
            this.rdoPM.UseVisualStyleBackColor = true;
            this.rdoPM.CheckedChanged += new System.EventHandler(this.rdoType_CheckedChanged);
            // 
            // rdoReset
            // 
            this.rdoReset.AutoSize = true;
            this.rdoReset.Location = new System.Drawing.Point(100, 13);
            this.rdoReset.Name = "rdoReset";
            this.rdoReset.Size = new System.Drawing.Size(53, 17);
            this.rdoReset.TabIndex = 16;
            this.rdoReset.Text = "Reset";
            this.rdoReset.UseVisualStyleBackColor = true;
            this.rdoReset.CheckedChanged += new System.EventHandler(this.rdoType_CheckedChanged);
            // 
            // frmCommonReset
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(810, 405);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.Name = "frmCommonReset";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CommonReset";
            this.Load += new System.EventHandler(this.frmCommonReset_Load);
            this.SizeChanged += new System.EventHandler(this.frmCommonReset_SizeChanged);
            this.Resize += new System.EventHandler(this.frmCommonReset_Resize);
            this.panel1.ResumeLayout(false);
            this.panBtnOk.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panDgv.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvContext)).EndInit();
            this.panDgvLbl.ResumeLayout(false);
            this.panDgvLbl.PerformLayout();
            this.panLbl.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panLbl;
        private System.Windows.Forms.RadioButton rdoReset;
        private System.Windows.Forms.RadioButton rdoPM;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panDgv;
        private System.Windows.Forms.DataGridView dgvContext;
        private System.Windows.Forms.Panel panDgvLbl;
        private System.Windows.Forms.Label lblDgv;
        private System.Windows.Forms.Panel panBtnOk;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}
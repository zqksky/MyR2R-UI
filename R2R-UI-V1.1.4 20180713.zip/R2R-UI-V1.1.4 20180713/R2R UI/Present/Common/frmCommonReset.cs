﻿using R2R_UI.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace R2R_UI.Present.Common
{
    public partial class frmCommonReset : Form
    {
        public frmCommonReset()
        {
            InitializeComponent();
        }
        public frmCommonReset(string strServiceName, string strCurrentUserName, string strCurrentPwd, string strFrmController, string strFrmGroup, List<string> strListFrmR2RContexts, UIServiceFun.structCOMMON_GetInputResetSettings structDataSetting)
        {
            InitializeComponent();
            strServiceAddress = strServiceName;
            strUserName = strCurrentUserName;
            strPassword = strCurrentPwd;

            strGroup = strFrmGroup;
            strCurrentController = strFrmController;
            strListR2RContexts = new List<string>(strListFrmR2RContexts);
            structData = structDataSetting;
            iListInputIndex = structDataSetting.iListInputIndex;
            dListInputMax = structDataSetting.dListInputMax;
            dListInputMin = structDataSetting.dListInputMin;
            dListInputPMValues = structDataSetting.dListInputPMValues;
            dListInputResetValues = structDataSetting.dListInputResetValues;
            strListInputParameterNames = structDataSetting.strListInputParameterNames;
        }

        #region Param
        bool bIsPM = true;
        bool bIsReset = false;

        string strGroup = "";
        string strCurrentController;
        string strServiceAddress;
        string strUserName;
        string strPassword;

        List<int> iListInputIndex;
        List<double> dListInputMax;
        List<double> dListInputMin;
        List<double> dListInputPMValues;
        List<double> dListInputResetValues;
        List<string> strListInputParameterNames;
        List<string> strListR2RContexts = new List<string>();

        List<int> iRowChangeIndex = new List<int>();
        List<int> iListInputIndexChange = new List<int>();
        List<double> dListInputMaxChange = new List<double>();
        List<double> dListInputMinChange = new List<double>();
        List<double> dListInputPMValuesChange = new List<double>();
        List<double> dListInputResetValuesChange = new List<double>();
        List<string> strListInputParameterNamesChange = new List<string>();

        UIServiceFun.structCOMMON_GetInputResetSettings structData = new UIServiceFun.structCOMMON_GetInputResetSettings();
        UIServiceFun.structCOMMON_UpdateInputResetSettings structDataUpdate = new UIServiceFun.structCOMMON_UpdateInputResetSettings();
        #endregion

        private float frmLocationX;
        private float frmLocationY;
        AdaptiveSizeResolution AutoSizeFrm = new AdaptiveSizeResolution();
        private void frmCommonReset_Load(object sender, EventArgs e)
        {
            #region AdaptiveSizeResolution
            //AutoSizeFrm.ControllInitializeSize(this);
            #endregion

            #region  AdaptiveSize
            //this.Resize += new EventHandler(frmCommonReset_Resize);
            //frmLocationX = this.Width;
            //frmLocationY = this.Height;
            //AdaptiveSize.setTag(this);
            #endregion

            #region
            rdoPM.Checked = true;
            DataGridViewHelp.InitDgvGrid(dgvContext, DataTableHelp.CreateCommonResetTable(structData, bIsPM));
            #endregion
        }

        private void frmCommonReset_Resize(object sender, EventArgs e)
        {
            #region AdaptiveSize
            //float newx = (this.Width) / frmLocationX;
            //float newy = this.Height / frmLocationY;
            //AdaptiveSize.setControls(newx, newy, this);
            #endregion
        }

        private void frmCommonReset_SizeChanged(object sender, EventArgs e)
        {
            #region AdaptiveSizeResolution
            //AutoSizeFrm.ControlAutoSize(this);
            #endregion
        }

        private void rdoType_CheckedChanged(object sender, EventArgs e)
        {
            List<double> dListInputValues = new List<double>();
            if (rdoPM.Checked)
            {
                bIsPM = true;
                bIsReset = false;
                dListInputValues = new List<double>(dListInputPMValues);
            }
            else if (rdoReset.Checked)
            {
                bIsPM = false;
                bIsReset = true;
                dListInputValues = new List<double>(dListInputResetValues);
            }
            //for (int i = 0; i < ctlNewTxtControl.Count; i++)
            //{
            //    ctlNewTxtControl[i].Text = dListInputValues[i].ToString();
            //}
            structDataUpdate.bIsPM = bIsPM;
            structDataUpdate.bIsReset = bIsReset;
            DataGridViewHelp.InitDgvGrid(dgvContext, DataTableHelp.CreateCommonResetTable(structData, bIsPM));
        }
        private void GetCellValue()
        {
            //List<double> dListInputValues = new List<double>();
            if (dgvContext.Rows.Count > 0)
            {
                if (rdoPM.Checked)
                {
                    bIsPM = true;
                    bIsReset = false;
                    dListInputPMValues.Clear();
                    for (int i = 0; i < dgvContext.Rows.Count; i++)
                    {
                        dListInputPMValues.Add(double.Parse(dgvContext.Rows[i].Cells[4].Value.ToString()));
                    }
                }
                else if (rdoReset.Checked)
                {
                    bIsPM = false;
                    bIsReset = true;
                    dListInputResetValues.Clear();
                    for (int i = 0; i < dgvContext.Rows.Count; i++)
                    {
                        dListInputResetValues.Add(double.Parse(dgvContext.Rows[i].Cells[4].Value.ToString()));
                    }
                }
            }
        }

        private bool IsCellValueChange(string strInputValue, int rowIndex, int colIndex)
        {
            bool flagValueChange = false;

            if (rdoPM.Checked)
            {
                flagValueChange = strInputValue != dListInputPMValues[rowIndex].ToString() ? true : false;
            }
            else if (rdoReset.Checked)
            {
                flagValueChange = strInputValue != dListInputResetValues[rowIndex].ToString() ? true : false;
            }
            return flagValueChange;
        }
        private void btnOk_Click(object sender, EventArgs e)
        {
            frmCheckedPwd frmChecked = new frmCheckedPwd(strUserName);
            if (frmChecked.ShowDialog() == DialogResult.OK)
            {
                if (frmChecked.strPassword.Equals(strPassword))
                {
                    #region
                    bool bSuccess;
                    try
                    {
                        //textValueChanged();
                        GetCellValue();
                        #region R2R_UI_COMMON_UpdateInputResetSettings
                        structDataUpdate.bIsPM = bIsPM;
                        structDataUpdate.bIsReset = bIsReset;
                        structDataUpdate.iListInputIndex = new List<int>(iListInputIndexChange);
                        structDataUpdate.dListInputMax = new List<double>(dListInputMaxChange);
                        structDataUpdate.dListInputMin = new List<double>(dListInputMinChange);
                        structDataUpdate.dListInputPMValues = new List<double>(dListInputPMValuesChange);
                        structDataUpdate.dListInputResetValues = new List<double>(dListInputResetValuesChange);

                        bSuccess = UIServiceFun.R2R_UI_COMMON_UpdateInputResetSettings(strServiceAddress, strUserName, strCurrentController, strGroup, strListR2RContexts, structDataUpdate);

                        if (bSuccess)
                        {
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Set Failed!");
                        }
                        this.DialogResult = DialogResult.OK;
                        #endregion
                    }
                    catch (Exception ee)
                    {
                        MessageBox.Show(ee.Message);
                    }
                    #endregion
                }
                else
                {
                    MessageBox.Show("Invalid password!");
                }
            }
            else
            {
                //MessageBox.Show("Invalid password!");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}

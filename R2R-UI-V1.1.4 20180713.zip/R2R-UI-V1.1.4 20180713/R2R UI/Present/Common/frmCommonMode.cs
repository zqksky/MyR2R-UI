﻿using R2R_UI.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace R2R_UI.Present.Common
{
    public partial class frmCommonMode : Form
    {
        public frmCommonMode()
        {
            InitializeComponent();
        }
        public frmCommonMode(string strServiceName, string strCurrentUserName, string strCurrentPwd, string strFrmController, string strFrmGroup, List<string> strListFrmR2RContexts, UIServiceFun.structCOMMON_GetInputSettings structDataSetting)
        {
            InitializeComponent();
            strServiceAddress = strServiceName;
            strUserName = strCurrentUserName;
            strPassword = strCurrentPwd;

            strGroup = strFrmGroup;
            strCurrentController = strFrmController;
            strListR2RContexts = new List<string>(strListFrmR2RContexts);
            structData = structDataSetting;
            strR2RMode = structDataSetting.strR2RMode;
            strInitR2RMode = structDataSetting.strR2RMode;
            iListInputIndex = structDataSetting.iListInputIndex;
            dListInputMax = structDataSetting.dListInputMax;
            dListInputMin = structDataSetting.dListInputMin;
            dListInputFixedValues = structDataSetting.dListInputFixedValues;
            dListInputCurrentValues = structDataSetting.dListInputCurrentValues;
            strListInputParameterNames = structDataSetting.strListInputParameterNames;
        }

        #region Param
        string strGroup = "";
        string strCurrentController;
        string strServiceAddress;
        string strUserName;
        string strPassword;

        bool bModeChanged = false;
        string strInitR2RMode;
        string strR2RMode;
        List<int> iListInputIndex;
        List<double> dListInputMax;
        List<double> dListInputMin;
        List<double> dListInputFixedValues;
        List<double> dListInputCurrentValues;
        List<string> strListInputParameterNames = new List<string>();
        List<string> strListR2RContexts = new List<string>();

        UIServiceFun.structCOMMON_GetInputSettings structData = new UIServiceFun.structCOMMON_GetInputSettings();

        List<string> strListNew = new List<string>();
        List<string> strListCurrent = new List<string>();

        string strR2RModeChange;
        List<int> iRowChangeIndex = new List<int>();
        List<int> iListInputIndexChange = new List<int>();
        List<double> dListInputMaxChange = new List<double>();
        List<double> dListInputMinChange = new List<double>();
        List<double> dListInputNewValues = new List<double>();
        List<string> strListInputParameterNamesChange = new List<string>();
        UIServiceFun.structCOMMON_UpdateInputSettings structDataUpdate = new UIServiceFun.structCOMMON_UpdateInputSettings();

        #endregion

        private void ClearList()
        {
            iRowChangeIndex.Clear();
            iListInputIndexChange.Clear();
            dListInputMaxChange.Clear();
            dListInputMinChange.Clear();
            dListInputNewValues.Clear();
            strListInputParameterNamesChange.Clear();
        }
        private void InitControl()
        {
            btnOk.Enabled = false;
        }
        private void InitR2RMode()
        {
            if (strR2RMode.Equals("Active"))
            {
                rdoActive.Checked = true;
            }
            else if (strR2RMode.Equals("Passive"))
            {
                rdoPassive.Checked = true;
            }
            else
            {
                rdoFixed.Checked = true;
            }
        }
        private void InitGrid(DataGridView ctlDgv, DataTable tb)
        {
            ctlDgv.DataSource = tb;

            //禁止编辑
            if (ctlDgv.ColumnCount > 5)
            {
                //禁止编辑
                //ctlDgv.ReadOnly = true;
                ctlDgv.Columns[0].ReadOnly = true;
                ctlDgv.Columns[1].ReadOnly = true;
                ctlDgv.Columns[2].ReadOnly = true;
                ctlDgv.Columns[3].ReadOnly = true;
                ctlDgv.Columns[4].ReadOnly = true;

                if (bModeChanged)
                {
                    ctlDgv.Columns[5].ReadOnly = false;
                }
                else
                {
                    ctlDgv.Columns[5].ReadOnly = true;
                }
            }
        }

        private float frmLocationX;
        private float frmLocationY;
        AdaptiveSizeResolution AutoSizeFrm = new AdaptiveSizeResolution();
        private void frmCommonMode_Load(object sender, EventArgs e)
        {
            #region AdaptiveSizeResolution
            //AutoSizeFrm.ControllInitializeSize(this);
            #endregion

            #region  AdaptiveSize
            //this.Resize += new EventHandler(frmCommonMode_Resize);
            //frmLocationX = this.Width;
            //frmLocationY = this.Height;
            //AdaptiveSize.setTag(this);
            #endregion

            #region
            InitControl();
            InitR2RMode();
            InitGrid(dgvContext, DataTableHelp.CreateCommonModeTable(structData));
            //DataGridViewHelp.InitDgvGrid(dgvContext, DataTableHelp.CreateCommonModeTable(structData));
            #endregion
        }

        private void frmCommonMode_Resize(object sender, EventArgs e)
        {
            #region AdaptiveSize
            //float newx = (this.Width) / frmLocationX;
            //float newy = this.Height / frmLocationY;
            //AdaptiveSize.setControls(newx, newy, this);
            #endregion
        }

        private void frmCommonMode_SizeChanged(object sender, EventArgs e)
        {
            #region AdaptiveSizeResolution
            //AutoSizeFrm.ControlAutoSize(this);
            #endregion
        }

        private void rdoType_CheckedChanged(object sender, EventArgs e)
        {
            bModeChanged = true;
            btnOk.Enabled = true;

            if (rdoActive.Checked)
            {
                strR2RMode = "Active";
            }
            else if (rdoPassive.Checked)
            {
                strR2RMode = "Passive";
            }
            else if (rdoFixed.Checked)
            {
                strR2RMode = "Fixed";
            }
            strR2RModeChange = strR2RMode;

            if (strInitR2RMode.Equals(strR2RMode))
            {
                bModeChanged = false;
                InitControl();
            }
            structData.strR2RMode = strR2RMode;
            InitGrid(dgvContext, DataTableHelp.CreateCommonModeTable(structData));
            //DataGridViewHelp.InitDgvGrid(dgvContext, DataTableHelp.CreateCommonModeTable(structData));
        }

        private void GetGridValue()
        {
            if (dgvContext.Rows.Count > 0)
            {
                for (int i = 0; i < 3; i++)
                {
                    iListInputIndexChange.Add(structData.iListInputIndex[i]);
                    //strListInputParameterNamesChange.Add(grdCommonMode.Rows[i].Cells[0].Value.ToString());
                    dListInputMaxChange.Add(double.Parse(dgvContext.Rows[i].Cells[1].Value.ToString()));
                    dListInputMinChange.Add(double.Parse(dgvContext.Rows[i].Cells[2].Value.ToString()));
                    dListInputNewValues.Add(double.Parse(dgvContext.Rows[i].Cells[5].Value.ToString()));
                }

                structDataUpdate.strR2RMode = strR2RMode;
                //structDataUpdate.strListInputParameterNames= new List<string>(strListInputParameterNamesChange);
                structDataUpdate.iListInputIndex = new List<int>(iListInputIndexChange);
                structDataUpdate.dListInputMax = new List<double>(dListInputMaxChange);
                structDataUpdate.dListInputMin = new List<double>(dListInputMinChange);
                structDataUpdate.dListInputNewValues = new List<double>(dListInputNewValues);
            }
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            frmCheckedPwd frmChecked = new frmCheckedPwd(strUserName);
            if (frmChecked.ShowDialog() == DialogResult.OK)
            {
                if (frmChecked.strPassword.Equals(strPassword))
                {
                    #region
                    bool bSuccess;
                    try
                    {
                        #region R2R_UI_COMMON_UpdateInputResetSettings
                        //CellValueChange(iRowChangeIndex);
                        GetGridValue();

                        bSuccess = UIServiceFun.R2R_UI_COMMON_UpdateInputSettings(strServiceAddress, strUserName, strCurrentController, strGroup, strListR2RContexts, structDataUpdate);

                        if (bSuccess)
                        {
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Set Failed!");
                        }
                        this.DialogResult = DialogResult.OK;
                        #endregion
                    }
                    catch (Exception ee)
                    {
                        MessageBox.Show(ee.Message);
                    }
                    #endregion
                }
                else
                {
                    MessageBox.Show("Invalid password!");
                }
            }
            else
            {
                //MessageBox.Show("Invalid password!");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}

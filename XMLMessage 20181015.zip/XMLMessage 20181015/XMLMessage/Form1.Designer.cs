﻿namespace XMLMessage
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panTvw = new System.Windows.Forms.Panel();
            this.tvwMain = new System.Windows.Forms.TreeView();
            this.imagListTreeView = new System.Windows.Forms.ImageList(this.components);
            this.panXML = new System.Windows.Forms.Panel();
            this.rtxtXml = new System.Windows.Forms.RichTextBox();
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.button1 = new System.Windows.Forms.Button();
            this.panTvw.SuspendLayout();
            this.panXML.SuspendLayout();
            this.SuspendLayout();
            // 
            // panTvw
            // 
            this.panTvw.Controls.Add(this.tvwMain);
            this.panTvw.Dock = System.Windows.Forms.DockStyle.Left;
            this.panTvw.Location = new System.Drawing.Point(0, 0);
            this.panTvw.Name = "panTvw";
            this.panTvw.Size = new System.Drawing.Size(400, 584);
            this.panTvw.TabIndex = 0;
            // 
            // tvwMain
            // 
            this.tvwMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tvwMain.ImageIndex = 0;
            this.tvwMain.ImageList = this.imagListTreeView;
            this.tvwMain.Location = new System.Drawing.Point(0, 0);
            this.tvwMain.Name = "tvwMain";
            this.tvwMain.SelectedImageIndex = 0;
            this.tvwMain.Size = new System.Drawing.Size(400, 584);
            this.tvwMain.TabIndex = 0;
            this.tvwMain.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.tvwMain_AfterSelect);
            // 
            // imagListTreeView
            // 
            this.imagListTreeView.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imagListTreeView.ImageStream")));
            this.imagListTreeView.TransparentColor = System.Drawing.Color.Transparent;
            this.imagListTreeView.Images.SetKeyName(0, "dir.PNG");
            this.imagListTreeView.Images.SetKeyName(1, "file.png");
            this.imagListTreeView.Images.SetKeyName(2, "folder_vertical_document.png");
            this.imagListTreeView.Images.SetKeyName(3, "folder_vertical_open.png");
            // 
            // panXML
            // 
            this.panXML.Controls.Add(this.button1);
            this.panXML.Controls.Add(this.webBrowser1);
            this.panXML.Controls.Add(this.rtxtXml);
            this.panXML.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panXML.Location = new System.Drawing.Point(400, 0);
            this.panXML.Name = "panXML";
            this.panXML.Size = new System.Drawing.Size(670, 584);
            this.panXML.TabIndex = 1;
            // 
            // rtxtXml
            // 
            this.rtxtXml.Dock = System.Windows.Forms.DockStyle.Top;
            this.rtxtXml.Location = new System.Drawing.Point(0, 0);
            this.rtxtXml.Name = "rtxtXml";
            this.rtxtXml.Size = new System.Drawing.Size(670, 242);
            this.rtxtXml.TabIndex = 0;
            this.rtxtXml.Text = "";
            // 
            // webBrowser1
            // 
            this.webBrowser1.Location = new System.Drawing.Point(6, 248);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(535, 333);
            this.webBrowser1.TabIndex = 1;
            this.webBrowser1.Navigated += new System.Windows.Forms.WebBrowserNavigatedEventHandler(this.webBrowser1_Navigated);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(572, 391);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1070, 584);
            this.Controls.Add(this.panXML);
            this.Controls.Add(this.panTvw);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmMain";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panTvw.ResumeLayout(false);
            this.panXML.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panTvw;
        private System.Windows.Forms.Panel panXML;
        private System.Windows.Forms.TreeView tvwMain;
        private System.Windows.Forms.RichTextBox rtxtXml;
        private System.Windows.Forms.ImageList imagListTreeView;
        private System.Windows.Forms.WebBrowser webBrowser1;
        private System.Windows.Forms.Button button1;
    }
}


﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace XMLMessage.BaseFun
{
    class TreeviewHelp
    {
        public static TreeNode AddFirstNode(TreeView tvw, string strRootNode, List<string> strList)
        {
            List<TreeNode> strListTreeNode = new List<TreeNode>();
            foreach (var str in strList)
            {
                TreeNode treeNodeTmp = new TreeNode(str);
                treeNodeTmp.Text = str;
                treeNodeTmp.Name = str;
                strListTreeNode.Add(treeNodeTmp);
            }
            TreeNode treeNode = new TreeNode(strRootNode, strListTreeNode.ToArray());
            treeNode.Text = strRootNode;
            treeNode.Name = strRootNode;
            tvw.Nodes.Add(treeNode);
            return treeNode;
        }

        public static TreeNode GetTreeNode(string strRootNode, List<string> strList)
        {
            List<TreeNode> strListTreeNode = new List<TreeNode>();
            foreach (var str in strList)
            {
                TreeNode treeNodeTmp = new TreeNode(str);
                treeNodeTmp.Text = str;
                treeNodeTmp.Name = str;
                strListTreeNode.Add(treeNodeTmp);
            }
            TreeNode treeNode = new TreeNode(strRootNode, strListTreeNode.ToArray());
            treeNode.Text = strRootNode;
            treeNode.Name = strRootNode;
            return treeNode;
        }

        public static void AddSonTreeNode(TreeNode treeNode, List<string> strList)
        {
            List<TreeNode> strListTreeNode = new List<TreeNode>();
            foreach (var str in strList)
            {
                TreeNode treeNodeTmp = new TreeNode(str);
                treeNodeTmp.Text = str;
                treeNodeTmp.Name = str;
                treeNodeTmp.ImageIndex = 1;
                treeNodeTmp.SelectedImageIndex = 1;
                strListTreeNode.Add(treeNodeTmp);
                treeNode.Nodes.Add(treeNodeTmp);
            }
        }

        //添加根节点
        public static void AddRootNode(TreeView tvw, string rootNodeName)
        {
            //要添加的节点名称为空，即文本框是否为空
            if (string.IsNullOrEmpty(rootNodeName))
            {
                MessageBox.Show("要添加的节点名称不能为空！");
                return;
            }
            //添加根节点
            TreeNode rootNode = new TreeNode();
            rootNode.Tag = 1;//把自己的id存放在该节点tag对象里
            rootNode.Name = rootNodeName;
            rootNode.Text = rootNodeName;
            tvw.Nodes.Add(rootNode);
        }

        private void AddTreeviewNodeTest(TreeView tvw)
        {
            TreeNode treeNode11 = new TreeNode("节点11");
            TreeNode treeNode12 = new TreeNode("节点12");
            TreeNode treeNode13 = new TreeNode("节点13");
            TreeNode treeNode1 = new TreeNode("节点1", new TreeNode[] { treeNode11, treeNode12, treeNode13 });

            TreeNode treeNode21 = new TreeNode("节点21");
            TreeNode treeNode22 = new TreeNode("节点22");
            TreeNode treeNode23 = new TreeNode("节点23");
            TreeNode treeNode2 = new TreeNode("节点2", new TreeNode[] { treeNode21, treeNode22, treeNode23 });

            TreeNode treeNode31 = new TreeNode("节点31");
            TreeNode treeNode32 = new TreeNode("节点32");
            TreeNode treeNode33 = new TreeNode("节点33");
            TreeNode treeNode3 = new TreeNode("节点3", new TreeNode[] { treeNode31, treeNode32, treeNode33 });

            TreeNode rootNode = new TreeNode("节点", new TreeNode[] { treeNode1, treeNode2, treeNode3 });

            tvw.Nodes.Add(rootNode);
            tvw.Nodes[treeNode1.Name].Nodes.Add(rootNode);
        }

        private void tvw_AfterSelect(object sender, TreeViewEventArgs e)
        {
            var tvw = sender as TreeView;
            //TreeView tvw = (TreeView)sender;

            //rtxtXml.Text = "";
            if (e.Node.Text.ToString().Contains(".xml"))
            {
                string strXmlFolderPath = @"C:\YMTC\XMLMessage\XMLMessage\XMLFile";
                string strFolder = "";
                string strXmlName = "";

                TreeNode node = e.Node;
                strXmlName = node.Text.ToString().Trim();

                TreeNode nodeParent = e.Node.Parent;
                strFolder = nodeParent.Text.ToString().Trim();
                //string strXmlFilePath = strXmlFolderPath + "\\" + strFolder + "\\" + strXmlName;
                string strXmlFilePath = Path.Combine(strXmlFolderPath, strFolder, strXmlName);

                string strXml = "";
                strXml = TxtHelp.ReadTxt(strXmlFilePath);
                //rtxtXml.Text = strXml;

                //rtxtXml.AppendTextColorful("Add new line", Color.Green);

                //MessageBox.Show(strXmlFilePath);
            }
        }
    }
}

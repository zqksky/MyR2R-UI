﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XMLMessage.BaseFun
{
    class HashtableHelp
    {
        //遍历方法一：遍历哈希表中的键
        public static List<string> GetHashtableKeys(Hashtable ht)
        {
            List<string> strList = new List<string>();
            foreach (string key in ht.Keys)
            {
                strList.Add(key);
            }
            return strList;
        }

        public static List<string> GetHashtableValues(Hashtable ht)
        {
            List<string> strList = new List<string>();
            foreach (string value in ht.Values)
            {
                strList.Add(value);
            }
            return strList;
        }

        public static void GetHashtableKeysAndValues(Hashtable ht, ref List<string> strListKey, ref List<string> strListValue)
        {
            //遍历方法三：遍历哈希表中的键值
            foreach (DictionaryEntry de in ht)
            {
                strListKey.Add(de.Key.ToString());
                strListValue.Add(de.Value.ToString());
            }

            //遍历方法四：遍历哈希表中的键值
            //IDictionaryEnumerator myEnumerator = ht.GetEnumerator();
            //bool flag = myEnumerator.MoveNext();
            //while (flag)
            //{
            //    strListKey.Add(myEnumerator.Key.ToString());
            //    strListValue.Add(myEnumerator.Value.ToString());
            //    flag = myEnumerator.MoveNext();
            //}
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XMLMessage.BaseFun
{
    class TxtHelp
    {
        public static string  ReadTxt(string strTxtFilePath)
        {
            string strTxtValue = "";
            using (FileStream fs = new FileStream(strTxtFilePath, FileMode.Open, FileAccess.Read))
            {
                StreamReader sr = new StreamReader(fs, Encoding.UTF8);
                strTxtValue = sr.ReadToEnd();

                sr.Close();
                fs.Close();
            }
            return strTxtValue;
        }

        public static void GetXmlFile(string strXmlTxt, ref string strXmlFileName, ref string strXmlNote, string strXmlSavePath)
        {
            string strXmlContext = "";

            strXmlNote = GetXmlNote(strXmlTxt);
            strXmlFileName = GetXmlName(strXmlTxt);
            strXmlContext = GetXmlContext(strXmlTxt);

            strXmlSavePath = strXmlSavePath + "\\" + strXmlFileName;
            XmlHelp.WriteStringToXml(strXmlContext, strXmlSavePath);


            //string strDate = "2018-06-19 17:32:17.2002";
            //DateTime dtDate;

            //if (DateTime.TryParse(strDate, out dtDate))
            //{
            //    MessageBox.Show(dtDate.ToShortTimeString());
            //}
            //else
            //{
            //    throw new Exception("不是正确的日期格式类型！");
            //}

        }

        private static string GetXmlNote(string strXmlTxt)
        {
            string strNote = "";

            strNote = strXmlTxt.Substring(0, strXmlTxt.IndexOf("Message[<?xml version=")).Trim();
            strNote = "<!--" + strNote + "-->";

            return strNote;
        }

        private static string GetXmlName(string strXmlTxt)
        {
            string strXmlName = "";

            strXmlName = strXmlTxt.Substring(0, strXmlTxt.IndexOf("Message[<?xml version=")).Trim();

            strXmlName = strXmlName.Substring(0, 24);
            strXmlName = strXmlName.Replace(':', '-');

            strXmlName = strXmlName + ".xml";

            return strXmlName;
        }

        private static string GetXmlContext(string strXmlTxt)
        {
            string strXmlContext = "";

            strXmlContext = strXmlTxt.Substring(strXmlTxt.IndexOf("Message[<?xml version=") + 8);
            strXmlContext += " </msg>";

            return strXmlContext.Trim();
        }

        public void ReadTxt()
        {
            string filename = "c:\\test.txt";
            var lines = File.ReadAllLines(filename);
            var query = lines.SkipWhile(x => x.Trim() == "test").TakeWhile(x => x.Trim() != "/test").ToArray();
            File.WriteAllLines(filename, lines.Take(1).ToArray());
            File.AppendAllLines(filename, query);
            File.AppendAllLines(filename, lines.Skip(lines.Length - 1).ToArray());
        }
    }
}

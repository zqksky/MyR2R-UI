﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TestProcessLog.BaseFun;
using XMLMessage.BaseFun;

namespace TestProcessLog
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        string strDebugName = "";
        string strDebugFilePath = "";
        string strXmlSavePath = "";
        List<string> strListCmb = new List<string>() { "Start", "DataArray",  "And", "AppCmd", "CallSub", "Case", "DataCache", "OR", "DataFilter", "DataSet" };

        private void frmMain_Load(object sender, EventArgs e)
        {
            //TestException();

            //btnOpen.DoubleClick += new EventHandler(btn_DoubleClick);

            #region strategydbg To xml
            strDebugFilePath = Environment.CurrentDirectory + "\\R2R_CMP_L2LCalcRcpSettings.strategydbg";
            strXmlSavePath = Environment.CurrentDirectory + "\\R2R_CMP_L2LCalcRcpSettings.xml";

            txtDebugFile.Text = strDebugFilePath;

            bool bSuccess = false;
            bSuccess = DebugToXml();

            InitCmb();

            #endregion
        }

        private void frmMain_Activated(object sender, EventArgs e)
        {
            cmbInstanceId.Focus();
        }

        private void btn_DoubleClick(object sender, EventArgs e)
        {
            MessageBox.Show("button double click");
        }

        private void btn_Click(object sender, EventArgs e)
        {
            MessageBox.Show("button click");
        }

        private void InitCmb()
        {                       
            cmbInstanceId.DataSource = strListCmb;
            cmbInstanceId.SelectedIndex=0;
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            OpenDebugFile();
            //GetXmlFile();
        }

        private void OpenDebugFile()
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = Application.StartupPath; //Environment.CurrentDirectory;
            openFileDialog.Filter = "Debug|*.strategydbg";
            openFileDialog.RestoreDirectory = true;
            openFileDialog.FilterIndex = 1;
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                strDebugFilePath = openFileDialog.FileName;
                strDebugName = openFileDialog.SafeFileName;

                strXmlSavePath = Environment.CurrentDirectory;
                strXmlSavePath += "\\" + strDebugName + ".xml";

                txtDebugFile.Text = strDebugFilePath;

                DebugToXml();
            }
            panDetails.Controls.Clear();//清空panel
            cmbInstanceId.SelectedIndex = -1;
            cmbInstanceId.SelectedIndex = 0;
        }

        private void GetXmlFile()
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = Environment.CurrentDirectory;
            openFileDialog.Filter = "File(*.strategydbg,*.xml)|*.strategydbg;*.xml|Debug(*.strategydbg)|*.strategydbg|Xml(.xml)|*.xml|All files (*.*)|*.*";
            openFileDialog.RestoreDirectory = true;
            openFileDialog.FilterIndex = 1;
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string strOpenFilePath = openFileDialog.FileName;

                //string str = "获取文件的全路径：" + Path.GetFullPath(strOpenFilePath);   //-->C:\JiYF\BenXH\BenXHCMS.xml
                //str = "获取文件所在的目录：" + Path.GetDirectoryName(strOpenFilePath); //-->C:\JiYF\BenXH
                //str = "获取文件的名称含有后缀：" + Path.GetFileName(strOpenFilePath);  //-->BenXHCMS.xml
                //str = "获取文件的名称没有后缀：" + Path.GetFileNameWithoutExtension(strOpenFilePath); //-->BenXHCMS
                //str = "获取路径的后缀扩展名称：" + Path.GetExtension(strOpenFilePath); //-->.xml
                //str = "获取路径的根目录：" + Path.GetPathRoot(strOpenFilePath); //-->C:\

                string strPath = Path.GetDirectoryName(strOpenFilePath); //返回文件所在目录
                string strFileNameFull = Path.GetFileName(strOpenFilePath);//文件名 “Default.aspx”
                string strFileName = Path.GetFileNameWithoutExtension(strOpenFilePath); //返回不带扩展名的文件名 
                string strExtension = Path.GetExtension(strOpenFilePath);//扩展名 “.aspx”

                strDebugFilePath = openFileDialog.FileName;
                strDebugName = openFileDialog.SafeFileName;

                txtDebugFile.Text = strDebugFilePath;
                if (strExtension.ToLower().Equals(".xml"))
                {
                    strXmlSavePath = strOpenFilePath;
                }
                else if (strExtension.ToLower().Equals(".strategydbg"))
                {
                    DebugToXml();
                }               
                
            }
        }

        private bool DebugToXml()
        {
            bool bSuccess = false;
            if (File.Exists(strDebugFilePath))
            {
                byte[] bytes;
                bytes = GzipHelp.Decompress(strDebugFilePath);

                string strXml = Encoding.UTF8.GetString(bytes);
                bSuccess =  XmlHelp.WriteStringToXml(strXml, strXmlSavePath);

                if(bSuccess)
                {
                    //GzipHelp.CompressSingleFile(strXmlSavePath);
                }
                return bSuccess;
            }
            else
            {
                MessageBox.Show("Debug file not Exists!");
                return false;
            }           
        }

        private List<string> ParseXml(string strId, ref List<List<string>> strGroupInputName, ref List<List<string>> strGroupInputData, ref List<List<string>> strGroupOutputName, ref List<List<string>> strGroupOutputData)
        {
            List<string> strListOutputId = new List<string>();

            if (File.Exists(strXmlSavePath))
            {
                strListOutputId = XPathHelp.ParseXml(strXmlSavePath, "ExeInfo", strId, ref strGroupInputName, ref strGroupInputData, ref strGroupOutputName, ref strGroupOutputData);
            }
            else
            {
                MessageBox.Show("Xml file not Exists!");
            }
            return strListOutputId;
        }

        private string ParseXml(string strInstanceId,ref List<string> strListInputName, ref List<string> strListInputData,ref List<string> strListOutputName, ref List<string> strListOutputData)
        {
            #region
            //XPathHelp.UseXPathWithXmlDocument(strXmlSavePath, "ExeInfo", "0016 - CM - Read Control Model");

            //XPathHelp.UseXPathWithXmlDocument(strXmlSavePath, "ExeInfo", "Start");//eventInfo
            //XPathHelp.UseXPathWithXmlDocument(strXmlSavePath, "ExeInfo", "And");//MergedPathCount
            ////XPathHelp.UseXPathWithXmlDocument(strXmlSavePath, "ExeInfo", "EndSub");//OutputData
            //XPathHelp.UseXPathWithXmlDocument(strXmlSavePath, "ExeInfo", "CallSub");//OutputData
            //XPathHelp.UseXPathWithXmlDocument(strXmlSavePath, "ExeInfo", "DataFilter");//DataFilter
            //XPathHelp.UseXPathWithXmlDocument(strXmlSavePath, "ExeInfo", "DataSet");//DataSet

            //XPathHelp.UseXPathWithXmlDocument(strXmlSavePath, "ExeInfo", "OR");//*
            //XPathHelp.UseXPathWithXmlDocument(strXmlSavePath, "ExeInfo", "DataCache");//*
            //XPathHelp.UseXPathWithXmlDocument(strXmlSavePath, "ExeInfo", "Case");//*
            //XPathHelp.UseXPathWithXmlDocument(strXmlSavePath, "ExeInfo", "DataArray");//*
            //XPathHelp.UseXPathWithXmlDocument(strXmlSavePath, "ExeInfo", "AppCmd");//*
            #endregion

            string strOutputId = string.Empty;

            if (File.Exists(strXmlSavePath))
            {
                strOutputId = XPathHelp.ParseXmlDocument(strXmlSavePath, "ExeInfo", strInstanceId,ref strListInputName, ref strListInputData, ref strListOutputName, ref strListOutputData);
            }
            else
            {
                MessageBox.Show("Xml file not Exists!");
            }
            return strOutputId;
        }

        private void cmbInstanceId_SelectedIndexChanged_Old(object sender, EventArgs e)
        {
            //ComboBox cmb = (ComboBox)sender;
            //string strCmbName = cmb.Text;

            //List<string> strListInputName = new List<string>();
            //List<string> strListInputData = new List<string>();
            //List<string> strListOutputName = new List<string>();
            //List<string> strListOutputData = new List<string>();

            //string strOutputId = string.Empty;

            //strOutputId = ParseXml(strCmbName, ref strListInputName, ref strListInputData, ref strListOutputName, ref strListOutputData);

            //lblOutput.Text = "Output - "+ strOutputId;

            //DataTable dbInput = CreateTable(strListInputName, strListInputData);
            //DataTable dbOutput = CreateTable(strListOutputName, strListOutputData);

            //InitDgvGrid(dgvInputData,dbInput);
            //InitDgvGrid(dgvOutputData, dbOutput);
        }

        private void cmbInstanceId_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox cmb = (ComboBox)sender;
            string strCmbName = cmb.Text;
            if (strCmbName.Equals(""))
            {
                return;
            }
            else
            {
                panDetails.Controls.Clear();//清空panel

                List<string> strListInputLbl = new List<string>();
                List<string> strListOutputLbl = new List<string>();
                List<string> strListOutputId = new List<string>();

                List<List<string>> strGroupInputName = new List<List<string>>();
                List<List<string>> strGroupInputData = new List<List<string>>();
                List<List<string>> strGroupOutputName = new List<List<string>>();
                List<List<string>> strGroupOutputData = new List<List<string>>();

                List<DataTable> dtListInput = new List<DataTable>();
                List<DataTable> dtListOutput = new List<DataTable>();

                try
                {
                    strListOutputId = ParseXml(strCmbName, ref strGroupInputName, ref strGroupInputData, ref strGroupOutputName, ref strGroupOutputData);

                    for (int i = 0; i < strListOutputId.Count; i++)
                    {
                        strListInputLbl.Add("Input");
                        strListOutputLbl.Add("Output - Id : " + strListOutputId[i]);

                        DataTable dbInput = CreateTable(strGroupInputName[i], strGroupInputData[i]);
                        DataTable dbOutput = CreateTable(strGroupOutputName[i], strGroupOutputData[i]);
                        dtListInput.Add(dbInput);
                        dtListOutput.Add(dbOutput);
                    }

                    if(strListInputLbl.Count>0)
                    {
                        AddControlHelp.AddControlToTabPanel(panDetails, strListInputLbl, strListOutputLbl, dtListInput, dtListOutput);
                    }

                }
                catch (Exception ee)
                {
                    MessageBox.Show(GetExceptionInformation(ee));
                }          
            }
            
        }

        private void InitDgvGrid(DataGridView dgv, DataTable tb)
        {
            dgv.DataSource = tb;

            //禁止编辑
            dgv.ReadOnly = true;
            for (int i = 0; i < dgv.ColumnCount; i++)
            {
                dgv.Columns[i].ReadOnly = true;
                //dgv.Columns[i].DefaultCellStyle.BackColor = Color.LightGray;
                dgv.Columns[i].DefaultCellStyle.BackColor = Color.Aqua;
            }
        }

        private DataTable CreateTable(List<string> strListName, List<string> strListValue)
        {
            DataTable db = new DataTable("Process");
            db.Columns.Add("Name", Type.GetType("System.String"));
            db.Columns.Add("Value", Type.GetType("System.String"));

            if (strListName.Count < 1)
            {
                db.Rows.Add();
                db.Rows[0][0] = "Null";
                db.Rows[0][1] = "Null";
            }
            else
            {
                for (int i = 0; i < strListName.Count; i++)
                {
                    db.Rows.Add();
                    db.Rows[i][0] = strListName[i];
                    db.Rows[i][1] = strListValue[i];
                }
            }

            return db;
        }

        private void GetFunInformation()
        {
            StackTrace st = new StackTrace(new StackFrame(true));

            MessageBox.Show(st.ToString());
            StackFrame sf = st.GetFrame(0);

            MessageBox.Show(" File: " + sf.GetFileName());
            MessageBox.Show(" Method: " + sf.GetMethod().Name);
            MessageBox.Show(" Line Number: " + sf.GetFileLineNumber());
            MessageBox.Show(" Column Number: " + sf.GetFileColumnNumber());

        }

        private void TestException()
        {
            int i = 0;
            try
            {
                int n = 1;
                n = n / i;
            }
            catch (Exception ee)
            { 
               MessageBox.Show(GetExceptionInformation(ee));
            }
        }

        private string GetExceptionInformation(Exception ee)
        {
            string strTmp = string.Empty;
            string strResult = string.Empty;
            string strStackTrace = ee.StackTrace;

            strTmp = strStackTrace.Substring(6, strStackTrace.IndexOf(" in ") - 6);
            strResult += strTmp + "\r\n";

            strTmp = strStackTrace.Substring(strStackTrace.IndexOf(":line") + 1);
            strResult += strTmp + "\r\n";

            strResult += ee.Message;

            return strResult;
        }
    }
}

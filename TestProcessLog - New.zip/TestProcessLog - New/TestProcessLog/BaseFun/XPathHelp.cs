﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace XMLMessage.BaseFun
{
    class XPathHelp
    {
        public enum OutputNode
        {
            eventInfo,
            MergedPathCount,
            OutputData,
            DataFilter,
            DataSet
        }

        public static List<string> ParseXml(string strXmlPath, string strNodeName, string strInstanceId, ref List<List<string>> strGroupInputName, ref List<List<string>> strGroupInputData, ref List<List<string>> strGroupOutputName, ref List<List<string>> strGroupOutputData)
        {
            List<string> strListOutputId = new List<string>();

            strGroupInputName.Clear();
            strGroupInputData.Clear();
            strGroupOutputName.Clear();
            strGroupOutputName.Clear();

            string strOutputId = string.Empty;
            string strOutputData = string.Empty;

            XmlDocument doc = new XmlDocument();
            doc.Load(strXmlPath);

            //使用xPath选择需要的节点
            //XmlNodeList nodes = doc.SelectNodes("//ExeInfo[InstanceId='0058 - CC - Create Full Array of Zero Values']");
            //XmlNodeList nodes = doc.SelectNodes("//StrategyExeInfo/ExecutionSeq/" + strNodeName + "[InstanceId='" + strInstanceId + "']");
            XmlNodeList nodes = doc.SelectNodes("//StrategyExeInfo/ExecutionSeq/" + strNodeName + "[Id='" + strInstanceId + "']");

            foreach (XmlNode item in nodes)
            {
                List<string> strListInputName = new List<string>();
                List<string> strListInputData = new List<string>();
                List<string> strListOutputName = new List<string>();
                List<string> strListOutputData = new List<string>();

                XmlNodeList nodesInput = item.SelectNodes("child::Inputs/InputParameter");

                foreach (XmlNode itemInput in nodesInput)
                {
                    string strInputName = itemInput.SelectSingleNode("child::Name").InnerText;
                    string strInputData = itemInput.SelectSingleNode("child::Data").InnerText;

                    //strInputData = GetNodeData(strInputData);
                    //GetNodeData(strInputData, strInputName, ref strListInputName, ref strListInputData);

                    GetInputNodeData(strInputData, strInputName, ref strListInputName, ref strListInputData);

                    //strListInputName.Add(strInputName);
                    //strListInputData.Add(strInputData);
                }

                XmlNodeList nodesOutput = item.SelectNodes("child::Output");
                foreach (XmlNode itemOutput in nodesOutput)
                {
                    strOutputId = itemOutput.SelectSingleNode("child::Id").InnerText;
                    strOutputData = itemOutput.SelectSingleNode("child::Data").InnerText;

                    bool bIsXml = XmlHelp.IsXml(strOutputData);
                    if (bIsXml)
                    {
                        List<string> strListName = new List<string>();
                        List<string> strListData = new List<string>();
                        GetOutputNodeData(strOutputData, ref strListName, ref strListData);
                        strListOutputName = new List<string>(strListName);
                        strListOutputData = new List<string>(strListData);
                    }
                }
                strGroupInputName.Add(strListInputName);
                strGroupInputData.Add(strListInputData);
                strGroupOutputName.Add(strListOutputName);
                strGroupOutputData.Add(strListOutputData);

                strListOutputId.Add(strOutputId);
            }
            doc.RemoveAll();
            doc = null;

            return strListOutputId;
        }


        public static string ParseXmlDocument(string strXmlPath, string strNodeName, string strId, ref List<string> strListInputName, ref List<string> strListInputData, ref List<string> strListOutputName, ref List<string> strListOutputData)
        {
            strListInputName.Clear();
            strListInputData.Clear();
            strListOutputName.Clear();
            strListOutputData.Clear();

            string strOutputId = string.Empty;
            string strOutputData = string.Empty;

            XmlDocument doc = new XmlDocument();
            doc.Load(strXmlPath);

            //使用xPath选择需要的节点
            //XmlNodeList nodes = doc.SelectNodes("//ExeInfo[InstanceId='0058 - CC - Create Full Array of Zero Values']");
            //XmlNodeList nodes = doc.SelectNodes("//StrategyExeInfo/ExecutionSeq/" + strNodeName + "[InstanceId='" + strInstanceId + "']");
            XmlNodeList nodes = doc.SelectNodes("//StrategyExeInfo/ExecutionSeq/" + strNodeName + "[Id='" + strId + "']");

            foreach (XmlNode item in nodes)
            {
                XmlNodeList nodesInput = item.SelectNodes("child::Inputs/InputParameter");

                foreach (XmlNode itemInput in nodesInput)
                {
                    string strInputName = itemInput.SelectSingleNode("child::Name").InnerText;
                    string strInputData = itemInput.SelectSingleNode("child::Data").InnerText;

                    //strInputData = GetNodeData(strInputData);
                    //GetNodeData(strInputData, strInputName, ref strListInputName, ref strListInputData);

                    GetInputNodeData(strInputData, strInputName, ref strListInputName, ref strListInputData);

                    //strListInputName.Add(strInputName);
                    //strListInputData.Add(strInputData);
                }

                XmlNodeList nodesOutput = item.SelectNodes("child::Output");
                foreach (XmlNode itemOutput in nodesOutput)
                {
                    strOutputId = itemOutput.SelectSingleNode("child::Id").InnerText;
                    strOutputData = itemOutput.SelectSingleNode("child::Data").InnerText;

                    bool bIsXml = XmlHelp.IsXml(strOutputData);
                    if (bIsXml)
                    {
                        List<string> strListName = new List<string>();
                        List<string> strListData = new List<string>();
                        GetOutputNodeData(strOutputData, ref strListName, ref strListData);
                        strListOutputName = new List<string>(strListName);
                        strListOutputData = new List<string>(strListData);
                    }
                }
            }

            return strOutputId;
        }


        private static void GetInputNodeData(string strXml, string strNodeName, ref List<string> strListName, ref List<string> strListData)
        {
            string strValue = string.Empty;
            bool bIsXml = XmlHelp.IsXml(strXml);
            if (bIsXml)
            {
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(strXml);

                //使用xPath选择需要的节点
                XmlNodeList subNodes = doc.SelectNodes("child::*");//ParametersOutput;
                foreach (XmlNode item in subNodes)
                {
                    GetInputSubNodeData(item, strNodeName, ref strListName, ref strListData);
                }
            }
            else
            {
                strListName.Add(strNodeName);
                strListData.Add(strXml);
            }
        }

        private static void GetInputSubNodeData(XmlNode subNode, string strInputName, ref List<string> strListName, ref List<string> strListData)
        {
            string strValue = string.Empty;
            string strName = subNode.Name;

            //strListName.Clear();
            //strListData.Clear();

            XmlNodeList nodes = subNode.SelectNodes("child::*");
            if (nodes.Count > 0)
            {
                int i = 0;
                foreach (XmlNode item in nodes)
                {
                    i++;
                    strListName.Add(strInputName + "." + i);
                    //strListName.Add(strInputName + "-" + strName + "." + i);
                    strListData.Add(item.InnerText);
                }
            }
            else
            {
                strListName.Add(strInputName + "-" + strName);
                strListData.Add(subNode.InnerText);
            }
        }

        private static int GetOutputNodeData(string strXml, ref List<string> strListName, ref List<string> strListData)
        {
            int type = -1;
            List<string> strList = new List<string>() { "//eventInfo", "//MergedPathCount", "//OutputData", "//DataFilter", "//DataSet" };

            try
            {
                strListName.Clear();
                strListData.Clear();

                XmlDocument doc = new XmlDocument();
                doc.LoadXml(strXml);

                //使用xPath选择需要的节点
                XmlNodeList nodes = null;
                for (int i = 0; i < strList.Count; i++)
                {
                    nodes = doc.SelectNodes(strList[i]);//ParametersOutput
                    if (nodes.Count > 0)
                    {
                        GetOutputData(nodes, ref strListName, ref strListData);
                        type = i;
                    }
                }
                if (type == -1)
                {
                    nodes = doc.SelectNodes("child::*");
                    if (nodes.Count > 0)
                    {
                        GetOutputDataOther(nodes, ref strListName, ref strListData);
                    }
                }
            }
            catch (Exception ee)
            {

            }

            return type;
        }

        private static void GetOutputDataOther(XmlNodeList nodes, ref List<string> strListName, ref List<string> strListData)
        {
            try
            {
                if (nodes.Count > 0)
                {
                    strListName.Clear();
                    strListData.Clear();
                    foreach (XmlNode item in nodes)
                    {
                        XmlNodeList nodes2 = item.SelectNodes("child::*");
                        if (nodes2.Count > 0)
                        {
                            int i = 0;
                            foreach (XmlNode item2 in nodes2)
                            {
                                i++;
                                GetSubNodeDataOther(item2, item.Name+"."+i,ref strListName, ref strListData);
                            }
                        }
                        else
                        {
                            string strName = item.Name;
                            strListName.Add(strName);

                            string strValue = item.InnerText;
                            strListData.Add(strValue);
                        }
                    }
                }
            }
            catch (Exception ee)
            {

            }
        }

        private static void GetSubNodeDataOther(XmlNode subNode, string strNodeName, ref List<string> strListName, ref List<string> strListData)
        {
            string strValue = string.Empty;
            string strName = subNode.Name;

            //strListName.Clear();
            //strListData.Clear();

            XmlNodeList nodes = subNode.SelectNodes("child::*");
            if (nodes.Count > 0)
            {
                int i = 0;
                foreach (XmlNode item in nodes)
                {
                    i++;
                    strListName.Add(strNodeName + "." + i);
                    //strListName.Add(strName + "." + i);
                    strListData.Add(item.InnerText);
                }
            }
            else
            {
                strListName.Add(strNodeName);
                //strListName.Add(strName);
                strListData.Add(subNode.InnerText);
            }
        }

        private static void GetOutputData(XmlNodeList nodes, ref List<string> strListName, ref List<string> strListData)
        {
            try
            {
                if (nodes.Count > 0)
                {
                    strListName.Clear();
                    strListData.Clear();
                    foreach (XmlNode item in nodes)
                    {
                        XmlNodeList nodes2 = item.SelectNodes("child::*");
                        if (nodes2.Count > 0)
                        {
                            foreach (XmlNode item2 in nodes2)
                            {
                                //string strName = item2.Name;
                                //strListName.Add(strName);

                                //string strValue = string.Empty;
                                //strValue = GetNodeData(item2);
                                //strListData.Add(strValue);

                                GetSubNodeData(item2, ref strListName, ref strListData);
                            }
                        }
                        else
                        {
                            string strName = item.Name;
                            strListName.Add(strName);

                            string strValue = item.InnerText;
                            strListData.Add(strValue);
                        }
                    }
                }
            }
            catch (Exception ee)
            {

            }
        }

        private static void GetSubNodeData(XmlNode subNode, ref List<string> strListName, ref List<string> strListData)
        {
            string strValue = string.Empty;
            string strName = subNode.Name;

            //strListName.Clear();
            //strListData.Clear();

            XmlNodeList nodes = subNode.SelectNodes("child::*");
            if (nodes.Count > 0)
            {
                int i = 0;
                foreach (XmlNode item in nodes)
                {
                    i++;
                    strListName.Add(strName + "." + i);
                    strListData.Add(item.InnerText);
                }
            }
            else
            {
                strListName.Add(strName);
                strListData.Add(subNode.InnerText);
            }
        }


        public static void UseXPathWithXmlDocument(string strXmlPath, string strNodeName, string strInstanceId)
        {

            XmlDocument doc = new XmlDocument();

            doc.Load(strXmlPath);

            //使用xPath选择需要的节点
            //XmlNodeList nodes = doc.SelectNodes("//ExeInfo[InstanceId='0058 - CC - Create Full Array of Zero Values']");
            XmlNodeList nodes = doc.SelectNodes("//" + strNodeName + "[InstanceId='" + strInstanceId + "']");

            List<string> strListInputName = new List<string>();
            List<string> strListInputData = new List<string>();
            List<string> strListOutputName = new List<string>();
            List<string> strListOutputData = new List<string>();

            foreach (XmlNode item in nodes)
            {
                XmlNodeList nodesInput = item.SelectNodes("child::Inputs/InputParameter");

                foreach (XmlNode itemInput in nodesInput)
                {
                    string strInputName = itemInput.SelectSingleNode("child::Name").InnerText;
                    string strInputData = itemInput.SelectSingleNode("child::Data").InnerText;

                    //strInputData = GetNodeData(strInputData);
                    GetNodeData(strInputData, strInputName, ref strListInputName, ref strListInputData);

                    //strListInputName.Add(strInputName);
                    //strListInputData.Add(strInputData);
                }

                XmlNodeList nodesOutput = item.SelectNodes("child::Output");
                foreach (XmlNode itemOutput in nodesOutput)
                {
                    string strOutputId = itemOutput.SelectSingleNode("child::Id").InnerText;
                    string strOutputData = itemOutput.SelectSingleNode("child::Data").InnerText;
                    strListOutputName.Add(strOutputId);
                    strListOutputData.Add(strOutputData);
                    bool bIsXml = XmlHelp.IsXml(strOutputData);
                    if (bIsXml)
                    {
                        //UseXPathParseOutput(strOutputData);

                        List<string> strListName = new List<string>();
                        List<string> strListData = new List<string>();
                        GetOutputNodeData(strOutputData, ref strListName, ref strListData);
                    }
                }
            }
        }

        public static void UseXPathParseOutput(string strXml)
        {
            List<string> strListName = new List<string>();
            List<string> strListData = new List<string>();

            XmlDocument doc = new XmlDocument();
            doc.LoadXml(strXml);

            //使用xPath选择需要的节点
            XmlNodeList nodes = doc.SelectNodes("//eventInfo");//ParametersOutput

            foreach (XmlNode item in nodes)
            {
                XmlNodeList nodes2 = item.SelectNodes("child::*");
                foreach (XmlNode item2 in nodes2)
                {
                    string strName = item2.Name;
                    strListName.Add(strName);

                    string strValue = item2.InnerText;
                    strListData.Add(strValue);
                }
            }
        }

        private static string GetNodeData(string strXml)
        {
            string strValue = string.Empty;
            bool bIsXml = XmlHelp.IsXml(strXml);
            if (bIsXml)
            {
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(strXml);

                //使用xPath选择需要的节点
                XmlNodeList subNodes = doc.SelectNodes("child::*");//ParametersOutput;
                foreach (XmlNode item in subNodes)
                {
                    string strName = item.Name;
                    strValue = GetNodeData(item);
                }
            }
            else
            {
                strValue = strXml;
            }
            return strValue;
        }

        private static string GetNodeData(XmlNode subNode)
        {
            string strValue = string.Empty;
            string strName = subNode.Name;

            XmlNodeList nodes = subNode.SelectNodes("child::*");
            if (nodes.Count > 0)
            {
                foreach (XmlNode item in nodes)
                {
                    strValue += item.InnerText + ";";
                }
                strValue = strValue.TrimEnd(';');
            }
            else
            {
                strValue = subNode.InnerText;
            }
            return strValue;
        }

        private static void GetNodeData(string strXml, string strNodeName, ref List<string> strListName, ref List<string> strListData)
        {
            string strValue = string.Empty;
            bool bIsXml = XmlHelp.IsXml(strXml);
            if (bIsXml)
            {
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(strXml);

                //使用xPath选择需要的节点
                XmlNodeList subNodes = doc.SelectNodes("child::*");//ParametersOutput;
                foreach (XmlNode item in subNodes)
                {
                    GetSubNodeData(item, ref strListName, ref strListData);
                }
            }
            else
            {
                strListName.Add(strNodeName);
                strListData.Add(strXml);
            }
        }
    }
}

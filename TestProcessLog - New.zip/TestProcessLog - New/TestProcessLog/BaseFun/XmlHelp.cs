﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;

namespace XMLMessage.BaseFun
{
    class XmlHelp
    {
        public static bool IsXml(string strXml)
        {
            try
            {
                XmlDocument xml = new XmlDocument();
                xml.LoadXml(strXml);//判断是否加载成功
                return true;//是xml文件，返回
            }
            catch
            {
                return false;//不是xml文件，返回
            }
        }
        public static bool IsXmlFile(string strPath)
        {
            string strXml = "";
            using (StreamReader sr = new StreamReader(strPath))
            {
                strXml = sr.ReadToEnd();
                sr.Close();
                sr.Dispose();
            }
            try
            {
                XmlDocument xml = new XmlDocument();
                xml.LoadXml(strXml);//判断是否加载成功
                return true;//是xml文件，返回
            }
            catch
            {
                return false;//不是xml文件，返回
            }
        }

        public static bool WriteStringToXml(string strTxt, string strXmlSavePath)
        {
            try
            {
                XmlDocument xdoc = new XmlDocument();
                xdoc.LoadXml(strTxt);
                //XmlComment comment = xdoc.CreateComment("<!-- note -->");
                xdoc.Save(strXmlSavePath);

                return true;
                //XmlDocument xdoc = new XmlDocument();
                //xdoc.LoadXml(这里是你的xml字符串);
                //或者
                //XmlDocument xdoc = new XmlDocument();
                //xdoc.Load(这里是你的xml文件);

                //或者
                //xdoc.InnerXml= strTxt; //是你的xml字符串
                //xdoc.Save(strXmlSavePath);    //这里是你的xml文件
            }
            catch (Exception e)
            {
                return false;
                MessageBox.Show(e.Message);
            }

        }

        public static void ReadXml(string strXmlPath)
        {
            //<? xml version = "1.0" encoding = "utf-8" ?>
            //< library id = "30" >
            //  < BOOK id = "20" >
            //      < name > 高等数学 </ name >
            //      < name1 > 大学英语 </ name1 >
            //  </ BOOK >
            //</ library >

            //将XML文件加载进来
            XDocument document = XDocument.Load(strXmlPath);

            //获取到XML的根元素进行操作
            XElement root = document.Root;
            XElement ele = root.Element("BOOK");

            //获取name标签的值
            XElement shuxing = ele.Element("name");
            MessageBox.Show(shuxing.Value.ToString());

            //获取根元素下的所有子元素
            IEnumerable<XElement> enumerable = root.Elements();
            foreach (XElement item in enumerable)
            {
                foreach (XElement item1 in item.Elements())
                {
                    MessageBox.Show(item1.Name.ToString());   //输出 name  name1            
                }
                MessageBox.Show(item.Attribute("id").Value.ToString());  //输出20
            }
            //Console.ReadKey();
        }

        /// <summary>
        /// 创建节点
        /// </summary>
        /// <param name="node"></param>
        /// <param name="newElementName"></param>
        /// <returns></returns>
        public static XmlNode AppendElement(XmlNode node, string newElementName)
        {
            return AppendElement(node, newElementName, null);
        }

        /// <summary>
        /// 创建节点
        /// </summary>
        /// <param name="node"></param>
        /// <param name="newElementName"></param>
        /// <param name="innerValue"></param>
        /// <returns></returns>
        public static XmlNode AppendElement(XmlNode node, string newElementName, string innerValue)
        {
            XmlNode oNode;
            if (node is XmlDocument)
            {
                oNode = node.AppendChild(((XmlDocument)node).CreateElement(newElementName));
            }
            else
            {
                oNode = node.AppendChild(node.OwnerDocument.CreateElement(newElementName));
            }

            if (innerValue != null)
            {
                oNode.AppendChild(node.OwnerDocument.CreateTextNode(innerValue));
            }
            return oNode;
        }

        /// <summary>
        /// 创建属性
        /// </summary>
        /// <param name="xmlDocument"></param>
        /// <param name="name"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public static XmlAttribute CreateAttribute(XmlDocument xmlDocument, string name, string value)
        {
            XmlAttribute oAtt = xmlDocument.CreateAttribute(name);
            oAtt.Value = value;
            return oAtt;
        }

        /// <summary>
        /// 设置属性的值
        /// </summary>
        /// <param name="node"></param>
        /// <param name="attributeName"></param>
        /// <param name="attributeValue"></param>
        public static void SetAttribute(XmlNode node, string attributeName, string attributeValue)
        {
            if (node.Attributes[attributeName] != null)
            {
                node.Attributes[attributeName].Value = attributeValue;
            }
            else
            {
                node.Attributes.Append(CreateAttribute(node.OwnerDocument, attributeName, attributeValue));
            }
        }

        /// <summary>
        /// 获取属性的值
        /// </summary>
        /// <param name="node"></param>
        /// <param name="attributeName"></param>
        /// <param name="defaultValue"></param>
        /// <returns></returns>
        public static string GetAttribute(XmlNode node, string attributeName, string defaultValue)
        {
            XmlAttribute att = node.Attributes[attributeName];
            if (att != null)
            {
                return att.Value;
            }
            else
            {
                return defaultValue;
            }
        }

        /// <summary>
        /// 获取节点的值
        /// </summary>
        /// <param name="parentNode"></param>
        /// <param name="nodeXPath"></param>
        /// <param name="defaultValue"></param>
        /// <returns></returns>
        public static string GetNodeValue(XmlNode parentNode, string nodeXPath, string defaultValue)
        {
            XmlNode node = parentNode.SelectSingleNode(nodeXPath);
            if (node.FirstChild != null)
            {
                return node.FirstChild.Value;
            }
            else if (node != null)
            {
                return node.Value;
            }
            else
            {
                return defaultValue;
            }
        }
    }
}




    
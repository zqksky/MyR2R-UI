﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestProcessLog.BaseFun
{
    class AddControlHelp
    {
        #region Add Control To TabPanel
        public static void AddControlToTabPanel(Panel ctlPanel, List<string> strListInputLbl, List<string> strListOutputLbl, List<DataTable> dtListInput, List<DataTable> dtListOutput)
        {
            try
            {
                int number = dtListInput.Count;
                TableLayoutPanel ctlTabPanel = new TableLayoutPanel();
                ctlTabPanel.Dock = DockStyle.Fill;
                ctlPanel.Controls.Add(ctlTabPanel);
                ctlTabPanel.ColumnCount = number;
                //ctlTabPanel.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
                float fNum = 1 / float.Parse(number.ToString());

                //ctlTabPanel.Height = ctlTabPanel.RowCount * 40; //table的整体高度，每行40

                for (int n = 0; n < number; n++)
                {
                    ctlTabPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, ctlTabPanel.Width * fNum));    //利用百分比计算，0.2f表示占用本行长度的20%
                }

                for (int i = 0; i < 2; i++)
                {
                    ctlTabPanel.RowStyles.Add(new RowStyle(SizeType.Percent, ctlTabPanel.Height * 0.5f));
                }

                SetRowValue(ctlTabPanel, 0, strListInputLbl, dtListInput);
                SetRowValue(ctlTabPanel, 1, strListOutputLbl, dtListOutput);

                ctlTabPanel.Dock = DockStyle.Fill;
            }
            catch (Exception err)
            {
               // MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
        }

        private static void SetRowValue(TableLayoutPanel ctlTabPanel, int row, List<string> strListLbl, List<DataTable> dtList)
        {
            try
            {
                // 动态添加一行
                //ctlTabPanel.RowCount++;
                for (int i = 0; i < dtList.Count; i++)
                {
                    //Panel ctlPanel = new Panel();
                    //AddDataGridViewToPanel(ctlPanel, dtList[i], strListLbl[i]);
                    //ctlTabPanel.Controls.Add(ctlPanel, i, row);
                    //ctlPanel.Dock = DockStyle.Fill;

                    Panel ctlPanel = new Panel();
                    AddDgvAndLbelToTabPanel(ctlPanel, strListLbl[i], dtList[i]);
                    ctlTabPanel.Controls.Add(ctlPanel, i, row);
                    ctlPanel.Dock = DockStyle.Fill;
                    ctlPanel.BorderStyle = BorderStyle.FixedSingle;
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

        }

        private static void AddDgvAndLbelToTabPanel(Panel ctlPanel, string strLbl, DataTable db)
        {
            TableLayoutPanel ctlTabPanel = new TableLayoutPanel();
            ctlTabPanel.Dock = DockStyle.Fill;
            ctlTabPanel.ColumnCount = 1;
            ctlTabPanel.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;

            ctlTabPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, ctlTabPanel.Width));    //利用百分比计算，0.2f表示占用本行长度的20%

            ctlTabPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 30));
            ctlTabPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            try
            {
                Label lbl = new Label();
                lbl = GetLbl(strLbl);
                ctlTabPanel.Controls.Add(lbl, 0, 0);

                //Panel lblPanel = new Panel();
                //lblPanel = GetLblPanel(strLbl);
                //ctlTabPanel.Controls.Add(lblPanel, 0, 1);

                Panel dgvPanel = new Panel();
                dgvPanel = GetDgvPanel(db);
                ctlTabPanel.Controls.Add(dgvPanel, 0, 1);

                ctlPanel.Controls.Add(ctlTabPanel);
            }
            catch (Exception err)
            {
                //MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
        }

        private static Label GetLbl(string strLblTxt)
        {
            Label ctlLable;

            ctlLable = new Label()
            {
                AutoSize = false,
                Text = strLblTxt,
                Width = 300,
                Height = 30,
                Font = new Font("隶书", 9, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleCenter,
                //Location = new Point(400, 800)
            };

            return ctlLable;
        }

        private static Panel GetDgvPanel(DataTable db)
        {
            Panel panDgv;
            DataGridView dgv;

            panDgv = new Panel()
            {
                Name = "panDgv",
                TabIndex = 1,
                Tag = 1,
                //Anchor= AnchorStyles.Top & AnchorStyles.Right & AnchorStyles.Left & AnchorStyles.Right,

                Dock = DockStyle.Fill,
                //BorderStyle = BorderStyle.FixedSingle,
                AutoScroll = true
            };

            dgv = new DataGridView()
            {
                AllowUserToAddRows = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells,
                //BackgroundColor = Color.Aqua,
                //ForeColor= Color.Aqua,                
                ReadOnly = true,
                DataSource = db,
                Dock = DockStyle.Fill
            };

            try
            {
                dgv.DefaultCellStyle.BackColor = Color.Aqua;
                panDgv.Controls.Add(dgv);

                if (dgv.RowCount > 0)
                {
                    dgv.CurrentCell.Style.SelectionBackColor = Color.Red;
                }
            }
            catch (Exception ee)
            {
            }
            return panDgv;
        }

        private static void AddDataGridViewToPanel(Panel ctlPanel, DataTable dt, string strLbl)
        {
            try
            {
                Label ctlLable = new Label();

                Panel panLbl = new Panel();
                panLbl.Dock = DockStyle.Top;

                panLbl.Controls.Add(ctlLable);
                ctlPanel.Controls.Add(panLbl);

                Panel panDgv = new Panel();
                panDgv.Dock = DockStyle.Fill;
                panDgv.AutoScroll = true;
                ctlPanel.Controls.Add(panDgv);


                panLbl.Height = 25;
                panLbl.BorderStyle = BorderStyle.FixedSingle;

                ctlLable.Text = strLbl;
                ctlLable.Location = new Point(Convert.ToInt32(panLbl.Width - ctlLable.Width) / 2,
                                           Convert.ToInt32(panLbl.Height - ctlLable.Height) / 2);


                DataGridView dgv = new DataGridView();
                dgv.AllowUserToAddRows = false;
                dgv.ReadOnly = true;
                dgv.DataSource = dt;
                dgv.Dock = DockStyle.Fill;
                panDgv.Controls.Add(dgv);
            }
            catch (Exception err)
            {
                //MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
        }
        #endregion
    }
}

1. Execute Oracle DDL
2. Import the E3 package (including DLL and parameter table already)
3. Test the event by manually generate the strategy event

ToDo:
1. Create scheduled task for hang detection
2. Build alarm message
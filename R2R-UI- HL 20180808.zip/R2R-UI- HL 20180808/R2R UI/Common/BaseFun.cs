﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.DataVisualization.Charting;
using static R2R_UI.Common.UIServiceFun;

namespace R2R_UI.Common
{
    class BaseFun
    {
        #region List Sort
        public static void GetSortListAndValue(List<string> strListUsedTime, ref List<string> strListValue, ref List<string> strListId)
        {
            List<int> iListIndex = new List<int>();
            iListIndex = GetSortListIndex(strListUsedTime);

            List<string> strListItemValuesSort = new List<string>();
            strListItemValuesSort = GetSortList(strListValue, iListIndex);

            List<string> strListIdSort = new List<string>();
            strListIdSort = GetSortList(strListId, iListIndex);

            strListValue = new List<string>(strListItemValuesSort);
            strListId = new List<string>(strListIdSort);
        }
        public static List<int> GetSortListIndex(List<string> strList)
        {
            List<int> iListIndex = new List<int>();
            List<string> strListSort = new List<string>(strList);
            strListSort.Sort();

            foreach (var str in strListSort)
            {
                for (int i = 0; i < strList.Count; i++)
                {
                    if (str.Equals(strList[i]))
                    {
                        iListIndex.Add(i);
                    }
                }
            }

            return iListIndex;
        }
        public static List<string> GetSortList(List<string> strList, List<int> iListIndex)
        {
            List<string> strListSort = new List<string>();

            for (int i = 0; i < iListIndex.Count; i++)
            {
                strListSort.Add(strList[iListIndex[i]]);
            }

            return strListSort;
        }
        #endregion

        #region old
        private static structCOMMON_GetLotRunHistory GetLotRunHistoryInput_Common(structCOMMON_GetLotRunHistory structData)
        {
            structCOMMON_GetLotRunHistory structDataNew = new structCOMMON_GetLotRunHistory();
            structDataNew.iListActualInputSizes = new List<int>();
            structDataNew.iListActualOutputSizes = new List<int>();
            structDataNew.strListIsValidRecords = new List<string>();
            structDataNew.strListLotIds = new List<string>();
            structDataNew.strListUsedTimeStamps = new List<string>();
            structDataNew.strListInputValues = new List<string>();
            structDataNew.strListOutputValues = new List<string>();
            structDataNew.strListGroups = new List<string>();


            if (structData.strListInputValues.Count > 0)
            {
                for (int i = 0; i < structData.strListInputValues.Count; i++)
                {
                    if (!structData.strListInputValues[i].Contains("NaN"))
                    {
                        structDataNew.iListActualInputSizes.Add(structData.iListActualInputSizes[i]);
                        structDataNew.iListActualOutputSizes.Add(structData.iListActualOutputSizes[i]);
                        structDataNew.strListIsValidRecords.Add(structData.strListIsValidRecords[i]);
                        structDataNew.strListLotIds.Add(structData.strListLotIds[i]);
                        structDataNew.strListUsedTimeStamps.Add(structData.strListUsedTimeStamps[i]);
                        structDataNew.strListInputValues.Add(structData.strListInputValues[i]);
                        structDataNew.strListOutputValues.Add(structData.strListOutputValues[i]);
                        structDataNew.strListGroups.Add(structData.strListGroups[i]);
                    }
                }
            }
            return structDataNew;
        }
        private static structCOMMON_GetLotRunHistory GetLotRunHistoryOutput_Common(structCOMMON_GetLotRunHistory structData)
        {
            structCOMMON_GetLotRunHistory structDataNew = new structCOMMON_GetLotRunHistory();
            structDataNew.iListActualInputSizes = new List<int>();
            structDataNew.iListActualOutputSizes = new List<int>();
            structDataNew.strListIsValidRecords = new List<string>();
            structDataNew.strListLotIds = new List<string>();
            structDataNew.strListUsedTimeStamps = new List<string>();
            structDataNew.strListInputValues = new List<string>();
            structDataNew.strListOutputValues = new List<string>();
            structDataNew.strListGroups = new List<string>();


            if (structData.strListOutputValues.Count > 0)
            {
                for (int i = 0; i < structData.strListOutputValues.Count; i++)
                {
                    if (!structData.strListOutputValues[i].Contains("NaN"))
                    {
                        structDataNew.iListActualInputSizes.Add(structData.iListActualInputSizes[i]);
                        structDataNew.iListActualOutputSizes.Add(structData.iListActualOutputSizes[i]);
                        structDataNew.strListIsValidRecords.Add(structData.strListIsValidRecords[i]);
                        structDataNew.strListLotIds.Add(structData.strListLotIds[i]);
                        structDataNew.strListUsedTimeStamps.Add(structData.strListUsedTimeStamps[i]);
                        structDataNew.strListInputValues.Add(structData.strListInputValues[i]);
                        structDataNew.strListOutputValues.Add(structData.strListOutputValues[i]);
                        structDataNew.strListGroups.Add(structData.strListGroups[i]);
                    }
                }
            }
            return structDataNew;
        }

        private static structCOMMON_GetLotRunHistory ListLotsWithMetrology_Common(structCOMMON_GetLotRunHistory structData)
        {
            structCOMMON_GetLotRunHistory structDataNew = new structCOMMON_GetLotRunHistory();
            structDataNew.iListActualInputSizes = new List<int>();
            structDataNew.iListActualOutputSizes = new List<int>();
            structDataNew.strListIsValidRecords = new List<string>();
            structDataNew.strListLotIds = new List<string>();
            structDataNew.strListUsedTimeStamps = new List<string>();
            structDataNew.strListInputValues = new List<string>();
            structDataNew.strListOutputValues = new List<string>();
            structDataNew.strListGroups = new List<string>();


            if (structData.strListIsValidRecords.Count > 0)
            {
                for (int i = 0; i < structData.strListIsValidRecords.Count; i++)
                {
                    if (structData.strListIsValidRecords[i].Equals("True"))
                    {
                        structDataNew.iListActualInputSizes.Add(structData.iListActualInputSizes[i]);
                        structDataNew.iListActualOutputSizes.Add(structData.iListActualOutputSizes[i]);
                        structDataNew.strListIsValidRecords.Add(structData.strListIsValidRecords[i]);
                        structDataNew.strListLotIds.Add(structData.strListLotIds[i]);
                        structDataNew.strListUsedTimeStamps.Add(structData.strListUsedTimeStamps[i]);
                        structDataNew.strListInputValues.Add(structData.strListInputValues[i]);
                        structDataNew.strListOutputValues.Add(structData.strListOutputValues[i]);
                        structDataNew.strListGroups.Add(structData.strListGroups[i]);
                    }
                }
            }
            return structDataNew;
        }

        private static structPH_CD_GetLotRunHistory ListLotsWithMetrology_CD(structPH_CD_GetLotRunHistory structData)
        {
            structPH_CD_GetLotRunHistory structDataNew = new structPH_CD_GetLotRunHistory();
            structDataNew.strCurrentR2RMode = structData.strCurrentR2RMode;
            structDataNew.strListIsValidRecords = new List<string>();
            structDataNew.strListLotIds = new List<string>();
            structDataNew.strListUsedTimeStamps = new List<string>();
            structDataNew.strListCD = new List<string>();
            structDataNew.strListDose = new List<string>();


            if (structData.strListIsValidRecords.Count > 0)
            {
                for (int i = 0; i < structData.strListIsValidRecords.Count; i++)
                {
                    if (structData.strListIsValidRecords[i].Equals("True"))
                    {
                        structDataNew.strListIsValidRecords.Add(structData.strListIsValidRecords[i]);
                        structDataNew.strListLotIds.Add(structData.strListLotIds[i]);
                        structDataNew.strListUsedTimeStamps.Add(structData.strListUsedTimeStamps[i]);
                        structDataNew.strListCD.Add(structData.strListCD[i]);
                        structDataNew.strListDose.Add(structData.strListDose[i]);
                    }
                }
            }
            return structDataNew;
        }
        private static structPH_Focus_GetLotRunHistory ListLotsWithMetrology_Focus(structPH_Focus_GetLotRunHistory structData)
        {
            structPH_Focus_GetLotRunHistory structDataNew = new structPH_Focus_GetLotRunHistory();
            structDataNew.strCurrentR2RMode = structData.strCurrentR2RMode;
            structDataNew.strListIsValidRecords = new List<string>();
            structDataNew.strListLotIds = new List<string>();
            structDataNew.strListUsedTimeStamps = new List<string>();
            structDataNew.strListCD = new List<string>();
            structDataNew.strListFocus = new List<string>();


            if (structData.strListIsValidRecords.Count > 0)
            {
                for (int i = 0; i < structData.strListIsValidRecords.Count; i++)
                {
                    if (structData.strListIsValidRecords[i].Equals("True"))
                    {
                        structDataNew.strListIsValidRecords.Add(structData.strListIsValidRecords[i]);
                        structDataNew.strListLotIds.Add(structData.strListLotIds[i]);
                        structDataNew.strListUsedTimeStamps.Add(structData.strListUsedTimeStamps[i]);
                        structDataNew.strListCD.Add(structData.strListCD[i]);
                        structDataNew.strListFocus.Add(structData.strListFocus[i]);
                    }
                }
            }
            return structDataNew;
        }
        #endregion

        #region old
        public struct structCommonGroupValue
        {
            public List<List<string>> strListGroupLotIds;
            public List<List<string>> strListGroupUsedTimeStamps;
            public List<List<string>> strListGroupInputValues;
            public List<List<string>> strListGroupOutputValues;
        };
        private static structCommonGroupValue GetCommonGroupValue(List<List<int>> iListGroupIndexs, List<string> strListLotIds, List<string> strListUsedTimeStamps, List<string> strListInputValues, List<string> strListOutputValues)
        {
            List<List<string>> strListGroupLotIds = new List<List<string>>();
            List<List<string>> strListGroupUsedTimeStamps = new List<List<string>>();
            List<List<string>> strListGroupInputValues = new List<List<string>>();
            List<List<string>> strListGroupOutputValues = new List<List<string>>();


            structCommonGroupValue structData = new structCommonGroupValue();

            for (int i = 0; i < iListGroupIndexs.Count; i++)
            {
                List<string> strListLotIdsTemp = new List<string>();
                List<string> strListUsedTimeStampsTemp = new List<string>();
                List<string> strListInputValuesTemp = new List<string>();
                List<string> strListOutputValuesTemp = new List<string>();
                for (int t = 0; t < iListGroupIndexs[i].Count; t++)
                {
                    strListLotIdsTemp.Add(strListLotIds[iListGroupIndexs[i][t]]);
                    strListUsedTimeStampsTemp.Add(strListUsedTimeStamps[iListGroupIndexs[i][t]]);
                    strListInputValuesTemp.Add(strListInputValues[iListGroupIndexs[i][t]]);
                    strListOutputValuesTemp.Add(strListOutputValues[iListGroupIndexs[i][t]]);
                }
                strListGroupLotIds.Add(strListLotIdsTemp);
                strListGroupUsedTimeStamps.Add(strListUsedTimeStampsTemp);
                strListGroupInputValues.Add(strListInputValuesTemp);
                strListGroupOutputValues.Add(strListOutputValuesTemp);
            }
            structData.strListGroupLotIds = new List<List<string>>(strListGroupLotIds);
            structData.strListGroupUsedTimeStamps = new List<List<string>>(strListGroupUsedTimeStamps);
            structData.strListGroupInputValues = new List<List<string>>(strListGroupInputValues);
            structData.strListGroupOutputValues = new List<List<string>>(strListGroupOutputValues);

            return structData;
        }

        private static void GetCommonGroupChartTest(int index, structCommonGroupValue structData, ref List<List<Chart>> ctlListInputChartGroup, ref List<List<Chart>> ctlListOutputChartGroup, List<string> strListInputNames, List<string> strListOutputNames)
        {
            //ctlListInputChartGroup.Clear();
            //ctlListOutputChartGroup.Clear();
            for (int i = 0; i < index; i++)
            {
                List<List<double>> dListInputValuesResultGroup = new List<List<double>>();
                List<List<double>> dListOutputValuesResultGroup = new List<List<double>>();
                List<Chart> ctlListInputChartTemp = new List<Chart>();
                List<Chart> ctlListOutputChartTemp = new List<Chart>();

                List<List<string>> strGroupListLotIdsInput = new List<List<string>>();
                List<List<string>> strGroupListLotIdsOutput = new List<List<string>>();
                dListInputValuesResultGroup = GetItemValues(structData.strListGroupInputValues[i], ref strGroupListLotIdsInput, structData.strListGroupLotIds[i]);
                dListOutputValuesResultGroup = GetItemValues(structData.strListGroupOutputValues[i], ref strGroupListLotIdsOutput, structData.strListGroupLotIds[i]);

                AddControlHelp.AddCommonChartToList(ref ctlListInputChartTemp, 2, strListInputNames, dListInputValuesResultGroup, strGroupListLotIdsInput);
                AddControlHelp.AddCommonChartToList(ref ctlListOutputChartTemp, 2, strListOutputNames, dListOutputValuesResultGroup, strGroupListLotIdsOutput);
                ctlListInputChartGroup.Add(ctlListInputChartTemp);
                ctlListOutputChartGroup.Add(ctlListOutputChartTemp);
            }
        }

        private static void GetCommonGroupChart(int index, structCommonGroupValue structData, ref List<List<Chart>> ctlListInputChartGroup, ref List<List<Chart>> ctlListOutputChartGroup, List<string> strListInputNames, List<string> strListOutputNames)
        {
            //ctlListInputChartGroup.Clear();
            //ctlListOutputChartGroup.Clear();
            for (int i = 0; i < index; i++)
            {
                List<List<double>> dListInputValuesResultGroup = new List<List<double>>();
                List<List<double>> dListOutputValuesResultGroup = new List<List<double>>();
                List<Chart> ctlListInputChartTemp = new List<Chart>();
                List<Chart> ctlListOutputChartTemp = new List<Chart>();

                dListInputValuesResultGroup = GetItemValues(structData.strListGroupInputValues[i]);
                dListOutputValuesResultGroup = GetItemValues(structData.strListGroupOutputValues[i]);
                AddControlHelp.AddCommonChartToList(ref ctlListInputChartTemp, 2, strListInputNames, dListInputValuesResultGroup, structData.strListGroupLotIds[i]);
                AddControlHelp.AddCommonChartToList(ref ctlListOutputChartTemp, 2, strListOutputNames, dListOutputValuesResultGroup, structData.strListGroupLotIds[i]);
                ctlListInputChartGroup.Add(ctlListInputChartTemp);
                ctlListOutputChartGroup.Add(ctlListOutputChartTemp);
            }
        }
        #endregion

        private static List<List<int>> GetGroupIndex(List<string> strList)
        {
            List<List<int>> iListIndexs = new List<List<int>>();
            List<string> strListGroup = new List<string>();

            strListGroup = GetGroupName(strList);
            foreach (var str in strListGroup)
            {
                List<int> iListIndex = new List<int>();
                for (int i = 0; i < strList.Count; i++)
                {
                    if (str.Equals(strList[i]))
                    {
                        iListIndex.Add(i);
                    }
                }
                iListIndexs.Add(iListIndex);
            }
            return iListIndexs;
        }

        public static List<string> GetGroupName(List<string> strList)
        {
            List<string> strGroup = new List<string>();
            //strList = new List<string>() { "p1", "p1", "p1", "p2", "p2", "p3", "p3", "p4" };
            var q = strList.GroupBy(x => x).Where(x => x.Count() > 0).ToList();

            foreach (var item in q)
            {
                //List<string> str = new List<string>(item.ToList());
                //foreach (var s in str)
                //{
                //    MessageBox.Show(s);
                //}
                //MessageBox.Show(item.Key);
                strGroup.Add(item.Key);
            }
            strGroup.Sort();
            return strGroup;
        }

        public static List<List<double>> GetItemValues(List<string> strListUsedTime, List<string> strListValue, ref List<List<string>> strGroupListLotIds, List<string> strListLotIds)
        {
            GetSortListAndValue(strListUsedTime, ref strListValue, ref strListLotIds);

            List<List<string>> strListTemp = new List<List<string>>();
            List<List<double>> dGroupListValue = new List<List<double>>();

            strListTemp = GetItemValuesTemp(strListValue);
            //dGroupListValue.Clear();
            if (strListTemp.Count > 0)
            {
                strGroupListLotIds = new List<List<string>>();
                for (int n = 0; n < strListTemp[0].Count; n++)
                {
                    int dCount = 0;
                    List<double> dListValue = new List<double>();
                    List<string> strListLotIdsNew = new List<string>();

                    #region test
                    for (int i = 0; i < strListTemp.Count; i++)
                    {
                        if (RegexHelp.IsDoubleValue(strListTemp[i][n]))
                        {
                            dListValue.Add(double.Parse(strListTemp[i][n]));
                        }
                        else
                        {
                            //System.Windows.Forms.MessageBox.Show("Add NaN");
                            dListValue.Add(double.NaN);
                        }
                    }
                    dGroupListValue.Add(dListValue);
                    strGroupListLotIds.Add(strListLotIds);
                    #endregion

                    #region
                    //for (int i = 0; i < strListTemp.Count; i++)
                    //{
                    //    dListValue.Add(double.Parse(strListTemp[i][n]));
                    //    if (RegexHelp.IsDoubleValue(strListTemp[i][n]))
                    //    {
                    //        dCount++;
                    //        //dListValue.Add(double.Parse(strListTemp[i][n]));
                    //        //strListLotIdsNew.Add(strListLotIds[i]);
                    //    }
                    //    else
                    //    {
                    //        //System.Windows.Forms.MessageBox.Show("Add NaN");
                    //    }
                    //}
                    //if (dCount > 0)
                    //{
                    //    dGroupListValue.Add(dListValue);
                    //    //strGroupListLotIds.Add(strListLotIdsNew);
                    //    strGroupListLotIds.Add(strListLotIds);
                    //}
                    #endregion
                }
            }
            return dGroupListValue;
        }
        public static List<List<double>> GetItemValues(List<string> strListUsedTime, List<string> strListValue, int index, int count, ref List<List<string>> strGroupListLotIds, List<string> strListLotIds)
        {
            GetSortListAndValue(strListUsedTime, ref strListValue, ref strListLotIds);

            List<List<string>> strListTemp = new List<List<string>>();
            List<List<double>> dGroupListValue = new List<List<double>>();

            strListTemp = GetItemValuesTemp(strListValue);
            //dGroupListValue.Clear();
            if (strListTemp.Count > 0)
            {
                for (int n = index; n < index + count; n++)
                {
                    int dCount = 0;
                    List<double> dListValue = new List<double>();
                    List<string> strListLotIdsNew = new List<string>();

                    #region test
                    for (int i = 0; i < strListTemp.Count; i++)
                    {
                        if (RegexHelp.IsDoubleValue(strListTemp[i][n]))
                        {
                            dListValue.Add(double.Parse(strListTemp[i][n]));
                        }
                        else
                        {
                            //System.Windows.Forms.MessageBox.Show("Add NaN");
                            dListValue.Add(double.NaN);
                        }
                    }
                    dGroupListValue.Add(dListValue);
                    strGroupListLotIds.Add(strListLotIds);
                    #endregion

                    #region
                    //for (int i = 0; i < strListTemp.Count; i++)
                    //{
                    //    dListValue.Add(double.Parse(strListTemp[i][n]));
                    //    if (RegexHelp.IsDoubleValue(strListTemp[i][n]))
                    //    {
                    //        dCount++;
                    //        //dListValue.Add(double.Parse(strListTemp[i][n]));
                    //        //strListLotIdsNew.Add(strListLotIds[i]);
                    //    }
                    //}
                    //if (dCount > 0)
                    //{
                    //    dGroupListValue.Add(dListValue);
                    //    //strGroupListLotIds.Add(strListLotIdsNew);
                    //    strGroupListLotIds.Add(strListLotIds);
                    //}
                    #endregion
                }
            }
            return dGroupListValue;
        }

        #region old
        private static List<List<double>> GetItemValues(List<string> strListValue, ref List<List<string>> strGroupListLotIds, List<string> strListLotIds)
        {
            List<List<string>> strListTemp = new List<List<string>>();
            List<List<double>> dGroupListValue = new List<List<double>>();

            strListTemp = GetItemValuesTemp(strListValue);
            dGroupListValue.Clear();
            if (strListTemp.Count > 0)
            {
                strGroupListLotIds = new List<List<string>>();
                for (int n = 0; n < strListTemp[0].Count; n++)
                {
                    List<double> dListValue = new List<double>();
                    List<string> strListLotIdsNew = new List<string>();
                    for (int i = 0; i < strListTemp.Count; i++)
                    {
                        if (RegexHelp.IsDoubleValue(strListTemp[i][n]))
                        {
                            dListValue.Add(double.Parse(strListTemp[i][n]));
                            strListLotIdsNew.Add(strListLotIds[i]);
                        }
                    }
                    dGroupListValue.Add(dListValue);
                    strGroupListLotIds.Add(strListLotIdsNew);
                }
            }
            return dGroupListValue;
        }
        private static List<List<double>> GetItemValues(List<string> strListValue, int index, int count, ref List<List<string>> strGroupListLotIds, List<string> strListLotIds)
        {
            List<List<string>> strListTemp = new List<List<string>>();
            List<List<double>> dGroupListValue = new List<List<double>>();

            strListTemp = GetItemValuesTemp(strListValue);
            dGroupListValue.Clear();
            if (strListTemp.Count > 0)
            {
                for (int n = index; n < index + count; n++)
                {
                    List<double> dListValue = new List<double>();
                    List<string> strListLotIdsNew = new List<string>();
                    for (int i = 0; i < strListTemp.Count; i++)
                    {
                        if (RegexHelp.IsDoubleValue(strListTemp[i][n]))
                        {
                            dListValue.Add(double.Parse(strListTemp[i][n]));
                            strListLotIdsNew.Add(strListLotIds[i]);
                        }
                    }
                    dGroupListValue.Add(dListValue);
                    strGroupListLotIds.Add(strListLotIdsNew);
                }
            }
            return dGroupListValue;
        }
        private static List<List<double>> GetItemValues(List<string> strList)
        {
            List<List<string>> strListTemp = new List<List<string>>();
            List<List<double>> strListResult = new List<List<double>>();
            double dValue = 0.0;

            strListTemp = GetItemValuesTemp(strList);
            strListResult.Clear();
            if (strListTemp.Count > 0)
            {
                for (int n = 0; n < strListTemp[0].Count; n++)
                {
                    List<double> strListValue = new List<double>();
                    for (int i = 0; i < strListTemp.Count; i++)
                    {
                        //double.TryParse(strListTemp[i][n], out dValue);
                        //strListValue.Add(dValue);

                        //if (RegexHelp.IsDoubleValue(strListTemp[i][n]))
                        //{
                        strListValue.Add(double.Parse(strListTemp[i][n]));
                        //}
                        //else
                        //{
                        //    strListValue.Add(0.0);
                        //}
                    }
                    strListResult.Add(strListValue);
                }
            }
            return strListResult;
        }

        private static List<List<double>> GetItemValues(List<string> strList, int index, int count)
        {
            List<List<string>> strListTemp = new List<List<string>>();
            List<List<double>> dListResult = new List<List<double>>();

            strListTemp = GetItemValuesTemp(strList);
            dListResult.Clear();
            if (strListTemp.Count > 0)
            {
                for (int n = index; n < index + count; n++)
                {
                    List<double> dListValue = new List<double>();
                    for (int i = 0; i < strListTemp.Count; i++)
                    {
                        dListValue.Add(double.Parse(strListTemp[i][n]));
                    }
                    dListResult.Add(dListValue);
                }
            }
            return dListResult;
        }
        #endregion

        private static List<List<string>> GetItemValuesTemp(List<string> strList)
        {
            List<string> strListTemp = new List<string>();
            List<string> strListFormat = new List<string>();
            List<List<string>> strListResult = new List<List<string>>();
            if (strList.Count > 0)
            {
                strListFormat = FormatItemValues(strList);
                foreach (var str in strListFormat)
                {
                    strListTemp = SplitString(str);
                    strListResult.Add(strListTemp);
                }
            }
            return strListResult;
        }

        private static List<string> FormatItemValues(List<string> strList)
        {
            List<string> strListResult = new List<string>();
            if (strList.Count > 0)
            {
                string str;
                for (int i = 0; i < strList.Count; i++)
                {
                    str = strList[i].TrimEnd(']');
                    str = str.TrimStart('[');
                    strListResult.Add(str.Trim());
                }
            }
            return strListResult;
        }
        private static List<string> SplitString(string str)
        {
            List<string> strList = new List<string>();
            if (str != "")
            {
                string[] strArray = str.Split(new char[] { ' ' });
                strList = new List<string>(strArray);
            }
            return strList;
        }
    }
}

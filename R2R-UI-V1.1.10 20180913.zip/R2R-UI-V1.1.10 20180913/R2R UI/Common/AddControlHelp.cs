﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace R2R_UI.Common
{
    class AddControlHelp
    {
        #region Set Lable Location
        public static void SetLable(Panel ctlPanel, Label ctlLable, string strLblTxt)
        {
            ctlLable.Text = strLblTxt;
            ctlLable.Location = new Point(Convert.ToInt32(ctlPanel.Width - ctlLable.Width) / 2,
                                        Convert.ToInt32(ctlPanel.Height - ctlLable.Height) / 2);
        }
        #endregion

        #region Add ChartToList
        public static void AddOVLChartToList(ref List<Chart> listChart, int chartType, List<string> strListChartName, List<List<double>> dListValues, List<string> strListChartColumn)
        {
            listChart.Clear();
            for (int n = 0; n < dListValues.Count; n++)
            {
                Chart chart = new Chart();
                if (chartType == 1)
                {
                    //chart = ChartHelp.CreateColumnChart("Input " + n, dListValues[n], strListChartColumn);
                    chart = ChartHelp.CreateColumnChart(strListChartName[n], dListValues[n], strListChartColumn);
                }
                else if (chartType == 2)
                {
                    //chart = ChartHelp.CreateLineChart("Output " + n, dListValues[n], strListChartColumn);
                    chart = ChartHelp.CreateLineChart(strListChartName[n], dListValues[n], strListChartColumn);
                }

                chart.Name = "chartPanNum" + n;
                listChart.Add(chart);
            }
        }
        public static void AddCommonChartToList(ref List<Chart> listChart, int chartType, List<string> strListChartName, List<List<double>> dListValues, List<List<string>> strGroupListChartColumn)
        {
            //List<double> dListMax = new List<double>() { 1, 1, 1,1,1,1,1,1};
            //List<double> dListMin = new List<double>() { 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5 };
            listChart.Clear();
            for (int n = 0; n < dListValues.Count; n++)
            {
                Chart chart = new Chart();
                if (chartType == 1)
                {
                    //chart = ChartHelp.CreateCompositeChart("Input " + n, dListValues[n], dListMax, dListMin,strListChartColumn);
                    //chart = ChartHelp.CreateColumnChart("Input " + n, dListValues[n], strListChartColumn);
                    chart = ChartHelp.CreateColumnChart(strListChartName[n], dListValues[n], strGroupListChartColumn[n]);
                }
                else if (chartType == 2)
                {
                    //chart = ChartHelp.CreateLineChart("Output " + n, dListValues[n], dListMax, dListMin, strListChartColumn);
                    //chart = ChartHelp.CreateLineChart("Output " + n, dListValues[n], strListChartColumn);
                    chart = ChartHelp.CreateLineChart(strListChartName[n], dListValues[n], strGroupListChartColumn[n]);
                }

                chart.Name = "chartPanNum" + n;
                listChart.Add(chart);
            }
        }

        public static void AddCommonChartToList(ref List<Chart> listChart, int chartType, List<string> strListChartName, List<List<double>> dListValues, List<List<string>> strGroupListChartColumn,int chartCount)
        {
            //List<double> dListMax = new List<double>() { 1, 1, 1,1,1,1,1,1};
            //List<double> dListMin = new List<double>() { 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5 };
            listChart.Clear();
            for (int n = 0; n < chartCount; n++)
            {
                Chart chart = new Chart();
                if (chartType == 1)
                {
                    //chart = ChartHelp.CreateCompositeChart("Input " + n, dListValues[n], dListMax, dListMin,strListChartColumn);
                    //chart = ChartHelp.CreateColumnChart("Input " + n, dListValues[n], strListChartColumn);
                    chart = ChartHelp.CreateColumnChart(strListChartName[n], dListValues[n], strGroupListChartColumn[n]);
                }
                else if (chartType == 2)
                {
                    //chart = ChartHelp.CreateLineChart("Output " + n, dListValues[n], dListMax, dListMin, strListChartColumn);
                    //chart = ChartHelp.CreateLineChart("Output " + n, dListValues[n], strListChartColumn);
                    chart = ChartHelp.CreateLineChart(strListChartName[n], dListValues[n], strGroupListChartColumn[n]);
                }

                chart.Name = "chartPanNum" + n;
                listChart.Add(chart);
            }
        }

        public static void AddCommonChartToList(ref List<Chart> listChart, int chartType, List<string> strListChartName, List<List<double>> dListValues, List<string> strListChartColumn)
        {
            //List<double> dListMax = new List<double>() { 1, 1, 1,1,1,1,1,1};
            //List<double> dListMin = new List<double>() { 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5 };
            listChart.Clear();
            for (int n = 0; n < dListValues.Count; n++)
            {
                Chart chart = new Chart();
                if (chartType == 1)
                {
                    //chart = ChartHelp.CreateCompositeChart("Input " + n, dListValues[n], dListMax, dListMin,strListChartColumn);
                    //chart = ChartHelp.CreateColumnChart("Input " + n, dListValues[n], strListChartColumn);
                    chart = ChartHelp.CreateColumnChart(strListChartName[n], dListValues[n], strListChartColumn);
                }
                else if (chartType == 2)
                {
                    //chart = ChartHelp.CreateLineChart("Output " + n, dListValues[n], dListMax, dListMin, strListChartColumn);
                    //chart = ChartHelp.CreateLineChart("Output " + n, dListValues[n], strListChartColumn);
                    chart = ChartHelp.CreateLineChart(strListChartName[n], dListValues[n], strListChartColumn);
                }

                chart.Name = "chartPanNum" + n;
                listChart.Add(chart);
            }
        }
        #endregion

        #region AddChartToPanel
        public static void AddChartToPanel(Panel ctlPanel, List<Chart> listChart)
        {
            int locationX = 0;
            int locationY = 0;
            int chartWidth = 0;
            for (int n = 0; n < listChart.Count; n++)
            {
                Chart chart = new Chart();
                if (n == 0)
                {
                    chart = listChart[0];
                    locationX = chart.Location.X;
                    locationY = chart.Location.Y;
                    chartWidth = chart.Width + 10;
                }
                else
                {
                    chart = listChart[n];
                    locationX = locationX + chartWidth;
                    locationY = chart.Location.Y;
                    chart.Location = new Point(locationX, locationY);
                }
                chart.Name = "chartPanNum" + n;
                ctlPanel.Controls.Add(chart);
            }
        }

        public static void AddChartToPanel(Panel ctlPanel, List<Chart> listChart, int colCount)
        {
            int locationX = 0;
            int locationY = 0;
            int chartWidth = 0;
            int chartHeight = 0;

            for (int n = 0; n < listChart.Count; n++)
            {
                Chart chart = new Chart();

                if (n == 0)
                {
                    chart = listChart[0];
                    locationX = chart.Location.X;
                    locationY = chart.Location.Y;
                    chartWidth = chart.Width + 10;
                }
                else
                {
                    chart = listChart[n];
                    locationX = locationX + chartWidth;
                    locationY = chart.Location.Y;
                }
                if (colCount == 2)
                {
                    chartHeight = listChart[0].Height;
                    locationY = chartHeight + 10;
                }
                chart.Location = new Point(locationX, locationY);
                //chart.Name = "chartPanNum" + n;
                ctlPanel.Controls.Add(chart);
            }
        }

        public static void AddChartToPanel(Panel ctlPanel, List<Chart> listInputChart, List<Chart> listOutputChart)
        {
            AddChartToPanel(ctlPanel, listInputChart, 1);
            AddChartToPanel(ctlPanel, listOutputChart, 2);

            #region old input/output same
            //int locationX = 0;
            //int locationY = 0;
            //int chartWidth = 0;
            //int chartHeight = 0;

            //for (int n = 0; n < listInputChart.Count; n++)
            //{
            //    Chart chart = new Chart();
            //    Chart chart2 = new Chart();
            //    chartHeight = listInputChart[0].Height;

            //    if (n == 0)
            //    {
            //        chart = listInputChart[0];
            //        chart2 = listOutputChart[0];
            //        locationX = chart.Location.X;
            //        locationY = chart.Location.Y;
            //        chartWidth = chart.Width + 10;
            //    }
            //    else
            //    {
            //        chart = listInputChart[n];
            //        chart2 = listOutputChart[n];
            //        locationX = locationX + chartWidth;
            //        locationY = chart.Location.Y;
            //        chart.Location = new Point(locationX, locationY);
            //    }
            //    chart.Name = "chartPanCol1_" + n;
            //    ctlPanel.Controls.Add(chart);
            //    chart2.Location = new Point(locationX, chartHeight + 10);
            //    chart2.Name = "chartPanCol2_" + n;
            //    ctlPanel.Controls.Add(chart2);
            //}
            #endregion

            #region old input/output not same
            //int locationX = 0;
            //int locationY = 0;
            //int chartWidth = 0;
            //int chartHeight = 0;

            //AddChartToPanel(ctlPanel, listInputChart);

            //for (int n = 0; n < listOutputChart.Count; n++)
            //{
            //    Chart chart = new Chart();
            //    chartHeight = listOutputChart[0].Height;
            //    if (n == 0)
            //    {
            //        chart = listOutputChart[0];
            //        locationX = chart.Location.X;
            //        locationY = chart.Location.Y;
            //        chartWidth = chart.Width + 10;
            //    }
            //    else
            //    {
            //        chart = listOutputChart[n];
            //        locationX = locationX + chartWidth;
            //        locationY = chart.Location.Y;
            //    }
            //    chart.Location = new Point(locationX, chartHeight + 10);
            //    //chart.Name = "chartPanNum" + n;
            //    ctlPanel.Controls.Add(chart);
            //}
            #endregion
        }
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.DataVisualization.Charting;

namespace R2R_UI.Common
{
    class ChartHelp
    {
        #region Create Chart
        public static Chart CreateColumnChart(string strChartTitle, List<double> dListValue, List<string> strListChartColumn)
        {
            Chart chart = new Chart();
            chart.Titles.Add(strChartTitle);

            ChartArea chartArea = new ChartArea();
            chart.ChartAreas.Add(chartArea);
            SetChartAreaAxisX(chartArea);
            SetChartAreaAxisY(chartArea);

            chart.Series.Clear();
            Series series = new Series("series");
            SetSeries(series,2);
            series.Points.DataBindXY(strListChartColumn, dListValue);
            //series.LegendToolTip = "value";//鼠标放到系列上出现的文字 
            chart.Series.Add(series);

            return chart;
        }

        public static Chart CreateLineChart(string strChartTitle, List<double> dListValue, List<string> strListChartColumn)
        {
            Chart chart = new Chart();
            chart.Titles.Add(strChartTitle);

            ChartArea chartArea = new ChartArea();           
            chart.ChartAreas.Add(chartArea);
            SetChartAreaAxisX(chartArea);
            SetChartAreaAxisY(chartArea);
            //chartArea.Area3DStyle.Enable3D = true;

            chart.Series.Clear();
            Series series = new Series("series");
            SetSeries(series);
            series.Points.DataBindXY(strListChartColumn, dListValue);
            //series.LegendToolTip = "value";//鼠标放到系列上出现的文字 
            chart.Series.Add(series);

            return chart;
        }
        #endregion

        #region Set Chart
        private static void SetChartAreaAxisX(ChartArea chartArea)
        {
            //chartArea.AxisX.Title = strTitle;
            chartArea.AxisX.MajorGrid.Interval = 0.5;
            chartArea.AxisX.MajorGrid.Enabled = true;
            chartArea.AxisX.MinorTickMark.Enabled = false;
            chartArea.AxisX.IsMarginVisible = true;
            chartArea.AxisX.TitleForeColor = Color.Crimson;
            //chartArea.AxisX.TextOrientation = TextOrientation.Rotated90;
            //chartArea.AxisX.IsInterlaced = true;  //显示交错带 
            //chartArea.AxisX.LabelStyle.Format = "#";                      //设置X轴显示样式

            //显示所有的标签
            //chartArea.AxisX.LabelAutoFitStyle = LabelAutoFitStyles.None;
            //chartArea.AxisX.LabelStyle.Interval = 1;

            //显示所有的标签
            chartArea.AxisX.Interval = 1;

            //显示所有的标签
            //chartArea.AxisX.IntervalAutoMode = IntervalAutoMode.VariableCount;
            //chartArea.AxisX.IsStartedFromZero = true;
            //chartArea.AxisX.LabelStyle.Angle = -90;                      //设置X轴显示样式

            chartArea.AxisX.LabelStyle.Angle = -90;                      //设置X轴显示样式
        }
        private static void SetChartAreaAxisY(ChartArea chartArea)
        {
            //chartArea.AxisY.Title = strTitle;
            //chartArea.AxisY.MajorGrid.Interval = 0.5;
            chartArea.AxisY.MajorGrid.Enabled = true;
            chartArea.AxisY.TitleForeColor = Color.Crimson;
            chartArea.AxisY.TextOrientation = TextOrientation.Horizontal;
        }
        private static void SetSeries(Series series)
        {
            series.ChartType = SeriesChartType.Line;
            //series.ChartType = SeriesChartType.Column;
            series.BorderWidth = 3;            //线条粗细
            series.Color = Color.YellowGreen;            //线条颜色

            //series.IsValueShownAsLabel = true;
            //series.Label = "#VAL";                //设置显示X Y的值

            series.ToolTip = "#VAL";     //鼠标移动到对应点显示数值

            SetSeriesMarker(series);

            ////饼图说明设置，这用来设置饼图每一块的信息显示在什么地方
            //series["PieLabelStyle"] = "Outside";//将文字移到外侧
            //series["PieLineColor"] = "Black";//绘制黑色的连线。

            ////柱状图其他设置
            //series["DrawingStyle"] = "Emboss";   //设置柱状平面形状
            //series["PointWidth"] = "0.5"; //设置柱状大小
        }
        private static void SetSeries(Series series,int chartType)
        {
            if (chartType == 1)
            {
                series.ChartType = SeriesChartType.Line;
            }
            else if(chartType == 2)
            {
                series.ChartType = SeriesChartType.Column;
            }

            series.BorderWidth = 3;            //线条粗细
            series.Color = Color.YellowGreen;            //线条颜色

            //series.IsValueShownAsLabel = true;
            //series.Label = "#VAL";                //设置显示X Y的值

            series.ToolTip = "#VAL";     //鼠标移动到对应点显示数值

            SetSeriesMarker(series);

            ////饼图说明设置，这用来设置饼图每一块的信息显示在什么地方
            //series["PieLabelStyle"] = "Outside";//将文字移到外侧
            //series["PieLineColor"] = "Black";//绘制黑色的连线。

            ////柱状图其他设置
            //series["DrawingStyle"] = "Emboss";   //设置柱状平面形状
            //series["PointWidth"] = "0.5"; //设置柱状大小
        }
        private static void SetSeriesMarker(Series series)
        {
            series.MarkerBorderColor = Color.Black;            //标记点边框颜色     
            series.MarkerBorderWidth = 3;            //标记点边框大小
            series.MarkerColor = Color.Red;            //标记点中心颜色
            series.MarkerSize = 8;            //标记点大小
            series.MarkerStyle = MarkerStyle.Circle;            //标记点类型    
        }

        private void SetMajorGridX(ChartArea chartArea)
        {
            //设置主刻度线和副刻度线 一般只有主刻度线才有对应标签值。  
            chartArea.AxisX.MajorGrid.Interval = 0.5;
            chartArea.AxisX.MajorGrid.Enabled = true;
            chartArea.AxisX.MinorTickMark.Enabled = false;
            chartArea.AxisX.MajorGrid.Enabled = false;       //X轴上网格
            chartArea.AxisX.MajorGrid.Enabled = false;      //y轴上网格
            chartArea.AxisX.MajorGrid.LineDashStyle = ChartDashStyle.Dash;   //网格类型 短横线
            chartArea.AxisX.MajorGrid.LineColor = Color.Gray;
            chartArea.AxisX.MajorTickMark.Enabled = false;                   //  x轴上突出的小点
            chartArea.AxisX.MajorGrid.LineDashStyle = ChartDashStyle.Dash;   //网格类型 短横线
            chartArea.AxisX.MajorGrid.LineColor = Color.Gray;
            chartArea.AxisX.MajorGrid.LineWidth = 3;
        }
        private void SetMajorGridY(ChartArea chartArea)
        {
            chartArea.AxisY.MajorGrid.Interval = 0.5;
            chartArea.AxisY.MajorGrid.Enabled = true;
            chartArea.AxisY.MinorTickMark.Enabled = false;
        }
        #endregion
    }
}

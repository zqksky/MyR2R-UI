﻿using R2R_UI.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static R2R_UI.Common.UIServiceFun;

namespace R2R_UI.Present.OVL
{
    public partial class frmPreLayerConfig : Form
    {
        #region
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x0014) // 禁掉清除背景消息
                return;
            base.WndProc(ref m);
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x02000000;
                return cp;
            }
        }

        private void CtlDoubleBuffer()
        {
            this.DoubleBuffered = true;//设置本窗体
            SetStyle(ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true); // 禁止擦除背景.
            SetStyle(ControlStyles.DoubleBuffer, true); // 双缓冲
            //SetStyle(ControlStyles.DoubleBuffer | ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint, true);
            UpdateStyles();
        }
        #endregion

        public frmPreLayerConfig()
        {
            InitializeComponent();
        }
        public frmPreLayerConfig(string strServiceName, string strCurrentUserName, string strCurrentPwd,string strCurrentController)
        {
            InitializeComponent();

            strServiceAddress = strServiceName;
            strUserName = strCurrentUserName;
            strPassword = strCurrentPwd;
            strRefController = strCurrentController;
        }

        #region Param
        string strServiceAddress;
        string strUserName;
        string strPassword;

        string strProduct;
        string strLayer;
        string strLot;

        string strRefLayer;
        string strRefLotId;
        string strRefController;

        public string strPreLayerTool;
        public string strPreLayerReticle;
        public string strPreLayerPMTime;
        public string strPreLayerCPEUpdatedTime;
        public string strPreLayerModelUpdatedTime;

        structPH_OVL_GetPreLayerInfo structData = new structPH_OVL_GetPreLayerInfo();
        structPH_OVL_GetPreLayerInfo structDataUpdate = new structPH_OVL_GetPreLayerInfo();
        #endregion

        private void InitControlEnabled(bool bFlag)
        {
            txtRefLot.Enabled = bFlag;
            txtRefLayer.Enabled = bFlag;
            txtRefController.Enabled = bFlag;
            btnQuery.Enabled = bFlag;
        }
        private void ShowValueToText()
        {
            txtTool.Text = structData.strPreLayerTool;
            txtReticle.Text = structData.strPreLayerReticle;
            txtPMTime.Text = structData.strPreLayerPMTime;
            txtCPEUpdatedTime.Text = structData.strPreLayerCPEUpdatedTime;
            txtModelUpdatedTime.Text = structData.strPreLayerModelUpdatedTime;
        }

        private void rdoMode_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoManualMode.Checked)
            {
                InitControlEnabled(false);
            }
            else if (rdoReferenceMode.Checked)
            {
                InitControlEnabled(true);
            }
        }

        private float frmLocationX;
        private float frmLocationY;
        AdaptiveSizeResolution AutoSizeFrm = new AdaptiveSizeResolution();
        private void frmPreLayerConfig_Load(object sender, EventArgs e)
        {
            #region  Double Buffer
            //CtlDoubleBuffer();
            #endregion

            #region AdaptiveSizeResolution
            //AutoSizeFrm.ControllInitializeSize(this);
            #endregion

            #region  AdaptiveSize
            //this.Resize += new EventHandler(frmPreLayerConfig_Resize);
            //frmLocationX = this.Width;
            //frmLocationY = this.Height;
            //AdaptiveSize.setTag(this);
            #endregion

            #region Init
            InitControlEnabled(false);
            txtRefController.Text = strRefController;

            strProduct = txtProduct.Text.ToString().Trim();
            strLayer = txtLayer.Text.ToString().Trim();
            strLot = txtLot.Text.ToString().Trim();
            #endregion
        }

        private void frmPreLayerConfig_Resize(object sender, EventArgs e)
        {
            #region AdaptiveSize
            //float newx = (this.Width) / frmLocationX;
            //float newy = this.Height / frmLocationY;
            //AdaptiveSize.setControls(newx, newy, this);
            #endregion
        }

        private void frmPreLayerConfig_SizeChanged(object sender, EventArgs e)
        {
            #region AdaptiveSizeResolution
            //AutoSizeFrm.ControlAutoSize(this);
            #endregion
        }

        private void btnQuery_Click(object sender, EventArgs e)
        {
            #region PH_OVL_GetPreLayerInfo
            strRefLayer = txtRefLayer.Text.ToString().Trim();
            strRefLotId = txtRefLot.Text.ToString().Trim();
            strRefController=txtRefController.Text.ToString().Trim();

            if (strRefLayer != "" && strRefLotId != "")
            {
                structPH_OVL_GetPreLayerInfo structDataNull = new structPH_OVL_GetPreLayerInfo();
                structData = R2R_UI_PH_OVL_GetPreLayerInfo(strServiceAddress, strRefLayer, strRefLotId,strRefController);
                if (structData.Equals(structDataNull))
                {
                    MessageBox.Show("Data is empty!");
                }
                else
                {
                    ShowValueToText();
                }
            }
            else
            {
                MessageBox.Show("Data is empty!");
            }
            #endregion
        }

        private bool GetUpdateValue()
        {
            bool flag = true;
            strProduct = txtProduct.Text.ToString().Trim();
            strLayer = txtLayer.Text.ToString().Trim();
            strLot = txtLot.Text.ToString().Trim();
            if (strProduct.Equals("") || strLayer.Equals("") || strLot.Equals(""))
            {
                flag = false;
            }
            else
            {
                if (txtTool.Text.ToString().Trim().Equals(""))
                {
                    structDataUpdate.strPreLayerTool = "NA";
                }
                else
                {
                    structDataUpdate.strPreLayerTool = txtTool.Text.ToString().Trim();
                }
                if (txtReticle.Text.ToString().Trim().Equals(""))
                {
                    structDataUpdate.strPreLayerReticle = "NA";
                }
                else
                {
                    structDataUpdate.strPreLayerReticle = txtReticle.Text.ToString().Trim();
                }
                if (txtPMTime.Text.ToString().Trim().Equals(""))
                {
                    structDataUpdate.strPreLayerPMTime = "NA";
                }
                else
                {
                    structDataUpdate.strPreLayerPMTime = txtPMTime.Text.ToString().Trim();
                }
                if (txtCPEUpdatedTime.Text.ToString().Trim().Equals(""))
                {
                    structDataUpdate.strPreLayerCPEUpdatedTime = "NA";
                }
                else
                {
                    structDataUpdate.strPreLayerCPEUpdatedTime = txtCPEUpdatedTime.Text.ToString().Trim();
                }
                if (txtModelUpdatedTime.Text.ToString().Trim().Equals(""))
                {
                    structDataUpdate.strPreLayerModelUpdatedTime = "NA";
                }
                else
                {
                    structDataUpdate.strPreLayerModelUpdatedTime = txtModelUpdatedTime.Text.ToString().Trim();
                }
            }

            return flag;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            frmCheckedPwd frmChecked = new frmCheckedPwd(strUserName);
            if (frmChecked.ShowDialog() == DialogResult.OK)
            {
                if (frmChecked.strPassword.Equals(strPassword))
                {
                    #region
                    bool flag = false;
                    bool bSuccess;
                    try
                    {
                        #region PH_OVL_ConfigPreLayerInfo
                        flag = GetUpdateValue();
                        if (flag)
                        {
                            //bSuccess = R2R_UI_PH_OVL_ConfigPreLayerInfo(strServiceAddress, strUserName, "PRODUCT", "LAYER3", "LOT_ID_1111", structDataUpdate);
                            bSuccess = R2R_UI_PH_OVL_ConfigPreLayerInfo(strServiceAddress, strUserName, strProduct, strLayer, strLot, structDataUpdate);
                            if (bSuccess)
                            {
                                this.Close();
                            }
                            else
                            {
                                //MessageBox.Show("Set Failed!");
                            }
                            this.DialogResult = DialogResult.OK;
                        }
                        else
                        {
                            MessageBox.Show("Data is empty!");
                        }
                        #endregion
                    }
                    catch (Exception ee)
                    {
                        MessageBox.Show(ee.Message);
                    }
                    #endregion
                }
                else
                {
                    MessageBox.Show("Invalid password!");
                }
            }
            else
            {
                //MessageBox.Show("Invalid password!");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

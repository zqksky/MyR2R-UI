﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TestSerialize.BaseEnity;
using TestSerialize.BaseFun;
using TestSerialize.TestWebService;

namespace TestSerialize
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SqliteHelp sqlite;
        private void Form1_Load(object sender, EventArgs e)
        {
            WebServiceHelp.TestHttpWebservice();
            TestWebService();
            sqlite = new SqliteHelp("data source=TemporyRecord.db");
            //CreateTemporyDb();
            string strXml = GetXmlHelp.GetXmlSerialize();

            EnitySerialize myStruct = new EnitySerialize();
            myStruct = GetXmlHelp.GetStruct(strXml);

            ShowDgvRecord();
        }

        private void TestWebService()
        {
            string error;
            bool succ = WebServiceHelp.CreateWebService(out error);//先下载wsdl到本地如果本地已下载直接调用本地已下载好的dll，在把方法放到内存中以便调用
            // SOAP 请求响应方式
            //TextBox1.Text = WSHelper.GetResponseString(EMethod.Add, Convert.ToInt32(TextBox1.Text), Convert.ToInt32(TextBox2.Text));
            string strResult = WebServiceHelp.GetResponseString(EWorldWeatherFun.getRegionCountry);
        }

        private void CreateTemporyDb()
        {
            //创建名为OperationRecord的数据表
            sqlite.CreateTable("OperationRecord", new string[] { "ID","Key1", "Key2", "Modify_By_User", "Modify_Time", "Operation", "Status", "StrXml" }, new string[] { "TEXT", "TEXT", "TEXT", "TEXT", "TEXT", "TEXT", "TEXT", "TEXT" });
            sqlite.CreateTable("PreActionRecord", new string[] { "ID","Key1", "Key2", "Modify_By_User", "Modify_Time", "Operation", "Status", "StrXml" }, new string[] { "TEXT", "TEXT", "TEXT", "TEXT", "TEXT", "TEXT", "TEXT", "TEXT" });
            sqlite.CreateTable("ActionRecord", new string[] { "ID", "Key1", "Key2", "Modify_By_User", "Modify_Time", "Operation", "Status", "StrXml" }, new string[] { "TEXT", "TEXT", "TEXT", "TEXT", "TEXT", "TEXT", "TEXT", "TEXT" });
            sqlite.CreateTable("FinalRecord", new string[] { "ID", "Key1", "Key2", "Modify_By_User", "Modify_Time", "Operation", "Status", "StrXml" }, new string[] { "TEXT", "TEXT", "TEXT", "TEXT", "TEXT", "TEXT", "TEXT", "TEXT" });

            ////插入数据
            sqlite.InsertValues("OperationRecord", new string[] { "1", "Key1", "Key2", "admin", "2019-04-17", "Create", "New", "StrXml" });
            sqlite.InsertValues("OperationRecord", new string[] { "2", "Key1", "Key2", "admin", "2019-04-17", "Modify", "New", "StrXml" });
            sqlite.InsertValues("OperationRecord", new string[] { "3", "Key1", "Key2", "admin", "2019-04-17", "Deleted", "New", "StrXml" });
            sqlite.InsertValues("OperationRecord", new string[] { "4", "Key1", "Key2", "user", "2019-04-17", "Create", "New", "StrXml" });
            sqlite.InsertValues("OperationRecord", new string[] { "5", "Key1", "Key2", "user", "2019-04-17", "Modify", "New", "StrXml" });

            #region
            ////更新数据，将Name="张三"的记录中的Name改为"Zhang3"
            //sql.UpdateValues("table1", new string[] { "Name" }, new string[] { "ZhangSan" }, "Name", "Zhang3");

            ////删除Name="张三"且Age=26的记录,DeleteValuesOR方法类似
            //sql.DeleteValuesAND("table1", new string[] { "Name", "Age" }, new string[] { "张三", "22" }, new string[] { "=", "=" });

            ////读取整张表
            //SQLiteDataReader reader = sql.ReadFullTable("table1");
            //while (reader.Read())
            //{
            //    //读取ID
            //    Log("" + reader.GetInt32(reader.GetOrdinal("ID")));
            //    //读取Name
            //    Log("" + reader.GetString(reader.GetOrdinal("Name")));
            //    //读取Age
            //    Log("" + reader.GetInt32(reader.GetOrdinal("Age")));
            //    //读取Email
            //    Log(reader.GetString(reader.GetOrdinal("Email")));
            //}

            //while (true)
            //{
            //    Console.ReadLine();
            //}
            #endregion
        }

        private void ShowDgvRecord()
        {
            DataTable dbRecord = new DataTable("Record");

            dbRecord = sqlite.GetTable("OperationRecord");

            //dbRecord = DataTableHelp.CreateTable(DataTableHelp.GetColumn(), DataTableHelp.GetValue());
            dgvOperationRecord.DataSource = dbRecord;

            //sqlite.CloseConnection();
        }

        private void btnCommit_Click(object sender, EventArgs e)
        {
            ShowDgvPreAction();
            ShowDgvAction();
        }

        private List<string> GetSelectedRow(ref string strStatus, DataGridView dgv)
        {
            strStatus = string.Empty;

            List<string> strList = new List<string>();
            if (dgv.CurrentRow == null)
            {
                return strList;
            }
            else
            {
                DataGridViewRow dgvr = dgv.CurrentRow;
                strStatus = dgvr.Cells["Status"].Value.ToString();

                strList.Add(dgvr.Cells["ID"].Value.ToString());
                strList.Add(dgvr.Cells["Key1"].Value.ToString());
                strList.Add(dgvr.Cells["Key2"].Value.ToString());
                strList.Add(dgvr.Cells["Modify_By_User"].Value.ToString());
                strList.Add(dgvr.Cells["Modify_By_Time"].Value.ToString());
                strList.Add(dgvr.Cells["Operation"].Value.ToString());
                strList.Add(dgvr.Cells["Status"].Value.ToString());
                strList.Add(dgvr.Cells["StrXml"].Value.ToString());
            }

            return strList;
        }

        private void DeleteSelecteRow()
        {
            if (dgvOperationRecord.CurrentRow == null)
            {

            }
            else
            {
                DataGridViewRow dgvr = dgvOperationRecord.CurrentRow;
                string strId = dgvr.Cells["ID"].Value.ToString();

                //删除Name="张三"且Age=26的记录,DeleteValuesOR方法类似
                sqlite.DeleteValuesAND("OperationRecord", new string[] { "ID" }, new string[] { strId }, new string[] { "=" });

                dgvOperationRecord.Rows.Remove(dgvr);//删除行   
            }
        }

        private void ShowDgvPreAction()
        {
            DeleteSelecteRow();
            string strStatus = string.Empty;
            List<string> strList = new List<string>();
            strList = GetSelectedRow(ref strStatus, dgvOperationRecord);

            DataTable dbPreAction = new DataTable("PreAction");

            sqlite.InsertValues("PreActionRecord", strList.ToArray());
            dbPreAction = sqlite.GetTable("PreActionRecord");

            //List<List<string>> listStr = new List<List<string>>() { strList };
            //dbPreAction = DataTableHelp.CreateTable(DataTableHelp.GetColumn(), listStr);
            dgvPreAction.DataSource = dbPreAction;

            //sqlite.CloseConnection();
        }

        private void ShowDgvAction()
        {
            string strStatus = string.Empty;
            List<string> strList = new List<string>();
            strList = GetSelectedRow(ref strStatus, dgvOperationRecord);

            if (strStatus.Equals("New"))
            {
                strList[6]= "Approving";
            }
            if (strStatus.Equals("Approving"))
            {
                strList[6] = "Approved";
                strList[6] = "Rejected";
            }


            DataTable dbAction = new DataTable("Action");

            sqlite.InsertValues("ActionRecord", strList.ToArray());
            dbAction = sqlite.GetTable("ActionRecord");

            //List<List<string>> listStr = new List<List<string>>() { strList };
            //dbAction = DataTableHelp.CreateTable(DataTableHelp.GetColumn(), listStr);
            dgvAction.DataSource = dbAction;

        }

        private void ShowCurrentDgvAction(bool bIsApproved)
        {
            string strStatus = string.Empty;
            List<string> strList = new List<string>();
            int indexRow = dgvAction.CurrentRow.Index;
            strList = GetSelectedRow(ref strStatus, dgvAction);

            if (bIsApproved)
            {
                strList[6] = "Approved";
            }
            else
            {
                strList[6] = "Rejected";
            }

            //更新数据，将Name="张三"的记录中的Name改为"Zhang3"
            sqlite.UpdateValues("ActionRecord", new string[] { "Status" }, new string[] { strList[6] }, "ID", strList[0]);

            DataTable dbAction = new DataTable("Action");
            dbAction = sqlite.GetTable("ActionRecord");

            //List<List<string>> listStr = new List<List<string>>() { strList };
            //dbAction = DataTableHelp.CreateTable(DataTableHelp.GetColumn(), listStr);
            dgvAction.DataSource = dbAction;

            if (indexRow != 0)
            {
                dgvAction.Rows[0].Selected = false;
            }
            dgvAction.Rows[indexRow].Selected = true;
        }

        private void btnApproved_Click(object sender, EventArgs e)
        {
            ShowCurrentDgvAction(true);
        }

        private void btnRejected_Click(object sender, EventArgs e)
        {
            ShowCurrentDgvAction(false);
        }

        private void ShowDgvFianl()
        {
            string strStatus = string.Empty;
            List<string> strList = new List<string>();
            strList = GetSelectedRow(ref strStatus, dgvAction);

            string strOperation = strList[5];
            string strId = strList[0];
            string strXml = strList[7];
            if (strStatus.Equals("Approved"))
            {
                DataTable dbFinal = new DataTable("Final");

                if (strOperation.Equals("Create"))
                {
                    sqlite.InsertValues("FinalRecord", strList.ToArray());
                }
                else if (strOperation.Equals("Modify"))
                {
                    sqlite.UpdateValues("FinalRecord", new string[] { "StrXml" }, new string[] { strXml }, "ID", strList[0]);

                }
                else if (strOperation.Equals("Deleted"))
                {
                    sqlite.DeleteValuesAND("FinalRecord", new string[] { "ID" }, new string[] { strId }, new string[] { "=" });
                }

                dbFinal = sqlite.GetTable("FinalRecord");

                //List<List<string>> listStr = new List<List<string>>() { strList };
                //dbFinal = DataTableHelp.CreateTable(DataTableHelp.GetColumn(), listStr);
                dgvFinal.DataSource = dbFinal;
            }
            else if (strStatus.Equals("Approving"))
            {
                MessageBox.Show("Approving");
            }
            else if (strStatus.Equals("Rejected"))
            {
                MessageBox.Show("Rejected");
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            ShowDgvFianl();
        }

        private void InsertDgvOperationRecord()
        {
            //插入数据
            sqlite.InsertValues("OperationRecord", new string[] { "1", "Key1", "Key2", "admin", "2019-04-17", "Create", "New", "StrXml" });
            sqlite.InsertValues("OperationRecord", new string[] { "2", "Key1", "Key2", "admin", "2019-04-17", "Modify", "New", "StrXml" });
            sqlite.InsertValues("OperationRecord", new string[] { "3", "Key1", "Key2", "admin", "2019-04-17", "Deleted", "New", "StrXml" });
            sqlite.InsertValues("OperationRecord", new string[] { "4", "Key1", "Key2", "user", "2019-04-17", "Create", "New", "StrXml" });
            sqlite.InsertValues("OperationRecord", new string[] { "5", "Key1", "Key2", "user", "2019-04-17", "Modify", "New", "StrXml" });

            ShowDgvRecord();
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            InsertDgvOperationRecord();
        }
    }
}

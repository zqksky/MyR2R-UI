﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestSerialize.TestWebService
{
    /// <summary>
    /// 方法枚举
    /// </summary>
    public enum EWorldWeatherFun
    {
        getRegionCountry,
        getRegionDataset,
        getRegionProvince,
        getSupportCityDataset,
        getSupportCityString,
        getWeather
    }

    /// <summary>
    /// 方法枚举
    /// </summary>
    public enum ERequestMode
    {
        Get,
        Post
    }
}

﻿using R2R_UI.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace R2R_UI
{
    public partial class frmCheckedPwd : Form
    {
        #region
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x0014) // 禁掉清除背景消息
                return;
            base.WndProc(ref m);
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x02000000;
                return cp;
            }
        }

        private void CtlDoubleBuffer()
        {
            this.DoubleBuffered = true;//设置本窗体
            SetStyle(ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true); // 禁止擦除背景.
            SetStyle(ControlStyles.DoubleBuffer, true); // 双缓冲
            //SetStyle(ControlStyles.DoubleBuffer | ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint, true);
            UpdateStyles();
        }
        #endregion

        public frmCheckedPwd()
        {
            InitializeComponent();
        }
        public frmCheckedPwd(string strCurrentUserName)
        {
            InitializeComponent();
            strUserName = strCurrentUserName;
        }

        public string strUserName
        {
            get
            {
                return txtUserName.Text;
            }
            set
            {
                txtUserName.Text = value;
            }
        }

        public string strPassword
        {
            set
            {
                txtPwd.Text = value;
            }

            get
            {
                return txtPwd.Text;
            }
        }

        private float frmLocationX;
        private float frmLocationY;
        AdaptiveSizeResolution AutoSizeFrm = new AdaptiveSizeResolution();
        private void frmCheckedPwd_Load(object sender, EventArgs e)
        {
            this.KeyPreview = true;

            #region 双缓冲
            CtlDoubleBuffer();
            #endregion

            #region AdaptiveSizeResolution
            //AutoSizeFrm.ControllInitializeSize(this);
            #endregion

            #region  AdaptiveSize
            //this.Resize += new EventHandler(frmCheckedPwd_Resize);
            //frmLocationX = this.Width;
            //frmLocationY = this.Height;
            //AdaptiveSize.setTag(this);
            #endregion
        }
        private void frmCheckedPwd_Resize(object sender, EventArgs e)
        {
            #region AdaptiveSize
            //float newx = (this.Width) / frmLocationX;
            //float newy = this.Height / frmLocationY;
            //AdaptiveSize.setControls(newx, newy, this);
            #endregion
        }

        private void frmCheckedPwd_SizeChanged(object sender, EventArgs e)
        {
            #region AdaptiveSizeResolution
            //AutoSizeFrm.ControlAutoSize(this);
            #endregion
        }

        private void btnConfrim_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtPwd.Text))
            {
                MessageBox.Show("Please input password!");
            }
            else
            {
                this.DialogResult = DialogResult.OK;
                //this.Close();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmCheckedPwd_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)//判断回车键
            {
                //this.btnLogin.Focus();
                this.btnConfrim_Click(sender, e);//触发按钮事件
            }
        }
    }
}

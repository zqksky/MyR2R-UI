﻿using R2R_UI.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.DataVisualization.Charting;
using static R2R_UI.Common.UIServiceFun;

namespace R2R_UI.Model
{
    class LotRunHistory_OVL
    {

        private string strServiceAddress;
        private string strController;
        private List<string> strListR2RContexts = new List<string>();
        structPH_OVL_GetLotRunHistory structData = new structPH_OVL_GetLotRunHistory();
        public string strCurrentR2RMode;
        public string strCurrentOVLModel;
        public string strToolVendor;
        public bool bIsActive;
        public bool bToolVendorASML;
        public bool bLinearMode;
        public bool bHOPCMode;
        public bool bIHOPCMode;
        public bool bCPEMode;
        public bool bNotData;

        public LotRunHistory_OVL(string strServiceAddress, string strController, List<string> strListR2RContexts)
        {
            this.strServiceAddress = strServiceAddress;
            this.strController = strController;
            this.strListR2RContexts = new List<string>(strListR2RContexts);

            structPH_OVL_GetLotRunHistory structDataNull = new structPH_OVL_GetLotRunHistory();
            structData = R2R_UI_PH_OVL_GetLotRunHistory(strServiceAddress, strController, strListR2RContexts);
            if (structData.Equals(structDataNull))
            {
                bNotData = true;
            }
            else
            {
                this.strCurrentR2RMode = structData.strCurrentR2RMode;
                this.strCurrentOVLModel = structData.strCurrentOVLModel;
                this.strToolVendor = structData.strToolVendor;

                this.bIsActive = IsActive(this.strCurrentR2RMode);
                this.bLinearMode = structData.bLinearMode;
                this.bHOPCMode = structData.bHOPCMode;
                this.bIHOPCMode = structData.bIHOPCMode;
                this.bCPEMode = structData.bCPEMode;
            }
        }
        private bool IsActive(string strR2RMode)
        {
            bool flag = false;
            if (strR2RMode.Equals("Active"))
            {
                flag = true;
            }
            else
            {
                //btnOptReset.Enabled = false;
            }
            return flag;
        }

        private DataTable CreateTable(List<string> strListValueColumn1, List<string> strListValueColumn2)
        {
            DataTable db = new DataTable("OVL");

            db.Columns.Add("LOT_IDS", Type.GetType("System.String"));
            db.Columns.Add("USED_TIME_STAMPS", Type.GetType("System.String"));

            for (int i = 0; i < strListValueColumn1.Count; i++)
            {
                db.Rows.Add();
                db.Rows[i]["LOT_IDS"] = strListValueColumn1[i];
                db.Rows[i]["USED_TIME_STAMPS"] = strListValueColumn2[i];
            }

            return db;
        }
        public DataTable GetTable(int ovlType)
        {
            DataTable db = new DataTable();

            List<string> strListLotIds = new List<string>();
            List<string> strListUsedTimeStamps = new List<string>();

            if (ovlType == 1)
            {
                strListLotIds = new List<string>(structData.strListLinear_LotIds);
                strListUsedTimeStamps = new List<string>(structData.strListLinear_UsedTimeStamps);
            }
            else if (ovlType == 2)
            {
                strListLotIds = new List<string>(structData.strListHOPC_LotIds);
                strListUsedTimeStamps = new List<string>(structData.strListHOPC_UsedTimeStamps);
            }
            else if (ovlType == 3)
            {
                strListLotIds = new List<string>(structData.strListIHOPC_LotIds);
                strListUsedTimeStamps = new List<string>(structData.strListIHOPC_UsedTimeStamps);
            }
            //else if (ovlType == 4)
            //{
            //    strListLotIds = new List<string>(structData.strListCPELotIds);
            //    strListUsedTimeStamps = new List<string>(structData.strListCPE_UsedTimeStamps);
            //}
            db = CreateTable(strListLotIds, strListUsedTimeStamps);
            return db;
        }
        private void SetOVLChartParam(ref int iOutputCount, ref int iOutputStartIndex, int iOutputSize, bool bIsChuckOne)
        {
            if (strToolVendor.Equals("ASML"))
            {
                bToolVendorASML = true;
                iOutputCount = iOutputSize / 2;

                iOutputStartIndex = bIsChuckOne ? 0 : iOutputSize / 2;
            }
            else
            {
                bToolVendorASML = false;
                iOutputCount = iOutputSize;
                iOutputStartIndex = 0;
            }
        }
        public List<Chart> AddChartToList(int chartType, int ovlType, bool bIsChuckOne)
        {
            int iOutputSize = 0;
            int iOutputCount = 0;
            int iOutputStartIndex = 0;
            List<Chart> ctlListChart = new List<Chart>();
            List<List<double>> dGroupListItemValues = new List<List<double>>();
            List<string> strListItemNames = new List<string>();
            List<string> strListItemValues = new List<string>();
            List<string> strListLotIds = new List<string>();
            List<string> strListUsedTimeStamps = new List<string>();

            if (ovlType == 1)
            {
                iOutputSize = structData.iLinear_OutputSize;
                strListLotIds = new List<string>(structData.strListLinear_LotIds);
                strListItemNames = new List<string>(structData.strListLinear_ItemNames_PostMetrology);
                strListItemValues = new List<string>(structData.strListLinear_ItemValues_PostMetrology);
                strListUsedTimeStamps = new List<string>(structData.strListLinear_UsedTimeStamps);
            }
            else if (ovlType == 2)
            {
                iOutputSize = structData.iHOPC_OutputSize;
                strListLotIds = new List<string>(structData.strListHOPC_LotIds);
                strListItemNames = new List<string>(structData.strListHOPC_ItemNames_PostMetrology);
                strListItemValues = new List<string>(structData.strListHOPC_ItemValues_PostMetrology);
                strListUsedTimeStamps = new List<string>(structData.strListHOPC_UsedTimeStamps);
            }
            else if (ovlType == 3)
            {
                iOutputSize = structData.iIHOPC_OutputSize;
                strListLotIds = new List<string>(structData.strListIHOPC_LotIds);
                strListItemNames = new List<string>(structData.strListIHOPC_ItemNames_PostMetrology);
                strListItemValues = new List<string>(structData.strListIHOPC_ItemValues_PostMetrology);
                strListUsedTimeStamps = new List<string>(structData.strListIHOPC_UsedTimeStamps);
            }

            SetOVLChartParam(ref iOutputCount, ref iOutputStartIndex, iOutputSize, bIsChuckOne);

            dGroupListItemValues.Clear();

            #region
            //dGroupListItemValues = BaseFun.GetItemValues(strListItemValues, iOutputStartIndex, iOutputCount);

            //AddControlHelp.AddOVLChartToList(ref ctlListChart, chartType, strListItemNames, dGroupListItemValues, strListLotIds);
            #endregion

            List<List<string>> strGroupListLotIds = new List<List<string>>();
            dGroupListItemValues = BaseFun.GetItemValues(strListUsedTimeStamps, strListItemValues, iOutputStartIndex, iOutputCount, ref strGroupListLotIds, strListLotIds);
            //dGroupListItemValues = BaseFun.GetItemValues(strListItemValues, iOutputStartIndex, iOutputCount, ref strGroupListLotIds, strListLotIds);

            if (dGroupListItemValues.Count > 0)
            {
                AddControlHelp.AddCommonChartToList(ref ctlListChart, chartType, strListItemNames, dGroupListItemValues, strGroupListLotIds);
            }
            return ctlListChart;
        }
    }
}

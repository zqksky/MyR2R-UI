﻿namespace R2R_UI.Present.OVL
{
    partial class frmOVLReset
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.dgvSet = new System.Windows.Forms.DataGridView();
            this.panDgvLblContext = new System.Windows.Forms.Panel();
            this.lblDgvContext = new System.Windows.Forms.Label();
            this.panBtnOk = new System.Windows.Forms.Panel();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOk = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.cmbOVLMode = new System.Windows.Forms.ComboBox();
            this.btnRun = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSet)).BeginInit();
            this.panDgvLblContext.SuspendLayout();
            this.panBtnOk.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panBtnOk);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1007, 424);
            this.panel1.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Controls.Add(this.panDgvLblContext);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 47);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1007, 338);
            this.panel4.TabIndex = 16;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.dgvSet);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 26);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1007, 312);
            this.panel5.TabIndex = 5;
            // 
            // dgvSet
            // 
            this.dgvSet.AllowUserToAddRows = false;
            this.dgvSet.AllowUserToDeleteRows = false;
            this.dgvSet.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvSet.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvSet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSet.Location = new System.Drawing.Point(0, 0);
            this.dgvSet.Name = "dgvSet";
            this.dgvSet.Size = new System.Drawing.Size(1007, 312);
            this.dgvSet.TabIndex = 1;
            // 
            // panDgvLblContext
            // 
            this.panDgvLblContext.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panDgvLblContext.Controls.Add(this.lblDgvContext);
            this.panDgvLblContext.Dock = System.Windows.Forms.DockStyle.Top;
            this.panDgvLblContext.Location = new System.Drawing.Point(0, 0);
            this.panDgvLblContext.Name = "panDgvLblContext";
            this.panDgvLblContext.Size = new System.Drawing.Size(1007, 26);
            this.panDgvLblContext.TabIndex = 4;
            // 
            // lblDgvContext
            // 
            this.lblDgvContext.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblDgvContext.AutoSize = true;
            this.lblDgvContext.Location = new System.Drawing.Point(443, 2);
            this.lblDgvContext.Name = "lblDgvContext";
            this.lblDgvContext.Size = new System.Drawing.Size(91, 13);
            this.lblDgvContext.TabIndex = 0;
            this.lblDgvContext.Text = "List of Parameters";
            // 
            // panBtnOk
            // 
            this.panBtnOk.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panBtnOk.Controls.Add(this.btnCancel);
            this.panBtnOk.Controls.Add(this.btnOk);
            this.panBtnOk.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panBtnOk.Location = new System.Drawing.Point(0, 385);
            this.panBtnOk.Name = "panBtnOk";
            this.panBtnOk.Size = new System.Drawing.Size(1007, 39);
            this.panBtnOk.TabIndex = 15;
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.Location = new System.Drawing.Point(876, 11);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(73, 23);
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOk
            // 
            this.btnOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOk.Location = new System.Drawing.Point(779, 11);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(73, 23);
            this.btnOk.TabIndex = 0;
            this.btnOk.Text = "Ok";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Controls.Add(this.cmbOVLMode);
            this.panel2.Controls.Add(this.btnRun);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1007, 47);
            this.panel2.TabIndex = 14;
            // 
            // textBox1
            // 
            this.textBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Location = new System.Drawing.Point(298, 11);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(69, 20);
            this.textBox1.TabIndex = 20;
            this.textBox1.Text = "OVL Mode:";
            // 
            // cmbOVLMode
            // 
            this.cmbOVLMode.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cmbOVLMode.FormattingEnabled = true;
            this.cmbOVLMode.Location = new System.Drawing.Point(382, 11);
            this.cmbOVLMode.Name = "cmbOVLMode";
            this.cmbOVLMode.Size = new System.Drawing.Size(223, 21);
            this.cmbOVLMode.TabIndex = 19;
            this.cmbOVLMode.SelectedIndexChanged += new System.EventHandler(this.cmbOVLMode_SelectedIndexChanged);
            // 
            // btnRun
            // 
            this.btnRun.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnRun.BackColor = System.Drawing.SystemColors.Control;
            this.btnRun.Location = new System.Drawing.Point(621, 10);
            this.btnRun.Name = "btnRun";
            this.btnRun.Size = new System.Drawing.Size(96, 23);
            this.btnRun.TabIndex = 18;
            this.btnRun.Text = "Run";
            this.btnRun.UseVisualStyleBackColor = false;
            this.btnRun.Click += new System.EventHandler(this.btnRun_Click);
            // 
            // frmOVLReset
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1007, 424);
            this.Controls.Add(this.panel1);
            this.Name = "frmOVLReset";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "OVLReset";
            this.Load += new System.EventHandler(this.frmOVLReset_Load);
            this.SizeChanged += new System.EventHandler(this.frmOVLReset_SizeChanged);
            this.Resize += new System.EventHandler(this.frmOVLReset_Resize);
            this.panel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSet)).EndInit();
            this.panDgvLblContext.ResumeLayout(false);
            this.panDgvLblContext.PerformLayout();
            this.panBtnOk.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnRun;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DataGridView dgvSet;
        private System.Windows.Forms.Panel panDgvLblContext;
        private System.Windows.Forms.Label lblDgvContext;
        private System.Windows.Forms.Panel panBtnOk;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.ComboBox cmbOVLMode;
        private System.Windows.Forms.TextBox textBox1;
    }
}
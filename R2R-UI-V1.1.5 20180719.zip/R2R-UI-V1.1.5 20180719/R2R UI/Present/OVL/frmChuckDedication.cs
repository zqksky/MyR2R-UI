﻿using R2R_UI.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace R2R_UI.Present.OVL
{
    public partial class frmChuckDedication : Form
    {
        public frmChuckDedication()
        {
            InitializeComponent();
        }
        public frmChuckDedication(string strServiceName, string strCurrentUserName, string strCurrentPwd, DataTable db)
        {
            InitializeComponent();
            strServiceAddress = strServiceName;
            strUserName = strCurrentUserName;
            strPassword = strCurrentPwd;
            //strLayer = strCurrentLayer;
            dbContext = db;
            dgvContext.DataSource = dbContext;
        }

        #region Param
        string strServiceAddress;
        string strUserName;
        string strPassword;

        string strFabName;
        string strLotId;
        string strLayer;
        string strStepSequence;

        DataTable dbContext;

        List<string> strListWaferIds = new List<string>();
        List<string> strListSlotIds = new List<string>();
        List<string> strListChuckIds = new List<string>();
        UIServiceFun.structPH_OVL_ChuckDedication structData = new UIServiceFun.structPH_OVL_ChuckDedication();
        #endregion

        private float frmLocationX;
        private float frmLocationY;
        AdaptiveSizeResolution AutoSizeFrm = new AdaptiveSizeResolution();
        private void frmChuckDedication_Load(object sender, EventArgs e)
        {
            #region AdaptiveSizeResolution
            //AutoSizeFrm.ControllInitializeSize(this);
            #endregion

            #region  AdaptiveSize
            //this.Resize += new EventHandler(frmChuckDedication_Resize);
            //frmLocationX = this.Width;
            //frmLocationY = this.Height;
            //AdaptiveSize.setTag(this);
            #endregion

            #region Init Lbl
            string strDgvLblContext = "List of context group";
            AddControlHelp.SetLable(panDgvLblContext, lblDgvContext, strDgvLblContext);

            string strDgvLblParameters = "List of Parameters";
            AddControlHelp.SetLable(panDgvLblParameters, lblDgvParameters, strDgvLblParameters);
            #endregion
        }

        private void frmChuckDedication_Resize(object sender, EventArgs e)
        {
            #region AdaptiveSize
            //float newx = (this.Width) / frmLocationX;
            //float newy = this.Height / frmLocationY;
            //AdaptiveSize.setControls(newx, newy, this);
            #endregion
        }

        private void frmChuckDedication_SizeChanged(object sender, EventArgs e)
        {
            #region AdaptiveSizeResolution
            //AutoSizeFrm.ControlAutoSize(this);
            #endregion
        }

        private void InitChuckType(List<string> strListChuck)
        {
            List<string> strList = new List<string>() { "NA", "C1", "C2" };
            for (int i = 0; i<dgvSet.RowCount;i++)
            {
                dgvSet.Rows[i].Cells[2] = new DataGridViewComboBoxCell();
                dgvSet.Rows[i].Cells[2].Value = strListChuck[0];
            }
        }

        private void InitChuckType()
        {
            List<string> strList = new List<string>() { "NA", "C1", "C2" };
            for (int i = 0; i < dgvSet.RowCount; i++)
            {
                dgvSet.Rows[i].Cells[2] = new DataGridViewComboBoxCell();
                //dgvSet.Rows[i].Cells[2].Value = strListChuck[0];
            }
        }
        private void btnQueryLotInfo_Click(object sender, EventArgs e)
        {
            #region PH_OVL_QueryLotInfo
            //strFabName = "FabName_50";
            //strLotId = "LotId_31";
            strFabName = txtFabName.Text.ToString().Trim();
            strLotId = txtLotId.Text.ToString().Trim();
            //strStepSequence = txtStepSequence.Text.ToString().Trim();
            strLayer = txtLayer.Text.ToString().Trim();

            if (strFabName.Equals("") || strLotId.Equals("") || strLayer.Equals(""))
            {
                MessageBox.Show("FabName Or LotId Or Config Layer is empty");
            }
            else
            {
                UIServiceFun.structPH_OVL_QueryLotInfo structDataNull = new UIServiceFun.structPH_OVL_QueryLotInfo();
                UIServiceFun.structPH_OVL_QueryLotInfo structData = new UIServiceFun.structPH_OVL_QueryLotInfo();
                structData = UIServiceFun.R2R_UI_PH_OVL_QueryLotInfo(strServiceAddress, strFabName, strLotId, strLayer);

                if (structData.Equals(structDataNull))
                {
                    MessageBox.Show("Data is empty!");
                }
                else
                {
                    strStepSequence = structData.strCurrentStepSequence;
                    //txtLayer.Text = strLayer;
                    txtStepSequence.Text = strStepSequence;

                    DataGridViewHelp.InitDgvSet(dgvSet, DataTableHelp.CreateQueryLotInfoTable(structData),3);

                    InitChuckType();
                    //InitChuckType(structData.strListChuckIds);

                    InitChuckDedicationStruct();
                }
            }
            #endregion
        }
        private void InitChuckDedicationStruct()
        {
            if (dgvSet.Rows.Count > 0)
            {
                strListWaferIds.Clear();
                strListSlotIds.Clear();
                strListChuckIds.Clear();
                structData.strListWaferIds = new List<string>();
                structData.strListSlotIds = new List<string>();
                structData.strListChuckIds = new List<string>();

                for (int i = 0; i < dgvSet.Rows.Count; i++)
                {
                    //MessageBox.Show(grdQueryLotInfo.Rows[i].Cells[1].Value.ToString());
                    //MessageBox.Show(grdQueryLotInfo.Rows[i].Cells[2].Value.ToString());
                    if (dgvSet.Rows[i].Cells[0].Value.ToString().Equals(""))
                    {
                        //grdQueryLotInfo.Rows[i].Cells[0].Value = "NA";
                    }
                    if (dgvSet.Rows[i].Cells[1].Value.ToString().Equals(""))
                    {
                        //grdQueryLotInfo.Rows[i].Cells[1].Value = "NA";
                    }
                    if (dgvSet.Rows[i].Cells[2].Value.ToString().Equals(""))
                    {
                        dgvSet.Rows[i].Cells[2].Value = "NA";
                    }
                    strListWaferIds.Add(dgvSet.Rows[i].Cells[0].Value.ToString());
                    strListSlotIds.Add(dgvSet.Rows[i].Cells[1].Value.ToString());
                    strListChuckIds.Add(dgvSet.Rows[i].Cells[2].Value.ToString());

                    structData.strListWaferIds.Add(dgvSet.Rows[i].Cells[0].Value.ToString());
                    structData.strListSlotIds.Add(dgvSet.Rows[i].Cells[1].Value.ToString());
                    structData.strListChuckIds.Add(dgvSet.Rows[i].Cells[2].Value.ToString());
                }
            }
        }
        private void btnOk_Click(object sender, EventArgs e)
        {
            frmCheckedPwd frmChecked = new frmCheckedPwd(strUserName);
            if (frmChecked.ShowDialog() == DialogResult.OK)
            {
                if (frmChecked.strPassword.Equals(strPassword))
                {
                    #region
                    bool bSuccess;
                    strLotId = txtLotId.Text.ToString().Trim();
                    strLayer = txtLayer.Text.ToString().Trim();
                    try
                    {
                        #region PH_OVL_ChuckDedication
                        if (strLotId.Equals("") || strLayer.Equals(""))
                        {
                            MessageBox.Show("The parameter cannot be empty");
                        }
                        else
                        {
                            InitChuckDedicationStruct();
                            //GetGrdQueryLotInfoValue();
                            //bSuccess = UIServiceFun.R2R_UI_PH_OVL_ChuckDedication(strServiceAddress,strUserName, strLotId, strLayer, strListSlotIds,strListChuckIds);
                            bSuccess = UIServiceFun.R2R_UI_PH_OVL_ChuckDedication(strServiceAddress, strUserName, strLotId, strLayer, structData);
                            if (bSuccess)
                            {
                                //MessageBox.Show("Set Successed!");
                                this.Close();
                            }
                            else
                            {
                                MessageBox.Show("Set Failed!");
                            }
                        }
                        this.DialogResult = DialogResult.OK;
                        #endregion
                    }
                    catch (Exception ee)
                    {
                        MessageBox.Show(ee.Message);
                    }
                    #endregion
                }
                else
                {
                    MessageBox.Show("Invalid password!");
                }
            }
            else
            {
                //MessageBox.Show("Invalid password!");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #region Test DataGidView Add CoboBox
        private ComboBox Chuck_ComboBox = new ComboBox();
        private void InitChuckComboBox()
        {
            this.Chuck_ComboBox.Items.Add("NA");
            this.Chuck_ComboBox.Items.Add("C1");
            this.Chuck_ComboBox.Items.Add("C2");
            this.Chuck_ComboBox.Text = "NA";

            this.Chuck_ComboBox.Leave += new EventHandler(cmbChuck_TextChanged);
            this.Chuck_ComboBox.SelectedIndexChanged += new EventHandler(cmbChuck_TextChanged);
            this.Chuck_ComboBox.Visible = false;
            this.Chuck_ComboBox.DropDownStyle = ComboBoxStyle.DropDownList;

            // 将下拉列表框加入到DataGridView控件
            this.dgvSet.Controls.Add(this.Chuck_ComboBox);
        }

        private void cmbChuck_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int row_index = this.dgvSet.CurrentCell.RowIndex;
                DataTable data = (this.dgvSet.DataSource as DataTable);
                data.Rows[row_index][2] = ((ComboBox)sender).Text;
                this.Chuck_ComboBox.Visible = false;
            }
            catch (Exception ex)
            {

            }
        }
        private void dgvSet_CurrentCellChanged(object sender, EventArgs e)
        {
            try
            {
                if (this.dgvSet.CurrentCell.ColumnIndex == 2 && this.dgvSet.CurrentCell.RowIndex < this.dgvSet.RowCount)
                {
                    Rectangle rect = dgvSet.GetCellDisplayRectangle(dgvSet.CurrentCell.ColumnIndex, dgvSet.CurrentCell.RowIndex, false);
                    string Value = dgvSet.CurrentCell.Value.ToString();
                    this.Chuck_ComboBox.Text = Value;
                    this.Chuck_ComboBox.Left = rect.Left;
                    this.Chuck_ComboBox.Top = rect.Top;
                    this.Chuck_ComboBox.Width = rect.Width;
                    this.Chuck_ComboBox.Height = rect.Height;
                    this.Chuck_ComboBox.Visible = true;
                }
                else
                {
                    this.Chuck_ComboBox.Visible = false;
                }
            }
            catch (Exception ex)
            {
                return;
            }
        }
        #endregion

    }
}

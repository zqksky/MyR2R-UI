﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace R2R_UI.Common
{
    class TxtHelp
    {
        public static void DeleteTxtFile(string path, string pattern)
        {
            //path = Application.StartupPath;
            //pattern = "V1*.txt";
            string[] strFileNames = Directory.GetFiles(path, pattern);
            foreach (var item in strFileNames)
            {
                File.Delete(item);
            }    
        }

        public static void WriteVersionTxt(string strFilePath, string strWrite)
        {
            using (StreamWriter sw = new StreamWriter(strFilePath, false, Encoding.UTF8))
            {
                sw.Write(strWrite);
                sw.WriteLine(Environment.NewLine);//换行
                sw.Write(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss:ffff dddd"));
                sw.Flush();
                sw.Close();
            }
        }

        public void SetFileAttributes(string aFilePath)
        {
            if (File.GetAttributes(aFilePath).ToString().IndexOf("ReadOnly") != -1)
            {
                File.SetAttributes(aFilePath, FileAttributes.Normal);
            }
        }

    }
}

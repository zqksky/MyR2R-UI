﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.DataVisualization.Charting;
using static R2R_UI.Common.UIServiceFun;

namespace R2R_UI.Common
{
    class BaseFun
    {
        #region PM/RESET TIME VALUE
        private static bool IsDate(string date)
        {
            try
            {
                DateTime.Parse(date);
                return true;
            }
            catch
            {
                return false;
            }
        }

        private static List<DateTime> StrToDateTime(List<string> strListUsedTime)
        {
            List<DateTime> strDateTime = new List<DateTime>();
            foreach (var str in strListUsedTime)
            {
                if (IsDate(str))
                {
                    strDateTime.Add(Convert.ToDateTime(str));
                }
            }
            return strDateTime;
        }
        public static int GetPMTimeValue(string strPMTime, List<string> strListUsedTime)
        {
            int num = 0;
            DateTime dtPM;
            DateTime dtMax;
            List<DateTime> strDateTime = new List<DateTime>();

            strDateTime = StrToDateTime(strListUsedTime);
            if (strDateTime.Count > 0)
            {
                if (IsDate(strPMTime))
                {
                    dtPM = Convert.ToDateTime(strPMTime);
                    dtMax = strDateTime.Max();
                    if (DateTime.Compare(dtMax, dtPM) < 0)
                    {
                        num = strDateTime.Count;
                    }
                    else
                    {
                        for (int i = 0; i < strListUsedTime.Count; i++)
                        {
                            if (DateTime.Compare(dtPM, Convert.ToDateTime(strListUsedTime[i])) < 0)
                            {
                                num++;
                            }
                            else
                            {
                                num = strDateTime.Count - num;
                                break;
                            }
                        }
                    }
                }
                else
                {
                    num = 0;
                }
            }
            return num;
        }

        public static int GetResetTimeValue(string strResetTime, List<string> strListUsedTime)
        {
            int num = 0;
            DateTime dtReset;
            DateTime dtMin;
            List<DateTime> strDateTime = new List<DateTime>();
            strDateTime = StrToDateTime(strListUsedTime);
            if (strDateTime.Count > 0)
            {
                if (IsDate(strResetTime))
                {
                    dtReset = Convert.ToDateTime(strResetTime);
                    dtMin = strDateTime.Min();
                    if (DateTime.Compare(dtMin, dtReset) > 0)
                    {
                        num = 0;
                    }
                    else
                    {
                        for (int i = 0; i < strListUsedTime.Count; i++)
                        {
                            if (DateTime.Compare(dtReset, Convert.ToDateTime(strListUsedTime[i])) < 0)
                            {
                                num++;
                            }
                            else
                            {
                                num = strDateTime.Count - num;
                                break;
                            }

                        }
                    }
                }
                else
                {
                    num = 0;
                }
            }
            return num;
        }
        #endregion

        #region List Sort
        private static void GetSortListAndValue(List<string> strListUsedTime, ref List<string> strListValue, ref List<string> strListId)
        {
            List<int> iListIndex = new List<int>();
            iListIndex = GetSortListIndex(strListUsedTime);

            List<string> strListItemValuesSort = new List<string>();
            strListItemValuesSort = GetSortList(strListValue, iListIndex);

            List<string> strListIdSort = new List<string>();
            strListIdSort = GetSortList(strListId, iListIndex);

            strListValue = new List<string>(strListItemValuesSort);
            strListId = new List<string>(strListIdSort);
        }
        private static List<int> GetSortListIndex(List<string> strList)
        {
            List<int> iListIndex = new List<int>();
            List<string> strListSort = new List<string>(strList);
            strListSort.Sort();

            foreach (var str in strListSort)
            {
                for (int i = 0; i < strList.Count; i++)
                {
                    if (str.Equals(strList[i]))
                    {
                        iListIndex.Add(i);
                    }
                }
            }

            return iListIndex;
        }
        private static List<string> GetSortList(List<string> strList, List<int> iListIndex)
        {
            List<string> strListSort = new List<string>();

            for (int i = 0; i < iListIndex.Count; i++)
            {
                strListSort.Add(strList[iListIndex[i]]);
            }

            return strListSort;
        }
        #endregion

        #region
        private static List<List<int>> GetGroupIndex(List<string> strList)
        {
            List<List<int>> iListIndexs = new List<List<int>>();
            List<string> strListGroup = new List<string>();

            strListGroup = GetGroupName(strList);
            foreach (var str in strListGroup)
            {
                List<int> iListIndex = new List<int>();
                for (int i = 0; i < strList.Count; i++)
                {
                    if (str.Equals(strList[i]))
                    {
                        iListIndex.Add(i);
                    }
                }
                iListIndexs.Add(iListIndex);
            }
            return iListIndexs;
        }

        public static List<string> GetGroupName(List<string> strList)
        {
            List<string> strGroup = new List<string>();
            //strList = new List<string>() { "p1", "p1", "p1", "p2", "p2", "p3", "p3", "p4" };
            var q = strList.GroupBy(x => x).Where(x => x.Count() > 0).ToList();

            foreach (var item in q)
            {
                //List<string> str = new List<string>(item.ToList());
                //foreach (var s in str)
                //{
                //    MessageBox.Show(s);
                //}
                //MessageBox.Show(item.Key);
                strGroup.Add(item.Key);
            }
            strGroup.Sort();
            return strGroup;
        }

        //CD/Focus/Common
        public static List<List<double>> GetItemValues(List<string> strListUsedTime, List<string> strListValue, ref List<List<string>> strGroupListLotIds, List<string> strListLotIds)
        {
            GetSortListAndValue(strListUsedTime, ref strListValue, ref strListLotIds);

            List<List<string>> strListTemp = new List<List<string>>();
            List<List<double>> dGroupListValue = new List<List<double>>();

            strListTemp = GetItemValuesTemp(strListValue);
            //dGroupListValue.Clear();
            if (strListTemp.Count > 0)
            {
                strGroupListLotIds = new List<List<string>>();
                for (int n = 0; n < strListTemp[0].Count; n++)
                {
                    List<double> dListValue = new List<double>();
                    List<string> strListLotIdsNew = new List<string>();

                    for (int i = 0; i < strListTemp.Count; i++)
                    {
                        if (RegexHelp.IsDoubleValue(strListTemp[i][n]))
                        {
                            dListValue.Add(double.Parse(strListTemp[i][n]));
                        }
                        else
                        {
                            //System.Windows.Forms.MessageBox.Show("Add NaN");
                            dListValue.Add(double.NaN);
                        }
                    }
                    dGroupListValue.Add(dListValue);
                    strGroupListLotIds.Add(strListLotIds);
                }
            }
            return dGroupListValue;
        }

        //OVL
        public static List<List<double>> GetItemValues(List<string> strListUsedTime, List<string> strListValue, int index, int count, ref List<List<string>> strGroupListLotIds, List<string> strListLotIds)
        {
            GetSortListAndValue(strListUsedTime, ref strListValue, ref strListLotIds);

            List<List<string>> strListTemp = new List<List<string>>();
            List<List<double>> dGroupListValue = new List<List<double>>();
            strGroupListLotIds.Clear();
            strListTemp = GetItemValuesTemp(strListValue);
            //dGroupListValue.Clear();
            if (strListTemp.Count > 0)
            {
                for (int n = index; n < index + count; n++)
                {
                    List<double> dListValue = new List<double>();
                    List<string> strListLotIdsNew = new List<string>();

                    for (int i = 0; i < strListTemp.Count; i++)
                    {
                        if (RegexHelp.IsDoubleValue(strListTemp[i][n]))
                        {
                            dListValue.Add(double.Parse(strListTemp[i][n]));
                        }
                        else
                        {
                            //System.Windows.Forms.MessageBox.Show("Add NaN");
                            dListValue.Add(double.NaN);
                        }
                    }
                    dGroupListValue.Add(dListValue);
                    strGroupListLotIds.Add(strListLotIds);
                }
            }
            return dGroupListValue;
        }

        public static List<List<string>> GetItemValuesTemp(List<string> strList)
        {
            List<string> strListTemp = new List<string>();
            List<string> strListFormat = new List<string>();
            List<List<string>> strListResult = new List<List<string>>();
            if (strList.Count > 0)
            {
                strListFormat = FormatItemValues(strList);
                foreach (var str in strListFormat)
                {
                    strListTemp = SplitString(str);
                    strListResult.Add(strListTemp);
                }
            }
            return strListResult;
        }

        private static List<string> FormatItemValues(List<string> strList)
        {
            List<string> strListResult = new List<string>();
            if (strList.Count > 0)
            {
                string str;
                for (int i = 0; i < strList.Count; i++)
                {
                    str = strList[i].TrimEnd(']');
                    str = str.TrimStart('[');
                    strListResult.Add(str.Trim());
                }
            }
            return strListResult;
        }
        private static List<string> SplitString(string str)
        {
            List<string> strList = new List<string>();
            if (str != "")
            {
                string[] strArray = str.Split(new char[] { ' ' });
                strList = new List<string>(strArray);
            }
            return strList;
        }
        #endregion
    }
}

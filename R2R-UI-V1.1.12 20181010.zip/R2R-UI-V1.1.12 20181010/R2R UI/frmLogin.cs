﻿using R2R_UI.Common;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace R2R_UI
{
    public partial class frmLogin : Form
    {
        #region
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x0014) // 禁掉清除背景消息
                return;
            base.WndProc(ref m);
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x02000000;
                return cp;
            }
        }

        private void CtlDoubleBuffer()
        {
            this.DoubleBuffered = true;//设置本窗体
            SetStyle(ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true); // 禁止擦除背景.
            SetStyle(ControlStyles.DoubleBuffer, true); // 双缓冲
            //SetStyle(ControlStyles.DoubleBuffer | ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint, true);
            UpdateStyles();
        }
        #endregion

        public frmLogin()
        {
            InitializeComponent();
        }

        #region Parm Define
        public string strDomainName
        {
            set
            {
                //txtDomainName.Text = value;
                cmbDomainName.Text = value;
            }

            get
            {
                //return txtDomainName.Text;
                return cmbDomainName.Text.ToString();
            }
        }

        public string strUserName
        {
            get
            {
                return txtUserName.Text;
            }
            set
            {
                txtUserName.Text = value;
            }
        }

        public string strPassword
        {
            set
            {
                txtPassword.Text = value;
            }

            get
            {
                return txtPassword.Text;
            }
        }

        public string strServerAddress
        {
            get
            {
                return cmbServerAddress.SelectedValue.ToString();
                //return cmbServerAddress.Text.ToString();
            }

            set
            {
                cmbServerAddress.Text = value;
            }
        }

        public bool bAutoLogin
        {
            get
            {
                return chkAutoLogin.Checked;
            }

            set
            {
                chkAutoLogin.Checked = value;
            }
        }
        #endregion

        private float frmLocationX;
        private float frmLocationY;
        AdaptiveSizeResolution AutoSizeFrm = new AdaptiveSizeResolution();
        private void frmLogin_Load(object sender, EventArgs e)
        {
            //ComboBox不能输入，只能从下拉列表中选择
            //设置combobox 的DropDownstyle属性为dropdownlist

            this.KeyPreview = true;

            #region  Double Buffer
            CtlDoubleBuffer();
            #endregion

            #region AdaptiveSizeResolution
            //AutoSizeFrm.ControllInitializeSize(this);
            #endregion

            #region  AdaptiveSize
            //this.Resize += new EventHandler(frmLogin_Resize);
            //frmLocationX = this.Width;
            //frmLocationY = this.Height;
            //AdaptiveSize.setTag(this);
            #endregion

            #region
            string strDebugPath = System.Reflection.Assembly.GetExecutingAssembly().Location;
            strDebugPath = strDebugPath.Substring(0, strDebugPath.LastIndexOf('\\'));

            List<string> strList = new List<string>();
            strList = ReadLoginConfig.GetDomainNameData(strDebugPath + "\\LoginConfigFile.xml");
            bindDomainNameCmbox(strList);
            cmbDomainName.SelectedIndex = 0;
           
            Dictionary<string, string> dt = new Dictionary<string, string>();
            dt = ReadLoginConfig.GetXmlData(strDebugPath + "\\LoginConfigFile.xml");
            bindServerAddressCmbox(dt);
            cmbServerAddress.SelectedIndex = 0;        //  设置为默认选中第一个
            #endregion

            #region test CmbBox can not sort
            //Hashtable ht = new Hashtable();
            //ht = ReadLoginConfig.GetServerAddressData(strDebugPath + "\\LoginConfigFile.xml");
            //bindServerAddressCmbox(ht);
            ////cmbServerAddress.Text = "localhost";
            ////cmbDomainName.SelectedIndex = 0;
            ////cmbServerAddress.SelectedIndex = 0;        //  设置为默认选中第一个

            //HashList hList = new HashList();
            //hList = ReadLoginConfig.GetXmlData(strDebugPath + "\\LoginConfigFile.xml", "ServerConfig", "ServerAddress");
            //hList.Sort();
            //bindDataToCmbox(cmbServerAddress, hList);
            #endregion

        }

        private void frmLogin_Resize(object sender, EventArgs e)
        {
            #region AdaptiveSize
            //float newx = (this.Width) / frmLocationX;
            //float newy = this.Height / frmLocationY;
            //AdaptiveSize.setControls(newx, newy, this);
            #endregion
        }

        private void frmLogin_SizeChanged(object sender, EventArgs e)
        {
            #region AdaptiveSizeResolution
            //AutoSizeFrm.ControlAutoSize(this);
            #endregion
        }

        #region
        private void bindDomainNameCmbox(List<string> strList)
        {
            //cmbDomainName.DataSource = strList;

            foreach (var str in strList)
            {
                cmbDomainName.Items.Add(str);
            }

            //BindingSource bs = new BindingSource();
            //bs.DataSource = strList;
            //cmbDomainName.DataSource = bs;
            ////cmbDomainName.ValueMember = "Key";
            //cmbDomainName.DisplayMember = "Value";
        }

        private void bindServerAddressCmbox(Hashtable ht)
        {
            BindingSource bs = new BindingSource();
            bs.DataSource = ht;
            cmbServerAddress.DataSource = bs;
            cmbServerAddress.ValueMember = "Value";
            cmbServerAddress.DisplayMember = "Key";
        }

        private void bindServerAddressCmbox(Dictionary<string, string> dt)
        {
            BindingSource bs = new BindingSource();
            bs.DataSource = dt;
            cmbServerAddress.DataSource = bs;
            cmbServerAddress.ValueMember = "Value";
            cmbServerAddress.DisplayMember = "Key";
        }

        private void bindDataToCmbox(ComboBox cmb, HashList ht)
        {
            BindingSource bs = new BindingSource();
            bs.DataSource = ht;
            cmb.DataSource = bs;
            cmb.ValueMember = "Value";
            cmb.DisplayMember = "Key";
        }
        #endregion

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(cmbDomainName.Text))
            {
                MessageBox.Show("Domain Name is mandatory");
            }

            else if (string.IsNullOrEmpty(txtUserName.Text))
            {
                MessageBox.Show("User name is mandatory");
            }

            else if (string.IsNullOrEmpty(txtPassword.Text))
            {
                MessageBox.Show("Password is mandatory");
            }

            else if (string.IsNullOrEmpty(cmbServerAddress.Text))
            {
                MessageBox.Show("E3 Server address is mandatory");
            }
            else
            {
                bool bSuccess = false;
                int operationType=0;
                //bSuccess = LoginFun.LoginManage(strServerAddress, strUserName, strPassword, strDomainName, false,ref operationType);
                bSuccess = LoginServiceFun.LoginManage(strServerAddress, strUserName, strPassword, strDomainName, false, ref operationType);

                if (bSuccess)
                {
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                else
                {
                    txtUserName.Text = "";
                    txtPassword.Text = "";
                }
            }
            //SendKeys.Send("{ENTER}");
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void frmLogin_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)//判断回车键
            {
                //this.btnLogin.Focus();
                this.btnOk_Click(sender, e);//触发按钮事件
            }
        }

        private void frmLogin_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (this.DialogResult != DialogResult.OK)
            {
                return;
            }
        }   
    }
}

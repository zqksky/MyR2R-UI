﻿namespace R2R_UI.Present.BatchOperation
{
    partial class frmBatchPMOffset
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.dgvSet = new System.Windows.Forms.DataGridView();
            this.panDgvLblParameters = new System.Windows.Forms.Panel();
            this.lblDgvParameters = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panDgv = new System.Windows.Forms.Panel();
            this.dgvContext = new System.Windows.Forms.DataGridView();
            this.panDgvLblContext = new System.Windows.Forms.Panel();
            this.lblDgvContext = new System.Windows.Forms.Label();
            this.panLbl = new System.Windows.Forms.Panel();
            this.lblContext = new System.Windows.Forms.Label();
            this.panBtnOk = new System.Windows.Forms.Panel();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOk = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSet)).BeginInit();
            this.panDgvLblParameters.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panDgv.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvContext)).BeginInit();
            this.panDgvLblContext.SuspendLayout();
            this.panLbl.SuspendLayout();
            this.panBtnOk.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.panLbl);
            this.panel1.Controls.Add(this.panBtnOk);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(961, 559);
            this.panel1.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.panDgvLblParameters);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 266);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(961, 260);
            this.panel3.TabIndex = 7;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.dgvSet);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 26);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(961, 234);
            this.panel4.TabIndex = 5;
            // 
            // dgvSet
            // 
            this.dgvSet.AllowUserToAddRows = false;
            this.dgvSet.AllowUserToDeleteRows = false;
            this.dgvSet.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvSet.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvSet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSet.Location = new System.Drawing.Point(0, 0);
            this.dgvSet.Name = "dgvSet";
            this.dgvSet.Size = new System.Drawing.Size(961, 234);
            this.dgvSet.TabIndex = 1;
            this.dgvSet.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvContext_CellFormatting);
            this.dgvSet.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.dgvContext_CellPainting);
            this.dgvSet.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSet_CellValueChanged);
            this.dgvSet.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvContext_RowPostPaint);
            // 
            // panDgvLblParameters
            // 
            this.panDgvLblParameters.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panDgvLblParameters.Controls.Add(this.lblDgvParameters);
            this.panDgvLblParameters.Dock = System.Windows.Forms.DockStyle.Top;
            this.panDgvLblParameters.Location = new System.Drawing.Point(0, 0);
            this.panDgvLblParameters.Name = "panDgvLblParameters";
            this.panDgvLblParameters.Size = new System.Drawing.Size(961, 26);
            this.panDgvLblParameters.TabIndex = 4;
            // 
            // lblDgvParameters
            // 
            this.lblDgvParameters.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblDgvParameters.AutoSize = true;
            this.lblDgvParameters.Location = new System.Drawing.Point(424, 3);
            this.lblDgvParameters.Name = "lblDgvParameters";
            this.lblDgvParameters.Size = new System.Drawing.Size(91, 13);
            this.lblDgvParameters.TabIndex = 0;
            this.lblDgvParameters.Text = "List of Parameters";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panDgv);
            this.panel2.Controls.Add(this.panDgvLblContext);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 35);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(961, 231);
            this.panel2.TabIndex = 6;
            // 
            // panDgv
            // 
            this.panDgv.Controls.Add(this.dgvContext);
            this.panDgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panDgv.Location = new System.Drawing.Point(0, 26);
            this.panDgv.Name = "panDgv";
            this.panDgv.Size = new System.Drawing.Size(961, 205);
            this.panDgv.TabIndex = 3;
            // 
            // dgvContext
            // 
            this.dgvContext.AllowUserToAddRows = false;
            this.dgvContext.AllowUserToDeleteRows = false;
            this.dgvContext.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvContext.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvContext.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvContext.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvContext.Location = new System.Drawing.Point(0, 0);
            this.dgvContext.Name = "dgvContext";
            this.dgvContext.Size = new System.Drawing.Size(961, 205);
            this.dgvContext.TabIndex = 0;
            this.dgvContext.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvContext_CellFormatting);
            this.dgvContext.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.dgvContext_CellPainting);
            this.dgvContext.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvContext_RowPostPaint);
            // 
            // panDgvLblContext
            // 
            this.panDgvLblContext.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panDgvLblContext.Controls.Add(this.lblDgvContext);
            this.panDgvLblContext.Dock = System.Windows.Forms.DockStyle.Top;
            this.panDgvLblContext.Location = new System.Drawing.Point(0, 0);
            this.panDgvLblContext.Name = "panDgvLblContext";
            this.panDgvLblContext.Size = new System.Drawing.Size(961, 26);
            this.panDgvLblContext.TabIndex = 2;
            // 
            // lblDgvContext
            // 
            this.lblDgvContext.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblDgvContext.AutoSize = true;
            this.lblDgvContext.Location = new System.Drawing.Point(418, 3);
            this.lblDgvContext.Name = "lblDgvContext";
            this.lblDgvContext.Size = new System.Drawing.Size(103, 13);
            this.lblDgvContext.TabIndex = 0;
            this.lblDgvContext.Text = "List of context group";
            // 
            // panLbl
            // 
            this.panLbl.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panLbl.Controls.Add(this.lblContext);
            this.panLbl.Dock = System.Windows.Forms.DockStyle.Top;
            this.panLbl.Location = new System.Drawing.Point(0, 0);
            this.panLbl.Name = "panLbl";
            this.panLbl.Size = new System.Drawing.Size(961, 35);
            this.panLbl.TabIndex = 5;
            // 
            // lblContext
            // 
            this.lblContext.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblContext.AutoSize = true;
            this.lblContext.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContext.Location = new System.Drawing.Point(378, 8);
            this.lblContext.Name = "lblContext";
            this.lblContext.Size = new System.Drawing.Size(182, 16);
            this.lblContext.TabIndex = 0;
            this.lblContext.Text = "Current Selected Context:";
            // 
            // panBtnOk
            // 
            this.panBtnOk.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panBtnOk.Controls.Add(this.btnCancel);
            this.panBtnOk.Controls.Add(this.btnOk);
            this.panBtnOk.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panBtnOk.Location = new System.Drawing.Point(0, 526);
            this.panBtnOk.Name = "panBtnOk";
            this.panBtnOk.Size = new System.Drawing.Size(961, 33);
            this.panBtnOk.TabIndex = 4;
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.Location = new System.Drawing.Point(827, 5);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(73, 23);
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOk
            // 
            this.btnOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOk.Location = new System.Drawing.Point(732, 5);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(73, 23);
            this.btnOk.TabIndex = 0;
            this.btnOk.Text = "Ok";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // frmBatchPMOffset
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(961, 559);
            this.Controls.Add(this.panel1);
            this.Name = "frmBatchPMOffset";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BatchPMOffset";
            this.Load += new System.EventHandler(this.frmBatchPMOffset_Load);
            this.SizeChanged += new System.EventHandler(this.frmBatchPMOffset_SizeChanged);
            this.Resize += new System.EventHandler(this.frmBatchPMOffset_Resize);
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSet)).EndInit();
            this.panDgvLblParameters.ResumeLayout(false);
            this.panDgvLblParameters.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panDgv.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvContext)).EndInit();
            this.panDgvLblContext.ResumeLayout(false);
            this.panDgvLblContext.PerformLayout();
            this.panLbl.ResumeLayout(false);
            this.panLbl.PerformLayout();
            this.panBtnOk.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panBtnOk;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panLbl;
        private System.Windows.Forms.Label lblContext;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panDgvLblParameters;
        private System.Windows.Forms.Label lblDgvParameters;
        private System.Windows.Forms.Panel panDgv;
        private System.Windows.Forms.Panel panDgvLblContext;
        private System.Windows.Forms.Label lblDgvContext;
        private System.Windows.Forms.DataGridView dgvSet;
        private System.Windows.Forms.DataGridView dgvContext;
    }
}
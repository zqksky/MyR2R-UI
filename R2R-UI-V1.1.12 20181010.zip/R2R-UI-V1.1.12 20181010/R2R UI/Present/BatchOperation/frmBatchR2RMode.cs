﻿using R2R_UI.Common;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace R2R_UI.Present.BatchOperation
{
    public partial class frmBatchR2RMode : Form
    {
        #region
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x0014) // 禁掉清除背景消息
                return;
            base.WndProc(ref m);
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x02000000;
                return cp;
            }
        }

        private void CtlDoubleBuffer()
        {
            this.DoubleBuffered = true;//设置本窗体
            SetStyle(ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true); // 禁止擦除背景.
            SetStyle(ControlStyles.DoubleBuffer, true); // 双缓冲
            //SetStyle(ControlStyles.DoubleBuffer | ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint, true);
            UpdateStyles();
        }
        #endregion

        public frmBatchR2RMode()
        {
            InitializeComponent();
        }
        public frmBatchR2RMode(string strServiceName, string strCurrentUserName, string strCurrentPwd, string strFrmProduct, string strFrmLayer, string strFrmTool, UIServiceFun.structPH_OVL_Batch_GetR2RMode structDataR2RMode)
        {
            InitializeComponent();
            strServiceAddress = strServiceName;
            strUserName = strCurrentUserName;
            strPassword = strCurrentPwd;

            strProduct = strFrmProduct;
            strLayer = strFrmLayer;
            strTool = strFrmTool;
            structData = structDataR2RMode;
            strListR2RModes = new List<string>(structDataR2RMode.strListR2RModes);
            strListR2RModeReticleIds = new List<string>(structDataR2RMode.strListR2RModeReticleIds);
            strListInputChuckIds = new List<string>(structDataR2RMode.strListInputChuckIds);
            strListInputReticleIds = new List<string>(structDataR2RMode.strListInputReticleIds);
            strListInputParameterNames = new List<string>(structDataR2RMode.strListInputParameterNames);
            dListInputFixedValues = new List<double>(structDataR2RMode.dListInputFixedValues);
            dListInputMax = new List<double>(structDataR2RMode.dListInputMax);
            dListInputMin = new List<double>(structDataR2RMode.dListInputMin);
        }

        #region parm
        string strServiceAddress;
        string strUserName;
        string strPassword;

        string strProduct;
        string strLayer;
        string strTool;

        List<string> strListR2RModes;
        List<string> strListR2RModeReticleIds;
        List<string> strListInputChuckIds;
        List<string> strListInputReticleIds;
        List<string> strListInputParameterNames;
        List<double> dListInputFixedValues;
        List<double> dListInputMax;
        List<double> dListInputMin;

        string strR2RMode;
        string strChuckId;
        string strReticleId;
        List<string> strListChuckId = new List<string>();
        List<string> strListInputParameterNamesChange = new List<string>();
        List<double> dListInputFixedValuesChange = new List<double>();
        List<double> dListInputMaxChange = new List<double>();
        List<double> dListInputMinChange = new List<double>();

        List<string> strListInputParameterNamesCurrent = new List<string>();
        List<double> dListInputFixedValuesCurrent = new List<double>();
        List<double> dListInputMaxCurrent = new List<double>();
        List<double> dListInputMinCurrent = new List<double>();

        UIServiceFun.structPH_OVL_Batch_GetR2RMode structData = new UIServiceFun.structPH_OVL_Batch_GetR2RMode();
        #endregion

        private void InitR2RMode()
        {
            rdoActive.Checked= true;
            strR2RMode = "Active";

            if (strListR2RModes[0].Equals("Fixed"))
            {
                rdoFixed.Checked= true;
                strR2RMode = "Fixed";
            }
        }

        private void SetR2RMode(string strReticle)
        {
            if (strListR2RModeReticleIds[0].Equals(strReticle))
            {
                if (strListR2RModes[0].Equals("Fixed"))
                {
                    rdoFixed.Checked = true;
                    strR2RMode = "Fixed";
                }
                else
                {
                    rdoActive.Checked = true;
                    strR2RMode = "Active";
                }
            }
            else
            {
                if (strListR2RModes[1].Equals("Fixed"))
                {
                    rdoFixed.Checked = true;
                    strR2RMode = "Fixed";
                }
                else
                {
                    rdoActive.Checked = true;
                    strR2RMode = "Active";
                }
            }
        }

        private void GetChuckIdAndReticleId()
        {
            strListChuckId = BaseFun.GetGroupName(strListInputChuckIds);
            cmbChuckId.DataSource = strListChuckId;

            cmbReticleId.DataSource = strListR2RModeReticleIds;
        }
        private void InitChuckId()
        {
            //strListChuckId = BaseFun.GetGroupName(strListInputChuckIds);
            //cmbChuckId.DataSource = strListChuckId;
            cmbChuckId.SelectedIndex = 0;
            strChuckId = cmbChuckId.Text.ToString();
        }
        private void InitReticleId()
        {
            //cmbReticleId.DataSource = strListR2RModeReticleIds;
            cmbReticleId.SelectedIndex = 0;
            strReticleId = cmbReticleId.Text.ToString();
        }

        private float frmLocationX;
        private float frmLocationY;
        AdaptiveSizeResolution AutoSizeFrm = new AdaptiveSizeResolution();
        DataTable dbGetContext = new DataTable("GetContext");
        DataTable dbGetR2RModeGroup = new DataTable("R2RModeGroup");
        private void frmBatchR2RMode_Load(object sender, EventArgs e)
        {
            #region  Double Buffer
            DataGridViewHelp.DoubleBuffered(dgvContext, true);
            DataGridViewHelp.DoubleBuffered(dgvSet, true);
            CtlDoubleBuffer();
            #endregion

            #region AdaptiveSizeResolution
            //AutoSizeFrm.ControllInitializeSize(this);
            #endregion

            #region  AdaptiveSize
            //this.Resize += new EventHandler(frmBatchR2RMode_Resize);
            //frmLocationX = this.Width;
            //frmLocationY = this.Height;
            //AdaptiveSize.setTag(this);
            #endregion

            #region Init Lbl
            string strLbl = "Current Selected Context:" + strProduct + " /" + strTool + " /" + strLayer;
            AddControlHelp.SetLable(panLbl, lblContext, strLbl);

            string strDgvLblContext = "List of context group";
            AddControlHelp.SetLable(panDgvLblContext, lblDgvContext, strDgvLblContext);

            string strDgvLblParameters = "List of Parameters";
            AddControlHelp.SetLable(panDgvLblParameters, lblDgvParameters, strDgvLblParameters);
            #endregion

            #region Init Control
            GetChuckIdAndReticleId();
            InitR2RMode();
            InitChuckId();
            InitReticleId();
            #endregion

            #region Get DataContext by zqk modify 20180809
            dbGetContext = DataTableHelp.CreateContextGroupTable(structData.structContext);

            DataTable dbContextGroup = new DataTable("ContextGroup");
            List<string> strListColumn = new List<string>(structData.structContext.strListContexts);
            dbContextGroup = DataTableHelp.GetDistinctTable(dbGetContext, strListColumn);

            //InitContextGrid(grdBatchR2RModeContext, dbContextGroup);
            DataGridViewHelp.InitDgvGrid(dgvContext, dbContextGroup);
            #endregion

            #region Get Parameters
            dbGetR2RModeGroup = DataTableHelp.CreateBatchR2RModeGroupTable(strListInputChuckIds, strListInputReticleIds, strListInputParameterNames, dListInputMax, dListInputMin, dListInputFixedValues);

            DataTable dbR2RMode = new DataTable("R2RMode");
            dbR2RMode = DataTableHelp.CreateBatchR2RModeTable(dbGetR2RModeGroup, strChuckId, strReticleId);

            //DataGridViewHelp.InitDgvGrid(grdBatchR2RMode, dbR2RMode);
            DataGridViewHelp.InitDgvSet(dgvSet, dbR2RMode, 6);
            GetCurrentGridValue();
            //GetCurrentGridValue(ref strListInputParameterNamesCurrent, ref dListInputMaxCurrent, ref dListInputMinCurrent, ref dListInputFixedValuesCurrent);
            #endregion
        }

        private void frmBatchR2RMode_Resize(object sender, EventArgs e)
        {
            #region AdaptiveSize
            //float newx = (this.Width) / frmLocationX;
            //float newy = this.Height / frmLocationY;
            //AdaptiveSize.setControls(newx, newy, this);
            #endregion
        }

        private void frmBatchR2RMode_SizeChanged(object sender, EventArgs e)
        {
            #region AdaptiveSizeResolution
            //AutoSizeFrm.ControlAutoSize(this);
            #endregion
        }

        private void ChuckIdOrReticleIdChanged()
        {
            if (cmbChuckId.Text.Equals("") || cmbReticleId.Text.Equals(""))
            {
            }
            else
            {
                strChuckId = cmbChuckId.Text;
                strReticleId = cmbReticleId.Text;
                SetR2RMode(strReticleId);

                DataTable dbR2RMode = new DataTable("R2RMode");
                if(dbGetR2RModeGroup.Rows.Count>0)
                {
                    dbR2RMode = DataTableHelp.CreateBatchR2RModeTable(dbGetR2RModeGroup, strChuckId, strReticleId);

                    DataGridViewHelp.InitDgvSet(dgvSet, dbR2RMode, 6);

                    GetCurrentGridValue();
                    //GetCurrentGridValue(ref strListInputParameterNamesCurrent, ref dListInputMaxCurrent, ref dListInputMinCurrent, ref dListInputFixedValuesCurrent);
                }     
            }
           
        }

        private void rdoType_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoActive.Checked)
            {
                strR2RMode = "Active";
            }
            else if (rdoFixed.Checked)
            {
                strR2RMode = "Fixed";
            }
        }

        private void cmbChuckId_SelectedIndexChanged(object sender, EventArgs e)
        {
            ChuckIdOrReticleIdChanged();
        }

        private void cmbReticleId_SelectedIndexChanged(object sender, EventArgs e)
        {
            ChuckIdOrReticleIdChanged();
        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            ChuckIdOrReticleIdChanged();
        }

        private void GetCurrentGridValue()
        {
            int rowCount = 0;
            rowCount = dgvSet.Rows.Count;
            if (rowCount > 0)
            {
                strListInputParameterNamesCurrent.Clear();
                dListInputFixedValuesCurrent.Clear();
                dListInputMinCurrent.Clear();
                dListInputMinCurrent.Clear();
                for (int i = 0; i < rowCount; i++)
                {
                    strListInputParameterNamesCurrent.Add(dgvSet.Rows[i].Cells[2].Value.ToString());
                    dListInputMaxCurrent.Add(double.Parse(dgvSet.Rows[i].Cells[3].Value.ToString()));
                    dListInputMinCurrent.Add(double.Parse(dgvSet.Rows[i].Cells[4].Value.ToString()));
                    dListInputFixedValuesCurrent.Add(double.Parse(dgvSet.Rows[i].Cells[6].Value.ToString()));
                }
            }
        }

        private void GetCurrentGridValue(ref List<string> strListParameterNamesCurrent, ref List<double> dListMaxCurrent, ref List<double> dListMinCurrent, ref List<double> dListFixedValuesCurrent)
        {
            int rowCount = 0;
            rowCount = dgvSet.Rows.Count;
            if (rowCount > 0)
            {
                strListParameterNamesCurrent.Clear();
                dListFixedValuesCurrent.Clear();
                dListMinCurrent.Clear();
                dListMinCurrent.Clear();
                for (int i = 0; i < rowCount; i++)
                {
                    strListParameterNamesCurrent.Add(dgvSet.Rows[i].Cells[2].Value.ToString());
                    dListMaxCurrent.Add(double.Parse(dgvSet.Rows[i].Cells[3].Value.ToString()));
                    dListMinCurrent.Add(double.Parse(dgvSet.Rows[i].Cells[4].Value.ToString()));
                    dListFixedValuesCurrent.Add(double.Parse(dgvSet.Rows[i].Cells[6].Value.ToString()));
                }
            }
        }
        private bool IsCellValueChange(double dFixedValue, int rowIndex)
        {
            bool flag = false;

            flag = dFixedValue != dListInputFixedValuesCurrent[rowIndex] ? true : false;
            if (flag)
            {
                this.dgvSet.Rows[rowIndex].Cells[6].Style.BackColor = Color.Honeydew;
            }
            else
            {
                this.dgvSet.Rows[rowIndex].Cells[6].Style.BackColor = Color.White;
            }

            return flag;
        }

        private Hashtable htRowChange = new Hashtable();
        private void dgvSet_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            //bool flag;
            //double dMax = 0.0;
            //double dMin = 0.0;
            //double dFixedValue = 0.0;
            //dMax = double.Parse(dgvSet.Rows[e.RowIndex].Cells[3].Value.ToString());
            //dMin = double.Parse(dgvSet.Rows[e.RowIndex].Cells[4].Value.ToString());
            //dFixedValue = double.Parse(dgvSet.Rows[e.RowIndex].Cells[6].Value.ToString());
            //if (dFixedValue <= dMax && dFixedValue >= dMin)
            //{
            //    flag = IsCellValueChange(dFixedValue, e.RowIndex);
            //    if (flag)
            //    {
            //        strListInputParameterNamesChange.Add(dgvSet.Rows[e.RowIndex].Cells[2].Value.ToString());
            //        dListInputMaxChange.Add(double.Parse(dgvSet.Rows[e.RowIndex].Cells[3].Value.ToString()));
            //        dListInputMinChange.Add(double.Parse(dgvSet.Rows[e.RowIndex].Cells[4].Value.ToString()));
            //        dListInputFixedValuesChange.Add(double.Parse(dgvSet.Rows[e.RowIndex].Cells[6].Value.ToString()));
            //        htRowChange.Add(e.RowIndex.ToString(), strListInputParameterNamesChange.Count - 1);
            //    }
            //}
            //else
            //{
            //    MessageBox.Show("Set values out of range");
            //    dgvSet.Rows[e.RowIndex].Cells[6].Value = dgvSet.Rows[e.RowIndex].Cells[5].Value;
            //}
        }

        private void dgvSet_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (htRowChange.ContainsKey(e.RowIndex.ToString()))
            {
                int index = int.Parse(htRowChange[e.RowIndex.ToString()].ToString());
                strListInputParameterNamesChange.RemoveAt(index);
                dListInputFixedValuesChange.RemoveAt(index);
                dListInputMaxChange.RemoveAt(index);
                dListInputMinChange.RemoveAt(index);
                htRowChange.Remove(e.RowIndex.ToString());
            }
            bool flag;
            double dMax = 0.0;
            double dMin = 0.0;
            double dFixedValue = 0.0;
            dMax = double.Parse(dgvSet.Rows[e.RowIndex].Cells[3].Value.ToString());
            dMin = double.Parse(dgvSet.Rows[e.RowIndex].Cells[4].Value.ToString());
            dFixedValue = double.Parse(dgvSet.Rows[e.RowIndex].Cells[6].Value.ToString());
            if (dFixedValue <= dMax && dFixedValue >= dMin)
            {
                flag = IsCellValueChange(dFixedValue, e.RowIndex);
                if (flag)
                {
                    strListInputParameterNamesChange.Add(dgvSet.Rows[e.RowIndex].Cells[2].Value.ToString());
                    dListInputMaxChange.Add(double.Parse(dgvSet.Rows[e.RowIndex].Cells[3].Value.ToString()));
                    dListInputMinChange.Add(double.Parse(dgvSet.Rows[e.RowIndex].Cells[4].Value.ToString()));
                    dListInputFixedValuesChange.Add(double.Parse(dgvSet.Rows[e.RowIndex].Cells[6].Value.ToString()));
                    htRowChange.Add(e.RowIndex.ToString(), strListInputParameterNamesChange.Count - 1);
                }
            }
            else
            {
                MessageBox.Show("Set values out of range");
                dgvSet.Rows[e.RowIndex].Cells[6].Value = dgvSet.Rows[e.RowIndex].Cells[5].Value;
            }
        }
        private void btnOk_Click(object sender, EventArgs e)
        {
            frmCheckedPwd frmChecked = new frmCheckedPwd(strUserName);
            if (frmChecked.ShowDialog() == DialogResult.OK)
            {
                if (frmChecked.strPassword.Equals(strPassword))
                {
                    #region
                    bool bSuccess;
                    try
                    {
                        #region PH_OVL_Batch_UpdateOVLModel
                        strChuckId = cmbChuckId.Text;
                        strReticleId = cmbReticleId.Text;
                        bSuccess = UIServiceFun.R2R_UI_PH_OVL_Batch_UpdateR2RMode(strServiceAddress, strUserName, strProduct, strLayer, strTool, strR2RMode, strChuckId, strReticleId, strListInputParameterNamesChange, dListInputMaxChange, dListInputMinChange, dListInputFixedValuesChange);
                        if (bSuccess)
                        {
                            this.Close();
                        }
                        else
                        {
                            //MessageBox.Show("Set Failed!");
                        }
                        #endregion

                        this.DialogResult = DialogResult.OK;
                    }
                    catch (Exception ee)
                    {
                        MessageBox.Show(ee.Message);
                    }
                    #endregion
                }
                else
                {
                    MessageBox.Show("Invalid password!");
                }
            }
            else
            {
                //MessageBox.Show("Invalid password!");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #region Test DataGridView Event
        private void dgvContext_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            //DataGridViewHelp.dgv_CellFormatting(sender, e);
        }

        private void dgvContext_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            //DataGridViewHelp.dgv_CellPainting(sender,  e);
        }

        private void dgvContext_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            //DataGridViewHelp.dgv_RowPostPaint(sender, e);
        }
        #endregion

    }
}

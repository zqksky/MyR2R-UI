﻿namespace R2R_UI
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panMain = new System.Windows.Forms.Panel();
            this.tabMain = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panOptMainTab = new System.Windows.Forms.Panel();
            this.panOptChart = new System.Windows.Forms.Panel();
            this.panOptSub = new System.Windows.Forms.Panel();
            this.panOptTabSub = new System.Windows.Forms.Panel();
            this.tabOptSubTab = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.grdOptLinear = new System.Windows.Forms.DataGridView();
            this.panLinearLbl = new System.Windows.Forms.Panel();
            this.lblLinear = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.grdOptHOPC = new System.Windows.Forms.DataGridView();
            this.panHOPCLbl = new System.Windows.Forms.Panel();
            this.lblHOPC = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.grdOptIHOPC = new System.Windows.Forms.DataGridView();
            this.panIHOPCLbl = new System.Windows.Forms.Panel();
            this.lblIHOPC = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.panel4 = new System.Windows.Forms.Panel();
            this.grdOptCPE = new System.Windows.Forms.DataGridView();
            this.panCPELbl = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.panel5 = new System.Windows.Forms.Panel();
            this.grdOptCD = new System.Windows.Forms.DataGridView();
            this.panCDLbl = new System.Windows.Forms.Panel();
            this.lblCD = new System.Windows.Forms.Label();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.panel6 = new System.Windows.Forms.Panel();
            this.grdOptFocus = new System.Windows.Forms.DataGridView();
            this.panFocusLbl = new System.Windows.Forms.Panel();
            this.lblFocus = new System.Windows.Forms.Label();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.panel7 = new System.Windows.Forms.Panel();
            this.grdOptCommon1 = new System.Windows.Forms.DataGridView();
            this.panCommon1Lb1 = new System.Windows.Forms.Panel();
            this.lblCommon1 = new System.Windows.Forms.Label();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.panel8 = new System.Windows.Forms.Panel();
            this.grdOptCommon2 = new System.Windows.Forms.DataGridView();
            this.panCommon2Lb1 = new System.Windows.Forms.Panel();
            this.lblCommon2 = new System.Windows.Forms.Label();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.panel9 = new System.Windows.Forms.Panel();
            this.grdOptCommon3 = new System.Windows.Forms.DataGridView();
            this.panCommon3Lb1 = new System.Windows.Forms.Panel();
            this.lblCommon3 = new System.Windows.Forms.Label();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.panel10 = new System.Windows.Forms.Panel();
            this.grdOptCommon4 = new System.Windows.Forms.DataGridView();
            this.panCommon4Lb1 = new System.Windows.Forms.Panel();
            this.lblCommon4 = new System.Windows.Forms.Label();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.panel11 = new System.Windows.Forms.Panel();
            this.grdOptCommon5 = new System.Windows.Forms.DataGridView();
            this.panCommon5Lb1 = new System.Windows.Forms.Panel();
            this.lblCommon5 = new System.Windows.Forms.Label();
            this.tabPage14 = new System.Windows.Forms.TabPage();
            this.panel12 = new System.Windows.Forms.Panel();
            this.grdOptCommon6 = new System.Windows.Forms.DataGridView();
            this.panCommon6Lb1 = new System.Windows.Forms.Panel();
            this.lblCommon6 = new System.Windows.Forms.Label();
            this.panOptSubBtn = new System.Windows.Forms.Panel();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtCurrentOVLMode = new System.Windows.Forms.Label();
            this.txtCurrentR2RMode = new System.Windows.Forms.Label();
            this.grpBtn = new System.Windows.Forms.GroupBox();
            this.btnOptMode = new System.Windows.Forms.Button();
            this.btnOptReset = new System.Windows.Forms.Button();
            this.grpList = new System.Windows.Forms.GroupBox();
            this.rdoMetrology = new System.Windows.Forms.RadioButton();
            this.rdoLotAll = new System.Windows.Forms.RadioButton();
            this.panOptContext = new System.Windows.Forms.Panel();
            this.panOptContextGroup = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.grdOptContextGroup = new System.Windows.Forms.DataGridView();
            this.panContextGroupLbl = new System.Windows.Forms.Panel();
            this.lblContextGroup = new System.Windows.Forms.Label();
            this.panOptBtn = new System.Windows.Forms.Panel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdoChuck2 = new System.Windows.Forms.RadioButton();
            this.rdoChuck1 = new System.Windows.Forms.RadioButton();
            this.btnPreLayerConfig = new System.Windows.Forms.Button();
            this.btnChuckDedication = new System.Windows.Forms.Button();
            this.btnOptBatchOperation = new System.Windows.Forms.Button();
            this.panOptContextGrid = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.cmbTool = new System.Windows.Forms.ComboBox();
            this.btnOptRun = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.txtLots = new System.Windows.Forms.TextBox();
            this.txtModule = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbProduct = new System.Windows.Forms.ComboBox();
            this.cmbControl = new System.Windows.Forms.ComboBox();
            this.cmbLayer = new System.Windows.Forms.ComboBox();
            this.txtStage = new System.Windows.Forms.TextBox();
            this.txtLayer = new System.Windows.Forms.TextBox();
            this.cmbStage = new System.Windows.Forms.ComboBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.cmbModule = new System.Windows.Forms.ComboBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panMain.SuspendLayout();
            this.tabMain.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panOptMainTab.SuspendLayout();
            this.panOptSub.SuspendLayout();
            this.panOptTabSub.SuspendLayout();
            this.tabOptSubTab.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdOptLinear)).BeginInit();
            this.panLinearLbl.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdOptHOPC)).BeginInit();
            this.panHOPCLbl.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdOptIHOPC)).BeginInit();
            this.panIHOPCLbl.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdOptCPE)).BeginInit();
            this.panCPELbl.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdOptCD)).BeginInit();
            this.panCDLbl.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdOptFocus)).BeginInit();
            this.panFocusLbl.SuspendLayout();
            this.tabPage9.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdOptCommon1)).BeginInit();
            this.panCommon1Lb1.SuspendLayout();
            this.tabPage10.SuspendLayout();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdOptCommon2)).BeginInit();
            this.panCommon2Lb1.SuspendLayout();
            this.tabPage11.SuspendLayout();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdOptCommon3)).BeginInit();
            this.panCommon3Lb1.SuspendLayout();
            this.tabPage12.SuspendLayout();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdOptCommon4)).BeginInit();
            this.panCommon4Lb1.SuspendLayout();
            this.tabPage13.SuspendLayout();
            this.panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdOptCommon5)).BeginInit();
            this.panCommon5Lb1.SuspendLayout();
            this.tabPage14.SuspendLayout();
            this.panel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdOptCommon6)).BeginInit();
            this.panCommon6Lb1.SuspendLayout();
            this.panOptSubBtn.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.grpBtn.SuspendLayout();
            this.grpList.SuspendLayout();
            this.panOptContext.SuspendLayout();
            this.panOptContextGroup.SuspendLayout();
            this.panel14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdOptContextGroup)).BeginInit();
            this.panContextGroupLbl.SuspendLayout();
            this.panOptBtn.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panOptContextGrid.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panMain
            // 
            this.panMain.Controls.Add(this.tabMain);
            this.panMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panMain.Location = new System.Drawing.Point(0, 0);
            this.panMain.Name = "panMain";
            this.panMain.Size = new System.Drawing.Size(1524, 867);
            this.panMain.TabIndex = 0;
            // 
            // tabMain
            // 
            this.tabMain.Controls.Add(this.tabPage1);
            this.tabMain.Controls.Add(this.tabPage2);
            this.tabMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabMain.Location = new System.Drawing.Point(0, 0);
            this.tabMain.Name = "tabMain";
            this.tabMain.SelectedIndex = 0;
            this.tabMain.Size = new System.Drawing.Size(1524, 867);
            this.tabMain.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.panOptMainTab);
            this.tabPage1.Controls.Add(this.statusStrip1);
            this.tabPage1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1516, 838);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Operation";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // panOptMainTab
            // 
            this.panOptMainTab.Controls.Add(this.panOptChart);
            this.panOptMainTab.Controls.Add(this.panOptSub);
            this.panOptMainTab.Controls.Add(this.panOptContext);
            this.panOptMainTab.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panOptMainTab.Location = new System.Drawing.Point(3, 3);
            this.panOptMainTab.Name = "panOptMainTab";
            this.panOptMainTab.Size = new System.Drawing.Size(1510, 810);
            this.panOptMainTab.TabIndex = 1;
            // 
            // panOptChart
            // 
            this.panOptChart.AutoScroll = true;
            this.panOptChart.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panOptChart.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panOptChart.Location = new System.Drawing.Point(0, 489);
            this.panOptChart.Name = "panOptChart";
            this.panOptChart.Size = new System.Drawing.Size(1510, 321);
            this.panOptChart.TabIndex = 2;
            // 
            // panOptSub
            // 
            this.panOptSub.Controls.Add(this.panOptTabSub);
            this.panOptSub.Controls.Add(this.panOptSubBtn);
            this.panOptSub.Dock = System.Windows.Forms.DockStyle.Top;
            this.panOptSub.Location = new System.Drawing.Point(0, 242);
            this.panOptSub.Name = "panOptSub";
            this.panOptSub.Size = new System.Drawing.Size(1510, 247);
            this.panOptSub.TabIndex = 1;
            // 
            // panOptTabSub
            // 
            this.panOptTabSub.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panOptTabSub.Controls.Add(this.tabOptSubTab);
            this.panOptTabSub.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panOptTabSub.Location = new System.Drawing.Point(0, 0);
            this.panOptTabSub.Name = "panOptTabSub";
            this.panOptTabSub.Size = new System.Drawing.Size(1243, 247);
            this.panOptTabSub.TabIndex = 3;
            // 
            // tabOptSubTab
            // 
            this.tabOptSubTab.Controls.Add(this.tabPage3);
            this.tabOptSubTab.Controls.Add(this.tabPage4);
            this.tabOptSubTab.Controls.Add(this.tabPage5);
            this.tabOptSubTab.Controls.Add(this.tabPage6);
            this.tabOptSubTab.Controls.Add(this.tabPage7);
            this.tabOptSubTab.Controls.Add(this.tabPage8);
            this.tabOptSubTab.Controls.Add(this.tabPage9);
            this.tabOptSubTab.Controls.Add(this.tabPage10);
            this.tabOptSubTab.Controls.Add(this.tabPage11);
            this.tabOptSubTab.Controls.Add(this.tabPage12);
            this.tabOptSubTab.Controls.Add(this.tabPage13);
            this.tabOptSubTab.Controls.Add(this.tabPage14);
            this.tabOptSubTab.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabOptSubTab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabOptSubTab.Location = new System.Drawing.Point(0, 0);
            this.tabOptSubTab.Name = "tabOptSubTab";
            this.tabOptSubTab.SelectedIndex = 0;
            this.tabOptSubTab.Size = new System.Drawing.Size(1241, 245);
            this.tabOptSubTab.TabIndex = 0;
            this.tabOptSubTab.SelectedIndexChanged += new System.EventHandler(this.tabOptSubTab_SelectedIndexChanged);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.panel1);
            this.tabPage3.Controls.Add(this.panLinearLbl);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1233, 216);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "Linear";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.grdOptLinear);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 29);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1227, 184);
            this.panel1.TabIndex = 4;
            // 
            // grdOptLinear
            // 
            this.grdOptLinear.AllowUserToAddRows = false;
            this.grdOptLinear.AllowUserToDeleteRows = false;
            this.grdOptLinear.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.grdOptLinear.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.grdOptLinear.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdOptLinear.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdOptLinear.Location = new System.Drawing.Point(0, 0);
            this.grdOptLinear.Name = "grdOptLinear";
            this.grdOptLinear.Size = new System.Drawing.Size(1227, 184);
            this.grdOptLinear.TabIndex = 2;
            this.grdOptLinear.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.grdOptContextGroup_CellFormatting);
            this.grdOptLinear.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.grdOptContextGroup_CellPainting);
            this.grdOptLinear.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.grdOptContextGroup_RowPostPaint);
            // 
            // panLinearLbl
            // 
            this.panLinearLbl.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panLinearLbl.Controls.Add(this.lblLinear);
            this.panLinearLbl.Dock = System.Windows.Forms.DockStyle.Top;
            this.panLinearLbl.Location = new System.Drawing.Point(3, 3);
            this.panLinearLbl.Name = "panLinearLbl";
            this.panLinearLbl.Size = new System.Drawing.Size(1227, 26);
            this.panLinearLbl.TabIndex = 3;
            // 
            // lblLinear
            // 
            this.lblLinear.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblLinear.AutoSize = true;
            this.lblLinear.Location = new System.Drawing.Point(137, 7);
            this.lblLinear.Name = "lblLinear";
            this.lblLinear.Size = new System.Drawing.Size(45, 16);
            this.lblLinear.TabIndex = 0;
            this.lblLinear.Text = "label2";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.panel2);
            this.tabPage4.Controls.Add(this.panHOPCLbl);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1233, 216);
            this.tabPage4.TabIndex = 1;
            this.tabPage4.Text = "HOPC";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.grdOptHOPC);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(3, 29);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1227, 184);
            this.panel2.TabIndex = 5;
            // 
            // grdOptHOPC
            // 
            this.grdOptHOPC.AllowUserToAddRows = false;
            this.grdOptHOPC.AllowUserToDeleteRows = false;
            this.grdOptHOPC.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.grdOptHOPC.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.grdOptHOPC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdOptHOPC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdOptHOPC.Location = new System.Drawing.Point(0, 0);
            this.grdOptHOPC.Name = "grdOptHOPC";
            this.grdOptHOPC.Size = new System.Drawing.Size(1227, 184);
            this.grdOptHOPC.TabIndex = 2;
            this.grdOptHOPC.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.grdOptContextGroup_CellFormatting);
            this.grdOptHOPC.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.grdOptContextGroup_CellPainting);
            this.grdOptHOPC.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.grdOptContextGroup_RowPostPaint);
            // 
            // panHOPCLbl
            // 
            this.panHOPCLbl.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panHOPCLbl.Controls.Add(this.lblHOPC);
            this.panHOPCLbl.Dock = System.Windows.Forms.DockStyle.Top;
            this.panHOPCLbl.Location = new System.Drawing.Point(3, 3);
            this.panHOPCLbl.Name = "panHOPCLbl";
            this.panHOPCLbl.Size = new System.Drawing.Size(1227, 26);
            this.panHOPCLbl.TabIndex = 4;
            // 
            // lblHOPC
            // 
            this.lblHOPC.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblHOPC.AutoSize = true;
            this.lblHOPC.Location = new System.Drawing.Point(137, 7);
            this.lblHOPC.Name = "lblHOPC";
            this.lblHOPC.Size = new System.Drawing.Size(45, 16);
            this.lblHOPC.TabIndex = 0;
            this.lblHOPC.Text = "label3";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.panel3);
            this.tabPage5.Controls.Add(this.panIHOPCLbl);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1233, 216);
            this.tabPage5.TabIndex = 2;
            this.tabPage5.Text = "IHOPC";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.grdOptIHOPC);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(3, 29);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1227, 184);
            this.panel3.TabIndex = 5;
            // 
            // grdOptIHOPC
            // 
            this.grdOptIHOPC.AllowUserToAddRows = false;
            this.grdOptIHOPC.AllowUserToDeleteRows = false;
            this.grdOptIHOPC.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.grdOptIHOPC.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.grdOptIHOPC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdOptIHOPC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdOptIHOPC.Location = new System.Drawing.Point(0, 0);
            this.grdOptIHOPC.Name = "grdOptIHOPC";
            this.grdOptIHOPC.Size = new System.Drawing.Size(1227, 184);
            this.grdOptIHOPC.TabIndex = 2;
            this.grdOptIHOPC.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.grdOptContextGroup_CellFormatting);
            this.grdOptIHOPC.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.grdOptContextGroup_CellPainting);
            this.grdOptIHOPC.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.grdOptContextGroup_RowPostPaint);
            // 
            // panIHOPCLbl
            // 
            this.panIHOPCLbl.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panIHOPCLbl.Controls.Add(this.lblIHOPC);
            this.panIHOPCLbl.Dock = System.Windows.Forms.DockStyle.Top;
            this.panIHOPCLbl.Location = new System.Drawing.Point(3, 3);
            this.panIHOPCLbl.Name = "panIHOPCLbl";
            this.panIHOPCLbl.Size = new System.Drawing.Size(1227, 26);
            this.panIHOPCLbl.TabIndex = 4;
            // 
            // lblIHOPC
            // 
            this.lblIHOPC.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblIHOPC.AutoSize = true;
            this.lblIHOPC.Location = new System.Drawing.Point(137, 7);
            this.lblIHOPC.Name = "lblIHOPC";
            this.lblIHOPC.Size = new System.Drawing.Size(45, 16);
            this.lblIHOPC.TabIndex = 0;
            this.lblIHOPC.Text = "label4";
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.panel4);
            this.tabPage6.Controls.Add(this.panCPELbl);
            this.tabPage6.Location = new System.Drawing.Point(4, 25);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(1233, 216);
            this.tabPage6.TabIndex = 3;
            this.tabPage6.Text = "CPE";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.grdOptCPE);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(3, 29);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1227, 184);
            this.panel4.TabIndex = 6;
            // 
            // grdOptCPE
            // 
            this.grdOptCPE.AllowUserToAddRows = false;
            this.grdOptCPE.AllowUserToDeleteRows = false;
            this.grdOptCPE.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.grdOptCPE.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.grdOptCPE.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdOptCPE.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdOptCPE.Location = new System.Drawing.Point(0, 0);
            this.grdOptCPE.Name = "grdOptCPE";
            this.grdOptCPE.Size = new System.Drawing.Size(1227, 184);
            this.grdOptCPE.TabIndex = 2;
            // 
            // panCPELbl
            // 
            this.panCPELbl.Controls.Add(this.label5);
            this.panCPELbl.Dock = System.Windows.Forms.DockStyle.Top;
            this.panCPELbl.Location = new System.Drawing.Point(3, 3);
            this.panCPELbl.Name = "panCPELbl";
            this.panCPELbl.Size = new System.Drawing.Size(1227, 26);
            this.panCPELbl.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(147, 7);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 16);
            this.label5.TabIndex = 0;
            this.label5.Text = "label5";
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.panel5);
            this.tabPage7.Controls.Add(this.panCDLbl);
            this.tabPage7.Location = new System.Drawing.Point(4, 25);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(1233, 216);
            this.tabPage7.TabIndex = 4;
            this.tabPage7.Text = "CD";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.grdOptCD);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(3, 29);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1227, 184);
            this.panel5.TabIndex = 7;
            // 
            // grdOptCD
            // 
            this.grdOptCD.AllowUserToAddRows = false;
            this.grdOptCD.AllowUserToDeleteRows = false;
            this.grdOptCD.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.grdOptCD.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.grdOptCD.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdOptCD.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdOptCD.Location = new System.Drawing.Point(0, 0);
            this.grdOptCD.Name = "grdOptCD";
            this.grdOptCD.Size = new System.Drawing.Size(1227, 184);
            this.grdOptCD.TabIndex = 2;
            this.grdOptCD.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.grdOptContextGroup_CellFormatting);
            this.grdOptCD.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.grdOptContextGroup_CellPainting);
            this.grdOptCD.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.grdOptContextGroup_RowPostPaint);
            // 
            // panCDLbl
            // 
            this.panCDLbl.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panCDLbl.Controls.Add(this.lblCD);
            this.panCDLbl.Dock = System.Windows.Forms.DockStyle.Top;
            this.panCDLbl.Location = new System.Drawing.Point(3, 3);
            this.panCDLbl.Name = "panCDLbl";
            this.panCDLbl.Size = new System.Drawing.Size(1227, 26);
            this.panCDLbl.TabIndex = 6;
            // 
            // lblCD
            // 
            this.lblCD.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblCD.AutoSize = true;
            this.lblCD.Location = new System.Drawing.Point(137, 7);
            this.lblCD.Name = "lblCD";
            this.lblCD.Size = new System.Drawing.Size(45, 16);
            this.lblCD.TabIndex = 0;
            this.lblCD.Text = "label6";
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.panel6);
            this.tabPage8.Controls.Add(this.panFocusLbl);
            this.tabPage8.Location = new System.Drawing.Point(4, 25);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(1233, 216);
            this.tabPage8.TabIndex = 5;
            this.tabPage8.Text = "Focus";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.grdOptFocus);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(3, 29);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1227, 184);
            this.panel6.TabIndex = 8;
            // 
            // grdOptFocus
            // 
            this.grdOptFocus.AllowUserToAddRows = false;
            this.grdOptFocus.AllowUserToDeleteRows = false;
            this.grdOptFocus.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.grdOptFocus.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.grdOptFocus.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdOptFocus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdOptFocus.Location = new System.Drawing.Point(0, 0);
            this.grdOptFocus.Name = "grdOptFocus";
            this.grdOptFocus.Size = new System.Drawing.Size(1227, 184);
            this.grdOptFocus.TabIndex = 2;
            this.grdOptFocus.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.grdOptContextGroup_CellFormatting);
            this.grdOptFocus.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.grdOptContextGroup_CellPainting);
            this.grdOptFocus.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.grdOptContextGroup_RowPostPaint);
            // 
            // panFocusLbl
            // 
            this.panFocusLbl.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panFocusLbl.Controls.Add(this.lblFocus);
            this.panFocusLbl.Dock = System.Windows.Forms.DockStyle.Top;
            this.panFocusLbl.Location = new System.Drawing.Point(3, 3);
            this.panFocusLbl.Name = "panFocusLbl";
            this.panFocusLbl.Size = new System.Drawing.Size(1227, 26);
            this.panFocusLbl.TabIndex = 7;
            // 
            // lblFocus
            // 
            this.lblFocus.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblFocus.AutoSize = true;
            this.lblFocus.Location = new System.Drawing.Point(136, 7);
            this.lblFocus.Name = "lblFocus";
            this.lblFocus.Size = new System.Drawing.Size(45, 16);
            this.lblFocus.TabIndex = 0;
            this.lblFocus.Text = "label7";
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.panel7);
            this.tabPage9.Controls.Add(this.panCommon1Lb1);
            this.tabPage9.Location = new System.Drawing.Point(4, 25);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(1233, 216);
            this.tabPage9.TabIndex = 6;
            this.tabPage9.Text = "tabPage9";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.grdOptCommon1);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(3, 29);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(1227, 184);
            this.panel7.TabIndex = 8;
            // 
            // grdOptCommon1
            // 
            this.grdOptCommon1.AllowUserToAddRows = false;
            this.grdOptCommon1.AllowUserToDeleteRows = false;
            this.grdOptCommon1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.grdOptCommon1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.grdOptCommon1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdOptCommon1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdOptCommon1.Location = new System.Drawing.Point(0, 0);
            this.grdOptCommon1.Name = "grdOptCommon1";
            this.grdOptCommon1.Size = new System.Drawing.Size(1227, 184);
            this.grdOptCommon1.TabIndex = 2;
            this.grdOptCommon1.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.grdOptContextGroup_CellFormatting);
            this.grdOptCommon1.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.grdOptContextGroup_CellPainting);
            this.grdOptCommon1.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.grdOptContextGroup_RowPostPaint);
            // 
            // panCommon1Lb1
            // 
            this.panCommon1Lb1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panCommon1Lb1.Controls.Add(this.lblCommon1);
            this.panCommon1Lb1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panCommon1Lb1.Location = new System.Drawing.Point(3, 3);
            this.panCommon1Lb1.Name = "panCommon1Lb1";
            this.panCommon1Lb1.Size = new System.Drawing.Size(1227, 26);
            this.panCommon1Lb1.TabIndex = 7;
            // 
            // lblCommon1
            // 
            this.lblCommon1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblCommon1.AutoSize = true;
            this.lblCommon1.Location = new System.Drawing.Point(138, 7);
            this.lblCommon1.Name = "lblCommon1";
            this.lblCommon1.Size = new System.Drawing.Size(45, 16);
            this.lblCommon1.TabIndex = 0;
            this.lblCommon1.Text = "label8";
            // 
            // tabPage10
            // 
            this.tabPage10.Controls.Add(this.panel8);
            this.tabPage10.Controls.Add(this.panCommon2Lb1);
            this.tabPage10.Location = new System.Drawing.Point(4, 25);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage10.Size = new System.Drawing.Size(1233, 216);
            this.tabPage10.TabIndex = 7;
            this.tabPage10.Text = "tabPage10";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.grdOptCommon2);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel8.Location = new System.Drawing.Point(3, 29);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(1227, 184);
            this.panel8.TabIndex = 9;
            // 
            // grdOptCommon2
            // 
            this.grdOptCommon2.AllowUserToAddRows = false;
            this.grdOptCommon2.AllowUserToDeleteRows = false;
            this.grdOptCommon2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.grdOptCommon2.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.grdOptCommon2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdOptCommon2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdOptCommon2.Location = new System.Drawing.Point(0, 0);
            this.grdOptCommon2.Name = "grdOptCommon2";
            this.grdOptCommon2.Size = new System.Drawing.Size(1227, 184);
            this.grdOptCommon2.TabIndex = 2;
            this.grdOptCommon2.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.grdOptContextGroup_CellFormatting);
            this.grdOptCommon2.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.grdOptContextGroup_CellPainting);
            this.grdOptCommon2.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.grdOptContextGroup_RowPostPaint);
            // 
            // panCommon2Lb1
            // 
            this.panCommon2Lb1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panCommon2Lb1.Controls.Add(this.lblCommon2);
            this.panCommon2Lb1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panCommon2Lb1.Location = new System.Drawing.Point(3, 3);
            this.panCommon2Lb1.Name = "panCommon2Lb1";
            this.panCommon2Lb1.Size = new System.Drawing.Size(1227, 26);
            this.panCommon2Lb1.TabIndex = 8;
            // 
            // lblCommon2
            // 
            this.lblCommon2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblCommon2.AutoSize = true;
            this.lblCommon2.Location = new System.Drawing.Point(138, 7);
            this.lblCommon2.Name = "lblCommon2";
            this.lblCommon2.Size = new System.Drawing.Size(45, 16);
            this.lblCommon2.TabIndex = 0;
            this.lblCommon2.Text = "label9";
            // 
            // tabPage11
            // 
            this.tabPage11.Controls.Add(this.panel9);
            this.tabPage11.Controls.Add(this.panCommon3Lb1);
            this.tabPage11.Location = new System.Drawing.Point(4, 25);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage11.Size = new System.Drawing.Size(1233, 216);
            this.tabPage11.TabIndex = 8;
            this.tabPage11.Text = "tabPage11";
            this.tabPage11.UseVisualStyleBackColor = true;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.grdOptCommon3);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(3, 29);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(1227, 184);
            this.panel9.TabIndex = 9;
            // 
            // grdOptCommon3
            // 
            this.grdOptCommon3.AllowUserToAddRows = false;
            this.grdOptCommon3.AllowUserToDeleteRows = false;
            this.grdOptCommon3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.grdOptCommon3.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.grdOptCommon3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdOptCommon3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdOptCommon3.Location = new System.Drawing.Point(0, 0);
            this.grdOptCommon3.Name = "grdOptCommon3";
            this.grdOptCommon3.Size = new System.Drawing.Size(1227, 184);
            this.grdOptCommon3.TabIndex = 2;
            this.grdOptCommon3.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.grdOptContextGroup_CellFormatting);
            this.grdOptCommon3.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.grdOptContextGroup_CellPainting);
            this.grdOptCommon3.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.grdOptContextGroup_RowPostPaint);
            // 
            // panCommon3Lb1
            // 
            this.panCommon3Lb1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panCommon3Lb1.Controls.Add(this.lblCommon3);
            this.panCommon3Lb1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panCommon3Lb1.Location = new System.Drawing.Point(3, 3);
            this.panCommon3Lb1.Name = "panCommon3Lb1";
            this.panCommon3Lb1.Size = new System.Drawing.Size(1227, 26);
            this.panCommon3Lb1.TabIndex = 8;
            // 
            // lblCommon3
            // 
            this.lblCommon3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblCommon3.AutoSize = true;
            this.lblCommon3.Location = new System.Drawing.Point(140, 7);
            this.lblCommon3.Name = "lblCommon3";
            this.lblCommon3.Size = new System.Drawing.Size(52, 16);
            this.lblCommon3.TabIndex = 0;
            this.lblCommon3.Text = "label10";
            // 
            // tabPage12
            // 
            this.tabPage12.Controls.Add(this.panel10);
            this.tabPage12.Controls.Add(this.panCommon4Lb1);
            this.tabPage12.Location = new System.Drawing.Point(4, 25);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage12.Size = new System.Drawing.Size(1233, 216);
            this.tabPage12.TabIndex = 9;
            this.tabPage12.Text = "tabPage12";
            this.tabPage12.UseVisualStyleBackColor = true;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.grdOptCommon4);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel10.Location = new System.Drawing.Point(3, 29);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(1227, 184);
            this.panel10.TabIndex = 9;
            // 
            // grdOptCommon4
            // 
            this.grdOptCommon4.AllowUserToAddRows = false;
            this.grdOptCommon4.AllowUserToDeleteRows = false;
            this.grdOptCommon4.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.grdOptCommon4.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.grdOptCommon4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdOptCommon4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdOptCommon4.Location = new System.Drawing.Point(0, 0);
            this.grdOptCommon4.Name = "grdOptCommon4";
            this.grdOptCommon4.Size = new System.Drawing.Size(1227, 184);
            this.grdOptCommon4.TabIndex = 2;
            this.grdOptCommon4.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.grdOptContextGroup_CellFormatting);
            this.grdOptCommon4.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.grdOptContextGroup_CellPainting);
            this.grdOptCommon4.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.grdOptContextGroup_RowPostPaint);
            // 
            // panCommon4Lb1
            // 
            this.panCommon4Lb1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panCommon4Lb1.Controls.Add(this.lblCommon4);
            this.panCommon4Lb1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panCommon4Lb1.Location = new System.Drawing.Point(3, 3);
            this.panCommon4Lb1.Name = "panCommon4Lb1";
            this.panCommon4Lb1.Size = new System.Drawing.Size(1227, 26);
            this.panCommon4Lb1.TabIndex = 8;
            // 
            // lblCommon4
            // 
            this.lblCommon4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblCommon4.AutoSize = true;
            this.lblCommon4.Location = new System.Drawing.Point(140, 7);
            this.lblCommon4.Name = "lblCommon4";
            this.lblCommon4.Size = new System.Drawing.Size(52, 16);
            this.lblCommon4.TabIndex = 0;
            this.lblCommon4.Text = "label11";
            // 
            // tabPage13
            // 
            this.tabPage13.Controls.Add(this.panel11);
            this.tabPage13.Controls.Add(this.panCommon5Lb1);
            this.tabPage13.Location = new System.Drawing.Point(4, 25);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage13.Size = new System.Drawing.Size(1233, 216);
            this.tabPage13.TabIndex = 10;
            this.tabPage13.Text = "tabPage13";
            this.tabPage13.UseVisualStyleBackColor = true;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.grdOptCommon5);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel11.Location = new System.Drawing.Point(3, 29);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(1227, 184);
            this.panel11.TabIndex = 9;
            // 
            // grdOptCommon5
            // 
            this.grdOptCommon5.AllowUserToAddRows = false;
            this.grdOptCommon5.AllowUserToDeleteRows = false;
            this.grdOptCommon5.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.grdOptCommon5.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.grdOptCommon5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdOptCommon5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdOptCommon5.Location = new System.Drawing.Point(0, 0);
            this.grdOptCommon5.Name = "grdOptCommon5";
            this.grdOptCommon5.Size = new System.Drawing.Size(1227, 184);
            this.grdOptCommon5.TabIndex = 2;
            this.grdOptCommon5.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.grdOptContextGroup_CellFormatting);
            this.grdOptCommon5.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.grdOptContextGroup_CellPainting);
            this.grdOptCommon5.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.grdOptContextGroup_RowPostPaint);
            // 
            // panCommon5Lb1
            // 
            this.panCommon5Lb1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panCommon5Lb1.Controls.Add(this.lblCommon5);
            this.panCommon5Lb1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panCommon5Lb1.Location = new System.Drawing.Point(3, 3);
            this.panCommon5Lb1.Name = "panCommon5Lb1";
            this.panCommon5Lb1.Size = new System.Drawing.Size(1227, 26);
            this.panCommon5Lb1.TabIndex = 8;
            // 
            // lblCommon5
            // 
            this.lblCommon5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblCommon5.AutoSize = true;
            this.lblCommon5.Location = new System.Drawing.Point(140, 7);
            this.lblCommon5.Name = "lblCommon5";
            this.lblCommon5.Size = new System.Drawing.Size(52, 16);
            this.lblCommon5.TabIndex = 0;
            this.lblCommon5.Text = "label12";
            // 
            // tabPage14
            // 
            this.tabPage14.Controls.Add(this.panel12);
            this.tabPage14.Controls.Add(this.panCommon6Lb1);
            this.tabPage14.Location = new System.Drawing.Point(4, 25);
            this.tabPage14.Name = "tabPage14";
            this.tabPage14.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage14.Size = new System.Drawing.Size(1233, 216);
            this.tabPage14.TabIndex = 11;
            this.tabPage14.Text = "tabPage14";
            this.tabPage14.UseVisualStyleBackColor = true;
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.grdOptCommon6);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel12.Location = new System.Drawing.Point(3, 29);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(1227, 184);
            this.panel12.TabIndex = 9;
            // 
            // grdOptCommon6
            // 
            this.grdOptCommon6.AllowUserToAddRows = false;
            this.grdOptCommon6.AllowUserToDeleteRows = false;
            this.grdOptCommon6.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.grdOptCommon6.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.grdOptCommon6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdOptCommon6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdOptCommon6.Location = new System.Drawing.Point(0, 0);
            this.grdOptCommon6.Name = "grdOptCommon6";
            this.grdOptCommon6.Size = new System.Drawing.Size(1227, 184);
            this.grdOptCommon6.TabIndex = 2;
            this.grdOptCommon6.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.grdOptContextGroup_CellFormatting);
            this.grdOptCommon6.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.grdOptContextGroup_CellPainting);
            this.grdOptCommon6.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.grdOptContextGroup_RowPostPaint);
            // 
            // panCommon6Lb1
            // 
            this.panCommon6Lb1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panCommon6Lb1.Controls.Add(this.lblCommon6);
            this.panCommon6Lb1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panCommon6Lb1.Location = new System.Drawing.Point(3, 3);
            this.panCommon6Lb1.Name = "panCommon6Lb1";
            this.panCommon6Lb1.Size = new System.Drawing.Size(1227, 26);
            this.panCommon6Lb1.TabIndex = 8;
            // 
            // lblCommon6
            // 
            this.lblCommon6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblCommon6.AutoSize = true;
            this.lblCommon6.Location = new System.Drawing.Point(140, 7);
            this.lblCommon6.Name = "lblCommon6";
            this.lblCommon6.Size = new System.Drawing.Size(52, 16);
            this.lblCommon6.TabIndex = 0;
            this.lblCommon6.Text = "label13";
            // 
            // panOptSubBtn
            // 
            this.panOptSubBtn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panOptSubBtn.Controls.Add(this.groupBox4);
            this.panOptSubBtn.Dock = System.Windows.Forms.DockStyle.Right;
            this.panOptSubBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panOptSubBtn.Location = new System.Drawing.Point(1243, 0);
            this.panOptSubBtn.Name = "panOptSubBtn";
            this.panOptSubBtn.Size = new System.Drawing.Size(267, 247);
            this.panOptSubBtn.TabIndex = 2;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtCurrentOVLMode);
            this.groupBox4.Controls.Add(this.txtCurrentR2RMode);
            this.groupBox4.Controls.Add(this.grpBtn);
            this.groupBox4.Controls.Add(this.grpList);
            this.groupBox4.Location = new System.Drawing.Point(4, 16);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(257, 223);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            // 
            // txtCurrentOVLMode
            // 
            this.txtCurrentOVLMode.AutoSize = true;
            this.txtCurrentOVLMode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCurrentOVLMode.Location = new System.Drawing.Point(38, 96);
            this.txtCurrentOVLMode.Name = "txtCurrentOVLMode";
            this.txtCurrentOVLMode.Size = new System.Drawing.Size(122, 18);
            this.txtCurrentOVLMode.TabIndex = 5;
            this.txtCurrentOVLMode.Text = "Current OVL Mode:";
            // 
            // txtCurrentR2RMode
            // 
            this.txtCurrentR2RMode.AutoSize = true;
            this.txtCurrentR2RMode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCurrentR2RMode.Location = new System.Drawing.Point(38, 124);
            this.txtCurrentR2RMode.Name = "txtCurrentR2RMode";
            this.txtCurrentR2RMode.Size = new System.Drawing.Size(123, 18);
            this.txtCurrentR2RMode.TabIndex = 6;
            this.txtCurrentR2RMode.Text = "Current R2R Mode:";
            // 
            // grpBtn
            // 
            this.grpBtn.Controls.Add(this.btnOptMode);
            this.grpBtn.Controls.Add(this.btnOptReset);
            this.grpBtn.Location = new System.Drawing.Point(38, 151);
            this.grpBtn.Name = "grpBtn";
            this.grpBtn.Size = new System.Drawing.Size(191, 51);
            this.grpBtn.TabIndex = 13;
            this.grpBtn.TabStop = false;
            // 
            // btnOptMode
            // 
            this.btnOptMode.Location = new System.Drawing.Point(15, 17);
            this.btnOptMode.Name = "btnOptMode";
            this.btnOptMode.Size = new System.Drawing.Size(58, 28);
            this.btnOptMode.TabIndex = 3;
            this.btnOptMode.Text = "Mode";
            this.btnOptMode.UseVisualStyleBackColor = true;
            this.btnOptMode.Click += new System.EventHandler(this.btnOptMode_Click);
            // 
            // btnOptReset
            // 
            this.btnOptReset.Location = new System.Drawing.Point(112, 17);
            this.btnOptReset.Name = "btnOptReset";
            this.btnOptReset.Size = new System.Drawing.Size(58, 28);
            this.btnOptReset.TabIndex = 4;
            this.btnOptReset.Text = "Reset";
            this.btnOptReset.UseVisualStyleBackColor = true;
            this.btnOptReset.Click += new System.EventHandler(this.btnOptReset_Click);
            // 
            // grpList
            // 
            this.grpList.Controls.Add(this.rdoMetrology);
            this.grpList.Controls.Add(this.rdoLotAll);
            this.grpList.Location = new System.Drawing.Point(38, 23);
            this.grpList.Name = "grpList";
            this.grpList.Size = new System.Drawing.Size(191, 66);
            this.grpList.TabIndex = 12;
            this.grpList.TabStop = false;
            // 
            // rdoMetrology
            // 
            this.rdoMetrology.AutoSize = true;
            this.rdoMetrology.Location = new System.Drawing.Point(15, 40);
            this.rdoMetrology.Name = "rdoMetrology";
            this.rdoMetrology.Size = new System.Drawing.Size(166, 20);
            this.rdoMetrology.TabIndex = 9;
            this.rdoMetrology.Text = "List Lots With Metrology";
            this.rdoMetrology.UseVisualStyleBackColor = true;
            this.rdoMetrology.CheckedChanged += new System.EventHandler(this.rdoMetrology_CheckedChanged);
            // 
            // rdoLotAll
            // 
            this.rdoLotAll.AutoSize = true;
            this.rdoLotAll.Checked = true;
            this.rdoLotAll.Location = new System.Drawing.Point(15, 14);
            this.rdoLotAll.Name = "rdoLotAll";
            this.rdoLotAll.Size = new System.Drawing.Size(85, 20);
            this.rdoLotAll.TabIndex = 8;
            this.rdoLotAll.TabStop = true;
            this.rdoLotAll.Text = "List All Lot";
            this.rdoLotAll.UseVisualStyleBackColor = true;
            this.rdoLotAll.CheckedChanged += new System.EventHandler(this.rdoLotAll_CheckedChanged);
            // 
            // panOptContext
            // 
            this.panOptContext.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panOptContext.Controls.Add(this.panOptContextGroup);
            this.panOptContext.Controls.Add(this.panOptBtn);
            this.panOptContext.Controls.Add(this.panOptContextGrid);
            this.panOptContext.Dock = System.Windows.Forms.DockStyle.Top;
            this.panOptContext.Location = new System.Drawing.Point(0, 0);
            this.panOptContext.Name = "panOptContext";
            this.panOptContext.Size = new System.Drawing.Size(1510, 242);
            this.panOptContext.TabIndex = 0;
            // 
            // panOptContextGroup
            // 
            this.panOptContextGroup.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panOptContextGroup.Controls.Add(this.panel14);
            this.panOptContextGroup.Controls.Add(this.panContextGroupLbl);
            this.panOptContextGroup.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panOptContextGroup.Location = new System.Drawing.Point(332, 0);
            this.panOptContextGroup.Name = "panOptContextGroup";
            this.panOptContextGroup.Size = new System.Drawing.Size(909, 240);
            this.panOptContextGroup.TabIndex = 2;
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.grdOptContextGroup);
            this.panel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel14.Location = new System.Drawing.Point(0, 26);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(907, 212);
            this.panel14.TabIndex = 10;
            // 
            // grdOptContextGroup
            // 
            this.grdOptContextGroup.AllowUserToAddRows = false;
            this.grdOptContextGroup.AllowUserToDeleteRows = false;
            this.grdOptContextGroup.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.grdOptContextGroup.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.grdOptContextGroup.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdOptContextGroup.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdOptContextGroup.Location = new System.Drawing.Point(0, 0);
            this.grdOptContextGroup.Name = "grdOptContextGroup";
            this.grdOptContextGroup.Size = new System.Drawing.Size(907, 212);
            this.grdOptContextGroup.TabIndex = 1;
            this.grdOptContextGroup.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grdOptContextGroup_CellClick);
            this.grdOptContextGroup.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grdOptContextGroup_CellDoubleClick);
            this.grdOptContextGroup.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.grdOptContextGroup_CellFormatting);
            this.grdOptContextGroup.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.grdOptContextGroup_CellPainting);
            this.grdOptContextGroup.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.grdOptContextGroup_RowPostPaint);
            // 
            // panContextGroupLbl
            // 
            this.panContextGroupLbl.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panContextGroupLbl.Controls.Add(this.lblContextGroup);
            this.panContextGroupLbl.Dock = System.Windows.Forms.DockStyle.Top;
            this.panContextGroupLbl.Location = new System.Drawing.Point(0, 0);
            this.panContextGroupLbl.Name = "panContextGroupLbl";
            this.panContextGroupLbl.Size = new System.Drawing.Size(907, 26);
            this.panContextGroupLbl.TabIndex = 9;
            // 
            // lblContextGroup
            // 
            this.lblContextGroup.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblContextGroup.AutoSize = true;
            this.lblContextGroup.Location = new System.Drawing.Point(358, 6);
            this.lblContextGroup.Name = "lblContextGroup";
            this.lblContextGroup.Size = new System.Drawing.Size(52, 16);
            this.lblContextGroup.TabIndex = 0;
            this.lblContextGroup.Text = "label14";
            // 
            // panOptBtn
            // 
            this.panOptBtn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panOptBtn.Controls.Add(this.groupBox3);
            this.panOptBtn.Dock = System.Windows.Forms.DockStyle.Right;
            this.panOptBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panOptBtn.Location = new System.Drawing.Point(1241, 0);
            this.panOptBtn.Name = "panOptBtn";
            this.panOptBtn.Size = new System.Drawing.Size(267, 240);
            this.panOptBtn.TabIndex = 1;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.groupBox1);
            this.groupBox3.Controls.Add(this.btnPreLayerConfig);
            this.groupBox3.Controls.Add(this.btnChuckDedication);
            this.groupBox3.Controls.Add(this.btnOptBatchOperation);
            this.groupBox3.Location = new System.Drawing.Point(5, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(257, 227);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdoChuck2);
            this.groupBox1.Controls.Add(this.rdoChuck1);
            this.groupBox1.Location = new System.Drawing.Point(38, 174);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(187, 46);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            // 
            // rdoChuck2
            // 
            this.rdoChuck2.AutoSize = true;
            this.rdoChuck2.Location = new System.Drawing.Point(96, 20);
            this.rdoChuck2.Name = "rdoChuck2";
            this.rdoChuck2.Size = new System.Drawing.Size(70, 20);
            this.rdoChuck2.TabIndex = 10;
            this.rdoChuck2.Text = "Chuck2";
            this.rdoChuck2.UseVisualStyleBackColor = true;
            this.rdoChuck2.CheckedChanged += new System.EventHandler(this.rdoChuck2_CheckedChanged);
            // 
            // rdoChuck1
            // 
            this.rdoChuck1.AutoSize = true;
            this.rdoChuck1.Checked = true;
            this.rdoChuck1.Location = new System.Drawing.Point(18, 20);
            this.rdoChuck1.Name = "rdoChuck1";
            this.rdoChuck1.Size = new System.Drawing.Size(70, 20);
            this.rdoChuck1.TabIndex = 9;
            this.rdoChuck1.TabStop = true;
            this.rdoChuck1.Text = "Chuck1";
            this.rdoChuck1.UseVisualStyleBackColor = true;
            this.rdoChuck1.CheckedChanged += new System.EventHandler(this.rdoChuck1_CheckedChanged);
            // 
            // btnPreLayerConfig
            // 
            this.btnPreLayerConfig.Location = new System.Drawing.Point(38, 18);
            this.btnPreLayerConfig.Name = "btnPreLayerConfig";
            this.btnPreLayerConfig.Size = new System.Drawing.Size(187, 46);
            this.btnPreLayerConfig.TabIndex = 3;
            this.btnPreLayerConfig.Text = "PreLayer Config";
            this.btnPreLayerConfig.UseVisualStyleBackColor = true;
            this.btnPreLayerConfig.Click += new System.EventHandler(this.btnPreLayer_Click);
            // 
            // btnChuckDedication
            // 
            this.btnChuckDedication.Location = new System.Drawing.Point(38, 70);
            this.btnChuckDedication.Name = "btnChuckDedication";
            this.btnChuckDedication.Size = new System.Drawing.Size(187, 46);
            this.btnChuckDedication.TabIndex = 4;
            this.btnChuckDedication.Text = "Chuck Dedication";
            this.btnChuckDedication.UseVisualStyleBackColor = true;
            this.btnChuckDedication.Click += new System.EventHandler(this.btnChuckDedication_Click);
            // 
            // btnOptBatchOperation
            // 
            this.btnOptBatchOperation.Location = new System.Drawing.Point(38, 122);
            this.btnOptBatchOperation.Name = "btnOptBatchOperation";
            this.btnOptBatchOperation.Size = new System.Drawing.Size(187, 46);
            this.btnOptBatchOperation.TabIndex = 5;
            this.btnOptBatchOperation.Text = "Batch Operation";
            this.btnOptBatchOperation.UseVisualStyleBackColor = true;
            this.btnOptBatchOperation.Click += new System.EventHandler(this.btnBatchOperation_Click);
            // 
            // panOptContextGrid
            // 
            this.panOptContextGrid.Controls.Add(this.groupBox2);
            this.panOptContextGrid.Dock = System.Windows.Forms.DockStyle.Left;
            this.panOptContextGrid.Location = new System.Drawing.Point(0, 0);
            this.panOptContextGrid.Name = "panOptContextGrid";
            this.panOptContextGrid.Size = new System.Drawing.Size(332, 240);
            this.panOptContextGrid.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox2.Controls.Add(this.textBox2);
            this.groupBox2.Controls.Add(this.cmbTool);
            this.groupBox2.Controls.Add(this.btnOptRun);
            this.groupBox2.Controls.Add(this.textBox4);
            this.groupBox2.Controls.Add(this.txtLots);
            this.groupBox2.Controls.Add(this.txtModule);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.cmbProduct);
            this.groupBox2.Controls.Add(this.cmbControl);
            this.groupBox2.Controls.Add(this.cmbLayer);
            this.groupBox2.Controls.Add(this.txtStage);
            this.groupBox2.Controls.Add(this.txtLayer);
            this.groupBox2.Controls.Add(this.cmbStage);
            this.groupBox2.Controls.Add(this.textBox1);
            this.groupBox2.Controls.Add(this.cmbModule);
            this.groupBox2.Location = new System.Drawing.Point(4, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(320, 224);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            // 
            // textBox2
            // 
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Location = new System.Drawing.Point(16, 164);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(55, 15);
            this.textBox2.TabIndex = 20;
            this.textBox2.Text = "Tool";
            // 
            // cmbTool
            // 
            this.cmbTool.FormattingEnabled = true;
            this.cmbTool.Location = new System.Drawing.Point(77, 159);
            this.cmbTool.Name = "cmbTool";
            this.cmbTool.Size = new System.Drawing.Size(223, 24);
            this.cmbTool.TabIndex = 21;
            this.cmbTool.SelectedIndexChanged += new System.EventHandler(this.cmbContext_SelectedIndexChanged);
            // 
            // btnOptRun
            // 
            this.btnOptRun.Location = new System.Drawing.Point(219, 196);
            this.btnOptRun.Name = "btnOptRun";
            this.btnOptRun.Size = new System.Drawing.Size(75, 23);
            this.btnOptRun.TabIndex = 2;
            this.btnOptRun.Text = "Run";
            this.btnOptRun.UseVisualStyleBackColor = true;
            this.btnOptRun.Click += new System.EventHandler(this.btnOptRun_Click);
            // 
            // textBox4
            // 
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox4.Location = new System.Drawing.Point(16, 136);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(55, 15);
            this.textBox4.TabIndex = 18;
            this.textBox4.Text = "Control";
            // 
            // txtLots
            // 
            this.txtLots.Location = new System.Drawing.Point(95, 197);
            this.txtLots.Name = "txtLots";
            this.txtLots.Size = new System.Drawing.Size(100, 22);
            this.txtLots.TabIndex = 1;
            this.txtLots.Text = "20";
            this.txtLots.TextChanged += new System.EventHandler(this.txtLots_TextChanged);
            this.txtLots.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtLots_KeyDown);
            // 
            // txtModule
            // 
            this.txtModule.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtModule.Location = new System.Drawing.Point(16, 24);
            this.txtModule.Name = "txtModule";
            this.txtModule.ReadOnly = true;
            this.txtModule.Size = new System.Drawing.Size(55, 15);
            this.txtModule.TabIndex = 14;
            this.txtModule.Text = "Module";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 200);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "List of Runs";
            // 
            // cmbProduct
            // 
            this.cmbProduct.FormattingEnabled = true;
            this.cmbProduct.Location = new System.Drawing.Point(77, 47);
            this.cmbProduct.Name = "cmbProduct";
            this.cmbProduct.Size = new System.Drawing.Size(223, 24);
            this.cmbProduct.TabIndex = 11;
            this.cmbProduct.SelectedIndexChanged += new System.EventHandler(this.cmbContext_SelectedIndexChanged);
            // 
            // cmbControl
            // 
            this.cmbControl.FormattingEnabled = true;
            this.cmbControl.Location = new System.Drawing.Point(77, 131);
            this.cmbControl.Name = "cmbControl";
            this.cmbControl.Size = new System.Drawing.Size(223, 24);
            this.cmbControl.TabIndex = 19;
            this.cmbControl.SelectedIndexChanged += new System.EventHandler(this.cmbContext_SelectedIndexChanged);
            // 
            // cmbLayer
            // 
            this.cmbLayer.FormattingEnabled = true;
            this.cmbLayer.Location = new System.Drawing.Point(77, 103);
            this.cmbLayer.Name = "cmbLayer";
            this.cmbLayer.Size = new System.Drawing.Size(223, 24);
            this.cmbLayer.TabIndex = 12;
            this.cmbLayer.SelectedIndexChanged += new System.EventHandler(this.cmbContext_SelectedIndexChanged);
            // 
            // txtStage
            // 
            this.txtStage.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtStage.Location = new System.Drawing.Point(16, 80);
            this.txtStage.Name = "txtStage";
            this.txtStage.ReadOnly = true;
            this.txtStage.Size = new System.Drawing.Size(55, 15);
            this.txtStage.TabIndex = 16;
            this.txtStage.Text = "Stage";
            // 
            // txtLayer
            // 
            this.txtLayer.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtLayer.Location = new System.Drawing.Point(16, 108);
            this.txtLayer.Name = "txtLayer";
            this.txtLayer.ReadOnly = true;
            this.txtLayer.Size = new System.Drawing.Size(55, 15);
            this.txtLayer.TabIndex = 10;
            this.txtLayer.Text = "Layer";
            // 
            // cmbStage
            // 
            this.cmbStage.FormattingEnabled = true;
            this.cmbStage.Location = new System.Drawing.Point(77, 75);
            this.cmbStage.Name = "cmbStage";
            this.cmbStage.Size = new System.Drawing.Size(223, 24);
            this.cmbStage.TabIndex = 17;
            this.cmbStage.SelectedIndexChanged += new System.EventHandler(this.cmbContext_SelectedIndexChanged);
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Location = new System.Drawing.Point(16, 52);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(55, 15);
            this.textBox1.TabIndex = 8;
            this.textBox1.Text = "Product";
            // 
            // cmbModule
            // 
            this.cmbModule.FormattingEnabled = true;
            this.cmbModule.Location = new System.Drawing.Point(77, 19);
            this.cmbModule.Name = "cmbModule";
            this.cmbModule.Size = new System.Drawing.Size(223, 24);
            this.cmbModule.TabIndex = 15;
            this.cmbModule.SelectedIndexChanged += new System.EventHandler(this.cmbContext_SelectedIndexChanged);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel3});
            this.statusStrip1.Location = new System.Drawing.Point(3, 813);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 15, 0);
            this.statusStrip1.Size = new System.Drawing.Size(1510, 22);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(1423, 17);
            this.toolStripStatusLabel1.Spring = true;
            this.toolStripStatusLabel1.Text = "Version";
            this.toolStripStatusLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(37, 17);
            this.toolStripStatusLabel2.Text = "Time";
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(34, 17);
            this.toolStripStatusLabel3.Text = "Data";
            // 
            // tabPage2
            // 
            this.tabPage2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1516, 838);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Config";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1524, 867);
            this.Controls.Add(this.panMain);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "R2R-UI";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.SizeChanged += new System.EventHandler(this.frmMain_SizeChanged);
            this.Resize += new System.EventHandler(this.frmMain_Resize);
            this.panMain.ResumeLayout(false);
            this.tabMain.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.panOptMainTab.ResumeLayout(false);
            this.panOptSub.ResumeLayout(false);
            this.panOptTabSub.ResumeLayout(false);
            this.tabOptSubTab.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdOptLinear)).EndInit();
            this.panLinearLbl.ResumeLayout(false);
            this.panLinearLbl.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdOptHOPC)).EndInit();
            this.panHOPCLbl.ResumeLayout(false);
            this.panHOPCLbl.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdOptIHOPC)).EndInit();
            this.panIHOPCLbl.ResumeLayout(false);
            this.panIHOPCLbl.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdOptCPE)).EndInit();
            this.panCPELbl.ResumeLayout(false);
            this.panCPELbl.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdOptCD)).EndInit();
            this.panCDLbl.ResumeLayout(false);
            this.panCDLbl.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdOptFocus)).EndInit();
            this.panFocusLbl.ResumeLayout(false);
            this.panFocusLbl.PerformLayout();
            this.tabPage9.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdOptCommon1)).EndInit();
            this.panCommon1Lb1.ResumeLayout(false);
            this.panCommon1Lb1.PerformLayout();
            this.tabPage10.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdOptCommon2)).EndInit();
            this.panCommon2Lb1.ResumeLayout(false);
            this.panCommon2Lb1.PerformLayout();
            this.tabPage11.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdOptCommon3)).EndInit();
            this.panCommon3Lb1.ResumeLayout(false);
            this.panCommon3Lb1.PerformLayout();
            this.tabPage12.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdOptCommon4)).EndInit();
            this.panCommon4Lb1.ResumeLayout(false);
            this.panCommon4Lb1.PerformLayout();
            this.tabPage13.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdOptCommon5)).EndInit();
            this.panCommon5Lb1.ResumeLayout(false);
            this.panCommon5Lb1.PerformLayout();
            this.tabPage14.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdOptCommon6)).EndInit();
            this.panCommon6Lb1.ResumeLayout(false);
            this.panCommon6Lb1.PerformLayout();
            this.panOptSubBtn.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.grpBtn.ResumeLayout(false);
            this.grpList.ResumeLayout(false);
            this.grpList.PerformLayout();
            this.panOptContext.ResumeLayout(false);
            this.panOptContextGroup.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdOptContextGroup)).EndInit();
            this.panContextGroupLbl.ResumeLayout(false);
            this.panContextGroupLbl.PerformLayout();
            this.panOptBtn.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panOptContextGrid.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panMain;
        private System.Windows.Forms.TabControl tabMain;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Panel panOptMainTab;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel panOptContext;
        private System.Windows.Forms.Panel panOptContextGroup;
        private System.Windows.Forms.Panel panOptBtn;
        private System.Windows.Forms.Panel panOptContextGrid;
        private System.Windows.Forms.Panel panOptChart;
        private System.Windows.Forms.Panel panOptSub;
        private System.Windows.Forms.Panel panOptTabSub;
        private System.Windows.Forms.Panel panOptSubBtn;
        private System.Windows.Forms.TabControl tabOptSubTab;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.DataGridView grdOptLinear;
        private System.Windows.Forms.RadioButton rdoMetrology;
        private System.Windows.Forms.RadioButton rdoLotAll;
        private System.Windows.Forms.Label txtCurrentR2RMode;
        private System.Windows.Forms.Label txtCurrentOVLMode;
        private System.Windows.Forms.Button btnOptReset;
        private System.Windows.Forms.Button btnOptMode;
        private System.Windows.Forms.DataGridView grdOptContextGroup;
        private System.Windows.Forms.Button btnOptBatchOperation;
        private System.Windows.Forms.Button btnChuckDedication;
        private System.Windows.Forms.Button btnPreLayerConfig;
        private System.Windows.Forms.Button btnOptRun;
        private System.Windows.Forms.TextBox txtLots;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox grpList;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdoChuck2;
        private System.Windows.Forms.RadioButton rdoChuck1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;

        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.TabPage tabPage12;
        private System.Windows.Forms.TabPage tabPage13;
        private System.Windows.Forms.TabPage tabPage14;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panLinearLbl;
        private System.Windows.Forms.Label lblLinear;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView grdOptHOPC;
        private System.Windows.Forms.Panel panHOPCLbl;
        private System.Windows.Forms.Label lblHOPC;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView grdOptIHOPC;
        private System.Windows.Forms.Panel panIHOPCLbl;
        private System.Windows.Forms.Label lblIHOPC;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.DataGridView grdOptCPE;
        private System.Windows.Forms.Panel panCPELbl;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DataGridView grdOptCD;
        private System.Windows.Forms.Panel panCDLbl;
        private System.Windows.Forms.Label lblCD;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.DataGridView grdOptFocus;
        private System.Windows.Forms.Panel panFocusLbl;
        private System.Windows.Forms.Label lblFocus;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.DataGridView grdOptCommon1;
        private System.Windows.Forms.Panel panCommon1Lb1;
        private System.Windows.Forms.Label lblCommon1;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.DataGridView grdOptCommon2;
        private System.Windows.Forms.Panel panCommon2Lb1;
        private System.Windows.Forms.Label lblCommon2;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.DataGridView grdOptCommon3;
        private System.Windows.Forms.Panel panCommon3Lb1;
        private System.Windows.Forms.Label lblCommon3;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.DataGridView grdOptCommon4;
        private System.Windows.Forms.Panel panCommon4Lb1;
        private System.Windows.Forms.Label lblCommon4;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.DataGridView grdOptCommon5;
        private System.Windows.Forms.Panel panCommon5Lb1;
        private System.Windows.Forms.Label lblCommon5;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.DataGridView grdOptCommon6;
        private System.Windows.Forms.Panel panCommon6Lb1;
        private System.Windows.Forms.Label lblCommon6;
        private System.Windows.Forms.DataGridViewTextBoxColumn test;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox txtLayer;
        private System.Windows.Forms.ComboBox cmbLayer;
        private System.Windows.Forms.ComboBox cmbProduct;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.ComboBox cmbControl;
        private System.Windows.Forms.TextBox txtStage;
        private System.Windows.Forms.ComboBox cmbStage;
        private System.Windows.Forms.TextBox txtModule;
        private System.Windows.Forms.ComboBox cmbModule;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panContextGroupLbl;
        private System.Windows.Forms.Label lblContextGroup;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.ComboBox cmbTool;
        private System.Windows.Forms.GroupBox grpBtn;
    }
}


﻿using R2R_UI.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.DataVisualization.Charting;
using static R2R_UI.Common.UIServiceFun;

namespace R2R_UI.Model
{
    class LotRunHistory_CD
    {
        private string strServiceAddress;
        private List<string> strListR2RContexts = new List<string>();
        structPH_CD_GetLotRunHistory structData = new structPH_CD_GetLotRunHistory();
        public string strCurrentR2RMode;
        public bool bIsActive;
        public bool bNotData;

        public LotRunHistory_CD(string strServiceAddress, List<string> strListR2RContexts, bool bIsAll)
        {
            this.strServiceAddress = strServiceAddress;
            this.strListR2RContexts = new List<string>(strListR2RContexts);

            structPH_CD_GetLotRunHistory structDataNull = new structPH_CD_GetLotRunHistory();
            structPH_CD_GetLotRunHistory structDataAll = new structPH_CD_GetLotRunHistory();
            structDataAll = R2R_UI_PH_CD_GetLotRunHistory(strServiceAddress, strListR2RContexts);
            if (structDataAll.Equals(structDataNull))
            {
                bNotData = true;
            }
            else
            {
                if (bIsAll)
                {
                    this.structData = structDataAll;
                }
                else
                {
                    this.structData = ListLotsWithMetrology(structDataAll);
                }
                this.strCurrentR2RMode = structData.strCurrentR2RMode;
                this.bIsActive = IsActive(this.strCurrentR2RMode);
            }

        }

        private bool IsActive(string strR2RMode)
        {
            bool flag = false;
            if (strR2RMode.Equals("Active"))
            {
                flag = true;
            }
            else
            {
                //btnOptReset.Enabled = false;
            }
            return flag;
        }

        public static structPH_CD_GetLotRunHistory ListLotsWithMetrology(structPH_CD_GetLotRunHistory structData)
        {
            structPH_CD_GetLotRunHistory structDataNew = new structPH_CD_GetLotRunHistory();
            structDataNew.strCurrentR2RMode = structData.strCurrentR2RMode;
            structDataNew.strListIsValidRecords = new List<string>();
            structDataNew.strListLotIds = new List<string>();
            structDataNew.strListUsedTimeStamps = new List<string>();
            structDataNew.strListCD = new List<string>();
            structDataNew.strListDose = new List<string>();

            if (structData.strListIsValidRecords.Count > 0)
            {
                for (int i = 0; i < structData.strListIsValidRecords.Count; i++)
                {
                    if (structData.strListIsValidRecords[i].Equals("True"))
                    {
                        structDataNew.strListIsValidRecords.Add(structData.strListIsValidRecords[i]);
                        structDataNew.strListLotIds.Add(structData.strListLotIds[i]);
                        structDataNew.strListUsedTimeStamps.Add(structData.strListUsedTimeStamps[i]);
                        structDataNew.strListCD.Add(structData.strListCD[i]);
                        structDataNew.strListDose.Add(structData.strListDose[i]);
                    }
                }
            }
            return structDataNew;
        }
        private DataTable CreateTable(List<string> strListValueColumn1, List<string> strListValueColumn2)
        {
            DataTable db = new DataTable("OVL");

            db.Columns.Add("LOT_IDS", Type.GetType("System.String"));
            db.Columns.Add("USED_TIME_STAMPS", Type.GetType("System.String"));

            for (int i = 0; i < strListValueColumn1.Count; i++)
            {
                db.Rows.Add();
                db.Rows[i]["LOT_IDS"] = strListValueColumn1[i];
                db.Rows[i]["USED_TIME_STAMPS"] = strListValueColumn2[i];
            }

            return db;
        }
        public DataTable GetTable()
        {
            DataTable db = new DataTable();

            //db = CreateTable(structData.strListLotIds, structData.strListUsedTimeStamps);
            db = DataTableHelp.CreateCDFocusTable(structData.strListLotIds, structData.strListUsedTimeStamps, structData.strListDose, structData.strListCD);
            return db;
        }

        private List<string> GetChartName(int chartNum, int chartType)
        {
            List<string> strListName = new List<string>();
            for (int i = 0; i < chartNum; i++)
            {
                if (chartType == 1)
                {
                    strListName.Add("Input " + (i + 1));
                }
                else if (chartType == 2)
                {
                    strListName.Add("Output " + (i + 1));
                }
            }
            return strListName;
        }
        public List<Chart> AddChartToList(int chartNameType, int chartType)
        {
            int chartNumber;
            List<Chart> ctlListChart = new List<Chart>();
            List<string> strListNames = new List<string>();
            List<List<double>> dGroupListItemValues = new List<List<double>>();

            //dGroupListItemValues.Clear();//by zqk note 20180731

            #region
            //if (chartNameType == 1)
            //{
            //    dGroupListItemValues = BaseFun.GetItemValues(structData.strListCD);
            //}
            //else
            //{
            //    dGroupListItemValues = BaseFun.GetItemValues(structData.strListDose);
            //}

            //chartNumber = dGroupListItemValues.Count();
            //strListNames = GetChartName(chartNumber, chartNameType);

            //AddControlHelp.AddCommonChartToList(ref ctlListChart, chartType, strListNames, dGroupListItemValues, structData.strListLotIds);
            #endregion

            List<List<string>> strGroupListLotIds = new List<List<string>>();
            if (chartNameType == 1)
            {
                //by zqk 20180625 CD/Focuse Input/Outout exrange
                if(structData.strListUsedTimeStamps.Count>0 && structData.strListDose.Count>0 && structData.strListLotIds.Count>0)
                {
                    dGroupListItemValues = BaseFun.GetItemValues(structData.strListUsedTimeStamps, structData.strListDose, ref strGroupListLotIds, structData.strListLotIds);
                }
               
                //dGroupListItemValues = BaseFun.GetItemValues(structData.strListDose, ref strGroupListLotIds, structData.strListLotIds);  
            }
            else
            {
                //by zqk 20180625 CD/Focuse Input/Outout exrange
                if (structData.strListUsedTimeStamps.Count > 0 && structData.strListCD.Count > 0 && structData.strListLotIds.Count > 0)
                {
                    dGroupListItemValues = BaseFun.GetItemValues(structData.strListUsedTimeStamps, structData.strListCD, ref strGroupListLotIds, structData.strListLotIds);
                }
                //dGroupListItemValues = BaseFun.GetItemValues(structData.strListCD, ref strGroupListLotIds, structData.strListLotIds);
            }

            if (dGroupListItemValues.Count > 0)
            {
                chartNumber = dGroupListItemValues.Count();
                strListNames = GetChartName(chartNumber, chartNameType);

                AddControlHelp.AddCommonChartToList(ref ctlListChart, chartType, strListNames, dGroupListItemValues, strGroupListLotIds);
            }

            return ctlListChart;
        }
    }
}

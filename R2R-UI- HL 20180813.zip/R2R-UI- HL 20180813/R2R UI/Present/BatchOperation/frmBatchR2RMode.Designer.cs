﻿namespace R2R_UI.Present.BatchOperation
{
    partial class frmBatchR2RMode
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.dgvSet = new System.Windows.Forms.DataGridView();
            this.panDgvLblParameters = new System.Windows.Forms.Panel();
            this.lblDgvParameters = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panDgv = new System.Windows.Forms.Panel();
            this.dgvContext = new System.Windows.Forms.DataGridView();
            this.panDgvLblContext = new System.Windows.Forms.Panel();
            this.lblDgvContext = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdoFixed = new System.Windows.Forms.RadioButton();
            this.rdoActive = new System.Windows.Forms.RadioButton();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.cmbReticleId = new System.Windows.Forms.ComboBox();
            this.cmbChuckId = new System.Windows.Forms.ComboBox();
            this.panBtnOk = new System.Windows.Forms.Panel();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOk = new System.Windows.Forms.Button();
            this.panLbl = new System.Windows.Forms.Panel();
            this.lblContext = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSet)).BeginInit();
            this.panDgvLblParameters.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panDgv.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvContext)).BeginInit();
            this.panDgvLblContext.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panBtnOk.SuspendLayout();
            this.panLbl.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.panBtnOk);
            this.panel1.Controls.Add(this.panLbl);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1032, 616);
            this.panel1.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Controls.Add(this.panDgvLblParameters);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 308);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1032, 275);
            this.panel4.TabIndex = 10;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.dgvSet);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 26);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1032, 249);
            this.panel5.TabIndex = 5;
            // 
            // dgvSet
            // 
            this.dgvSet.AllowUserToAddRows = false;
            this.dgvSet.AllowUserToDeleteRows = false;
            this.dgvSet.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvSet.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvSet.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvSet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSet.Location = new System.Drawing.Point(0, 0);
            this.dgvSet.Name = "dgvSet";
            this.dgvSet.Size = new System.Drawing.Size(1032, 249);
            this.dgvSet.TabIndex = 1;
            this.dgvSet.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSet_CellEndEdit);
            this.dgvSet.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvContext_CellFormatting);
            this.dgvSet.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.dgvContext_CellPainting);
            this.dgvSet.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSet_CellValueChanged);
            this.dgvSet.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvContext_RowPostPaint);
            // 
            // panDgvLblParameters
            // 
            this.panDgvLblParameters.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panDgvLblParameters.Controls.Add(this.lblDgvParameters);
            this.panDgvLblParameters.Dock = System.Windows.Forms.DockStyle.Top;
            this.panDgvLblParameters.Location = new System.Drawing.Point(0, 0);
            this.panDgvLblParameters.Name = "panDgvLblParameters";
            this.panDgvLblParameters.Size = new System.Drawing.Size(1032, 26);
            this.panDgvLblParameters.TabIndex = 4;
            // 
            // lblDgvParameters
            // 
            this.lblDgvParameters.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblDgvParameters.AutoSize = true;
            this.lblDgvParameters.Location = new System.Drawing.Point(490, 3);
            this.lblDgvParameters.Name = "lblDgvParameters";
            this.lblDgvParameters.Size = new System.Drawing.Size(91, 13);
            this.lblDgvParameters.TabIndex = 0;
            this.lblDgvParameters.Text = "List of Parameters";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.panDgv);
            this.panel3.Controls.Add(this.panDgvLblContext);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 77);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1032, 231);
            this.panel3.TabIndex = 9;
            // 
            // panDgv
            // 
            this.panDgv.Controls.Add(this.dgvContext);
            this.panDgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panDgv.Location = new System.Drawing.Point(0, 26);
            this.panDgv.Name = "panDgv";
            this.panDgv.Size = new System.Drawing.Size(1032, 205);
            this.panDgv.TabIndex = 3;
            // 
            // dgvContext
            // 
            this.dgvContext.AllowUserToAddRows = false;
            this.dgvContext.AllowUserToDeleteRows = false;
            this.dgvContext.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvContext.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvContext.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvContext.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvContext.Location = new System.Drawing.Point(0, 0);
            this.dgvContext.Name = "dgvContext";
            this.dgvContext.Size = new System.Drawing.Size(1032, 205);
            this.dgvContext.TabIndex = 0;
            this.dgvContext.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvContext_CellFormatting);
            this.dgvContext.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.dgvContext_CellPainting);
            this.dgvContext.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvContext_RowPostPaint);
            // 
            // panDgvLblContext
            // 
            this.panDgvLblContext.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panDgvLblContext.Controls.Add(this.lblDgvContext);
            this.panDgvLblContext.Dock = System.Windows.Forms.DockStyle.Top;
            this.panDgvLblContext.Location = new System.Drawing.Point(0, 0);
            this.panDgvLblContext.Name = "panDgvLblContext";
            this.panDgvLblContext.Size = new System.Drawing.Size(1032, 26);
            this.panDgvLblContext.TabIndex = 2;
            // 
            // lblDgvContext
            // 
            this.lblDgvContext.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblDgvContext.AutoSize = true;
            this.lblDgvContext.Location = new System.Drawing.Point(484, 3);
            this.lblDgvContext.Name = "lblDgvContext";
            this.lblDgvContext.Size = new System.Drawing.Size(103, 13);
            this.lblDgvContext.TabIndex = 0;
            this.lblDgvContext.Text = "List of context group";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Controls.Add(this.textBox3);
            this.panel2.Controls.Add(this.cmbReticleId);
            this.panel2.Controls.Add(this.cmbChuckId);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 35);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1032, 42);
            this.panel2.TabIndex = 8;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox1.Controls.Add(this.rdoFixed);
            this.groupBox1.Controls.Add(this.rdoActive);
            this.groupBox1.Location = new System.Drawing.Point(105, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(155, 33);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            // 
            // rdoFixed
            // 
            this.rdoFixed.AutoSize = true;
            this.rdoFixed.Location = new System.Drawing.Point(89, 10);
            this.rdoFixed.Name = "rdoFixed";
            this.rdoFixed.Size = new System.Drawing.Size(50, 17);
            this.rdoFixed.TabIndex = 13;
            this.rdoFixed.Text = "Fixed";
            this.rdoFixed.UseVisualStyleBackColor = true;
            this.rdoFixed.CheckedChanged += new System.EventHandler(this.rdoType_CheckedChanged);
            // 
            // rdoActive
            // 
            this.rdoActive.AutoSize = true;
            this.rdoActive.Checked = true;
            this.rdoActive.Location = new System.Drawing.Point(15, 10);
            this.rdoActive.Name = "rdoActive";
            this.rdoActive.Size = new System.Drawing.Size(55, 17);
            this.rdoActive.TabIndex = 12;
            this.rdoActive.TabStop = true;
            this.rdoActive.Text = "Active";
            this.rdoActive.UseVisualStyleBackColor = true;
            this.rdoActive.CheckedChanged += new System.EventHandler(this.rdoType_CheckedChanged);
            // 
            // textBox1
            // 
            this.textBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Location = new System.Drawing.Point(307, 13);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(55, 20);
            this.textBox1.TabIndex = 7;
            this.textBox1.Text = "Chuck Id:";
            // 
            // textBox3
            // 
            this.textBox3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox3.Location = new System.Drawing.Point(636, 13);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(55, 20);
            this.textBox3.TabIndex = 8;
            this.textBox3.Text = "Reticle Id:";
            // 
            // cmbReticleId
            // 
            this.cmbReticleId.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cmbReticleId.FormattingEnabled = true;
            this.cmbReticleId.Location = new System.Drawing.Point(707, 13);
            this.cmbReticleId.Name = "cmbReticleId";
            this.cmbReticleId.Size = new System.Drawing.Size(223, 21);
            this.cmbReticleId.TabIndex = 10;
            this.cmbReticleId.SelectedIndexChanged += new System.EventHandler(this.cmbReticleId_SelectedIndexChanged);
            // 
            // cmbChuckId
            // 
            this.cmbChuckId.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cmbChuckId.FormattingEnabled = true;
            this.cmbChuckId.Location = new System.Drawing.Point(378, 13);
            this.cmbChuckId.Name = "cmbChuckId";
            this.cmbChuckId.Size = new System.Drawing.Size(223, 21);
            this.cmbChuckId.TabIndex = 9;
            this.cmbChuckId.SelectedIndexChanged += new System.EventHandler(this.cmbChuckId_SelectedIndexChanged);
            // 
            // panBtnOk
            // 
            this.panBtnOk.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panBtnOk.Controls.Add(this.btnCancel);
            this.panBtnOk.Controls.Add(this.btnOk);
            this.panBtnOk.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panBtnOk.Location = new System.Drawing.Point(0, 583);
            this.panBtnOk.Name = "panBtnOk";
            this.panBtnOk.Size = new System.Drawing.Size(1032, 33);
            this.panBtnOk.TabIndex = 7;
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.Location = new System.Drawing.Point(922, 6);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(73, 23);
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOk
            // 
            this.btnOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOk.Location = new System.Drawing.Point(824, 6);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(73, 23);
            this.btnOk.TabIndex = 0;
            this.btnOk.Text = "Ok";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // panLbl
            // 
            this.panLbl.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panLbl.Controls.Add(this.lblContext);
            this.panLbl.Dock = System.Windows.Forms.DockStyle.Top;
            this.panLbl.Location = new System.Drawing.Point(0, 0);
            this.panLbl.Name = "panLbl";
            this.panLbl.Size = new System.Drawing.Size(1032, 35);
            this.panLbl.TabIndex = 6;
            // 
            // lblContext
            // 
            this.lblContext.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblContext.AutoSize = true;
            this.lblContext.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContext.Location = new System.Drawing.Point(444, 9);
            this.lblContext.Name = "lblContext";
            this.lblContext.Size = new System.Drawing.Size(182, 16);
            this.lblContext.TabIndex = 0;
            this.lblContext.Text = "Current Selected Context:";
            // 
            // frmBatchR2RMode
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1032, 616);
            this.Controls.Add(this.panel1);
            this.MinimumSize = new System.Drawing.Size(845, 520);
            this.Name = "frmBatchR2RMode";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BatchR2RMode";
            this.Load += new System.EventHandler(this.frmBatchR2RMode_Load);
            this.SizeChanged += new System.EventHandler(this.frmBatchR2RMode_SizeChanged);
            this.Resize += new System.EventHandler(this.frmBatchR2RMode_Resize);
            this.panel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSet)).EndInit();
            this.panDgvLblParameters.ResumeLayout(false);
            this.panDgvLblParameters.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panDgv.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvContext)).EndInit();
            this.panDgvLblContext.ResumeLayout(false);
            this.panDgvLblContext.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panBtnOk.ResumeLayout(false);
            this.panLbl.ResumeLayout(false);
            this.panLbl.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panLbl;
        private System.Windows.Forms.Label lblContext;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panBtnOk;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panDgv;
        private System.Windows.Forms.DataGridView dgvContext;
        private System.Windows.Forms.Panel panDgvLblContext;
        private System.Windows.Forms.Label lblDgvContext;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DataGridView dgvSet;
        private System.Windows.Forms.Panel panDgvLblParameters;
        private System.Windows.Forms.Label lblDgvParameters;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.ComboBox cmbReticleId;
        private System.Windows.Forms.ComboBox cmbChuckId;
        private System.Windows.Forms.RadioButton rdoFixed;
        private System.Windows.Forms.RadioButton rdoActive;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}
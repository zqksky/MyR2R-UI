﻿using R2R_UI.Common;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace R2R_UI.Present.HL
{
    public partial class frmFeedForward : Form
    {
        #region
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x0014) // 禁掉清除背景消息
                return;
            base.WndProc(ref m);
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x02000000;
                return cp;
            }
        }

        private void CtlDoubleBuffer()
        {
            this.DoubleBuffered = true;//设置本窗体
            SetStyle(ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true); // 禁止擦除背景.
            SetStyle(ControlStyles.DoubleBuffer, true); // 双缓冲
            //SetStyle(ControlStyles.DoubleBuffer | ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint, true);
            UpdateStyles();
        }
        #endregion

        public frmFeedForward()
        {
            InitializeComponent();
        }
        public frmFeedForward(string strServiceName, string strCurrentUserName, string strCurrentPwd, string strFrmProduct, string strFrmLayer,string strFrmController, string strFrmTool, UIServiceFun.structGetFFOVLSettings structDataFFOVL)
        {

            InitializeComponent();
            strServiceAddress = strServiceName;
            strUserName = strCurrentUserName;
            strPassword = strCurrentPwd;

            strProduct = strFrmProduct;
            strLayer = strFrmLayer;
            strController = strFrmController;
            strTool = strFrmTool;
            //strOVLModel = strFrmOVLModel;

            structData = structDataFFOVL;

            strCurrentLayer = structDataFFOVL.strCurrentLayer;
            strListPreLayerPriority = new List<string>(structDataFFOVL.strListPreLayerPriority);
            strListPreLayer = new List<string>(structDataFFOVL.strListPreLayer);
            strListAlignmentLayer = new List<string>(structDataFFOVL.strListAlignmentLayer);
            strListVarNames = new List<string>(structDataFFOVL.strListVarNames);
            strListReticles = new List<string>(structDataFFOVL.strListReticles);
            strListChucks = new List<string>(structDataFFOVL.strListChucks);
            dListG1 = new List<double>(structDataFFOVL.dListG1);
            dListG2 = new List<double>(structDataFFOVL.dListG2);
            dListG3 = new List<double>(structDataFFOVL.dListG3);
            dListOVL_Offsets = new List<double>(structDataFFOVL.dListOVLOffsets);
            strListMS_Current = new List<double>(structDataFFOVL.strListMSCurrent);
            bListMS_Flags = new List<bool>(structDataFFOVL.bListMSFlags);
        }

        #region parm
        string strServiceAddress;
        string strUserName;
        string strPassword;

        string strProduct;
        string strLayer;
        string strController;
        string strTool;
        //string strOVLModel;

        public string strCurrentLayer;
        List<string> strListPreLayerPriority = new List<string>();
        List<string> strListPreLayer = new List<string>();
        List<string> strListAlignmentLayer = new List<string>();
        List<string> strListVarNames = new List<string>();
        List<string> strListReticles = new List<string>();
        List<string> strListChucks = new List<string>();
        List<double> dListG1 = new List<double>();
        List<double> dListG2 = new List<double>();
        List<double> dListG3 = new List<double>();
        List<double> dListOVL_Offsets = new List<double>();
        List<double> strListMS_Current = new List<double>();
        List<bool> bListMS_Flags = new List<bool>();

        List<string> strListVarNamesCurrent = new List<string>();
        List<double> dListG1Current = new List<double>();
        List<double> dListG2Current = new List<double>();
        List<double> dListG3Current = new List<double>();
        List<double> dListOVL_OffsetsCurrent = new List<double>();
        List<double> strListMS_CurrentCurrent = new List<double>();
        List<bool> bListMS_FlagsCurrent = new List<bool>();
        List<string> strListOVLModelCurrent = new List<string>();

        List<string> strListVarNamesChange = new List<string>();
        List<double> dListG1Change = new List<double>();
        List<double> dListG2Change = new List<double>();
        List<double> dListG3Change = new List<double>();
        List<double> dListOVL_OffsetsChange = new List<double>();
        List<double> strListMS_CurrentChange = new List<double>();
        List<bool> bListMS_FlagsChange = new List<bool>();
        List<string> strListOVLModelChange = new List<string>();

        string strChuckId;
        string strReticleId;
        List<string> strListChuckId = new List<string>();
        List<string> strListReticleId = new List<string>();

        UIServiceFun.structGetFFOVLSettings structData = new UIServiceFun.structGetFFOVLSettings();
        UIServiceFun.structUpdateFFOVLSettings structDataUpdate = new UIServiceFun.structUpdateFFOVLSettings();
        #endregion

        private void GetChuckIdAndReticleId()
        {
            strListChuckId = BaseFun.GetGroupName(strListChucks);
            cmbChuckId.DataSource = strListChuckId;

            strListReticleId = BaseFun.GetGroupName(strListReticles);
            cmbReticleId.DataSource = strListReticleId;
            //cmbReticleId.DataSource = strListReticles;
        }
        private void InitChuckId()
        {
            cmbChuckId.SelectedIndex = 0;
            strChuckId = cmbChuckId.Text.ToString();
        }
        private void InitReticleId()
        {
            cmbReticleId.SelectedIndex = 0;
            strReticleId = cmbReticleId.Text.ToString();
        }

        private float frmLocationX;
        private float frmLocationY;
        AdaptiveSizeResolution AutoSizeFrm = new AdaptiveSizeResolution();
        private void frmFeedForward_Load(object sender, EventArgs e)
        {
            #region 双缓冲
            DataGridViewHelp.DoubleBuffered(dgvPrelayer, true);
            DataGridViewHelp.DoubleBuffered(dgvSet, true);
            CtlDoubleBuffer();
            #endregion

            #region AdaptiveSizeResolution
            //AutoSizeFrm.ControllInitializeSize(this);
            #endregion

            #region  AdaptiveSize
            //this.Resize += new EventHandler(frmFeedForward_Resize);
            //frmLocationX = this.Width;
            //frmLocationY = this.Height;
            //AdaptiveSize.setTag(this);
            #endregion

            #region Init Lbl
            string strLbl = "Current Selected Context:" + strProduct + " /" + strTool + " /" + strLayer;
            AddControlHelp.SetLable(panLbl, lblContext, strLbl);

            string strDgvLblContext = "List of context group";
            AddControlHelp.SetLable(panDgvLblContext, lblDgvContext, strDgvLblContext);

            string strDgvLblParameters = "List of Parameters";
            AddControlHelp.SetLable(panDgvLblParameters, lblDgvParameters, strDgvLblParameters);
            #endregion

            #region Init Control
            txtCurrentLayer.Text = strCurrentLayer;
            GetChuckIdAndReticleId();
            InitChuckId();
            InitReticleId();
            #endregion

            #region Init DgvPrelayer
            GetDgvPrelayer();   //GetDgvPrelayer
            #endregion

            #region Init DgvSet
            //GetDgvSet();    //GetDgvSet
            //GetDgvSetCmb()

            //GetDgvSetTest();    //GetDgvSet

            //GetCurrentGridValue();
            #endregion
        }

        private void frmFeedForward_Resize(object sender, EventArgs e)
        {
            #region AdaptiveSize
            //float newx = (this.Width) / frmLocationX;
            //float newy = this.Height / frmLocationY;
            //AdaptiveSize.setControls(newx, newy, this);
            #endregion
        }

        private void frmFeedForward_SizeChanged(object sender, EventArgs e)
        {
            #region AdaptiveSizeResolution
            //AutoSizeFrm.ControlAutoSize(this);
            #endregion
        }

        private void GetDgvPrelayer()
        {
            DataTable dbPrelayerGroup = new DataTable("Prelayer");
            dbPrelayerGroup = DataTableHelp.CreatePrelayerTable(structData);

            dbPrelayerGroup = DataTableHelp.CreatePrelayerTable(structData);
            if (dbPrelayerGroup.Rows.Count > 0)
            {
                DataGridViewHelp.InitDgvGrid(dgvPrelayer, dbPrelayerGroup);
            }

            //DataTable dbPrelayer = new DataTable("dbPrelayer");
            //dbPrelayer = DataTableHelp.CreateFFOVLTable(dbPrelayerGroup, strChuckId, strReticleId);
            //DataGridViewHelp.InitDgvGrid(dgvPrelayer, dbPrelayer);
        }

        private void GetDgvSet()
        {
            DataTable dbFFOVLGroup = new DataTable("FFOVLGroup");
            dbFFOVLGroup = DataTableHelp.CreateFFOVLSetTable(structData);

            if (dbFFOVLGroup.Rows.Count > 0)
            {
                DataTable dbFFOVL = new DataTable("dbFFOVL");
                dbFFOVL = DataTableHelp.CreateFFOVLTable(dbFFOVLGroup, strChuckId, strReticleId);

                List<int> iList = new List<int>() { 0, 1, 2, 3, 4, 5, 6, 8 };
                DataGridViewHelp.InitDgvSet(dgvSet, dbFFOVL, iList);
            }
        }

        #region DgvComBox 
        private List<string> GetColDefValue(DataTable db,int colIndex)
        {
            List<string> strList = new List<string>();
            for (int i = 0; i < db.Rows.Count; i++)
            {
                strList.Add(db.Rows[i][colIndex].ToString());
            }
            return strList;
        }

        private void SetColDefValue(List<string> strListDefValue,int colIndex)
        {
            for (int i = 0; i < strListDefValue.Count; i++)
            {
                dgvSet.Rows[i].Cells[colIndex].Value = strListDefValue[i];

                //string strValue = dgvSet.Rows[i].Cells[8].Value.ToString();
                //DataGridViewHelp.SetDgvCmb(dgvSet, strListRangeValue, i, 8, strValue);
            }
        }

        private void GetDgvSetCmb()
        {
            DataTable dbFFOVLGroup = new DataTable("FFOVLGroup");
            dbFFOVLGroup = DataTableHelp.CreateFFOVLSetTable(structData);

            //DataTable dbFFOVL = null;
            DataTable dbFFOVL = new DataTable("dbFFOVL");
            dbFFOVL = DataTableHelp.CreateFFOVLTable(dbFFOVLGroup, strChuckId, strReticleId);

            List<string> strListRange = new List<string>() { "True", "False" };

            List<string> strListDefValue = new List<string>();
            strListDefValue = GetColDefValue(dbFFOVL, 8);

            dbFFOVL.Columns.Remove("New MS_Flags");

            List<int> iList = new List<int>() { 0, 1, 2, 3, 4, 5, 6, 8 };
            DataGridViewHelp.InitDgvSet(dgvSet, dbFFOVL, iList);

            DataGridViewHelp.SetDgvCmb(dgvSet, 9, strListRange, "New MS_Flags");
            SetColDefValue(strListDefValue, 9);
        }
        #endregion

        #region Test
        private void ShowDgvSet(DataTable db)
        {
            //dgvSet.DataSource = null;
            //if (dgvSet != null && dgvSet.ColumnCount > 0)
            //{
            //    //dgvSet.Columns.Clear();
            //    //DataTable dt = (DataTable)dgvSet.DataSource;
            //    //dt.Rows.Clear();

            //    BindingSource bs = new BindingSource();
            //    bs.DataSource = null;
            //    dgvSet.DataSource = bs;
            //    dgvSet.EndEdit();
            //    bs.EndEdit();
            //}

            DataGridViewHelp.InitDgvSet(dgvSet, db, iListReadOnlyIndex);
        }

        private void GetDgvSetTest(List<string> strListRange, string strColName, int iColIndex)
        {
            DataTable dbFFOVLGroup = new DataTable("FFOVLGroup");
            dbFFOVLGroup = DataTableHelp.CreateFFOVLSetTableTest(structData);

            //DataTable dbFFOVL = new DataTable("dbFFOVL");
            DataTable dbFFOVL = null;
            dbFFOVL = DataTableHelp.CreateFFOVLTable(dbFFOVLGroup, strChuckId, strReticleId);

            //iColIndex = 8;
            //strColName= "New MS_Flags";
            //strListRange = new List<string>() { "True", "False" };

            List<string> strListDefValue = new List<string>();
            //strListDefValue = GetColDefValue(dbFFOVL, iColIndex);
            strListDefValue = GetColDefValue(dbFFOVL, iColIndex - 1);

            dbFFOVL.Columns.Remove(strColName);

            //ShowDgvSet(dbFFOVL);
            DataGridViewHelp.InitDgvSet(dgvSet, dbFFOVL, iListReadOnlyIndex);

            DataGridViewHelp.SetDgvCmb(dgvSet, iColIndex, strListRange, strColName);
            SetColDefValue(strListDefValue, iColIndex);
            //dbFFOVL.Clear();
        }

        List<int> iListReadOnlyIndex = new List<int>() { 0, 1, 2, 3, 4, 5, 7 };
        List<string> strListMSFlagRange = new List<string>() { "True", "False" };
        List<string> strListOVLModelRange = new List<string>() { "LINEAR", "CD", "Focus", "FF" };
        private void GetDgvSetTest()
        {
            DataTable dbFFOVLGroup = new DataTable("FFOVLGroup");
            dbFFOVLGroup = DataTableHelp.CreateFFOVLSetTableTest(structData);

            //DataTable dbFFOVL = null;
            DataTable dbFFOVL = new DataTable("dbFFOVL");
            dbFFOVL = DataTableHelp.CreateFFOVLTable(dbFFOVLGroup, strChuckId, strReticleId);

            List<string> strListMSFlagDefValue = new List<string>();
            List<string> strListOVLModelDefValue = new List<string>();
            strListMSFlagDefValue = GetColDefValue(dbFFOVL, 7);
            strListOVLModelDefValue = GetColDefValue(dbFFOVL, 9);

            dbFFOVL.Columns.Remove("New MS_Flags");
            dbFFOVL.Columns.Remove("New OVLModel");

            //ShowDgvSet(dbFFOVL);
            DataGridViewHelp.InitDgvSet(dgvSet, dbFFOVL, iListReadOnlyIndex);

            DataGridViewHelp.SetDgvCmb(dgvSet, 8, strListMSFlagRange, "New MS_Flags");
            DataGridViewHelp.SetDgvCmb(dgvSet, 10, strListOVLModelRange, "New OVLModel");
            SetColDefValue(strListMSFlagDefValue, 8);
            SetColDefValue(strListOVLModelDefValue, 10);
        }
        #endregion

        private void ChuckIdOrReticleIdChanged()
        {
            if (cmbChuckId.Text.Equals("") || cmbReticleId.Text.Equals(""))
            {
            }
            else
            {
                strChuckId = cmbChuckId.Text;
                strReticleId = cmbReticleId.Text;

                #region Init DgvSet
                //GetDgvSet();
                GetDgvSetCmb();

                ////GetDgvSetTest();

                GetCurrentGridValue();
                #endregion
            }

        }
        bool bIsCellChange = false;
        private void cmbChuckId_SelectedIndexChanged(object sender, EventArgs e)
        {
            bIsCellChange = false;
            ChuckIdOrReticleIdChanged();
            bIsCellChange = true;
        }

        private void cmbReticleId_SelectedIndexChanged(object sender, EventArgs e)
        {
            bIsCellChange = false;
            ChuckIdOrReticleIdChanged();
            bIsCellChange = true;
        }

        private void GetCurrentGridValue()
        {
            int rowCount = 0;
            rowCount = dgvSet.Rows.Count;
            if (rowCount > 0)
            {
                strListVarNamesCurrent.Clear();
                dListG1Current.Clear();
                dListG2Current.Clear();
                dListG3Current.Clear();
                dListOVL_OffsetsCurrent.Clear();
                strListMS_CurrentCurrent.Clear();
                bListMS_FlagsCurrent.Clear();
                strListOVLModelCurrent.Clear();
                for (int i = 0; i < rowCount; i++)
                {
                    strListOVLModelCurrent.Add(dgvSet.Rows[i].Cells[0].Value.ToString());
                    strListVarNamesCurrent.Add(dgvSet.Rows[i].Cells[1].Value.ToString());
                    dListG1Current.Add(double.Parse(dgvSet.Rows[i].Cells[2].Value.ToString()));
                    dListG2Current.Add(double.Parse(dgvSet.Rows[i].Cells[3].Value.ToString()));
                    dListG3Current.Add(double.Parse(dgvSet.Rows[i].Cells[4].Value.ToString()));
                    strListMS_CurrentCurrent.Add(double.Parse(dgvSet.Rows[i].Cells[5].Value.ToString()));
                    dListOVL_OffsetsCurrent.Add(double.Parse(dgvSet.Rows[i].Cells[6].Value.ToString()));
                    bListMS_FlagsCurrent.Add(bool.Parse(dgvSet.Rows[i].Cells[8].Value.ToString()));
                }
            }
        }
        private bool IsCellValueChange(double dOVLOffsetValue, bool bMSFlags, int rowIndex)
        {
            bool flag1 = false;
            bool flag2 = false;

            flag1 = dOVLOffsetValue != dListOVL_OffsetsCurrent[rowIndex] ? true : false;
            if (flag1)
            {
                this.dgvSet.Rows[rowIndex].Cells[7].Style.BackColor = Color.Honeydew; //Color.MediumPurple;
            }
            else
            {
                this.dgvSet.Rows[rowIndex].Cells[7].Style.BackColor = Color.White;
            }
            flag2 = bMSFlags != bListMS_FlagsCurrent[rowIndex] ? true : false;
            if (flag2)
            {
                this.dgvSet.Rows[rowIndex].Cells[9].Style.BackColor = Color.Honeydew;
            }
            else
            {
                this.dgvSet.Rows[rowIndex].Cells[9].Style.BackColor = Color.White;
            }

            return flag1 || flag2;
        }

        private Hashtable htRowChange = new Hashtable();
        private void dgvSet_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void dgvSet_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (bIsCellChange)
            {
                if (htRowChange.ContainsKey(e.RowIndex.ToString()))
                {
                    int index = int.Parse(htRowChange[e.RowIndex.ToString()].ToString());
                    strListVarNamesChange.RemoveAt(index);
                    dListG1Change.RemoveAt(index);
                    dListG2Change.RemoveAt(index);
                    dListG3Change.RemoveAt(index);
                    dListOVL_OffsetsChange.RemoveAt(index);
                    strListMS_CurrentChange.RemoveAt(index);
                    bListMS_FlagsChange.RemoveAt(index);
                    strListOVLModelChange.RemoveAt(index);
                    htRowChange.Remove(e.RowIndex.ToString());
                }

                bool flag;
                bool bMSFlag;
                double dOVLOffsetValue = 0.0;
                bMSFlag = bool.Parse(dgvSet.Rows[e.RowIndex].Cells[9].Value.ToString());
                dOVLOffsetValue = double.Parse(dgvSet.Rows[e.RowIndex].Cells[7].Value.ToString());
                flag = IsCellValueChange(dOVLOffsetValue, bMSFlag, e.RowIndex);
                if (flag)
                {
                    strListOVLModelChange.Add(dgvSet.Rows[e.RowIndex].Cells[0].Value.ToString());
                    strListVarNamesChange.Add(dgvSet.Rows[e.RowIndex].Cells[1].Value.ToString());
                    dListG1Change.Add(double.Parse(dgvSet.Rows[e.RowIndex].Cells[2].Value.ToString()));
                    dListG2Change.Add(double.Parse(dgvSet.Rows[e.RowIndex].Cells[3].Value.ToString()));
                    dListG3Change.Add(double.Parse(dgvSet.Rows[e.RowIndex].Cells[4].Value.ToString()));
                    strListMS_CurrentChange.Add(double.Parse(dgvSet.Rows[e.RowIndex].Cells[5].Value.ToString()));
                    dListOVL_OffsetsChange.Add(double.Parse(dgvSet.Rows[e.RowIndex].Cells[7].Value.ToString()));
                    bListMS_FlagsChange.Add(bool.Parse(dgvSet.Rows[e.RowIndex].Cells[9].Value.ToString()));

                    htRowChange.Add(e.RowIndex.ToString(), strListVarNamesChange.Count - 1);
                }
            }
            
        }

        private bool GetChangeValue()
        {
            bool flag = false;
            if (strListVarNamesChange.Count > 0)
            {
                structDataUpdate.strListChucks = new List<string>();
                structDataUpdate.strListReticles = new List<string>();
                for (int i = 0; i < strListVarNamesChange.Count; i++)
                {
                    structDataUpdate.strListChucks.Add(strChuckId);
                    structDataUpdate.strListReticles.Add(strReticleId);
                }

                structDataUpdate.strListOVLModel = new List<string>(strListOVLModelChange);
                structDataUpdate.strListVarNames = new List<string>(strListVarNamesChange);
                structDataUpdate.dListNewOVLOffsets = new List<double>(dListOVL_OffsetsChange);
                structDataUpdate.bListNewMSFlags = new List<bool>(bListMS_FlagsChange);
                flag = true;
            }
            else
            {
                flag = false;
            }
            return flag;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            frmCheckedPwd frmChecked = new frmCheckedPwd(strUserName);
            if (frmChecked.ShowDialog() == DialogResult.OK)
            {
                if (frmChecked.strPassword.Equals(strPassword))
                {
                    #region
                    try
                    {
                        #region PH_OVL_Batch_UpdateOVLModel
                        strChuckId = cmbChuckId.Text;
                        strReticleId = cmbReticleId.Text;

                        bool bHaveChange;
                        bHaveChange = GetChangeValue();
                        if (bHaveChange)
                        {
                            bool bSuccess;
                            bSuccess = UIServiceFun.R2R_UI_PH_OVL_UpdateFFOVLSettings(strServiceAddress, strUserName, strProduct, strLayer, strController, strTool, structDataUpdate);
                            if (bSuccess)
                            {
                                this.Close();
                            }
                            else
                            {
                                //MessageBox.Show("Set Failed!");
                            }
                        }
                        #endregion

                        this.DialogResult = DialogResult.OK;
                    }
                    catch (Exception ee)
                    {
                        MessageBox.Show(ee.Message);
                    }
                    #endregion
                }
                else
                {
                    MessageBox.Show("Invalid password!");
                }
            }
            else
            {
                //MessageBox.Show("Invalid password!");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

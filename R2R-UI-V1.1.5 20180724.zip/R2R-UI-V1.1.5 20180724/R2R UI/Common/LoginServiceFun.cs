﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R_UI.Common
{
    class LoginServiceFun
    {
        public const int view = 8;
        public const int save = 32;
        public const int delete = 64;

        /// <summary>
        /// connect WebService(LoginManage)
        /// </summary>
        /// <param name="userId">XNi160297(VM-user)</param>
        /// <param name="passwd">Amat2018.(VM-pwd)</param>
        /// <param name="domain">amat</param>
        /// <param name="autoLogin"></param>
        /// <returns></returns>
        public static int LoginManage(string ServiceAddress, string userId, string passwd, string domain, bool autoLogin)
        {
            int opr = 0;
            try
            {
                //string url = @"http://" + "localhost" + @":58251/Adapter/YMTCUserLoginService.asmx";
                //string url = @"http://" + "192.168.150.135" + @":58251/Adapter/YMTCUserLoginService.asmx";
                string url = @"http://" + ServiceAddress + @":58251/Adapter/YMTCUserLoginService.asmx";
                LoginManage.YMTCUserLoginService cfg = new LoginManage.YMTCUserLoginService();
                cfg.Url = url;
                LoginManage.LoginRequest rq = new LoginManage.LoginRequest();
                rq.UserName = userId;
                rq.Password = passwd;
                rq.DomainName = domain;
                rq.AppType = "R2R_ModelConfig";
                rq.AutoLogin = autoLogin;
                LoginManage.LoginReply rly = cfg.Login(rq);
                if (!rly.Success)
                {
                    System.Windows.Forms.MessageBox.Show(rly.Message);
                    System.Environment.Exit(0);
                }
                opr = rly.UserOperations;
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(err.Message);
                System.Environment.Exit(0);
            }

            return opr;
        }

        /// <summary>
        /// connect Login WebService by zqk 20180724 modify
        /// </summary>
        /// <param name="strServiceAddress"></param>
        /// <param name="strUserId"></param>
        /// <param name="strPwd"></param>
        /// <param name="strDomain"></param>
        /// <param name="bAutoLogin"></param>
        /// <param name="operationType"></param>
        /// <returns></returns>
        public static bool LoginManage(string strServiceAddress, string strUserId, string strPwd, string strDomain, bool bAutoLogin,ref int operationType)
        {
            bool bSuccess = false;
            operationType = 0;
            try
            {
                //string url = @"http://" + "localhost" + @":58251/Adapter/YMTCUserLoginService.asmx";
                //string url = @"http://" + "192.168.150.135" + @":58251/Adapter/YMTCUserLoginService.asmx";
                string url = @"http://" + strServiceAddress + @":58251/Adapter/YMTCUserLoginService.asmx";
                LoginManage.YMTCUserLoginService cfg = new LoginManage.YMTCUserLoginService();
                cfg.Url = url;
                LoginManage.LoginRequest rq = new LoginManage.LoginRequest();
                rq.UserName = strUserId;
                rq.Password = strPwd;
                rq.DomainName = strDomain;
                rq.AppType = "R2R_ModelConfig";
                rq.AutoLogin = bAutoLogin;
                LoginManage.LoginReply rly = cfg.Login(rq);
                if (rly.Success)
                {
                    bSuccess = true;
                    operationType = rly.UserOperations;
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("Invalid login information!");
                    //System.Windows.Forms.MessageBox.Show(rly.Message);
                    //System.Environment.Exit(0);
                }
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show("Unable to verify login information!");
                //System.Windows.Forms.MessageBox.Show(err.Message);
                //System.Environment.Exit(0);
            }

            return bSuccess;
        }
    }
}

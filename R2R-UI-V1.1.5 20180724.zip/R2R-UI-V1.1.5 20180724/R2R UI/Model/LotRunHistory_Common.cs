﻿using R2R_UI.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.DataVisualization.Charting;
using static R2R_UI.Common.UIServiceFun;

namespace R2R_UI.Model
{
    class LotRunHistory_Common
    {
        private string strServiceAddress;
        private string strController;
        private List<string> strListR2RContexts = new List<string>();
        structCOMMON_GetLotRunHistory structData = new structCOMMON_GetLotRunHistory();
        public List<string> strListGroupNames = new List<string>();
        public List<List<int>> iGroupListIndexs = new List<List<int>>();

        public structGroupValue structGroupData = new structGroupValue();
        public string strCurrentR2RMode;
        public bool bIsActive;
        public bool bNotData;

        public LotRunHistory_Common(string strServiceAddress, string strController, List<string> strListR2RContexts, bool bIsAll)
        {
            this.strServiceAddress = strServiceAddress;
            this.strController = strController;
            this.strListR2RContexts = new List<string>(strListR2RContexts);

            structCOMMON_GetLotRunHistory structDataNull = new structCOMMON_GetLotRunHistory();
            structCOMMON_GetLotRunHistory structDataAll = new structCOMMON_GetLotRunHistory();
            structDataAll = R2R_UI_COMMON_GetLotRunHistory(strServiceAddress, strController, strListR2RContexts);
            if (structDataAll.Equals(structDataNull))
            {
                bNotData = true;
            }
            else
            {
                if (bIsAll)
                {
                    this.structData = structDataAll;
                }
                else
                {
                    this.structData = ListLotsWithMetrology(structDataAll);
                }
                this.strListGroupNames = GetGroupName(structData.strListGroups);
                this.iGroupListIndexs = GetGroupIndex(structData.strListGroups);
                this.structGroupData = GetStructGroupData();
                //this.structGroupData = GetStructGroupValue();

                //this.strCurrentR2RMode = structData.strCurrentR2RMode;
                //this.bIsActive = IsActive(this.strCurrentR2RMode);
            }
        }
        private bool IsActive(string strR2RMode)
        {
            bool flag = false;
            if (strR2RMode.Equals("Active"))
            {
                flag = true;
            }
            else
            {
                //btnOptReset.Enabled = false;
            }
            return flag;
        }
        private List<List<int>> GetGroupIndex(List<string> strList)
        {
            List<List<int>> iListIndexs = new List<List<int>>();
            List<string> strListGroup = new List<string>();

            strListGroup = GetGroupName(strList);
            foreach (var str in strListGroup)
            {
                List<int> iListIndex = new List<int>();
                for (int i = 0; i < strList.Count; i++)
                {
                    if (str.Equals(strList[i]))
                    {
                        iListIndex.Add(i);
                    }
                }
                iListIndexs.Add(iListIndex);
            }
            return iListIndexs;
        }

        private List<string> GetGroupName(List<string> strList)
        {
            List<string> strGroup = new List<string>();
            //strList = new List<string>() { "p1", "p1", "p1", "p2", "p2", "p3", "p3", "p4" };
            var q = strList.GroupBy(x => x).Where(x => x.Count() > 0).ToList();

            foreach (var item in q)
            {
                //List<string> str = new List<string>(item.ToList());
                //foreach (var s in str)
                //{
                //    MessageBox.Show(s);
                //}
                //MessageBox.Show(item.Key);
                strGroup.Add(item.Key);
            }
            strGroup.Sort();
            return strGroup;
        }
        public struct structGroupValue
        {
            public List<List<string>> strListGroupLotIds;
            public List<List<string>> strListGroupUsedTimeStamps;
            public List<List<string>> strListGroupInputValues;
            public List<List<string>> strListGroupOutputValues;
        };


        public structGroupValue GetStructGroupValue()
        {
            List<List<string>> strListGroupLotIds = new List<List<string>>();
            List<List<string>> strListGroupUsedTimeStamps = new List<List<string>>();
            List<List<string>> strListGroupInputValues = new List<List<string>>();
            List<List<string>> strListGroupOutputValues = new List<List<string>>();


            structGroupValue structValue = new structGroupValue();

            for (int i = 0; i < iGroupListIndexs.Count; i++)
            {
                List<string> strListLotIdsTemp = new List<string>();
                List<string> strListUsedTimeStampsTemp = new List<string>();
                List<string> strListInputValuesTemp = new List<string>();
                List<string> strListOutputValuesTemp = new List<string>();
                for (int t = 0; t < iGroupListIndexs[i].Count; t++)
                {
                    strListLotIdsTemp.Add(structData.strListLotIds[iGroupListIndexs[i][t]]);
                    strListUsedTimeStampsTemp.Add(structData.strListUsedTimeStamps[iGroupListIndexs[i][t]]);
                    strListInputValuesTemp.Add(structData.strListInputValues[iGroupListIndexs[i][t]]);
                    strListOutputValuesTemp.Add(structData.strListOutputValues[iGroupListIndexs[i][t]]);
                }
                strListGroupLotIds.Add(strListLotIdsTemp);
                strListGroupUsedTimeStamps.Add(strListUsedTimeStampsTemp);
                strListGroupInputValues.Add(strListInputValuesTemp);
                strListGroupOutputValues.Add(strListOutputValuesTemp);
            }
            structValue.strListGroupLotIds = new List<List<string>>(strListGroupLotIds);
            structValue.strListGroupUsedTimeStamps = new List<List<string>>(strListGroupUsedTimeStamps);
            structValue.strListGroupInputValues = new List<List<string>>(strListGroupInputValues);
            structValue.strListGroupOutputValues = new List<List<string>>(strListGroupOutputValues);

            return structValue;
        }

        private structGroupValue GetStructGroupValue(List<List<int>> iListGroupIndexs, List<string> strListLotIds, List<string> strListUsedTimeStamps, List<string> strListInputValues, List<string> strListOutputValues)
        {
            List<List<string>> strListGroupLotIds = new List<List<string>>();
            List<List<string>> strListGroupUsedTimeStamps = new List<List<string>>();
            List<List<string>> strListGroupInputValues = new List<List<string>>();
            List<List<string>> strListGroupOutputValues = new List<List<string>>();


            structGroupValue structValue = new structGroupValue();

            for (int i = 0; i < iListGroupIndexs.Count; i++)
            {
                List<string> strListLotIdsTemp = new List<string>();
                List<string> strListUsedTimeStampsTemp = new List<string>();
                List<string> strListInputValuesTemp = new List<string>();
                List<string> strListOutputValuesTemp = new List<string>();
                for (int t = 0; t < iListGroupIndexs[i].Count; t++)
                {
                    strListLotIdsTemp.Add(strListLotIds[iListGroupIndexs[i][t]]);
                    strListUsedTimeStampsTemp.Add(strListUsedTimeStamps[iListGroupIndexs[i][t]]);
                    strListInputValuesTemp.Add(strListInputValues[iListGroupIndexs[i][t]]);
                    strListOutputValuesTemp.Add(strListOutputValues[iListGroupIndexs[i][t]]);
                }
                strListGroupLotIds.Add(strListLotIdsTemp);
                strListGroupUsedTimeStamps.Add(strListUsedTimeStampsTemp);
                strListGroupInputValues.Add(strListInputValuesTemp);
                strListGroupOutputValues.Add(strListOutputValuesTemp);
            }
            structValue.strListGroupLotIds = new List<List<string>>(strListGroupLotIds);
            structValue.strListGroupUsedTimeStamps = new List<List<string>>(strListGroupUsedTimeStamps);
            structValue.strListGroupInputValues = new List<List<string>>(strListGroupInputValues);
            structValue.strListGroupOutputValues = new List<List<string>>(strListGroupOutputValues);

            return structValue;
        }

        public structGroupValue GetStructGroupData()
        {
            structGroupValue structGroup = new structGroupValue();
            structGroup = GetStructGroupValue(iGroupListIndexs, structData.strListLotIds, structData.strListUsedTimeStamps, structData.strListInputValues, structData.strListOutputValues);
            return structGroup;
        }
        private List<string> GetChartName(int chartNum, int chartType)
        {
            List<string> strListName = new List<string>();
            for (int i = 0; i < chartNum; i++)
            {
                if (chartType == 1)
                {
                    strListName.Add("Input " + (i + 1));
                }
                else if (chartType == 2)
                {
                    strListName.Add("Output " + (i + 1));
                }
            }
            return strListName;
        }

        public void GetCommonGroupChart(int index, structGroupValue structData, ref List<List<Chart>> ctlListInputChartGroup, ref List<List<Chart>> ctlListOutputChartGroup)
        {
            //ctlListInputChartGroup.Clear();
            //ctlListOutputChartGroup.Clear();
            ctlListInputChartGroup = new List<List<Chart>>();
            ctlListOutputChartGroup = new List<List<Chart>>();

            for (int i = 0; i < index; i++)
            {
                List<List<double>> dListInputValuesResultGroup = new List<List<double>>();
                List<List<double>> dListOutputValuesResultGroup = new List<List<double>>();
                //List<Chart> ctlListInputChartTemp = new List<Chart>();
                //List<Chart> ctlListOutputChartTemp = new List<Chart>();

                List<List<string>> strGroupListLotIdsInput = new List<List<string>>();
                List<List<string>> strGroupListLotIdsOutput = new List<List<string>>();
                dListInputValuesResultGroup = BaseFun.GetItemValues(structData.strListGroupUsedTimeStamps[i], structData.strListGroupInputValues[i], ref strGroupListLotIdsInput, structData.strListGroupLotIds[i]);
                dListOutputValuesResultGroup = BaseFun.GetItemValues(structData.strListGroupUsedTimeStamps[i], structData.strListGroupOutputValues[i], ref strGroupListLotIdsOutput, structData.strListGroupLotIds[i]);
                //dListInputValuesResultGroup = BaseFun.GetItemValues(structData.strListGroupInputValues[i], ref strGroupListLotIdsInput, structData.strListGroupLotIds[i]);
                //dListOutputValuesResultGroup = BaseFun.GetItemValues(structData.strListGroupOutputValues[i], ref strGroupListLotIdsOutput, structData.strListGroupLotIds[i]);

                int chartInputNumber = dListInputValuesResultGroup.Count();
                int chartOutputNumber = dListOutputValuesResultGroup.Count();

                List<string> strListInputNames = new List<string>();
                strListInputNames = GetChartName(chartInputNumber, 1);
                List<string> strListOutputNames = new List<string>();
                strListOutputNames = GetChartName(chartOutputNumber, 2);

                //by zqk 20180625 modify Chart show
                List<Chart> ctlListInputChartTemp = new List<Chart>();
                List<Chart> ctlListOutputChartTemp = new List<Chart>();
                AddControlHelp.AddCommonChartToList(ref ctlListInputChartTemp, 2, strListInputNames, dListInputValuesResultGroup, strGroupListLotIdsInput);
                AddControlHelp.AddCommonChartToList(ref ctlListOutputChartTemp, 2, strListOutputNames, dListOutputValuesResultGroup, strGroupListLotIdsOutput);
                ctlListInputChartGroup.Add(ctlListInputChartTemp);
                ctlListOutputChartGroup.Add(ctlListOutputChartTemp);
            }
        }

        public static structCOMMON_GetLotRunHistory ListLotsWithMetrology(structCOMMON_GetLotRunHistory structData)
        {
            structCOMMON_GetLotRunHistory structDataNew = new structCOMMON_GetLotRunHistory();
            structDataNew.iListActualInputSizes = new List<int>();
            structDataNew.iListActualOutputSizes = new List<int>();
            structDataNew.strListIsValidRecords = new List<string>();
            structDataNew.strListLotIds = new List<string>();
            structDataNew.strListUsedTimeStamps = new List<string>();
            structDataNew.strListInputValues = new List<string>();
            structDataNew.strListOutputValues = new List<string>();
            structDataNew.strListGroups = new List<string>();


            if (structData.strListIsValidRecords.Count > 0)
            {
                for (int i = 0; i < structData.strListIsValidRecords.Count; i++)
                {
                    if (structData.strListIsValidRecords[i].Equals("True"))
                    {
                        structDataNew.iListActualInputSizes.Add(structData.iListActualInputSizes[i]);
                        structDataNew.iListActualOutputSizes.Add(structData.iListActualOutputSizes[i]);
                        structDataNew.strListIsValidRecords.Add(structData.strListIsValidRecords[i]);
                        structDataNew.strListLotIds.Add(structData.strListLotIds[i]);
                        structDataNew.strListUsedTimeStamps.Add(structData.strListUsedTimeStamps[i]);
                        structDataNew.strListInputValues.Add(structData.strListInputValues[i]);
                        structDataNew.strListOutputValues.Add(structData.strListOutputValues[i]);
                        structDataNew.strListGroups.Add(structData.strListGroups[i]);
                    }
                }
            }
            return structDataNew;
        }

        public DataTable CreateTable(List<string> strListValueColumn1, List<string> strListValueColumn2)
        {
            DataTable db = new DataTable("DBCommon");

            db.Columns.Add("LOT_IDS", Type.GetType("System.String"));
            db.Columns.Add("USED_TIME_STAMPS", Type.GetType("System.String"));

            for (int i = 0; i < strListValueColumn1.Count; i++)
            {
                db.Rows.Add();
                db.Rows[i]["LOT_IDS"] = strListValueColumn1[i];
                db.Rows[i]["USED_TIME_STAMPS"] = strListValueColumn2[i];
            }

            return db;
        }

        public static structCOMMON_GetLotRunHistory GetLotRunHistoryInput_Common(structCOMMON_GetLotRunHistory structData)
        {
            structCOMMON_GetLotRunHistory structDataNew = new structCOMMON_GetLotRunHistory();
            structDataNew.iListActualInputSizes = new List<int>();
            structDataNew.iListActualOutputSizes = new List<int>();
            structDataNew.strListIsValidRecords = new List<string>();
            structDataNew.strListLotIds = new List<string>();
            structDataNew.strListUsedTimeStamps = new List<string>();
            structDataNew.strListInputValues = new List<string>();
            structDataNew.strListOutputValues = new List<string>();
            structDataNew.strListGroups = new List<string>();


            if (structData.strListInputValues.Count > 0)
            {
                for (int i = 0; i < structData.strListInputValues.Count; i++)
                {
                    if (!structData.strListInputValues[i].Contains("NaN"))
                    {
                        structDataNew.iListActualInputSizes.Add(structData.iListActualInputSizes[i]);
                        structDataNew.iListActualOutputSizes.Add(structData.iListActualOutputSizes[i]);
                        structDataNew.strListIsValidRecords.Add(structData.strListIsValidRecords[i]);
                        structDataNew.strListLotIds.Add(structData.strListLotIds[i]);
                        structDataNew.strListUsedTimeStamps.Add(structData.strListUsedTimeStamps[i]);
                        structDataNew.strListInputValues.Add(structData.strListInputValues[i]);
                        structDataNew.strListOutputValues.Add(structData.strListOutputValues[i]);
                        structDataNew.strListGroups.Add(structData.strListGroups[i]);
                    }
                }
            }
            return structDataNew;
        }
        public static structCOMMON_GetLotRunHistory GetLotRunHistoryOutput_Common(structCOMMON_GetLotRunHistory structData)
        {
            structCOMMON_GetLotRunHistory structDataNew = new structCOMMON_GetLotRunHistory();
            structDataNew.iListActualInputSizes = new List<int>();
            structDataNew.iListActualOutputSizes = new List<int>();
            structDataNew.strListIsValidRecords = new List<string>();
            structDataNew.strListLotIds = new List<string>();
            structDataNew.strListUsedTimeStamps = new List<string>();
            structDataNew.strListInputValues = new List<string>();
            structDataNew.strListOutputValues = new List<string>();
            structDataNew.strListGroups = new List<string>();


            if (structData.strListOutputValues.Count > 0)
            {
                for (int i = 0; i < structData.strListOutputValues.Count; i++)
                {
                    if (!structData.strListOutputValues[i].Contains("NaN"))
                    {
                        structDataNew.iListActualInputSizes.Add(structData.iListActualInputSizes[i]);
                        structDataNew.iListActualOutputSizes.Add(structData.iListActualOutputSizes[i]);
                        structDataNew.strListIsValidRecords.Add(structData.strListIsValidRecords[i]);
                        structDataNew.strListLotIds.Add(structData.strListLotIds[i]);
                        structDataNew.strListUsedTimeStamps.Add(structData.strListUsedTimeStamps[i]);
                        structDataNew.strListInputValues.Add(structData.strListInputValues[i]);
                        structDataNew.strListOutputValues.Add(structData.strListOutputValues[i]);
                        structDataNew.strListGroups.Add(structData.strListGroups[i]);
                    }
                }
            }
            return structDataNew;
        }
    }
}

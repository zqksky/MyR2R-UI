﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExcelParse.BaseFun
{
    class FileHelp
    {
        public static int GetFileType(string strPath)
        {
            int flag = 0;
            FileInfo fi = new FileInfo(strPath);
            if (fi.Attributes == FileAttributes.Directory)
            {
                //MessageBox.Show("文件夹");
                flag = 1;
            }
            else if (fi.Attributes == FileAttributes.Normal)
            {
                //MessageBox.Show("文件");
                flag = 2;
            }
            else
            {
                flag = 0;
            }
            return flag;
        }

        public static bool IsExcelFile(string strFile)
        {
            bool flag = false;
            if (File.Exists(strFile))
            {
                if (Path.GetExtension(strFile).Equals(".xlsx") || Path.GetExtension(strFile).Equals(".xls"))
                {
                    flag = true;
                }
                else
                {
                    MessageBox.Show("Not Excel File!");
                    flag = false;
                }
            }
            else
            {
                MessageBox.Show("Excel File Not Exist!");
                flag = false;
            }
            return flag;
        }
        public static string GetSavePath(string strSavePth,string strDefalutPath)
        {
            int fileType = 0;
            string strPath = strDefalutPath;

            fileType = GetFileType(strSavePth);

            if (fileType == 1)
            {
                if (Directory.Exists(strSavePth))
                {
                    strPath = strSavePth + "\\output.xlsx";
                }
            }
            if (fileType == 2)
            {
                if (File.Exists(strSavePth))
                {
                    if (Path.GetExtension(strSavePth).Equals(".xlsx") || Path.GetExtension(strSavePth).Equals(".xls"))
                    {
                        strPath = strSavePth;
                    }
                    else
                    {
                        strPath = strDefalutPath;
                    }
                }
                else
                {
                    strPath = strDefalutPath;
                }
            }

            return strPath;
        }
    }
}

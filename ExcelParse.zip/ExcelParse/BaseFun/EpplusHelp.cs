﻿using OfficeOpenXml;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static ExcelParse.BaseFun.StructDefine;

namespace ExcelParse.BaseFun
{
    class EpplusHelp
    {
        public static System.Data.DataTable ExcelToDataTable(string strExcelPath)
        {
            System.Data.DataTable db = new System.Data.DataTable("dbExcel");
            try
            {
                FileInfo existingFile = new FileInfo(strExcelPath);
                using (ExcelPackage package = new ExcelPackage(existingFile))
                {
                    //ExcelPackage package = new ExcelPackage(existingFile);
                    int vSheetCount = package.Workbook.Worksheets.Count; //获取总Sheet页
                    ExcelWorksheet worksheet = package.Workbook.Worksheets[1];//选定 指定页
                    int maxColumnNum = worksheet.Dimension.End.Column;//最大列
                    int minColumnNum = worksheet.Dimension.Start.Column;//最小列
                    int maxRowNum = worksheet.Dimension.End.Row;//最小行
                    int minRowNum = worksheet.Dimension.Start.Row;//最大行

                    for (int m = 1; m <= maxColumnNum; m++)
                    {
                        db.Columns.Add(worksheet.Cells[1, m].Value.ToString(), Type.GetType("System.String"));
                    }
                    for (int n = 2; n <= maxRowNum; n++)
                    {
                        db.Rows.Add();
                        for (int m = 1; m <= maxColumnNum; m++)
                        {
                            db.Rows[n - 2][m - 1] = worksheet.Cells[n, m].Value.ToString();
                        }
                    }
                }
            }
            catch (Exception Err)
            {
                MessageBox.Show(Err.Message);
            }

            return db;
        }
       
        public static void SaveDataToExcel(string strSaveExcelPath,List<structDataContext> strListStruct)
        {
            //strSaveExcelPath = @"C:\YMTC\ExcelParse - Copy\output.xlsx";
            FileInfo newFile = new FileInfo(strSaveExcelPath);
            if (newFile.Exists)
            {
                newFile.Delete();
                newFile = new FileInfo(strSaveExcelPath);
            }
            using (ExcelPackage package = new ExcelPackage(newFile))
            {
                ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("Result");
                for (int i = 0; i < strListStruct.Count; i++)
                {
                    worksheet.Cells[i + 1, 1].Value = strListStruct[i].strList1;
                    worksheet.Cells[i + 1, 2].Value = strListStruct[i].strList2;
                    worksheet.Cells[i + 1, 3].Value = strListStruct[i].strList3;
                    worksheet.Cells[i + 1, 4].Value = strListStruct[i].strList4;
                    worksheet.Cells[i + 1, 5].Value = strListStruct[i].strList5;
                }
                package.Save();
                MessageBox.Show("Save Excel Succeed");
            }
        }

        public static Hashtable ExcelToHashtable(string strExcelPath)
        {
            Hashtable ht = new Hashtable();
            try
            {
                FileInfo existingFile = new FileInfo(strExcelPath);
                using (ExcelPackage package = new ExcelPackage(existingFile))
                {
                    //ExcelPackage package = new ExcelPackage(existingFile);
                    int vSheetCount = package.Workbook.Worksheets.Count; //获取总Sheet页
                    ExcelWorksheet worksheet = package.Workbook.Worksheets[1];//选定 指定页
                    int maxColumnNum = worksheet.Dimension.End.Column;//最大列
                    int minColumnNum = worksheet.Dimension.Start.Column;//最小列
                    int maxRowNum = worksheet.Dimension.End.Row;//最小行
                    int minRowNum = worksheet.Dimension.Start.Row;//最大行

                    for (int n = 2; n <= maxRowNum; n++)
                    {
                        string strKey = "";
                        string strValue = "";
                        for (int m = 1; m <= maxColumnNum; m++)
                        {
                            if (m < 4)
                            {
                                strKey += worksheet.Cells[n, m].Value.ToString() + ",";
                            }
                            else
                            {
                                strValue += worksheet.Cells[n, m].Value.ToString() + ",";
                            }
                        }
                        strKey = strKey.TrimEnd(',');
                        strValue = strValue.TrimEnd(',');
                        if (ht.Contains(strKey))
                        {
                            ht[strKey] = ht[strKey] + ";" + strValue;
                        }
                        else
                        {
                            ht.Add(strKey, strValue);
                        }
                    }
                }
            }
            catch (Exception Err)
            {
                MessageBox.Show(Err.Message);
            }

            return ht;
        }

        public static Hashtable GetParseHashtable(Hashtable ht)
        {
            Hashtable htNew = new Hashtable();
            try
            {
                //遍历方法一：遍历哈希表中的键 
                foreach (string key in ht.Keys)
                {
                    string strValueTmp = ht[key].ToString();
                    string strValue = "";
                    if (ht[key].ToString().Contains(";"))
                    {
                        strValue = SpilitValue(strValueTmp);
                        htNew.Add(key, strValue);
                    }
                    else
                    {          
                        strValue = strValueTmp.Insert(2,"[ ");
                        strValue += " ]";
                        htNew.Add(key, strValue);
                    }
                    //Console.WriteLine(ht[key]);
                }

                ////遍历方法二：遍历哈希表中的值 
                //foreach (string value in ht.Values)
                //{
                //    Console.WriteLine(value);
                //}
            }
            catch (Exception Err)
            {
                MessageBox.Show(Err.Message);
            }

            return htNew;
        }

        public static string SpilitValue(string strValue)
        {
            List<string> strListIndex = new List<string>();
            List<string> strListValue = new List<string>();

            string strResult = "";
            string[] arryStr = strValue.Split(';');
            for (int i = 0; i < arryStr.Length; i++)
            {
                string[] arryStr2 = arryStr[i].Split(',');
                strListIndex.Add(arryStr2[0]);
                strListValue.Add(arryStr2[1]);
            }

            strResult = ParseValue(strListIndex, strListValue);
            return strResult;
        }

        public static string ParseValue(List<string> strListIndex, List<string> strListValue)
        {
            string strResult = "";
            string[] arryStr = new string[strListValue.Count];
            for (int i = 0; i < strListIndex.Count; i++)
            {
                arryStr[i] = strListValue[int.Parse(strListIndex[i])];
            }
          
            foreach(var str in arryStr)
            {
                strResult += str + " ";
            }
            strResult = strListValue.Count + ","+ "[ " + strResult + "]";
            return strResult;
        }

        public static void WriteDataToCsv(string path,Hashtable ht)
        {
            using (FileStream fs = new FileStream(path, FileMode.Create))
            {
                StreamWriter sw = new StreamWriter(fs);

                //开始写入
                foreach (string key in ht.Keys)
                {
                    sw.WriteLine(key+","+ht[key]);
                    //sw.WriteLine();//换行
                    //sw.WriteLine("\r\n");
                    //sw.WriteLine(Environment.NewLine);//换行
                }                    
                //清空缓冲区
                sw.Flush();
                //关闭流
                sw.Close();
                fs.Close();
            }
                
        }
    }
}
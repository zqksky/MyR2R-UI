﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcelParse.BaseFun
{
    class StructDefine
    {
        public struct structDataContext
        {
            public string strList1;
            public string strList2;
            public string strList3;
            public string strList4;
            public string strList5;
        };
    }
}

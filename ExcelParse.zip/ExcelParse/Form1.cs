﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using System.Data.OleDb;
using System.IO;
using OfficeOpenXml;
using ExcelParse.BaseFun;
using static ExcelParse.BaseFun.StructDefine;
using System.Threading;
using System.Collections;

namespace ExcelParse
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string strSourceExcelPath = AppDomain.CurrentDomain.SetupInformation.ApplicationBase + "input.xlsx";//@"C:\YMTC\ExcelParse - Copy\input.xlsx";
        string strSavePath = AppDomain.CurrentDomain.SetupInformation.ApplicationBase + "output.xlsx"; //Directory.GetCurrentDirectory(); //获取应用程序的当前工作目录

        private void Form1_Load(object sender, EventArgs e)
        {
            //LinqDatatableHelp.Test();

            //appendStringCtrl = new AppendStringCallback(AppendString);
            //appendObjectCtrl = new AppendObjectCallback(AppendObject);

            txtSourcePath.Text= strSourceExcelPath;
            txtSavePath.Text= strSavePath; //获取应用程序的当前工作目录
            //MessageBox.Show(Path.GetExtension(txtSavePath.Text.ToString()));
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            string strFilePath = "";
            //打开文件
            OpenFileDialog file = new OpenFileDialog();
            file.Filter = "Excel(*.xlsx)|*.xlsx|Excel(*.xls)|*.xls";

            file.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            file.Multiselect = false;

            if (file.ShowDialog() == DialogResult.Cancel)
            {
            }
            else
            {
                strFilePath = file.FileName;
                txtSourcePath.Text = strFilePath;
            }
            //判断文件后缀
            string fileSuffix = System.IO.Path.GetExtension(strFilePath);
            if (string.IsNullOrEmpty(fileSuffix))
            {
                //MessageBox.Show("Not Excel File!");
            }
        }
        private void btnSelect_Click(object sender, EventArgs e)
        {
            try
            {
                FolderBrowserDialog dialog = new FolderBrowserDialog();
                dialog.Description = "请选择文件路径";
                DialogResult result = dialog.ShowDialog();
                if (result == DialogResult.Cancel)
                {
                    return;
                }
                string folderPath = dialog.SelectedPath.Trim();
                DirectoryInfo theFolder = new DirectoryInfo(folderPath);
                if (theFolder.Exists)
                {

                    txtSavePath.Text = theFolder.FullName;
                    //return;
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        private void btnParse_Click(object sender, EventArgs e)
        {
            //创建无参的线程
            Thread thread1 = new Thread(new ThreadStart(ParseFun));
            //Thread thread1 = new Thread(new ThreadStart(ParseFunCsv));
            //调用Start方法执行线程
            thread1.Start();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private string AssembleFun(List<string> strList)
        {
            string str = "";
            foreach (var s in strList)
            {
                str += s + " ";
            }
            return str = "[ " + str + "]";
        }

        private void ParseFunCsv()
        {
            bool flagHaveFile = false;
            strSourceExcelPath = txtSourcePath.Text.ToString();

            flagHaveFile = FileHelp.IsExcelFile(strSourceExcelPath);

            if (flagHaveFile)
            {
                Hashtable ht = new Hashtable();
                ht = EpplusHelp.ExcelToHashtable(strSourceExcelPath);

                Hashtable htNew = new Hashtable();
                htNew = EpplusHelp.GetParseHashtable(ht);

                string strDefaultPath = strSavePath;
                strSavePath = txtSavePath.Text.ToString();

                string strOutputPath = "";
                strOutputPath = FileHelp.GetSavePath(strSavePath, strDefaultPath);
                if (strOutputPath.Equals(strDefaultPath))
                {
                    //txtSavePath.Text = strDefaultPath;
                    SettxtBox(txtSavePath, strDefaultPath);
                }
                EpplusHelp.WriteDataToCsv(strOutputPath, htNew);
            }
        }

        private void ParseFun()
        {
            bool flagHaveFile = false;
            strSourceExcelPath = txtSourcePath.Text.ToString();

            flagHaveFile = FileHelp.IsExcelFile(strSourceExcelPath);

            if (flagHaveFile)
            {
                List<structDataContext> strListStruct = new List<structDataContext>();
                System.Data.DataTable dbAll = new System.Data.DataTable("dbAll");
                DataSet ds = new DataSet();

                dbAll = EpplusHelp.ExcelToDataTable(strSourceExcelPath);

                //dbAll = dbAll.DefaultView.ToTable();
                //MessageBox.Show(dbAll.Rows.Count.ToString());

                //Sort
                System.Data.DataTable dtNew = DatatableHelp.SortDatatable(dbAll);
                //MessageBox.Show(dtNew.Rows.Count.ToString());

                //Split
                ds = DatatableHelp.SplitDataTable(dtNew, 100);
                //MessageBox.Show(ds.Tables.Count.ToString());

                foreach (System.Data.DataTable db in ds.Tables)
                {
                    var distinctRows = (from DataRow dRow in db.Rows
                                        select new { col1 = dRow[db.Columns[0]], col2 = dRow[db.Columns[1]], col3 = dRow[db.Columns[2]] }).Distinct();

                    //MessageBox.Show(distinctRows.Count().ToString());
                    int flag = 0;
                    foreach (var row in distinctRows)
                    {
                        flag++;
                        var value1 = row.col1.ToString();
                        var value2 = row.col2.ToString();
                        var value3 = row.col3.ToString();
                        structDataContext structData = new structDataContext();
                        structData.strList1 = row.col1.ToString();
                        structData.strList2 = row.col2.ToString();
                        structData.strList3 = row.col3.ToString();

                        List<string> lstID = new List<string>();
                        lstID = (from d in db.AsEnumerable()
                                 where d.Field<string>(db.Columns[0]) == value1 && d.Field<string>(db.Columns[1]) == value2 && d.Field<string>(db.Columns[2]) == value3
                                 select d.Field<string>(db.Columns[4])).ToList<string>();

                        structData.strList4 = lstID.Count.ToString();
                        structData.strList5 = AssembleFun(lstID);

                        if (strListStruct.Count > 0 && flag == 1)
                        {
                            int count = strListStruct.Count - 1;
                            if (strListStruct[count].strList1.Equals(structData.strList1) && strListStruct[count].strList2.Equals(structData.strList2) && strListStruct[count].strList3.Equals(structData.strList3))
                            {
                                structData.strList4 = (int.Parse(strListStruct[count].strList4) + int.Parse(structData.strList4)).ToString();
                                structData.strList5 = strListStruct[count].strList5.Substring(0, strListStruct[count].strList5.IndexOf("]")) + structData.strList5.Substring(2);
                                strListStruct.RemoveAt(count);
                            }
                        }
                        strListStruct.Add(structData);
                    }
                }

                string strDefaultPath = strSavePath;
                strSavePath = txtSavePath.Text.ToString();

                string strOutputPath = "";
                strOutputPath = FileHelp.GetSavePath(strSavePath, strDefaultPath);
                if (strOutputPath.Equals(strDefaultPath))
                {
                    //txtSavePath.Text = strDefaultPath;
                    SettxtBox(txtSavePath, strDefaultPath);
                }

                EpplusHelp.SaveDataToExcel(strOutputPath, strListStruct);
            }
            else
            {

            }
        }

        #region 子线程中给Winform控件赋值
        public delegate void Settext(System.Windows.Forms.TextBox txt, string str); //首先声明一个委托
        private void SettxtBox(System.Windows.Forms.TextBox txt, string text)  //写一个方法
        {
            if (txt.InvokeRequired)
            {
                Settext set = new Settext(SettxtBox);
                txt.Invoke(set, new object[] { txt, text });
            }
            else
            {
                txt.Text = text;
            }
        }
        #endregion

        #region test
        public delegate void AppendStringCallback(string text);
        public static event AppendStringCallback appendStringCtrl;
        public delegate void AppendObjectCallback(object[] obj);
        public static event AppendObjectCallback appendObjectCtrl;

        private void AppendString(string text)
        {
            if (this.txtSavePath.InvokeRequired)
            {
                this.txtSavePath.BeginInvoke(new AppendStringCallback(AppendString), new object[] { text });
            }
            else
            {
                //SetMessage(text);
            }
        }

        private void AppendObject(object[] obj)
        {
            //if (this.dgv.InvokeRequired)
            //{
            //    this.dgv.BeginInvoke(new AppendObjectCallback(AppendObject), new object[] { obj });
            //}
            //else
            //{
            //    dgv.Rows.Add(obj);
            //}
        }
        private void testFun()
        {
            Thread objThread = new Thread(new ThreadStart(delegate
            {
                ParseFun();
                appendStringCtrl("sefsef");
            }));
            objThread.Start();
        }
        #endregion
    }
}
